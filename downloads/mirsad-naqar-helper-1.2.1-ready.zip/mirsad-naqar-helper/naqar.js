(() => {
  if (window.__mirsadNaqarHelperLoaded) return;
  window.__mirsadNaqarHelperLoaded = true;

  // ضع رابط تطبيق Google Apps Script المنشور هنا بعد إنشائه.
  const SHARED_ENDPOINT = "https://script.google.com/macros/s/AKfycbznAVdLw5KVYmESB6Dx4av84-UQi3lewoK2Si59UNf_03y9keQf3CNxtXu0KhGbudX7Ng/exec";
  const SHARED_WRITE_TOKEN = "R_aV0QTRykcU9yH1qd_pzR2GBFQdvM0NKNdAIu377Gs";
  let lastSignature = "";
  let timer = null;

  function pushShared(payload) {
    if (!SHARED_ENDPOINT.startsWith("https://script.google.com/")) {
      showToast("مرصاد: احفظت البيانات على هذا الكمبيوتر فقط. أكمل ربط رابط الخدمة لمزامنة الجوال.");
      return;
    }
    // no-cors مقصود: Apps Script يعيد توجيه الطلب، ولا نحتاج قراءة الرد هنا.
    fetch(SHARED_ENDPOINT, {
      method: "POST",
      mode: "no-cors",
      headers: { "Content-Type": "text/plain;charset=utf-8" },
      body: JSON.stringify({ ...payload, token: SHARED_WRITE_TOKEN })
    }).then(() => {
      showToast(`مرصاد: أُرسل طلب مزامنة ${payload.totalLessons} حصة إلى المصدر المشترك.`);
    }).catch(() => {
      showToast("مرصاد: تعذر إرسال التحديث المشترك. البيانات المحلية محفوظة.");
    });
  }

  function scrape(showMessage = true) {
    const buttons = [...document.querySelectorAll("button.aa")];
    if (!buttons.length) return;
    const data = buttons.map((b, i) => {
      const row = b.closest("tr");
      const teacher = (row?.innerText || "").split("\t").map(x => x.trim())
        .find(x => x && !/^[0-9]+$/.test(x) && !/^[√X×]\s/.test(x)) || "معلم غير معروف";
      const cell = b.closest("td");
      const info = b.parentElement;
      const fullText = (info?.innerText || b.innerText || "").trim();
      const title = (fullText.match(/عنوان الدرس:\s*([^\n]+)/) || [])[1] || "";
      const time = (fullText.match(/التوقيت:\s*([^\n]+)/) || [])[1] || "";
      const raw = (b.innerText || "").trim();
      const lesson = raw.replace(/^[√X×]\s*/, "").trim();
      const teams = info?.querySelector('a[href*="teams.microsoft.com"]')?.href ||
        cell?.querySelector('a[href*="teams.microsoft.com"]')?.href || "";
      return { n: i + 1, teacher, cellIndex: cell ? cell.cellIndex : null, lesson, title, time, teams,
        status: /^[X×]/.test(raw) ? "غير مؤكد" : "موجود" };
    }).filter(x => x.teacher && x.lesson);

    const signature = JSON.stringify(data);
    if (signature === lastSignature) return;
    lastSignature = signature;
    const teachers = [...new Set(data.map(x => x.teacher))];
    const payload = { updatedAt: new Date().toISOString(), sourceUrl: location.href,
      totalLessons: data.length, teachers, lessons: data };

    chrome.storage.local.set({ mirsadLatest: payload }, () => {
      if (showMessage) showToast(`مرصاد: تم تحديث ${data.length} حصة لـ ${teachers.length} معلمًا على الكمبيوتر.`);
      pushShared(payload);
    });
  }

  function showToast(msg) {
    let el = document.getElementById("mirsad-naqar-toast");
    if (!el) {
      el = document.createElement("div"); el.id = "mirsad-naqar-toast";
      Object.assign(el.style, { position:"fixed", bottom:"18px", left:"18px", zIndex:999999,
        background:"#0f766e", color:"#fff", padding:"12px 16px", borderRadius:"10px",
        font:"bold 14px Tahoma,Arial", boxShadow:"0 4px 18px #0003", maxWidth:"340px", lineHeight:"1.7" });
      document.body.appendChild(el);
    }
    el.textContent = msg; clearTimeout(el._hideTimer);
    el._hideTimer = setTimeout(() => el.remove(), 6500);
  }

  function addButton() {
    if (!document.body || document.getElementById("mirsad-refresh-btn")) return;
    const btn = document.createElement("button"); btn.id = "mirsad-refresh-btn"; btn.textContent = "تحديث مرصاد من نقار";
    Object.assign(btn.style, { position:"fixed", bottom:"18px", right:"18px", zIndex:999999,
      background:"#155e75", color:"#fff", border:"0", borderRadius:"10px", padding:"12px 16px",
      font:"bold 14px Tahoma,Arial", cursor:"pointer", boxShadow:"0 4px 18px #0003" });
    btn.addEventListener("click", () => { lastSignature = ""; scrape(true); });
    document.body.appendChild(btn);
  }
  function scheduleScrape() { clearTimeout(timer); timer = setTimeout(() => { addButton(); scrape(false); }, 900); }
  addButton(); setTimeout(() => scrape(true), 1200);
  const observer = new MutationObserver(scheduleScrape);
  observer.observe(document.body, { subtree:true, childList:true, characterData:true });
  setInterval(() => { addButton(); scrape(false); }, 15000);
})();
