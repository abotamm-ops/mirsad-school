const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const source=fs.readFileSync(path.join(__dirname,'../probe/popup.js'),'utf8');const nodes=new Map();let downloaded;
const getNode=id=>{if(!nodes.has(id))nodes.set(id,{value:'',textContent:'',hidden:false,events:{},addEventListener(type,fn){this.events[type]=fn}});return nodes.get(id)};
const row={teacher:'اسم المعلم',scheduledTeacher:'اسم المعلم',period:4,status:'unresolved',subject:'المادة',className:'الفصل',detail:'الحصة مؤمّنة: الاجتماع مقفل'};
const ctx=vm.createContext({console,Date,URL,setInterval(){},setTimeout(){},document:{getElementById:getNode},chrome:{runtime:{async sendMessage(m){if(m.type==='MIRSAD_STATUS')return {status:{text:'اختبار'},run:{results:[row]}};return {ok:true,scheduleSettings:{}}}},storage:{local:{async get(){return {}}}},downloads:{async download(data){downloaded=data}}}});
vm.runInContext(source,ctx);
(async()=>{
 await vm.runInContext('refresh()',ctx);assert.match(getNode('status').textContent,/غير محسوم/);
 await getNode('export').events.click();assert.ok(downloaded);
 const csv=decodeURIComponent(downloaded.url.split(',')[1]);assert.match(csv,/غير محسوم/);assert.match(csv,/اسم المعلم/);assert.match(csv,/"4"/);
 console.log('PASS popup and exported CSV show unresolved state with teacher and lesson');
})().catch(e=>{console.error(e);process.exitCode=1});
