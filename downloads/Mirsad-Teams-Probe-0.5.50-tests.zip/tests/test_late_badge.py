from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=b.new_page();page.set_content('<button data-inp="roster-button">أشخاص</button><button>مغادرة</button><div data-tid="participantsInCall-المعلم المسؤول">المعلم المسؤول</div><h2>تمت دعوة الآخرين (2)</h2><div data-tid="participantsFromMeeting-مدعو آخر">مدعو آخر</div>')
 page.evaluate('''()=>{window.calls=[];window.chrome={runtime:{onMessage:{addListener(){}},async sendMessage(m){calls.push(m);if(m.type==='MIRSAD_PAGE_READY')return {active:true,teacher:'اسم الجدول',period:4,scanId:'late-badge'};return {ok:true}}}}}''')
 page.add_script_tag(path=str(ROOT/'probe/schedule-core.js'))
 s=(ROOT/'probe/content.js').read_text().replace('await new Promise(resolve=>setTimeout(resolve,5000));', '''window.waitAt=performance.now();setTimeout(()=>{const badge=document.createElement('span');badge.dataset.tid='ts-roster-organizer-status';badge.textContent='المنظِم';document.querySelector('[data-tid="participantsInCall-المعلم المسؤول"]').append(badge)},500);await new Promise(resolve=>setTimeout(resolve,5000));window.retryAt=performance.now();''')
 page.add_script_tag(content=s);page.wait_for_function("calls.some(m=>m.type==='MIRSAD_SCAN_RESULT')",timeout=25000)
 result=page.evaluate("({calls,gap:retryAt-waitAt})");assert result['gap']>=4900
 scans=[m for m in result['calls'] if m['type']=='MIRSAD_SCAN_RESULT'];assert scans[0]['result']['status']=='present'
 assert not any(m['type']=='MIRSAD_CAPTURE_EVIDENCE' for m in result['calls'])
 print('PASS badge appears during the five-second wait: present on second scan, no screenshot, no page refresh')
 b.close()
