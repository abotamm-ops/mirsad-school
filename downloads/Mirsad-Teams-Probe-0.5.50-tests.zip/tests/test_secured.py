from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
content=(ROOT/'probe/content.js').read_text()
detector=content[content.index('  function securedMeetingReason()'):content.index('  async function attemptJoinIfReady()')]
normalizer="const normalize=s=>(s||'').normalize('NFKC').replace(/[\\u064B-\\u065F\\u0670\\u0640]/g,'').replace(/[أإآ]/g,'ا').replace(/ى/g,'ي').replace(/\\s+/g,' ').trim();"
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=b.new_page()
 for text,expected in [('This meeting is locked',True),('You do not have permission to join',True),('تم تأمين الاجتماع',True),('هذا الاجتماع مؤمّن',True),('waiting in the lobby',True),('بانتظار موافقة المنظّم',True),('Check your internet connection',False),('Sign in to continue',False),('جارٍ تحميل الاجتماع',False),('The meeting has ended',False)]:
  page.set_content('<p></p>')
  page.locator('p').evaluate('(el,text)=>el.textContent=text',text)
  result=page.evaluate(normalizer+'\n'+detector+'\nsecuredMeetingReason()')
  assert bool(result)==expected,(text,result)
 print('PASS 10 access-message cases: restrictions/lobby secured; network/sign-in/loading/ended not guessed')
 page.close()
 for text in ['This meeting is locked','بانتظار موافقة المنظّم']:
  page=b.new_page();page.set_content('<div role="alert">'+text+'</div><button onclick="window.joinClicked=true">Join now</button>')
  page.evaluate('''()=>{window.calls=[];window.chrome={runtime:{onMessage:{addListener(){}},async sendMessage(m){calls.push(m);if(m.type==='MIRSAD_PAGE_READY')return {active:true,teacher:'المعلم',period:4,scanId:'secured-scan'};return {ok:true}}}}}''')
  page.add_script_tag(path=str(ROOT/'probe/schedule-core.js'));page.add_script_tag(content=content)
  page.wait_for_function("calls.some(m=>m.type==='MIRSAD_SCAN_RESULT')",timeout=15000)
  calls=page.evaluate('calls');result=next(m for m in calls if m['type']=='MIRSAD_SCAN_RESULT')
  assert result['result']['status']=='secured' and result['result']['teacher']=='المعلم',result
  assert not any(m['type']=='MIRSAD_CAPTURE_EVIDENCE' for m in calls)
  assert not page.evaluate('!!window.joinClicked')
  print('PASS blocked/lobby auto flow: secured result, no join click, no false absence or diagnostic screenshot')
  page.close()
 b.close()
