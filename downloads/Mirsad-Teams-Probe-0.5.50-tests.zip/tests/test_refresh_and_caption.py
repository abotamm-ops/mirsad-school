from pathlib import Path
from playwright.sync_api import sync_playwright
import base64
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'probe/background.js').read_text()
caption=source[source.index('async function labelEvidenceCapture('):source.index('async function waitForEvidenceDownload(')]
CONTENT=(ROOT/'probe/content.js').read_text()
HTML='<button data-inp="roster-button">أشخاص</button><button>مغادرة</button><div data-tid="participantsInCall-اسم ظاهر">اسم ظاهر</div><h2>تمت دعوة الآخرين (1)</h2><div id="participantsFromMeeting-مدعو آخر">مدعو آخر</div>'
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=b.new_page();page.set_content('<p>Caption test</p>');page.add_script_tag(content=caption)
 for state,label in [('absent','غائب'),('unresolved','غير محسوم')]:
  result=page.evaluate('''async ([state,label])=>{const calls=[];const proto=OffscreenCanvasRenderingContext2D.prototype,original=proto.fillText;proto.fillText=function(...args){calls.push(args[0]);return original.apply(this,args)};try{const src=new OffscreenCanvas(600,80),ctx=src.getContext('2d');ctx.fillStyle='#ff0000';ctx.fillRect(0,0,600,80);const blob=await src.convertToBlob(),data='data:image/png;base64,'+btoa(String.fromCharCode(...new Uint8Array(await blob.arrayBuffer())));const png=await labelEvidenceCapture(data,'اسم المعلم',state,5,2);const bitmap=await createImageBitmap(await(await fetch(png)).blob());const out=new OffscreenCanvas(bitmap.width,bitmap.height);out.getContext('2d').drawImage(bitmap,0,0);const pixel=[...out.getContext('2d').getImageData(20,20,1,1).data];return {png,width:bitmap.width,height:bitmap.height,pixel,calls}}finally{proto.fillText=original}}''',[state,label])
  assert (result['width'],result['height'])==(600,180)
  assert result['pixel']==[255,0,0,255]
  assert 'اسم المعلم — '+label in result['calls']
  out=ROOT/'tests'/('caption-'+state+'.png');out.write_bytes(base64.b64decode(result['png'].split(',')[1]))
  print('PASS actual PNG annotation:',state,'original pixels preserved; name and state caption rendered')
 page.close()
 b.close()
