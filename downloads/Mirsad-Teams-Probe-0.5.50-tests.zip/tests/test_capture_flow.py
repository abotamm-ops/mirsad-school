"""Exercise the real content-script auto flow with a stub Chrome transport.
Chrome's privileged screenshot call is simulated; no real meeting is accessed.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
LIVE_ROW='<div data-cid="roster-participant" data-tid="participantsInCall-حمد بن الفلاحي"><div><span>حمد بن الفلاحي</span></div><div><span data-tid="ts-roster-organizer-status">المنظِم</span></div></div>'
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for expected,body in [
  ('absent','<h2>تمت دعوة الآخرين (1)</h2><div id="participantsFromMeeting-حمد بن الفلاحي">حمد بن الفلاحي<span>المنظِم</span></div>'),
  ('present','<div id="participantsFromMeeting-حمد بن الفلاحي">حمد بن الفلاحي<span>المنظِم</span></div><h2>تمت دعوة الآخرين (28)</h2><div id="participantsFromMeeting-مدعو آخر">مدعو آخر</div>'),
  ('unresolved','<div id="participantsFromMeeting-حمد بن الفلاحي">حمد بن الفلاحي</div><h2>تمت دعوة الآخرين (1)</h2><div id="participantsFromMeeting-مدعو آخر">مدعو آخر</div>')]:
  page=b.new_page()
  if expected!='absent':body=body.replace('<div id="participantsFromMeeting-حمد بن الفلاحي">حمد بن الفلاحي<span>المنظِم</span></div>',LIVE_ROW)
  if expected=='present':body=body.replace('<div id="participantsFromMeeting-مدعو آخر">مدعو آخر</div>','<div data-cid="roster-participant"><div class="fui-TreeItemPersonaLayout__main"><span id="roster-avatar-img-test">مدعو آخر</span></div></div>')
  page.set_content('<button data-inp="roster-button">أشخاص</button><button>مغادرة</button>'+body)
  page.evaluate('''() => {window.calls=[];window.chrome={runtime:{onMessage:{addListener(){}},async sendMessage(m){calls.push(m);if(m.type==='MIRSAD_PAGE_READY')return {active:true,teacher:'اسم الجدول المختلف',period:3,scanId:'fixture-scan'};if(m.type==='MIRSAD_CAPTURE_EVIDENCE')return {ok:true,filename:'fixture-proof.png'};return {ok:true}}}}}''')
  page.add_script_tag(path=str(ROOT/'probe/schedule-core.js'))
  source=(ROOT/'probe/content.js').read_text()
  source=source.replace('const joinState = await attemptJoinIfReady();','const joinState = await attemptJoinIfReady();window.joinReadyAt=performance.now();').replace('result=await automaticScan(target.teacher);','result = await automaticScan(target.teacher);').replace('result = await automaticScan(target.teacher);','window.firstScanAt ??= performance.now();window.scanAttempts=(window.scanAttempts||0)+1;(window.scanTimes??=[]).push(performance.now());result = await automaticScan(target.teacher);')
  page.add_script_tag(content=source)
  page.wait_for_function("calls.some(m=>m.type==='MIRSAD_SCAN_RESULT')",timeout=25000)
  delay=page.evaluate('firstScanAt-joinReadyAt');assert 1900<=delay<3500,delay
  calls=page.evaluate('calls');result=next(m for m in calls if m['type']=='MIRSAD_SCAN_RESULT')
  captures=[m for m in calls if m['type']=='MIRSAD_CAPTURE_EVIDENCE']
  assert result['result']['status']==expected,result
  assert len(captures)==(0 if expected=='present' else 1),(expected,captures)
  if captures:
   assert captures[0]['teacher']==('اسم الجدول المختلف' if expected=='unresolved' else 'حمد بن الفلاحي')
   assert captures[0]['status']==expected
   assert captures[0]['period']==3
   assert captures[0]['scanId']=='fixture-scan'
   assert 'fixture-proof.png' in result['result']['detail']
  assert result['scanId']=='fixture-scan'
  if expected=='unresolved':
   assert page.evaluate('scanAttempts')==2
   gaps=page.evaluate('scanTimes');assert gaps[1]-gaps[0]>=4900,gaps
  print('PASS auto flow:',expected,'capture requests:',len(captures),'teacher:',result['result'].get('teacher'),'pre-scan wait ms:',round(delay))
  page.close()
 b.close()
