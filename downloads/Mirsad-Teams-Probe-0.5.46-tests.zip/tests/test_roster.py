"""Browser regression tests using synthetic DOM fixtures, never production records."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json
ROOT=Path(__file__).resolve().parents[1]
ORIGINAL=Path(__file__).with_name('content-0.5.43-baseline.js')

def row(name,organizer=False,attribute='id'):
    return f'<div {attribute}="participantsFromMeeting-{name}" style="height:30px"><span>{name}</span>'+('<span>المنظِم</span>' if organizer else '')+'</div>'

def fixture(names, organizer='حمد بن الفلاحي', count=None, attribute='id', present_heading=True, organizer_in_invited=False):
    head='<h2>الحضور (1)</h2>' if present_heading else '<h2>مسؤول الاجتماع</h2>'
    top=head+row(organizer,not organizer_in_invited,attribute)
    invitees=''.join(row(n,organizer_in_invited and n==organizer,attribute) for n in names)
    return top+f'<section><h2>تمت دعوة الآخرين ({len(names) if count is None else count})</h2><div>{invitees}</div></section>'

def in_call_fixture(names, count=None, heading=True):
    # Same selectors and parent/child structure as the live HTML supplied by the user.
    html=fixture(names,count=count,present_heading=heading)
    before=row('حمد بن الفلاحي',True)
    actual='''<div id="calling-roster-item-8:orgid:test" data-cid="roster-participant" data-tag="refactored" data-tid="participantsInCall-حمد بن الفلاحي" aria-label="حمد بن الفلاحي, المنظِم, تم إلغاء كتم الصوت" class="fui-TreeItemPersonaLayout"><div class="fui-TreeItemPersonaLayout__main"><div><span title="حمد بن الفلاحي" id="roster-avatar-img-8:orgid:test">حمد بن الفلاحي</span></div></div><div class="fui-TreeItemPersonaLayout__description"><div><div><span data-tid="ts-roster-organizer-status" id="roster-user-message-8:orgid:test">المنظِم</span></div></div></div></div>'''
    return html.replace(before,actual)

def generic_row(name, badge=False, named=True):
    main=f'<div class="fui-TreeItemPersonaLayout__main"><span id="roster-avatar-img-{name}" title="{name}">{name}</span></div>' if named else '<div>لا يمكن قراءة الاسم</div>'
    return '<div data-cid="roster-participant" data-tag="refactored">'+main+('<span data-tid="ts-roster-organizer-status">المنظِم</span>' if badge else '')+'</div>'

def ten_invitees_fixture(incomplete=False, organizer_after=False, unknown_name=False):
    organizer=generic_row('حمد بن الفلاحي',True)
    if not organizer_after:organizer=organizer.replace('data-cid="roster-participant"','data-cid="roster-participant" data-tid="participantsInCall-حمد بن الفلاحي"')
    # One old-style row plus nine generic rows: the exact 1-of-10 failure.
    others=''.join(generic_row('مدعو '+str(i),named=not(unknown_name and i==9)) for i in range(1,10 if not incomplete else 5))
    invitations='<section><h2>تمت دعوة الآخرين (10)</h2>'+row('مدعو معروف')+others+'</section>'
    return (invitations+'<h2>مقدمو الاجتماع (1)</h2>'+organizer) if organizer_after else organizer+invitations

def install(page,html,source):
    page.set_content(html)
    page.evaluate('''() => {window.__mirsadAutoPageHandshake=true;window.__mirsadTeamsProbeLoaded=false;window.scanListener=null;window.chrome={runtime:{onMessage:{addListener(fn){window.scanListener=fn}}}}}''')
    page.add_script_tag(path=str(ROOT/'probe/schedule-core.js'))
    page.add_script_tag(path=str(source))

def scan(page):
    return page.evaluate('''() => new Promise(resolve=>window.scanListener({type:'MIRSAD_AUTO_SCAN',teacher:'اسم جدول مختلف تماما'}, {}, resolve))''')

with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1000,'height':800})
    errors=[];page.on('pageerror',lambda error:errors.append(str(error)))
    names=['مدعو '+str(i) for i in range(1,32)]
    install(page,fixture(names),ORIGINAL)
    old=scan(page);assert old['status']=='unresolved',old
    print('REPRODUCED: 0.5.43 returns unresolved on ID-only Teams rows')
    install(page,in_call_fixture(names),Path(__file__).with_name('content-0.5.44-baseline.js'))
    prior=scan(page);assert prior['status']=='unresolved',prior
    print('REPRODUCED: 0.5.44 misses participantsInCall organizer row from live HTML')
    install(page,ten_invitees_fixture(),Path(__file__).with_name('content-0.5.45-baseline.js'))
    prior=scan(page);assert prior['status']=='unresolved' and '1 اسمًا من 10' in prior['detail'],prior
    print('REPRODUCED: 0.5.45 reads only 1 of 10 refactored invitees')
    cases=[
        ('ten generic invitee rows',ten_invitees_fixture(),'present'),
        ('presenter section is not a presence prerequisite',ten_invitees_fixture(organizer_after=True),'present'),
        ('partial generic invitee rows stay unresolved',ten_invitees_fixture(incomplete=True),'unresolved'),
        ('unreadable invitee name stays unresolved',ten_invitees_fixture(unknown_name=True),'unresolved'),
        ('generic absent organizer', '<h2>تمت دعوة الآخرين (1)</h2>'+generic_row('حمد بن الفلاحي',True),'absent'),
        ('live in-call organizer DOM',in_call_fixture(names),'present'),
        ('live DOM no attendance heading',in_call_fixture(names,heading=False),'present'),
        ('live DOM incomplete invitees',in_call_fixture(names[:3],count=31),'unresolved'),
        ('in-call identity found in invitees',in_call_fixture(['حمد بن الفلاحي']+names),'absent'),
        ('ID-only present',fixture(names),'present'),
        ('data-tid compatibility',fixture(names,attribute='data-tid'),'present'),
        ('attendance not required',fixture(names,present_heading=False),'present'),
        ('absent organizer',fixture(['حمد بن الفلاحي']+names,organizer_in_invited=True),'absent'),
        ('incomplete count',fixture(names[:4],count=31),'unresolved'),
        ('Arabic count',fixture(names,count='٣١'),'present'),
        ('zero invitees',fixture([],count=0),'present'),
        ('missing organizer',fixture(names).replace('المنظِم','مشارك'),'unresolved'),
        ('missing roster','<p>بيانات الاجتماع غير متاحة</p>','unresolved'),
        ('collapsed list',fixture(names).replace('<section>','<section aria-expanded="false">'),'unresolved'),
        ('unrelated next group',fixture(names)+ '<h2>لا توجد استجابة (1)</h2>'+row('حمد بن الفلاحي'),'present'),
        ('ambiguous organizers',fixture(names)+row('منظم آخر',True),'unresolved'),
    ]
    for name,html,expected in cases:
        install(page,html,ROOT/'probe/content.js');result=scan(page)
        assert result['status']==expected,(name,result)
        if expected=='present':assert result['teacher']=='حمد بن الفلاحي'
        if expected=='absent':assert result['evidence']['verified'] is True
        if expected=='unresolved':assert result.get('detail')
        print('PASS',name)
    # A virtualized roster replaces its rows on each existing 140-ms scroll step.
    install(page,'<h2>مسؤول الاجتماع</h2>'+row('حمد بن الفلاحي',True)+'''<section><h2>تمت دعوة الآخرين (31)</h2><div id="viewport" style="height:180px;overflow-y:auto"><div style="height:1240px;position:relative"><div id="window"></div></div></div></section>''',ROOT/'probe/content.js')
    page.evaluate('''() => {const vp=document.querySelector('#viewport'),win=document.querySelector('#window');const render=()=>{let start=Math.floor(vp.scrollTop/40);win.style.position='absolute';win.style.top=(start*40)+'px';win.innerHTML=Array.from({length:Math.min(6,31-start)},(_,j)=>'<div style="height:40px" id="participantsFromMeeting-مدعو '+(start+j)+'">مدعو '+(start+j)+'</div>').join('')};vp.addEventListener('scroll',render);vp.scrollTop=400;render()}''')
    result=scan(page);assert result['status']=='present',result
    print('PASS virtualized roster, starts mid-list, 31 rows across scroll windows')
    assert not errors,errors
    browser.close()
print('PASS 25 regression checks; real Teams account validation remains required')
