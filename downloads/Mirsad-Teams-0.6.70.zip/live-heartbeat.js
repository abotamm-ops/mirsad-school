/* Actual scan progress and next-cycle timing are shared through the writer heartbeat. */
var MirsadLiveSender=(()=>{let busy=false,pending=false,last=0,lastSignature='';async function sync(){if(busy){pending=true;return;}busy=true;try{
 let r=(await chrome.storage.local.get('mirsadAutoRun')).mirsadAutoRun;if(r?.immediateMode)r=r.suspendedRun;
 const running=!!r?.running&&!r.paused&&!r.testMode&&!r.backtestMode,phase=running?(r.current?'scanning':'waiting'):r?.paused?'paused':'stopped',nextCycleAt=running&&r.waitingForCycle2?r.nextCycleAt:null;
 const signature=[phase,r?.period,r?.cycle,r?.current?.scanId,nextCycleAt].join('|');if(lastSignature===signature&&(Date.now()-last<20000||!running))return;
 const reply=await CloudMonitoring.heartbeat({running,phase,period:running?r.period:null,cycle:running?r.cycle:null,totalCycles:typeof scheduleSettings!=='undefined'?scheduleSettings.roundCount:null,nextCycleAt:nextCycleAt||null,nextCycleInMs:nextCycleAt?Math.max(0,nextCycleAt-Date.now()):null,nextCycle:nextCycleAt?r.cycle+1:null,activity:running&&r.current?{teacher:r.current.teacher,teacherId:r.current.teacherId||null,scanId:r.current.scanId}:null});
 if(!reply.heartbeatSaved)throw new Error('حدّث سكربت مرصاد لتفعيل النبض');last=Date.now();lastSignature=signature;
 const day=MirsadMonitorModel.day(),key='mirsadRemoteLinksVersion',saved=(await chrome.storage.local.get(key))[key];
 if(reply.linksVersion&&(!saved||saved.date!==day||saved.version!==reply.linksVersion)&&CloudMonitoring.pullRemoteLinks){await CloudMonitoring.pullRemoteLinks();await chrome.storage.local.set({[key]:{date:day,version:reply.linksVersion}})}
 await chrome.storage.local.set({mirsadLiveHeartbeatStatus:{ok:true,at:last}});
 }catch(e){await chrome.storage.local.set({mirsadLiveHeartbeatStatus:{ok:false,at:Date.now(),error:e.message}})}finally{busy=false;if(pending){pending=false;void sync()}}}
chrome.alarms.onAlarm.addListener(a=>{if(a.name==='mirsadLiveHeartbeat')void sync()});chrome.runtime.onStartup?.addListener(()=>void sync());chrome.runtime.onInstalled?.addListener(()=>void sync());return {sync};})();
