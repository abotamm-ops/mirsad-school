const form = document.querySelector('#school-change');
const feedback = document.querySelector('#result');
const cancel = document.querySelector('#cancel');
let pendingId = null;
let submitted = false;
request('schoolChangeStatus').then(state => {
  if (submitted || !state.pending) return;
  pendingId = state.pending;
  cancel.hidden = false;
}).catch(() => {});


async function request(action, payload) {
  const result = await chrome.runtime.sendMessage({type:'MIRSAD_SCHOOL_CHANGE',action,payload});
  if (!result?.ok) throw Error(result?.error || 'تعذر الاتصال بالإضافة');
  return result;
}

let destination = null;

function diskName(entry) {
  const safeName = entry.name.replace(/[<>:"/\\|?*\u0000-\u001f]/g, '_').trim().slice(0, 120);
  return entry.id + '-' + (safeName || 'ملف');
}

async function writeArchive(id) {
  feedback.textContent = 'جارٍ قراءة قائمة سجلات المدرسة…';
  const archive = await request('schoolChangeExport', {transitionId:id});
  const folder = await destination.getDirectoryHandle('Mirsad-School-'+id, {create:true});
  for (const [index, file] of archive.files.entries()) {
    feedback.textContent = 'حفظ ملف '+(index+1)+' من '+archive.files.length;
    let directory = folder;
    for (const part of file.path) directory = await directory.getDirectoryHandle(diskName(part), {create:true});
    const handle = await directory.getFileHandle(diskName(file), {create:true});
    const writer = await handle.createWritable();
    try {
      for (let start = 0; start < file.size;) {
        const part = await request('schoolChangeExportChunk', {transitionId:id,exportId:archive.exportId,fileId:file.id,start});
        const bytes = Uint8Array.from(atob(part.content), char => char.charCodeAt(0));
        if (!bytes.length || part.next !== start+bytes.length || part.next > file.size) throw Error('جزء من الأرشيف غير مكتمل');
        await writer.write(bytes);
        start = part.next;
      }
      await writer.close();
    } catch (error) {
      await writer.abort().catch(()=>{});
      throw error;
    }
    if ((await handle.getFile()).size !== file.size) throw Error('ملف على الجهاز غير مكتمل');
  }
  const index = await folder.getFileHandle('mirsad-archive-info.json', {create:true});
  const writer = await index.createWritable();
  try{
    await writer.write(JSON.stringify({schoolId:archive.schoolId,files:archive.files},null,2));
    await writer.close();
  }catch(error){
    await writer.abort().catch(()=>{});
    throw error;
  }
  return {saved:true,transitionId:id,exportId:archive.exportId};
}

const changeSchool = MirsadSchoolChange.create({
  prepare: async (input) => {
    const result = await request('schoolChangePrepare', input);
    pendingId = result.committed ? null : result.id;
    return result;
  },
  saveToDisk: ({id}) => writeArchive(id),
  commit: (input) => request('schoolChangeCommit', input),
  resetLocal: (input) => request('schoolChangeReset', input)
});

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  submitted = true;
  const disposition = event.submitter.value;
  const buttons = [...form.querySelectorAll('button')];
  try {
    const url = new URL(form.elements.school.value);
    const school = [...url.searchParams].find(([name]) => name.toLowerCase() === 'schoolid')?.[1];
    if (url.origin !== 'https://schools.madrasati.sa' ||
        url.pathname.toLowerCase() !== '/schoolmanagment/teachers' ||
        !/^[a-f0-9]{32}$/i.test(school)) throw Error('أدخل رابط إدارة بيانات المعلمين للمدرسة الجديدة');
    const confirmed = confirm(disposition === 'disk'
      ? 'تأكيد حفظ السجلات على الجهاز ثم نقل النسخة السحابية إلى المهملات؟'
      : 'تأكيد نقل سجلات المدرسة السابقة إلى مهملات Drive والبدء بمدرسة جديدة؟');
    if (!confirmed) return;
    buttons.forEach(button => { button.disabled = true; });
    cancel.hidden = true;
    if (disposition === 'disk') destination = await window.showDirectoryPicker({mode:'readwrite'});
    feedback.textContent = 'جارٍ تبديل المدرسة…';
    await changeSchool({nextSchoolId:school,disposition,confirmed});
    pendingId = null;
    feedback.textContent = 'تم التبديل. افتح الإضافة لتحميل جدول المدرسة الجديدة.';
  } catch (error) {
    feedback.textContent = error.message;
  } finally {
    destination = null;
    buttons.forEach(button => { button.disabled = false; });
    cancel.hidden = !pendingId;
  }
});

cancel.addEventListener('click', async () => {
  try {
    await request('schoolChangeCancel', {transitionId:pendingId});
    pendingId = null;
    cancel.hidden = true;
    feedback.textContent = 'تم الإلغاء. بقيت سجلات المدرسة الحالية.';
  } catch (error) {
    feedback.textContent = error.message;
  }
});
