const el = id => document.getElementById(id);
async function request(action, payload) {
  const result = await chrome.runtime.sendMessage({type:'MIRSAD_SCHOOL_ACCOUNT',action,payload});
  if (!result?.ok) throw Error(result?.error || 'تعذر الاتصال بالخدمة');
  return result;
}
async function perform(button, task) {
  button.disabled = true;
  el('status').textContent = '';
  try { await task(); }
  catch(error) { el('status').textContent = error.message; }
  finally { button.disabled = false; }
}
el('load').onclick = event => perform(event.currentTarget, async () => {
  const settings = await request('schoolSettingsRead');
  el('title').value = settings.announcement?.title || '';
  el('body').value = settings.announcement?.body || '';
  el('date').textContent = settings.date;
  const list = el('lessons');
  list.replaceChildren();
  for (const lesson of settings.lessons) {
    const item = document.createElement('li');
    item.textContent = lesson.name + ' · الحصة '+lesson.period;
    const url = lesson.calendarUrl && MirsadScheduleCore.normalizeTeamsUrl(lesson.calendarUrl);
    if (url) {
      const link = document.createElement('a');
      link.href = url;
      link.target = '_blank';
      link.rel = 'noopener';
      link.textContent = ' · تقويم تيمز';
      item.append(link);
    }
    list.append(item);
  }
  if (!list.childElementCount) list.textContent = 'حمّل جدول المدرسة لعرض الحصص.';
  el('settings').hidden = false;
});
el('announcement').onsubmit = event => {
  event.preventDefault();
  void perform(event.submitter,async()=>{
    if(!el('body').value.trim()&&!confirm('هل تريد إزالة الإعلان؟'))return;
    await request('schoolAnnouncementSave',{title:el('title').value,body:el('body').value});
    el('status').textContent = 'تم حفظ الإعلان.';
  });
};
