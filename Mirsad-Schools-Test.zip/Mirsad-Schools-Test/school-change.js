/* Runs only after the user confirms a school change. */
(function (root) {
  function create({ prepare, saveToDisk, commit, resetLocal }) {
    let active = null;

    async function change({ nextSchoolId, disposition, confirmed }) {
      if (!confirmed || !/^[a-f0-9]{32}$/i.test(nextSchoolId) ||
          !['disk', 'delete'].includes(disposition)) {
        throw new Error('اختر المدرسة الجديدة وأكّد حفظ سجلات السابقة أو حذفها');
      }
      const transition = await prepare({ nextSchoolId: nextSchoolId.toLowerCase(), disposition, confirmed: true });
      if (!transition?.id) throw new Error('تعذر تجهيز تبديل المدرسة');

      if (!transition.committed) {
        let receipt = null;
        if (disposition === 'disk' && transition.hasPreviousSchool) {
          receipt = await saveToDisk(transition);
          if (receipt?.saved !== true || receipt.transitionId !== transition.id) {
            throw new Error('تعذر تأكيد حفظ السجلات على القرص. بقيت المدرسة الحالية مفتوحة');
          }
        }
        const result = await commit({ transitionId: transition.id, receipt });
        if (result?.committed !== true) throw new Error('لم تكتمل عملية تبديل المدرسة');
      }

      await resetLocal({ transitionId: transition.id, nextSchoolId: nextSchoolId.toLowerCase() });
      return { ok: true, schoolId: nextSchoolId.toLowerCase() };
    }

    return (choice) => {
      if (active) return Promise.reject(new Error('تبديل المدرسة جارٍ'));
      active = change(choice).finally(() => { active = null; });
      return active;
    };
  }

  if (typeof module === 'object' && module.exports) module.exports = { create };
  else root.MirsadSchoolChange = { create };
})(globalThis);
