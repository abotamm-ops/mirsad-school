const el = id => document.getElementById(id);
let account = null;

async function request(action, payload) {
  const result = await chrome.runtime.sendMessage({type:'MIRSAD_SCHOOL_ACCOUNT',action,payload});
  if (!result?.ok) throw Error(result?.error || 'تعذر الاتصال بالخدمة');
  return result;
}

async function load() {
  const server = await request('schoolAccountInfo');
  const saved = await chrome.storage.local.get(['mirsadSchoolAccountLocal','mirsadDriveConfig']);
  const local = saved.mirsadSchoolAccountLocal;
  const config = saved.mirsadDriveConfig;
  el('email').value = server.email || '';
  if (!server.email || local?.email !== server.email || local.url !== config?.url ||
      local.generation !== (config?.schoolGeneration || null)) return;
  account = local;
  el('activate').hidden = true;
  el('account').hidden = false;
  el('account-email').textContent = account.email;
}

async function perform(button, task) {
  button.disabled = true;
  el('message').textContent = '';
  try { await task(); }
  catch (error) { el('message').textContent = error.message; }
  finally { button.disabled = false; }
}

el('send').addEventListener('click', event => {
  if (!el('email').reportValidity()) return;
  void perform(event.currentTarget, async () => {
    await request('schoolAccountCode', {email:el('email').value});
    el('message').textContent = 'أُرسل رمز التفعيل إلى بريد المدرسة.';
    el('code').focus();
  });
});
el('activate').addEventListener('submit', event => {
  event.preventDefault();
  void perform(event.submitter, async () => {
    await request('schoolAccountActivate', {email:el('email').value,code:el('code').value,pin:el('pin').value});
    el('activate').reset();
    await load();
  });
});
el('toggle-pin').addEventListener('click', event => {
  const button = event.currentTarget;
  const show = button.getAttribute('aria-pressed') !== 'true';
  button.setAttribute('aria-pressed', String(show));
  button.textContent = show ? '👁 إخفاء الرقم' : '👁 إظهار الرقم';
  el('account-pin').textContent = show ? account.pin : '••••';
});
el('copy-email').onclick = event => perform(event.currentTarget, () => navigator.clipboard.writeText(account.email));
el('copy-pin').onclick = event => perform(event.currentTarget, () => navigator.clipboard.writeText(account.pin));
el('share').onclick = () => {
  const text = ['مرصاد المدارس', account.url, 'اسم المستخدم: '+account.email, 'الرقم السري: '+account.pin].join('\n');
  void chrome.tabs.create({url:'https://wa.me/?text='+encodeURIComponent(text)});
};
load().catch(error => { el('message').textContent = error.message; });
