document.querySelector('#open-school-site').addEventListener('click', async event=>{
  const button=event.currentTarget;
  const status=document.querySelector('#open-school-site-result');
  button.disabled=true;
  status.textContent='جارٍ فتح الموقع…';
  try{
    const result=await chrome.runtime.sendMessage({type:'MIRSAD_OPEN_SCHOOL_SITE'});
    if(!result?.ok)throw Error(result?.error||'تعذر فتح الموقع');
    status.textContent='';
  }catch(error){
    status.textContent=error.message;
  }finally{
    button.disabled=false;
  }
});
