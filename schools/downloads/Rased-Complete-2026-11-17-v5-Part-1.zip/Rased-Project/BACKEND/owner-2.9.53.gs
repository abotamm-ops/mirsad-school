// Generated: do not edit. Run scripts/build-cloud-backend.py
var MirsadPasswords = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // ../../tmp/mirsad-password-build/password-entry.js
  var password_entry_exports = {};
  __export(password_entry_exports, {
    derive: () => derive
  });

  // ../../tmp/mirsad-password-build/node_modules/@noble/hashes/esm/utils.js
  function isBytes(a) {
    return a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array";
  }
  function anumber(n) {
    if (!Number.isSafeInteger(n) || n < 0)
      throw new Error("positive integer expected, got " + n);
  }
  function abytes(b, ...lengths) {
    if (!isBytes(b))
      throw new Error("Uint8Array expected");
    if (lengths.length > 0 && !lengths.includes(b.length))
      throw new Error("Uint8Array expected of length " + lengths + ", got length=" + b.length);
  }
  function ahash(h) {
    if (typeof h !== "function" || typeof h.create !== "function")
      throw new Error("Hash should be wrapped by utils.createHasher");
    anumber(h.outputLen);
    anumber(h.blockLen);
  }
  function aexists(instance, checkFinished = true) {
    if (instance.destroyed)
      throw new Error("Hash instance has been destroyed");
    if (checkFinished && instance.finished)
      throw new Error("Hash#digest() has already been called");
  }
  function aoutput(out, instance) {
    abytes(out);
    const min = instance.outputLen;
    if (out.length < min) {
      throw new Error("digestInto() expects output buffer of length at least " + min);
    }
  }
  function clean(...arrays) {
    for (let i = 0; i < arrays.length; i++) {
      arrays[i].fill(0);
    }
  }
  function createView(arr) {
    return new DataView(arr.buffer, arr.byteOffset, arr.byteLength);
  }
  function rotr(word, shift) {
    return word << 32 - shift | word >>> shift;
  }
  function utf8ToBytes(str) {
    if (typeof str !== "string")
      throw new Error("string expected");
    return new Uint8Array(new TextEncoder().encode(str));
  }
  function toBytes(data) {
    if (typeof data === "string")
      data = utf8ToBytes(data);
    abytes(data);
    return data;
  }
  function kdfInputToBytes(data) {
    if (typeof data === "string")
      data = utf8ToBytes(data);
    abytes(data);
    return data;
  }
  function checkOpts(defaults, opts) {
    if (opts !== void 0 && {}.toString.call(opts) !== "[object Object]")
      throw new Error("options should be object or undefined");
    const merged = Object.assign(defaults, opts);
    return merged;
  }
  var Hash = class {
  };
  function createHasher(hashCons) {
    const hashC = (msg) => hashCons().update(toBytes(msg)).digest();
    const tmp = hashCons();
    hashC.outputLen = tmp.outputLen;
    hashC.blockLen = tmp.blockLen;
    hashC.create = () => hashCons();
    return hashC;
  }

  // ../../tmp/mirsad-password-build/node_modules/@noble/hashes/esm/hmac.js
  var HMAC = class extends Hash {
    constructor(hash, _key) {
      super();
      this.finished = false;
      this.destroyed = false;
      ahash(hash);
      const key = toBytes(_key);
      this.iHash = hash.create();
      if (typeof this.iHash.update !== "function")
        throw new Error("Expected instance of class which extends utils.Hash");
      this.blockLen = this.iHash.blockLen;
      this.outputLen = this.iHash.outputLen;
      const blockLen = this.blockLen;
      const pad = new Uint8Array(blockLen);
      pad.set(key.length > blockLen ? hash.create().update(key).digest() : key);
      for (let i = 0; i < pad.length; i++)
        pad[i] ^= 54;
      this.iHash.update(pad);
      this.oHash = hash.create();
      for (let i = 0; i < pad.length; i++)
        pad[i] ^= 54 ^ 92;
      this.oHash.update(pad);
      clean(pad);
    }
    update(buf) {
      aexists(this);
      this.iHash.update(buf);
      return this;
    }
    digestInto(out) {
      aexists(this);
      abytes(out, this.outputLen);
      this.finished = true;
      this.iHash.digestInto(out);
      this.oHash.update(out);
      this.oHash.digestInto(out);
      this.destroy();
    }
    digest() {
      const out = new Uint8Array(this.oHash.outputLen);
      this.digestInto(out);
      return out;
    }
    _cloneInto(to) {
      to || (to = Object.create(Object.getPrototypeOf(this), {}));
      const { oHash, iHash, finished, destroyed, blockLen, outputLen } = this;
      to = to;
      to.finished = finished;
      to.destroyed = destroyed;
      to.blockLen = blockLen;
      to.outputLen = outputLen;
      to.oHash = oHash._cloneInto(to.oHash);
      to.iHash = iHash._cloneInto(to.iHash);
      return to;
    }
    clone() {
      return this._cloneInto();
    }
    destroy() {
      this.destroyed = true;
      this.oHash.destroy();
      this.iHash.destroy();
    }
  };
  var hmac = (hash, key, message) => new HMAC(hash, key).update(message).digest();
  hmac.create = (hash, key) => new HMAC(hash, key);

  // ../../tmp/mirsad-password-build/node_modules/@noble/hashes/esm/pbkdf2.js
  function pbkdf2Init(hash, _password, _salt, _opts) {
    ahash(hash);
    const opts = checkOpts({ dkLen: 32, asyncTick: 10 }, _opts);
    const { c, dkLen, asyncTick } = opts;
    anumber(c);
    anumber(dkLen);
    anumber(asyncTick);
    if (c < 1)
      throw new Error("iterations (c) should be >= 1");
    const password = kdfInputToBytes(_password);
    const salt = kdfInputToBytes(_salt);
    const DK = new Uint8Array(dkLen);
    const PRF = hmac.create(hash, password);
    const PRFSalt = PRF._cloneInto().update(salt);
    return { c, dkLen, asyncTick, DK, PRF, PRFSalt };
  }
  function pbkdf2Output(PRF, PRFSalt, DK, prfW, u) {
    PRF.destroy();
    PRFSalt.destroy();
    if (prfW)
      prfW.destroy();
    clean(u);
    return DK;
  }
  function pbkdf2(hash, password, salt, opts) {
    const { c, dkLen, DK, PRF, PRFSalt } = pbkdf2Init(hash, password, salt, opts);
    let prfW;
    const arr = new Uint8Array(4);
    const view = createView(arr);
    const u = new Uint8Array(PRF.outputLen);
    for (let ti = 1, pos = 0; pos < dkLen; ti++, pos += PRF.outputLen) {
      const Ti = DK.subarray(pos, pos + PRF.outputLen);
      view.setInt32(0, ti, false);
      (prfW = PRFSalt._cloneInto(prfW)).update(arr).digestInto(u);
      Ti.set(u.subarray(0, Ti.length));
      for (let ui = 1; ui < c; ui++) {
        PRF._cloneInto(prfW).update(u).digestInto(u);
        for (let i = 0; i < Ti.length; i++)
          Ti[i] ^= u[i];
      }
    }
    return pbkdf2Output(PRF, PRFSalt, DK, prfW, u);
  }

  // ../../tmp/mirsad-password-build/node_modules/@noble/hashes/esm/_md.js
  function setBigUint64(view, byteOffset, value, isLE) {
    if (typeof view.setBigUint64 === "function")
      return view.setBigUint64(byteOffset, value, isLE);
    const _32n = BigInt(32);
    const _u32_max = BigInt(4294967295);
    const wh = Number(value >> _32n & _u32_max);
    const wl = Number(value & _u32_max);
    const h = isLE ? 4 : 0;
    const l = isLE ? 0 : 4;
    view.setUint32(byteOffset + h, wh, isLE);
    view.setUint32(byteOffset + l, wl, isLE);
  }
  function Chi(a, b, c) {
    return a & b ^ ~a & c;
  }
  function Maj(a, b, c) {
    return a & b ^ a & c ^ b & c;
  }
  var HashMD = class extends Hash {
    constructor(blockLen, outputLen, padOffset, isLE) {
      super();
      this.finished = false;
      this.length = 0;
      this.pos = 0;
      this.destroyed = false;
      this.blockLen = blockLen;
      this.outputLen = outputLen;
      this.padOffset = padOffset;
      this.isLE = isLE;
      this.buffer = new Uint8Array(blockLen);
      this.view = createView(this.buffer);
    }
    update(data) {
      aexists(this);
      data = toBytes(data);
      abytes(data);
      const { view, buffer, blockLen } = this;
      const len = data.length;
      for (let pos = 0; pos < len; ) {
        const take = Math.min(blockLen - this.pos, len - pos);
        if (take === blockLen) {
          const dataView = createView(data);
          for (; blockLen <= len - pos; pos += blockLen)
            this.process(dataView, pos);
          continue;
        }
        buffer.set(data.subarray(pos, pos + take), this.pos);
        this.pos += take;
        pos += take;
        if (this.pos === blockLen) {
          this.process(view, 0);
          this.pos = 0;
        }
      }
      this.length += data.length;
      this.roundClean();
      return this;
    }
    digestInto(out) {
      aexists(this);
      aoutput(out, this);
      this.finished = true;
      const { buffer, view, blockLen, isLE } = this;
      let { pos } = this;
      buffer[pos++] = 128;
      clean(this.buffer.subarray(pos));
      if (this.padOffset > blockLen - pos) {
        this.process(view, 0);
        pos = 0;
      }
      for (let i = pos; i < blockLen; i++)
        buffer[i] = 0;
      setBigUint64(view, blockLen - 8, BigInt(this.length * 8), isLE);
      this.process(view, 0);
      const oview = createView(out);
      const len = this.outputLen;
      if (len % 4)
        throw new Error("_sha2: outputLen should be aligned to 32bit");
      const outLen = len / 4;
      const state = this.get();
      if (outLen > state.length)
        throw new Error("_sha2: outputLen bigger than state");
      for (let i = 0; i < outLen; i++)
        oview.setUint32(4 * i, state[i], isLE);
    }
    digest() {
      const { buffer, outputLen } = this;
      this.digestInto(buffer);
      const res = buffer.slice(0, outputLen);
      this.destroy();
      return res;
    }
    _cloneInto(to) {
      to || (to = new this.constructor());
      to.set(...this.get());
      const { blockLen, buffer, length, finished, destroyed, pos } = this;
      to.destroyed = destroyed;
      to.finished = finished;
      to.length = length;
      to.pos = pos;
      if (length % blockLen)
        to.buffer.set(buffer);
      return to;
    }
    clone() {
      return this._cloneInto();
    }
  };
  var SHA256_IV = /* @__PURE__ */ Uint32Array.from([
    1779033703,
    3144134277,
    1013904242,
    2773480762,
    1359893119,
    2600822924,
    528734635,
    1541459225
  ]);

  // ../../tmp/mirsad-password-build/node_modules/@noble/hashes/esm/sha2.js
  var SHA256_K = /* @__PURE__ */ Uint32Array.from([
    1116352408,
    1899447441,
    3049323471,
    3921009573,
    961987163,
    1508970993,
    2453635748,
    2870763221,
    3624381080,
    310598401,
    607225278,
    1426881987,
    1925078388,
    2162078206,
    2614888103,
    3248222580,
    3835390401,
    4022224774,
    264347078,
    604807628,
    770255983,
    1249150122,
    1555081692,
    1996064986,
    2554220882,
    2821834349,
    2952996808,
    3210313671,
    3336571891,
    3584528711,
    113926993,
    338241895,
    666307205,
    773529912,
    1294757372,
    1396182291,
    1695183700,
    1986661051,
    2177026350,
    2456956037,
    2730485921,
    2820302411,
    3259730800,
    3345764771,
    3516065817,
    3600352804,
    4094571909,
    275423344,
    430227734,
    506948616,
    659060556,
    883997877,
    958139571,
    1322822218,
    1537002063,
    1747873779,
    1955562222,
    2024104815,
    2227730452,
    2361852424,
    2428436474,
    2756734187,
    3204031479,
    3329325298
  ]);
  var SHA256_W = /* @__PURE__ */ new Uint32Array(64);
  var SHA256 = class extends HashMD {
    constructor(outputLen = 32) {
      super(64, outputLen, 8, false);
      this.A = SHA256_IV[0] | 0;
      this.B = SHA256_IV[1] | 0;
      this.C = SHA256_IV[2] | 0;
      this.D = SHA256_IV[3] | 0;
      this.E = SHA256_IV[4] | 0;
      this.F = SHA256_IV[5] | 0;
      this.G = SHA256_IV[6] | 0;
      this.H = SHA256_IV[7] | 0;
    }
    get() {
      const { A, B, C, D, E, F, G, H } = this;
      return [A, B, C, D, E, F, G, H];
    }
    // prettier-ignore
    set(A, B, C, D, E, F, G, H) {
      this.A = A | 0;
      this.B = B | 0;
      this.C = C | 0;
      this.D = D | 0;
      this.E = E | 0;
      this.F = F | 0;
      this.G = G | 0;
      this.H = H | 0;
    }
    process(view, offset) {
      for (let i = 0; i < 16; i++, offset += 4)
        SHA256_W[i] = view.getUint32(offset, false);
      for (let i = 16; i < 64; i++) {
        const W15 = SHA256_W[i - 15];
        const W2 = SHA256_W[i - 2];
        const s0 = rotr(W15, 7) ^ rotr(W15, 18) ^ W15 >>> 3;
        const s1 = rotr(W2, 17) ^ rotr(W2, 19) ^ W2 >>> 10;
        SHA256_W[i] = s1 + SHA256_W[i - 7] + s0 + SHA256_W[i - 16] | 0;
      }
      let { A, B, C, D, E, F, G, H } = this;
      for (let i = 0; i < 64; i++) {
        const sigma1 = rotr(E, 6) ^ rotr(E, 11) ^ rotr(E, 25);
        const T1 = H + sigma1 + Chi(E, F, G) + SHA256_K[i] + SHA256_W[i] | 0;
        const sigma0 = rotr(A, 2) ^ rotr(A, 13) ^ rotr(A, 22);
        const T2 = sigma0 + Maj(A, B, C) | 0;
        H = G;
        G = F;
        F = E;
        E = D + T1 | 0;
        D = C;
        C = B;
        B = A;
        A = T1 + T2 | 0;
      }
      A = A + this.A | 0;
      B = B + this.B | 0;
      C = C + this.C | 0;
      D = D + this.D | 0;
      E = E + this.E | 0;
      F = F + this.F | 0;
      G = G + this.G | 0;
      H = H + this.H | 0;
      this.set(A, B, C, D, E, F, G, H);
    }
    roundClean() {
      clean(SHA256_W);
    }
    destroy() {
      this.set(0, 0, 0, 0, 0, 0, 0, 0);
      clean(this.buffer);
    }
  };
  var sha256 = /* @__PURE__ */ createHasher(() => new SHA256());

  // ../../tmp/mirsad-password-build/node_modules/@noble/hashes/esm/sha256.js
  var sha2562 = sha256;

  // ../../tmp/mirsad-password-build/password-entry.js
  var utf8 = (value) => {
    const s = unescape(encodeURIComponent(String(value)));
    return Uint8Array.from(s, (c) => c.charCodeAt(0));
  };
  function derive(password, salt, iterations = 6e5) {
    return Array.from(pbkdf2(sha2562, utf8(password), utf8(salt), { c: iterations, dkLen: 32 }), (n) => n.toString(16).padStart(2, "0")).join("");
  }
  return __toCommonJS(password_entry_exports);
})();
/*! Bundled license information:

@noble/hashes/esm/utils.js:
  (*! noble-hashes - MIT License (c) 2022 Paul Miller (paulmillr.com) *)
*/

/* One school / one recorder. All authorization decisions belong on the server. */
function createSchoolRegistry(a){
 const fail=(message,code='denied')=>{const e=new Error(message);e.code=code;throw e},now=()=>a.now(),token=p=>p+'.'+a.random(),same=(x,y)=>a.equal(String(x||''),String(y||''));
 const load=()=>a.read()||{version:1,schools:[],owners:[],attempts:{}},save=r=>a.write(r),email=v=>{v=String(v||'').trim().toLowerCase();if(v.length>254||!/^\S+@[^\s@]+\.[^\s@]+$/.test(v))fail('أدخل بريد المدرسة الصحيح','validation');return v};
 function registered(s){if(!s.devices)s.devices=s.device?[s.device]:[];return s.devices}
 function chooseDevice(s,key){s.device=registered(s).find(d=>same(d.writerToken,key))||null;return s.device}
 function registerDevice(s,input){const devices=registered(s),old=devices.find(d=>same(d.id,input.deviceId));if(old&&!same(old.secretHash,a.hash(input.deviceSecret)))fail('هوية الجهاز غير صحيحة؛ أعد تفعيل الإضافة','device-proof');s.device=old||{id:input.deviceId,secretHash:a.hash(input.deviceSecret),writerToken:token('w.'+s.id),at:now(),label:String(input.deviceLabel||'جهاز الرصد').slice(0,120)};if(!old)devices.push(s.device);s.device.lastSeen=now()}
 function revokeDevice(s,key){const current=registered(s).find(d=>same(d.writerToken,key));s.devices=registered(s).filter(d=>!same(d.writerToken,key));if(s.monitorLease?.deviceId===current?.id)s.monitorLease=null;s.device=s.devices[0]||null}
 function month(stamp){const d=new Date(stamp+10800000),y=d.getUTCFullYear(),m=d.getUTCMonth()+1,last=new Date(Date.UTC(y,m+1,0)).getUTCDate();return Date.UTC(y,m,Math.min(d.getUTCDate(),last),d.getUTCHours(),d.getUTCMinutes(),d.getUTCSeconds(),d.getUTCMilliseconds())-10800000}
 function attempt(r,key,ok){const t=now(),v=r.attempts[key]||{at:t,count:0};if(t-v.at>=900000){v.at=t;v.count=0}if(v.count>=8)fail('محاولات كثيرة؛ أعد المحاولة بعد ربع ساعة','rate-limit');if(ok)delete r.attempts[key];else{v.count++;r.attempts[key]=v}for(const [k,x]of Object.entries(r.attempts))if(t-x.at>900000)delete r.attempts[k];save(r)}
 function owner(r,key){r.owners=r.owners.filter(x=>x.until>now());if(!r.owners.some(x=>same(x.hash,a.hash(key))))fail('سجّل دخول مالك مرصاد','owner-required')}
 function publicSchool(s){return {id:s.id,email:s.email,accessMode:s.accessMode||"paid",selfRegistered:s.selfRegistered===true,sitePinReady:!!s.websitePin,subscriptionMessage:s.subscriptionMessage||"",messageAt:s.messageAt||null,profile:{...(s._site?.profile||s.campuses?.find(x=>x.id===s.activeSiteId)?.profile||s.profile)},activeSiteId:s.activeSiteId||null,sites:(s.campuses||[]).map(x=>({id:x.id,localId:x.localId,legacy:!!x.legacy,profile:x.profile})),enabled:s.enabled,expiresAt:s.expiresAt,active:s.enabled&&s.expiresAt>now(),deviceRegistered:registered(s).length>0,deviceLimit:null,registeredDeviceCount:registered(s).length,createdAt:s.createdAt,startsAt:s.startsAt||s.createdAt,deletedAt:s.deletedAt||null,passwordReady:!!s.password,emailVerified:s.emailVerified===true,webDeviceCount:Object.keys(s.webDevices||{}).length,extensionDeviceCount:Object.keys(s.extensionDevices||{}).length,activeExtension:s.device?{label:s.device.label||'جهاز الرصد',since:s.device.at,lastSeen:s.device.lastSeen||s.device.at}:null}}
 function resolve(r,key,active=false,billing=false){const match=/^([aw])\.([a-f0-9-]{36})\.[a-f0-9]{64}$/.exec(String(key||''));if(!match)fail('التفعيل غير صالح؛ سجّل دخول المدرسة','invalid-session');const s=r.schools.find(x=>x.id===match[2]);if(!s||s.deletedAt)fail('الحساب غير موجود','invalid-session');const role=match[1]==='w'?'recorder':'admin',hash=a.hash(key);if(role==='recorder'){chooseDevice(s,key);if(!s.device||!same(a.hash(s.device.writerToken),hash))fail('ربط الجهاز غير صالح؛ راجع مالك مرصاد','device-revoked')}else if(!s.sessions.some(x=>x.until>now()&&same(x.hash,hash)))fail('انتهت جلسة المدرسة؛ استخدم رمز التفعيل','invalid-session');if(role==='admin'){var pinSession=s.sessions.find(x=>x.until>now()&&same(x.hash,hash));if(pinSession?.websitePin&&pinSession.pinVersion!==s.websitePin?.version)fail('تم تغيير الرقم السري؛ ادخل مجددًا','invalid-session')}if(role==='admin'){var session=s.sessions.find(x=>x.until>now()&&same(x.hash,hash));if(session?.writerHash&&!registered(s).some(d=>same(session.writerHash,a.hash(d.writerToken))))fail('انتهت جلسة العرض المرتبطة بالإضافة','invalid-session')}if(!billing&&!s.enabled)fail('حساب المدرسة موقوف؛ تواصل مع مرصاد','school-disabled');if(active&&s.expiresAt<=now())fail('انتهى الاشتراك الشهري؛ تواصل مع مرصاد للتجديد','subscription-expired');if(!billing&&role==='admin'&&s.sessions.some(x=>same(x.hash,hash)&&x.billingOnly))fail('افتح صفحة الاشتراك لتفعيل الحساب','subscription-required');return {school:s,role}}
 function issueCode(s){const code=a.random();s.activation={hash:a.hash(code),until:now()+72*3600000};return code}
 function normalizePassword(value){const password=String(value||'');if(password.length<12||password.length>128||!/[A-Za-z]/.test(password)||!/[0-9]/.test(password))fail('كلمة المرور 12 خانة على الأقل، وتتضمن حروفًا وأرقامًا','validation');return password}
 function generatedPassword(){const chars='ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789',raw=a.random();return Array.from({length:14},(_,i)=>chars[parseInt(raw.slice(i*2,i*2+2),16)%chars.length]).join('')+'7a'}
 function setPassword(s,value){const password=normalizePassword(value||generatedPassword()),salt=a.random(),iterations=600000;if(!a.passwordHash)fail('حدّث خدمة حماية كلمات المرور','password-engine');s.password={salt,iterations,hash:a.passwordHash(password,salt,iterations)};s.sessions=[];s.monitorLease=null;s.devices=[];s.device=null;s.activation=null;s.loginCodes=[];s.emailVerified=false;s.extensionEmailCode=null;const verificationCode=a.random();s.emailVerification={hash:a.hash(verificationCode),until:now()+72*3600000};return {password,emailVerificationCode:verificationCode}}
 function webSession(s,input={}){const key=token('a.'+s.id);s.sessions=s.sessions.filter(x=>x.until>now());s.sessions.push({hash:a.hash(key),until:now()+365*86400000,deviceId:input.deviceId||null});track(s,'webDevices',input);return key}
 function track(s,collection,input){if(!/^[a-f0-9-]{36}$/.test(input.deviceId||''))return;const id=a.hash(input.deviceId);s[collection]=s[collection]||{};const previous=s[collection][id];s[collection][id]={label:String(input.deviceLabel||'متصفح').slice(0,120),firstSeen:previous?.firstSeen||now(),lastSeen:now(),logins:(previous?.logins||0)+1}}
 function credentials(input,requireActive){const r=load(),mail=email(input.email);const attemptKey='login:'+a.hash(mail),previous=r.attempts[attemptKey];if(previous&&now()-previous.at<900000&&previous.count>=8)fail('محاولات كثيرة؛ أعد المحاولة بعد ربع ساعة','rate-limit');const s=r.schools.find(x=>!x.deletedAt&&x.email===mail);const candidate=String(input.password||''),record=s?.password||{salt:'mirsad-dummy-account-salt',iterations:600000,hash:'0'.repeat(64)},derived=candidate.length<=128?a.passwordHash(candidate,record.salt,record.iterations):'';const valid=!!s?.password&&same(derived,record.hash);if(!valid){attempt(r,attemptKey,false);fail('الإيميل أو كلمة المرور غير صحيحة','invalid-credentials')}delete r.attempts[attemptKey];save(r);if(!s.enabled)fail('الحساب موقوف؛ تواصل مع مرصاد','school-disabled');if(!s.emailVerified)fail('افتح رسالة مرصاد في بريد المدرسة واضغط تأكيد البريد أولًا','email-unverified');if(requireActive&&s.expiresAt<=now())fail('انتهى الاشتراك؛ تواصل مع مرصاد للتجديد','subscription-expired');return {r,s}}
 function fields(v){const out={};for(const k of ['school','educationAdministration','director']){if(typeof v[k]!=='string'||v[k].trim().length>180||!v[k].trim())fail('أكمل بيانات المدرسة الثلاثة بشكل صحيح','validation');out[k]=v[k].trim()}return out}
 return {
  ownerPortal(key){const r=load();owner(r,key);return {settings:commercialOwnerSettingsPublic_(r),schools:r.schools.map(s=>({...publicSchool(s),usage:commercialUsageSummary_(s,now()),feedback:s.customerFeedback||null})),suggestions:r.schools.flatMap(s=>(s.suggestions||[]).map(x=>({...x,schoolId:s.id,school:s.profile?.school||s.email,email:s.email}))) }},
  ownerSettings(key,input){const r=load();owner(r,key);if(input!==undefined){const accounts=commercialValidateBankAccounts_(input.accounts);r.portalSettings={accounts,updatedAt:now()};save(r)}return {settings:commercialOwnerSettingsPublic_(r)}},
  customerPortal(key){const r=load(),v=resolve(r,key);if(v.role!=='admin')fail('العملية خاصة بإدارة المدرسة','owner-required');return {settings:commercialOwnerSettingsPublic_(r),feedback:v.school.customerFeedback||null,suggestions:(v.school.suggestions||[]).slice(-50)}},
  customerFeedback(key,input){const r=load(),v=resolve(r,key);if(v.role!=='admin')fail('العملية خاصة بإدارة المدرسة','owner-required');const s=v.school,suggestion=String(input.suggestion||'').trim(),comment=String(input.comment||'').trim();if(suggestion.length>4000||comment.length>1000)fail('اختصر الاقتراح إلى 4000 حرف والتعليق إلى 1000 حرف','validation');if(input.rating!==undefined){if(!Number.isInteger(input.rating)||input.rating<1||input.rating>5)fail('اختر تقييمًا من نجمة إلى خمس نجوم','validation')}else if(comment)fail('اختر تقييمًا مع تعليقك','validation');if(input.rating===undefined&&!suggestion)fail('أضف تقييمًا أو اقتراحًا','validation');if(suggestion&&(s.suggestions||[]).length>=100)fail('وصل عدد اقتراحات الحساب إلى 100؛ تواصل مع مالك مرصاد','validation');if(input.rating!==undefined)s.customerFeedback={rating:input.rating,comment,updatedAt:now()};if(suggestion){s.suggestions=s.suggestions||[];s.suggestions.push({id:a.uuid(),text:suggestion,at:now()})}save(r);return {saved:true,feedback:s.customerFeedback||null,suggestions:(s.suggestions||[]).slice(-50)}},
  month,
  ownerLogin(password){const r=load(),ok=same(a.hash(String(password||'')),a.ownerHash());attempt(r,'owner',ok);if(!ok)fail('كلمة مرور المالك غير صحيحة','owner-required');const key=token('o');r.owners=r.owners.filter(x=>x.until>now()).slice(-5);r.owners.push({hash:a.hash(key),until:now()+12*3600000});save(r);return {key}},
  list(key){const r=load();owner(r,key);return {schools:r.schools.map(publicSchool)}},
  create(key,input){const r=load();owner(r,key);if(input.paidConfirmed!==true)fail('أكد استلام الدفع قبل إنشاء الاشتراك','payment-confirmation');const mail=email(input.email);if(r.schools.some(s=>!s.deletedAt&&s.email===mail))fail('البريد مسجل؛ استخدم التجديد','already-exists');const id=a.uuid(),s={id,email:mail,rootId:a.provisionSchool(id),enabled:true,createdAt:now(),expiresAt:month(now()),profile:{school:'',educationAdministration:'',director:''},sessions:[],device:null,viewerToken:token('v.'+id)};const code=issueCode(s),credentials=input.accountLogin?setPassword(s,input.password):null;r.schools.push(s);save(r);return {school:publicSchool(s),activationCode:code,...(credentials||{})}},
  manage(key,input){const r=load();owner(r,key);const s=r.schools.find(s=>s.id===input.schoolId);if(!s)fail('المدرسة غير موجودة');let code,extra={};
   if(input.operation==='renew'){if(input.paidConfirmed!==true)fail('أكد استلام الدفع قبل التجديد','payment-confirmation');s.expiresAt=month(now());s.accessMode='paid';s.enabled=true;code=issueCode(s)}
   else if(input.operation==='activation')code=issueCode(s);
   else if(input.operation==='resetDevice'){s.monitorLease=null;s.devices=[];s.device=null;s.sessions=[];code=issueCode(s)}
   else if(input.operation==='password'){extra=setPassword(s,input.password);delete r.attempts['login:'+a.hash(s.email)];delete r.attempts['verify:'+a.hash(s.email)]}
   else if(input.operation==='logoutExtension'){s.monitorLease=null;s.devices=[];s.device=null}
   else if(input.operation==='delete'){s.deletedAt=now();s.enabled=false;s.monitorLease=null;s.devices=[];s.device=null;s.sessions=[];s.password=null;s.activation=null;s.emailVerification=null}
   else if(input.operation==='enable'||input.operation==='disable')s.enabled=input.operation==='enable';
   else fail('عملية غير صالحة','validation');if(['renew','enable','disable','delete'].includes(input.operation))delete s.bulkAccessBlock;if(input.operation==='renew'){for(const session of s.sessions||[])delete session.billingOnly;s.invoiceUploadBlocked=false;for(const invoice of s.invoices||[])if(invoice.status==='pending'){invoice.status='approved';invoice.reviewedAt=now();invoice.note='تم تأكيد السداد بالتفعيل اليدوي'}}save(r);return {school:publicSchool(s),...(code?{activationCode:code}:{}),...extra}},
  activate(input){const r=load(),mail=email(input.email),s=r.schools.find(s=>!s.deletedAt&&s.email===mail),codeHash=a.hash(String(input.code||'')),ok=!!s&&((!!s.activation&&s.activation.until>now()&&same(s.activation.hash,codeHash))||(s.loginCodes||[]).some(c=>c.until>now()&&same(c.hash,codeHash)));attempt(r,'email:'+a.hash(mail),ok);if(!ok)fail('البريد أو رمز التفعيل غير صحيح، أو انتهت صلاحية الرمز','invalid-activation');if(!s.enabled)fail('الحساب موقوف؛ تواصل مع مرصاد','school-disabled');if(s.password&&!s.emailVerified)fail('أكد بريد المدرسة من رسالة التفعيل أولًا','email-unverified');const key=token('a.'+s.id);s.sessions=s.sessions.filter(x=>x.until>now());s.sessions.push({hash:a.hash(key),until:now()+365*86400000});if(s.activation&&same(s.activation.hash,codeHash))s.activation=null;s.loginCodes=(s.loginCodes||[]).filter(c=>!same(c.hash,codeHash)&&c.until>now());save(r);return {key,school:publicSchool(s)}},
  confirmEmail(input){const r=load(),mail=email(input.email),s=r.schools.find(s=>!s.deletedAt&&s.email===mail),ok=!!s?.emailVerification&&s.emailVerification.until>now()&&same(s.emailVerification.hash,a.hash(String(input.code||'')));attempt(r,'verify:'+a.hash(mail),ok);if(!ok)fail('رابط تأكيد البريد غير صالح أو منتهي','invalid-verification');if(!s.enabled)fail('الحساب موقوف','school-disabled');s.emailVerified=true;s.emailVerification=null;save(r);return {verified:true}},
  websiteLogin(input){const {r,s}=credentials(input,false);if(s.simpleSetup)fail('افتح موقع مرصاد من الإضافة؛ دخولك محفوظ فيها','extension-login-required');const key=webSession(s,input);save(r);return {key,school:publicSchool(s)}},
  websiteLogout(key){const r=load(),v=resolve(r,key);if(v.role!=='admin')fail('جلسة غير صالحة');v.school.sessions=v.school.sessions.filter(x=>!same(x.hash,a.hash(key)));save(r);return {loggedOut:true}},
  websiteActivity(key,input){const r=load(),v=resolve(r,key);if(v.role!=='admin')fail('جلسة غير صالحة');const id=a.hash(String(input.deviceId||''));if(/^[a-f0-9-]{36}$/.test(input.deviceId||'')){v.school.webDevices=v.school.webDevices||{};const previous=v.school.webDevices[id];v.school.webDevices[id]={label:String(input.deviceLabel||previous?.label||'متصفح').slice(0,120),firstSeen:previous?.firstSeen||now(),lastSeen:now(),logins:previous?.logins||1};if(typeof input.active==='boolean')commercialUsageTouch_(v.school,'website',id,input.active,now());save(r)}return {ok:true,settings:commercialOwnerSettingsPublic_(r)}},
  ownerAccessControl(key,input){const r=load();owner(r,key);if(input){if(input.operation==='blockAll'){const message=String(input.message||r.accessControl?.message||'يرجى سداد قيمة الاشتراك: 100 ريال شهريًا لتفعيل الحساب.').trim();if(message.length>1000)fail('اختصر الرسالة إلى ألف حرف','validation');let count=0;for(const s of r.schools){if(s.deletedAt)continue;if(s.enabled){count++;if(!s.bulkAccessBlock)s.bulkAccessBlock={message:s.subscriptionMessage||'',messageAt:s.messageAt||null}}s.enabled=false;s.subscriptionMessage=message;s.messageAt=now()}r.accessControl={...(r.accessControl||{}),registrationOpen:false,message,updatedAt:now(),blockedAt:now(),blockedCount:count};save(r)}else if(input.operation==='restoreAll'){let count=0;for(const s of r.schools){if(s.deletedAt||!s.bulkAccessBlock)continue;s.enabled=true;s.subscriptionMessage=s.bulkAccessBlock.message;s.messageAt=s.bulkAccessBlock.messageAt;delete s.bulkAccessBlock;count++}r.accessControl={...(r.accessControl||{}),updatedAt:now(),restoredAt:now(),restoredCount:count};save(r)}else if(input.operation==='notice'){const message=String(input.message||'').trim();if(!message||message.length>1000)fail('أدخل ملاحظة الاشتراك بما لا يتجاوز ألف حرف','validation');r.accessControl={...(r.accessControl||{}),message,updatedAt:now()};for(const s of r.schools){if(!s.deletedAt&&!s.enabled){s.subscriptionMessage=message;s.messageAt=now()}}save(r)}else if(input.operation==='registration'){if(typeof input.open!=='boolean')fail('حدد حالة التسجيل','validation');r.accessControl={...(r.accessControl||{}),registrationOpen:input.open,updatedAt:now()};save(r)}else fail('عملية غير معروفة','validation')}return {control:{message:r.accessControl?.message||'يرجى سداد قيمة الاشتراك: 100 ريال شهريًا لتفعيل الحساب.',registrationOpen:r.accessControl?.registrationOpen!==false,updatedAt:r.accessControl?.updatedAt||null,blockedAt:r.accessControl?.blockedAt||null,blockedCount:r.accessControl?.blockedCount||0,canRestore:r.schools.some(s=>!s.deletedAt&&s.bulkAccessBlock),restoredCount:r.accessControl?.restoredCount||0}}},
  billingSession(input){const r=load(),v=resolve(r,input.key,false,true);if(v.role==='recorder')this.recorderStatus(input);return {r,s:v.school}},
  billingStatus(input){const {r,s}=this.billingSession(input),billing=commercialBillingPublic_(r);if(billing.enabled){const lower=billing.plans.some(p=>p.amount<(s.billingQuote?.plans||[]).find(x=>x.id===p.id)?.amount);if(!s.billingQuote||s.billingQuote.until<=now()||lower){s.billingQuote={id:a.uuid(),at:now(),until:now()+900000,plans:billing.plans};save(r)}billing.plans=s.billingQuote.plans;billing.quote={id:s.billingQuote.id,until:s.billingQuote.until}}return {school:publicSchool(s),billing,invoices:(s.invoices||[]).slice(-10).map(x=>({id:x.id,plan:x.plan,amount:x.amount,status:x.status,at:x.at,expiresAt:x.expiresAt,note:x.note||''})),uploadBlocked:s.invoiceUploadBlocked===true}},
  ownerCommerce(key,input){const r=load();owner(r,key);let invoiceOffset=0;r.announcements=r.announcements||[];if(input){if(input.operation==='list'){invoiceOffset=Number(input.offset||0);if(!Number.isInteger(invoiceOffset)||invoiceOffset<0||invoiceOffset>1000000)fail('صفحة فواتير غير صحيحة','validation')}else if(input.operation==='publish'){const title=String(input.title||'').trim(),body=String(input.body||'').trim(),days=Number(input.days||7);if(!title||title.length>120||!body||body.length>3000||!Number.isInteger(days)||days<1||days>30)fail('أكمل عنوان الرسالة ونصها ومدة عرضها من يوم إلى 30 يومًا','validation');if(r.announcements.filter(x=>x.enabled&&x.expiresAt>now()).length>=5)fail('أخفِ رسالة قبل نشر أخرى؛ الحد خمس رسائل نشطة','validation');r.announcements=r.announcements.slice(-19);r.announcements.push({id:a.uuid(),title,body,tone:input.tone==='warning'?'warning':'info',at:now(),expiresAt:now()+days*86400000,enabled:true});save(r)}else if(input.operation==='hide'){const item=r.announcements.find(x=>x.id===input.id);if(!item)fail('الرسالة غير موجودة','validation');item.enabled=false;save(r)}else if(input.operation==='billingSettings'){if(typeof input.enabled!=='boolean'||typeof input.offerEnabled!=='boolean')fail('حدد حالة الدفع والعرض','validation');const providerName=String(input.providerName||'').trim(),supportEmail=String(input.supportEmail||'').trim();if(input.enabled&&(!providerName||providerName.length>160||!/^\S+@[^\s@]+\.[^\s@]+$/.test(supportEmail)||input.termsApproved!==true))fail('أكمل اسم مقدّم الخدمة وبريد الدعم وراجع الشروط قبل فتح الدفع','validation');const end=Number(input.offerEndsAt||0);if(input.offerEnabled&&(!Number.isFinite(end)||(end<=now()&&end!==r.billingSettings?.offerEndsAt)||end>now()+366*86400000))fail('حدد نهاية فعلية للعرض خلال سنة بتوقيت السعودية','validation');r.billingSettings={providerName,supportEmail,termsApproved:input.termsApproved===true,enabled:input.enabled,offerEnabled:input.offerEnabled,offerEndsAt:input.offerEnabled?end:0,at:now()};save(r)}else if(input.operation==='review'){const s=r.schools.find(x=>!x.deletedAt&&x.id===input.schoolId),invoice=s?.invoices?.find(x=>x.id===input.id);if(!invoice)fail('الإثبات غير موجود','validation');if(!['approve','reject'].includes(input.decision))fail('اختر اعتمادًا أو رفضًا','validation');if(invoice.status==='pending'){invoice.status=input.decision==='approve'?'approved':'rejected';invoice.reviewedAt=now();invoice.note=String(input.note||'').trim().slice(0,1000);if(input.decision==='approve'){s.enabled=true;s.invoiceUploadBlocked=false;delete s.bulkAccessBlock}if(input.decision==='reject'){s.enabled=false;s.invoiceUploadBlocked=true;delete s.bulkAccessBlock;s.subscriptionMessage=invoice.note||'اتضح في سجلاتنا أنك لم تسدد قيمة الاشتراك. يرجى السداد والتواصل مع الإدارة لإعادة تفعيل حسابك.';s.messageAt=now();if(s.expiresAt===invoice.expiresAt){s.expiresAt=invoice.previousExpiry;s.accessMode=invoice.previousAccessMode}}save(r)}}else fail('عملية غير معروفة','validation')}const allInvoices=r.schools.filter(s=>!s.deletedAt).flatMap(s=>(s.invoices||[]).map(x=>({...x,schoolId:s.id,email:s.email,school:s.profile?.school||s.email}))).sort((x,y)=>Number(y.status==='pending')-Number(x.status==='pending')||y.at-x.at);return {announcements:r.announcements,billing:commercialBillingPublic_(r),invoiceTotal:allInvoices.length,invoiceOffset,invoiceNext:invoiceOffset+100<allInvoices.length?invoiceOffset+100:null,invoices:allInvoices.slice(invoiceOffset,invoiceOffset+100)}},
  invoiceFile(key,input){const r=load();owner(r,key);const s=r.schools.find(x=>!x.deletedAt&&x.id===input.schoolId),v=s?.invoices?.find(x=>x.id===input.id);if(!v)fail('الإثبات غير موجود','validation');return a.readInvoice(v)},
  invoiceUpload(input){const {r,s}=this.billingSession(input);if(!/^[a-f0-9-]{36}$/.test(input.requestId||''))fail('تعذر تعريف الطلب؛ حدّث الصفحة','validation');const previous=(s.invoices||[]).find(x=>x.id===input.requestId);if(previous)return {school:publicSchool(s),invoice:{id:previous.id,status:previous.status},duplicate:true};if(s.invoiceUploadBlocked)fail('راجع إدارة راصد لتأكيد السداد وإعادة تفعيل الحساب؛ لا يمكن رفع إثبات آخر الآن','invoice-blocked');if(!r.billingSettings?.enabled)fail('رفع الفواتير والتفعيل بالدفع غير مفتوح حاليًا','billing-closed');if((s.invoices||[]).some(x=>x.status==='pending'))fail('لديك إثبات بانتظار المراجعة؛ إعادة الرفع لا تمدد الاشتراك','invoice-pending');if((s.invoices||[]).length>=100)fail('راجع الإدارة لمتابعة الاشتراك','invoice-limit');if(input.termsAccepted!==true||input.termsVersion!==COMMERCIAL_BILLING_TERMS_VERSION)fail('اقرأ الشروط ووافق عليها قبل التحويل ورفع الإثبات','terms-required');const quote=s.billingQuote;if(!quote||quote.id!==input.quoteId||quote.until<=now())fail('انتهت مهلة السعر؛ حدّث حالة الاشتراك قبل التحويل','quote-expired');const plan=quote.plans.find(x=>x.id===input.plan);if(!plan)fail('اختر باقة صحيحة','validation');if(Number(input.amount)!==plan.amount)fail('المبلغ لا يطابق سعر الباقة الحالي؛ راجع الباقة قبل التحويل','price-changed');const bank=String(input.bank||'').trim(),shortName=String(input.shortName||'').trim(),account=String(input.account||'').replace(/\s/g,'');if(!bank||bank.length>100||!shortName||shortName.length>100||!/^[A-Za-z0-9]{4,34}$/.test(account))fail('أكمل البنك والاسم المختصر ورقم الحساب','validation');const file=a.validateInvoice(input.file);if(r.schools.some(x=>(x.invoices||[]).some(v=>v.hash===file.hash)))fail('سبق استخدام هذا الملف؛ ارفع إثبات التحويل الجديد','invoice-duplicate');const stored=a.storeInvoice(s.id,input.requestId,file);const start=s.accessMode==='paid'?Math.max(now(),s.expiresAt):now(),end=commercialPlanEnd_(start,plan.id),invoice={id:input.requestId,plan:plan.id,amount:plan.amount,bank,shortName,account,fileId:stored.id,mime:file.mime,name:file.name,hash:file.hash,at:now(),status:'pending',quote:{id:quote.id,at:quote.at,until:quote.until},terms:{version:COMMERCIAL_BILLING_TERMS_VERSION,acceptedAt:now(),email:s.email,providerName:r.billingSettings.providerName,supportEmail:r.billingSettings.supportEmail},previousExpiry:s.expiresAt,previousAccessMode:s.accessMode||'paid',expiresAt:end};s.invoices=s.invoices||[];s.invoices.push(invoice);s.enabled=true;s.accessMode='paid';s.expiresAt=end;delete s.bulkAccessBlock;for(const session of s.sessions||[])delete session.billingOnly;save(r);return {school:publicSchool(s),invoice:{id:invoice.id,status:'pending'},message:'تم تفعيل اشتراكك فورًا، وإثبات السداد بانتظار مراجعة الإدارة.'}},
  billingLogout(input){const {r,s}=this.billingSession(input);if(!/^a\./.test(input.key||''))fail('العملية خاصة بجلسة الموقع','validation');s.sessions=s.sessions.filter(x=>!same(x.hash,a.hash(input.key)));save(r);return {loggedOut:true}},
  spaces(input){const r=load(),v=resolve(r,input.key),s=v.school;if(v.role==='recorder')this.recorderProof(input.key,input);if(!s.campuses){const discovered=a.discoverCampus(s);s.campuses=[];if(discovered.id||discovered.hasData){const id=discovered.id||'legacy';s.campuses.push({id,localId:s.id,legacy:true,profile:{...s.profile},localRootId:s.rootId,createdAt:now(),viewerToken:s.viewerToken});s.activeSiteId=id}delete s.madrasatiBinding;save(r)}for(const site of s.campuses)a.ensureCampus(s,site);save(r);return {sites:s.campuses.map(x=>({id:x.id,localId:x.localId,legacy:!!x.legacy,profile:{...x.profile},createdAt:x.createdAt})),activeSiteId:s.activeSiteId||null,archives:(s.archives||[]).filter(x=>!x.deletedAt).map(x=>({id:x.archiveId,schoolId:x.id,localId:x.localId,profile:x.profile,legacy:!!x.legacy,archivedAt:x.archivedAt,driveUrl:x.remoteRootId?'https://drive.google.com/drive/folders/'+x.remoteRootId:null}))}},
  selectSpace(input){this.recorderProof(input.key,input);this.spaces(input);const r=load(),v=resolve(r,input.key,true),s=v.school,id=String(input.siteId||'').toLowerCase();if(!/^[a-f0-9]{32}$/.test(id))fail('لم يتأكد معرّف المدرسة من صفحة مدرستي','validation');const changing=s.activeSiteId&&s.activeSiteId!==id;if(changing&&s.monitorLease?.until>now())fail('أوقف الرصد الحالي قبل الانتقال إلى مدرسة أخرى','monitor-in-use');if(changing&&(!['archive','delete'].includes(input.switchAction)||input.confirmedSchoolId!==id||input.previousWorkspace!==s.campuses.find(x=>x.id===s.activeSiteId)?.localId))fail('هل أنت متأكد من تغيير المدرسة؟ سيتم حفظ سجلات المدرسة السابقة في الأرشيف وبدء مساحة نظيفة للمدرسة الجديدة','school-switch-confirmation');let site=s.campuses.find(x=>x.id===id);if(changing&&input.switchAction==='delete'&&input.confirmDelete!==true)fail('أكد حذف سجلات المدرسة السابقة','school-delete-confirmation');if(changing){s.archives=s.archives||[];for(const previous of s.campuses)s.archives.push({...previous,archiveId:'archive-'+a.uuid(),archivedAt:now(),deleteRequested:input.switchAction==='delete'&&previous.id===s.activeSiteId});s.campuses=[];site=null}if(!site){site={id,localId:a.uuid(),profile:{school:String(input.name||'').trim().slice(0,160)||'مدرسة '+id.slice(-6),educationAdministration:'',director:''},createdAt:now(),viewerToken:token('v.'+s.id)};a.ensureCampus(s,site);s.campuses.push(site)}else a.ensureCampus(s,site);s.activeSiteId=id;save(r);if(changing&&input.switchAction==='delete'){for(const previous of s.archives.filter(x=>x.deleteRequested)){a.deleteCampus(s,previous);previous.deletedAt=now();delete previous.deleteRequested}save(r)}return {site:{id:site.id,localId:site.localId,legacy:!!site.legacy,profile:{...site.profile}},sites:s.campuses.map(x=>({id:x.id,localId:x.localId,legacy:!!x.legacy,profile:{...x.profile}})),activeSiteId:id,school:publicSchool(s)}},
  monitorSession(input){this.recorderProof(input.key,input);const r=load(),v=resolve(r,input.key,true),s=v.school,id=String(input.siteId||''),run=String(input.runToken||'');if(!/^[a-f0-9]{64}$/.test(run))fail('جلسة رصد غير صالحة','validation');const site=s.campuses?.find(x=>x.id===id);if(!site||s.activeSiteId!==id)fail('حمّل جدول المدرسة المطلوبة قبل الرصد','site-changed');const old=s.monitorLease;
   if(input.operation==='release'){if(old?.runToken===run&&old.siteId===id&&old.deviceId===s.device.id){s.monitorLease=null;save(r)}return {released:true}}
   if(!['begin','renew'].includes(input.operation))fail('عملية رصد غير صالحة','validation');if(old&&old.until>now()&&(old.runToken!==run||old.siteId!==id||old.deviceId!==s.device.id))fail('هذا الإيميل يرصد مدرسة بالفعل؛ أوقفها قبل بدء رصد آخر على أي جهاز','monitor-in-use');if(input.operation==='renew'&&(!old||old.runToken!==run||old.until<=now()))fail('انتهت جلسة الرصد؛ أعد التشغيل','monitor-session-expired');if(input.operation==='begin')a.checkCampusReady(s,site);s.monitorLease={siteId:id,runToken:run,deviceId:s.device.id,startedAt:old?.runToken===run?old.startedAt:now(),until:now()+180000};save(r);return {lease:{siteId:id,runToken:run,until:s.monitorLease.until}}},
  spaceSettings(key,input){const r=load(),v=resolve(r,key,input.profile!==undefined);if(v.role!=='admin')fail('إعدادات المدرسة خاصة بالإدارة');const site=v.school.campuses?.find(x=>x.id===(input.siteId||v.school.activeSiteId));if(!site)fail('اختر المدرسة أولًا','site-required');if(input.profile!==undefined){site.profile=fields(input.profile);save(r)}return {school:{...publicSchool(v.school),profile:{...site.profile},siteId:site.id}}},
  resetUsername(key,input){const r=load();owner(r,key);const s=r.schools.find(x=>!x.deletedAt&&x.id===input.schoolId);if(!s)fail('الحساب غير موجود','validation');s.monitorLease=null;s.devices=[];s.device=null;s.sessions=[];s.monitorLease=null;save(r);return {school:publicSchool(s),reset:true}},
  requestExtensionCode(input){const r=load(),mail=email(input.email);if(r.accessControl?.registrationOpen===false&&!r.schools.some(x=>!x.deletedAt&&x.email===mail))fail('التسجيل الجديد موقوف من إدارة راصد؛ تواصل مع الإدارة','registration-closed');const id='extension-mail:'+a.hash(mail),prior=r.attempts[id]||{at:0,count:0};if(now()-prior.at<60000)fail('انتظر دقيقة قبل إعادة الإرسال','rate-limit');const recent=now()-(prior.windowAt||0)<3600000?prior.count:0;if(recent>=5)fail('وصلت للحد المسموح؛ حاول لاحقًا','rate-limit');r.attempts[id]={at:now(),windowAt:recent?prior.windowAt:now(),count:recent+1};const s=r.schools.find(s=>!s.deletedAt&&s.email===mail);if(s&&!s.enabled){save(r);fail(s.subscriptionMessage||'يرجى تسديد الاشتراك: 100 ريال شهريًا. يُفعّل شهر كامل بعد تأكيد استلام المبلغ.','school-disabled')}const code=String(parseInt(a.random().slice(0,10),16)%100000000).padStart(8,'0'),record={hash:a.hash(code),until:now()+600000,attempts:0};if(s)s.extensionEmailCode=record;else{r.selfSignup=r.selfSignup||{};for(const [k,v]of Object.entries(r.selfSignup))if(v.until<=now())delete r.selfSignup[k];if(Object.keys(r.selfSignup).length>=200)fail('طلبات كثيرة؛ حاول لاحقًا','rate-limit');r.selfSignup[a.hash(mail)]={...record,email:mail}}save(r);return {email:mail,code}},
  extensionCodeLogin(input){const r=load(),mail=email(input.email);if(r.accessControl?.registrationOpen===false&&!r.schools.some(x=>!x.deletedAt&&x.email===mail))fail('التسجيل الجديد موقوف من إدارة راصد؛ تواصل مع الإدارة','registration-closed');let s=r.schools.find(s=>!s.deletedAt&&s.email===mail);const c=s?.extensionEmailCode||r.selfSignup?.[a.hash(mail)];if(!c||c.until<=now()||c.attempts>=8)fail('رمز الدخول غير صالح أو منتهي','invalid-code');c.attempts++;save(r);if(!same(c.hash,a.hash(String(input.password||'').trim())))fail('رمز الدخول غير صحيح','invalid-code');if(s&&!s.enabled)fail(s.subscriptionMessage||'الحساب موقوف؛ يرجى تسديد الاشتراك','school-disabled');if(!/^[a-f0-9-]{36}$/.test(input.deviceId||'')||!/^[a-f0-9]{64}$/.test(input.deviceSecret||''))fail('هوية الإضافة غير صالحة','device-proof');if(!s){const id=a.uuid();s={id,email:mail,rootId:a.provisionSchool(id),enabled:true,createdAt:now(),expiresAt:253402289999000,accessMode:'free',selfRegistered:true,profile:{school:'',educationAdministration:'',director:''},sessions:[],device:null,viewerToken:token('v.'+id)};r.schools.push(s)}s.emailVerified=true;s.simpleSetup=true;s.emailVerification=null;s.extensionEmailCode=null;if(r.selfSignup)delete r.selfSignup[a.hash(mail)];registerDevice(s,input);track(s,'extensionDevices',input);save(r);return {writerKey:s.device.writerToken,school:publicSchool(s)}},
  recorderStatus(input){const r=load(),s=r.schools.find(s=>!s.deletedAt&&chooseDevice(s,input.key));if(!s)fail('الحساب غير موجود أو انتهت الجلسة','invalid-session');if(!same(s.device.id,input.deviceId)||!same(s.device.secretHash,a.hash(String(input.deviceSecret||''))))fail('هوية الجهاز غير صحيحة','device-proof');s.device.lastSeen=now();save(r);return {school:publicSchool(s),accounts:commercialOwnerSettingsPublic_(r).accounts||[],announcements:(r.announcements||[]).filter(x=>x.enabled&&x.expiresAt>now()).map(x=>({id:x.id,title:x.title,body:x.body,tone:x.tone,expiresAt:x.expiresAt}))}},
  recorderSignout(input){this.recorderStatus(input);const r=load(),v=resolve(r,input.key);revokeDevice(v.school,input.key);save(r);return {loggedOut:true}},
  manageAccess(key,input){const r=load();owner(r,key);const s=r.schools.find(s=>s.id===input.schoolId&&!s.deletedAt);if(!s)fail('الحساب غير موجود','validation');if(input.operation==='accessMessage'){const text=String(input.message||'').trim();if(text.length>1000)fail('الرسالة بحد أقصى 1000 حرف','validation');s.subscriptionMessage=text;s.messageAt=now()}else fail('عملية غير صالحة','validation');save(r);return {school:publicSchool(s)}},
  recorderPortal(input){const r=load(),v=resolve(r,input.key,true),s=v.school;if(v.role!=='recorder'||!same(s.device.id,input.deviceId)||!same(s.device.secretHash,a.hash(String(input.deviceSecret||''))))fail('جلسة جهاز الرصد غير صالحة','device-proof');const key=webSession(s,input),entry=s.sessions.find(x=>same(x.hash,a.hash(key)));entry.readOnly=input.purpose!=='controls';entry.writerHash=a.hash(s.device.writerToken);entry.until=now()+86400000;save(r);return {key,readOnly:entry.readOnly,school:publicSchool(s)}},
  setWebsitePin(input){this.recorderStatus(input);const r=load(),v=resolve(r,input.key,false,true),s=v.school,pin=String(input.pin||'');if(v.role!=='recorder'||!/^\d{4}$/.test(pin))fail('أدخل رقمًا سريًا من أربع أرقام','validation');const salt=a.random();s.websitePin={salt,hash:a.pinHash(pin,salt),version:(s.websitePin?.version||0)+1};s.sessions=s.sessions.filter(x=>x.writerHash);delete r.attempts['website-pin:'+a.hash(s.email)];save(r);return {school:publicSchool(s)}},
  websitePinLogin(input){const r=load(),mail=email(input.email),attemptKey='website-pin:'+a.hash(mail),prior=r.attempts[attemptKey];if(prior&&now()-prior.at<900000&&prior.count>=8)fail('محاولات كثيرة؛ أعد المحاولة بعد ربع ساعة','rate-limit');const s=r.schools.find(x=>!x.deletedAt&&x.email===mail),pin=String(input.pin||''),record=s?.websitePin,valid=/^\d{4}$/.test(pin)&&record&&same(a.pinHash(pin,record.salt),record.hash);if(!valid){attempt(r,attemptKey,false);fail('اليوزر أو الرقم السري غير صحيح','invalid-credentials')}if(!s.emailVerified)fail('فعّل الحساب من الإضافة أولًا','email-unverified');if(!/^[a-f0-9-]{36}$/.test(input.deviceId||''))fail('تعذر تعريف المتصفح؛ حدّث الصفحة','device-proof');delete r.attempts[attemptKey];const key=webSession(s,input),entry=s.sessions.find(x=>same(x.hash,a.hash(key)));entry.readOnly=true;entry.billingOnly=!s.enabled||s.expiresAt<=now();entry.websitePin=true;entry.pinVersion=record.version;entry.until=now()+(input.remember===true?365*86400000:12*3600000);save(r);return {key,school:publicSchool(s),remember:input.remember===true}},
  websiteAccess(key){const r=load(),v=resolve(r,key);if(v.role!=='admin')fail('ادخل اليوزر والرقم السري','website-login-required');const entry=v.school.sessions.find(x=>x.until>now()&&same(x.hash,a.hash(key)));if(v.school.simpleSetup&&!entry?.websitePin)fail('ادخل اليوزر والرقم السري للموقع','website-login-required');return {school:publicSchool(v.school)}},
  extensionLogin(input){const {r,s}=credentials(input,true);if(!/^[a-f0-9-]{36}$/.test(input.deviceId||'')||!/^[a-f0-9]{64}$/.test(input.deviceSecret||''))fail('هوية الإضافة غير صالحة','validation');const secretHash=a.hash(input.deviceSecret);registerDevice(s,input);track(s,'extensionDevices',input);save(r);return {writerKey:s.device.writerToken,school:publicSchool(s)}},
  extensionLogout(key,input){const r=load(),v=resolve(r,key);if(v.role!=='recorder'||!same(v.school.device.id,input.deviceId)||!same(v.school.device.secretHash,a.hash(String(input.deviceSecret||''))))fail('طلب ليس من الإضافة المسجلة','device-proof');revokeDevice(v.school,key);save(r);return {loggedOut:true}},
  recorderActivity(key,input={}){const r=load(),v=resolve(r,key);if(v.role!=='recorder')return;v.school.device.lastSeen=now();const id=a.hash(v.school.device.id);v.school.extensionDevices=v.school.extensionDevices||{};const prior=v.school.extensionDevices[id];v.school.extensionDevices[id]={label:v.school.device.label||prior?.label||'جهاز الرصد',firstSeen:prior?.firstSeen||v.school.device.at,lastSeen:now(),logins:prior?.logins||1};commercialUsageTouch_(v.school,'monitor',id,input.running===true&&['scanning','waiting'].includes(input.phase),now());save(r)},
  devices(key,schoolId){const r=load();owner(r,key);const s=r.schools.find(x=>x.id===schoolId);if(!s)fail('الحساب غير موجود');return {school:publicSchool(s),website:Object.values(s.webDevices||{}),extensions:Object.values(s.extensionDevices||{})}},
  authorizeView(key){const m=/^v\.([a-f0-9-]{36})\.[a-f0-9]{64}$/.exec(String(key||'')),s=m&&load().schools.find(s=>s.id===m[1]);if(!s||s.deletedAt||!s.enabled)fail('رابط مشاهدة غير صالح');if(s.campuses){const site=[...s.campuses,...(s.archives||[])].find(x=>!x.deletedAt&&same(x.viewerToken||'',key));if(!site)fail('رابط مشاهدة غير صالح');return {school:s,role:'viewer',siteId:site.archiveId||site.id}}if(!same(s.viewerToken,key))fail('رابط مشاهدة غير صالح');return {school:s,role:'viewer'}},
  loginLink(key){const r=load(),v=resolve(r,key,true);if(v.role!=='admin')fail('العملية خاصة بالإدارة');const code=a.random();v.school.loginCodes=(v.school.loginCodes||[]).filter(c=>c.until>now()).slice(-2);v.school.loginCodes.push({hash:a.hash(code),until:now()+300000});save(r);return {code,email:v.school.email}},
  recorderProof(key,input){const v=resolve(load(),key);if(v.role!=='recorder'||!same(v.school.device.id,input.deviceId)||!same(v.school.device.secretHash,a.hash(String(input.deviceSecret||''))))fail('طلب الرصد ليس من الجهاز المرتبط','device-proof');return true},
  authorize(key,active=false){const {school,role}=resolve(load(),key,active);return {school,role}},
  settings(key,profile){const r=load(),v=resolve(r,key,profile!==undefined);if(v.role!=='admin')fail('إعدادات المدرسة خاصة بالإدارة');if(profile!==undefined){v.school.profile=fields(profile);save(r)}return {school:publicSchool(v.school)}},
  enroll(key,input){const r=load(),v=resolve(r,key,true);if(v.role!=='admin')fail('ربط الجهاز يتطلب دخول المدرسة');if(v.school.password)fail('سجّل الدخول بالإيميل وكلمة المرور من داخل الإضافة','extension-login-required');if(!/^[a-f0-9-]{36}$/.test(input.deviceId||'')||!/^[a-f0-9]{64}$/.test(input.deviceSecret||''))fail('هوية الجهاز غير صالحة','validation');const s=v.school;registerDevice(s,input);save(r);return {writerKey:s.device.writerToken,school:publicSchool(s)}}
 };
}


  function monitorNormalizeTeamsLink_(value) {
    let raw=String(value||'').trim();
    for(let depth=0;depth<5;depth++){
      if(!raw||raw.length>8000||/[\u0000-\u0020\u007f\\]/.test(raw))return '';
      const match=/^https:\/\/(teams\.microsoft\.com|teams\.live\.com)(\/.*)$/i.exec(raw);
      if(!match)return '';
      const origin='https://'+match[1].toLowerCase(),path=match[2];
      if(/^\/(?:l\/meetup-join\/|meet\/)[^/?#]+(?:[/?#].*)?$/.test(path)){
        try{const hashAt=path.indexOf('#'),plain=hashAt<0?path:path.slice(0,hashAt),q=plain.indexOf('?'),pathname=q<0?plain:plain.slice(0,q),query=q<0?'':plain.slice(q+1),canonicalPath=pathname.split('/').map(part=>encodeURIComponent(decodeURIComponent(part))).join('/'),canonicalQuery=query?query.split('&').map(part=>{const i=part.indexOf('='),key=i<0?part:part.slice(0,i),value=i<0?'':part.slice(i+1);return encodeURIComponent(decodeURIComponent(key.replace(/\+/g,' ')))+'='+encodeURIComponent(decodeURIComponent(value.replace(/\+/g,' ')))}).sort().join('&'):'';return origin+canonicalPath+(canonicalQuery?'?'+canonicalQuery:'')+(hashAt<0?'':path.slice(hashAt))}catch{return ''}
      }
      if(path.startsWith('/_#/')){raw=origin+path.slice(3);continue}
      if(!/^\/dl\/launcher\/launcher\.html\?/.test(path))return '';
      const targets=[];
      try{for(const part of path.slice(path.indexOf('?')+1).split('#')[0].split('&')){const at=part.indexOf('=');if(at<0)continue;if(decodeURIComponent(part.slice(0,at))==='url')targets.push(decodeURIComponent(part.slice(at+1).replace(/\+/g,' ')))}}catch{return ''}
      if(targets.length!==1)return '';
      let target=targets[0];
      try{for(let n=0;n<2&&target.startsWith('%');n++)target=decodeURIComponent(target)}catch{return ''}
      if(target.startsWith('/')&&!target.startsWith('//'))raw=origin+target;
      else if(/^https:\/\//i.test(target))raw=target;
      else return '';
    }
    return '';
  }

// Independent Google Apps Script web app. Never merge with timetable/absence services.
var MONITOR_ROOT='';
function configureMonitoringService(){var p=commercialProperties_();if(!p.getProperty('MONITOR_API_KEY'))p.setProperty('MONITOR_API_KEY',Utilities.getUuid()+Utilities.getUuid());if(!p.getProperty('MONITOR_READER_KEY'))p.setProperty('MONITOR_READER_KEY',Utilities.getUuid()+Utilities.getUuid());return 'Set MONITOR_API_KEY and MONITOR_READER_KEY in Script properties. Never paste values into chat.'}
function monitorDateValid_(value){if(!/^\d{4}-\d{2}-\d{2}$/.test(value||''))return false;var stamp=Date.parse(value+'T12:00:00Z');return Number.isFinite(stamp)&&new Date(stamp).toISOString().slice(0,10)===value}
function monitorMadrasatiPayload_(p){
 if(!p||p.source!=='madrasati'||(!monitorDateValid_(p.scheduleDate)||(p.importedForDate||p.scheduleDate)!==monitorToday_())||!Array.isArray(p.teachers)||!p.teachers.length||p.teachers.length>500||p.totalTeachers!==p.teachers.length||!Array.isArray(p.lessons)||p.lessons.length>3500||p.totalLessons!==p.lessons.length)throw new Error('جدول مدرستي ناقص أو تاريخ استيراده غير صالح');
 if(!/^[A-Fa-f0-9]{32}$/.test(p.schoolId||'')||!/^https:\/\/schools\.madrasati\.sa\/SchoolManagment\/Teachers\?/i.test(p.sourceUrl||''))throw new Error('مصدر المدرسة غير صالح');
 var sourceSchool=/[?&]schoolid=([A-Fa-f0-9]{32})(?:&|$)/i.exec(p.sourceUrl);if(!sourceSchool||sourceSchool[1].toLowerCase()!==p.schoolId.toLowerCase())throw new Error('رابط المصدر لا يطابق المدرسة');
 var names={},teachers=p.teachers.map(function(name){var key=monitorName_(name);if(!key||names[key]||String(name).length>180)throw new Error('أسماء المعلمين غير صالحة');names[key]=true;return String(name).trim()}),seen={},lessons=p.lessons.map(function(l,i){var period=Number(l.cellIndex)-1,key=monitorName_(l.teacher)+'|'+period;if(!names[monitorName_(l.teacher)]||!Number.isInteger(period)||period<1||period>7||seen[key]||!String(l.lesson||'').trim()||!String(l.title||'').trim()||!String(l.time||'').trim())throw new Error('بيانات الحصة غير مكتملة أو مكررة');seen[key]=true;var rawTeams=String(l.teams||''),teams=monitorNormalizeTeamsLink_(rawTeams);if(rawTeams&&!teams)throw new Error('رابط تيمز غير صالح');if(!teams&&l.linkState!=='unprepared')throw new Error('تعذر قراءة الرابط لا يعني عدم تحضير الحصة');return {n:i+1,teacher:String(l.teacher),cellIndex:period+1,lesson:String(l.lesson).slice(0,200),title:String(l.title).slice(0,300),time:String(l.time).slice(0,100),teams:teams,status:'موجود',...monitorCalendarFields_(l,teams)}});
 return {source:'madrasati',schoolId:p.schoolId,sourceUrl:p.sourceUrl,updatedAt:new Date().toISOString(),scheduleDate:p.scheduleDate,importedForDate:p.importedForDate||p.scheduleDate,totalLessons:lessons.length,teachers:teachers,lessons:lessons};
}
function monitorToday_(){return Utilities.formatDate(new Date(),'Asia/Riyadh','yyyy-MM-dd')}
function monitorLinkClass_(v){return monitorName_(v).replace(/[\u200b-\u200f\u202a-\u202e\u2060-\u2069]/g,'')}
function monitorName_(v){return String(v||'').normalize('NFKC').replace(/[\u064B-\u065F\u0670\u0640]/g,'').replace(/[أإآ]/g,'ا').replace(/ى/g,'ي').replace(/\s+/g,' ').trim()}
function monitorEqual_(a,b){a=String(a||'');b=String(b||'');var diff=a.length^b.length;for(var i=0;i<Math.max(a.length,b.length);i++)diff|=(a.charCodeAt(i)||0)^(b.charCodeAt(i)||0);return !!a.length&&diff===0}
function monitorPrivate_(folder){if(commercialProperties_().getProperty('MONITOR_PUBLIC_READ')==='true')return folder;var access=folder.getSharingAccess();if(access===commercialSchoolDrive_().Access.ANYONE||access===commercialSchoolDrive_().Access.ANYONE_WITH_LINK)throw new Error('الوصول العام غير مقبول: '+folder.getName()+' — '+String(access)+'. إذا كان الوصول موروثًا من مجلد أب، شغّل createPrivateMonitoringFolder بحساب المالك لتجهيز مجلد خاص مستقل.');return folder}
function monitorFile_(folder,name){var it=folder.getFilesByName(name);return it.hasNext()?it.next():null}

var MONITOR_RESET_EXPERIMENT_='';
// Explicit resets suppress inferred absence until a new conclusive scan arrives.
function monitorRestoreResetProjection_(data){
 if(!data||!data.snapshot||!Array.isArray(data.snapshot.lessons))return data;
 var props=typeof COMMERCIAL_CONTEXT_!=='undefined'&&COMMERCIAL_CONTEXT_&&typeof commercialProperties_==='function'?commercialProperties_():PropertiesService.getScriptProperties(),raw=props.getProperty('MONITOR_PURGED_DAY_'+(MONITOR_RESET_EXPERIMENT_?MONITOR_RESET_EXPERIMENT_+'_':'')+data.snapshot.date),purged=null;
 try{purged=raw?JSON.parse(raw):null}catch(ignore){}
 var audit=data.adjustments||[],sequence=Math.max(0,...audit.map(function(a){return Number(a.sequence)||0}));
 function add(entry){if(audit.some(function(a){return a.id===entry.id}))return;entry.sequence=++sequence;audit.push(entry)}
 if(purged&&Number.isFinite(Number(purged.at))&&Number(data.snapshot.createdAt)>=Number(purged.at)&&!audit.some(function(a){return a.type==='reset'&&Number(a.at)>=Number(purged.at)}))audit.unshift({id:'purged-reset-'+String(purged.requestId),type:'reset',at:Number(purged.at),sequence:0});
 var timing=monitorSchedule_(data.reportSchedule||data.snapshot.scheduleSettings)||{manualStart:'06:30',periodDuration:45,manualGapMinutes:1},m=/^(\d{2}):(\d{2})$/.exec(timing.manualStart||'');
 if(m)(data.rangePurges||[]).forEach(function(range){
  var at=Number(range.at);if(!Number.isFinite(at))return;
  data.snapshot.lessons.forEach(function(l){
   if(audit.some(function(a){return (a.type==='reset'||a.type==='range-reset'&&a.teacherId===l.teacherId&&Number(a.period)===Number(l.period))&&Number(a.at)>=at}))return;
   var records=(data.records||[]).filter(function(r){return r.teacherId===l.teacherId&&Number(r.period)===Number(l.period)});
   if(records.length||audit.some(function(a){return a.type==='override'&&a.teacherId===l.teacherId&&Number(a.period)===Number(l.period)}))return;
   var start=Date.parse(data.snapshot.date+'T00:00:00+03:00')+(Number(m[1])*60+Number(m[2])+(Number(l.period)-1)*(Number(timing.periodDuration)+Number(timing.manualGapMinutes)))*60000,end=start+Number(timing.periodDuration)*60000;
   if(start<Number(range.until)&&end>Number(range.from))add({id:'range-projection-'+range.id+'-'+l.teacherId+'-'+l.period,type:'range-reset',teacherId:l.teacherId,period:Number(l.period),at:at});
  });
 });
 if(audit.length)data.adjustments=audit;return data;
}

function monitorRead_(file,fallback){return file?monitorRestoreResetProjection_(JSON.parse(file.getBlob().getDataAsString())):fallback}
function monitorWrite_(folder,name,data){var text=JSON.stringify(data),file=monitorFile_(folder,name);if(file)file.setContent(text);else file=folder.createFile(name,text,'application/json');return file}
function monitorDay_(root,date,create){if(!/^\d{4}-\d{2}-\d{2}$/.test(date||''))throw new Error('تاريخ غير صالح');var name='توثيق غياب '+date,it=root.getFoldersByName(name),folder=it.hasNext()?it.next():null;if(!folder&&create)folder=root.createFolder(name);if(!folder)throw new Error('لم تبدأ أرشفة هذا اليوم');return monitorPrivate_(folder)}

// Calendar supplements keep the canonical Madrasati lesson and its primary URL intact.
function monitorMeetingKey_(value){var link=monitorNormalizeTeamsLink_(String(value||''));return link?link.split(/[?#]/)[0]:''}
function monitorCalendarFields_(value,primary){
 var raw=value.calendarUrl;if(raw===undefined||raw==='')return {};
 if(typeof raw!=='string')throw new Error('رابط تقويم تيمز غير صالح');var url=monitorNormalizeTeamsLink_(raw);
 if(!url)throw new Error('رابط تقويم تيمز غير صالح');if(monitorMeetingKey_(url)===monitorMeetingKey_(primary))return {};
 var result={calendarUrl:url};if(value.calendarEventId!==undefined){if(typeof value.calendarEventId!=='string'||value.calendarEventId.length>2000||/[\u0000-\u001f]/.test(value.calendarEventId))throw new Error('معرّف موعد تيمز غير صالح');if(value.calendarEventId)result.calendarEventId=value.calendarEventId}return result;
}
function monitorLinkRecordFields_(record){
 var fields={};
 if(record.aggregateScanId!==undefined){
  if(typeof record.aggregateScanId!=='string'||!record.aggregateScanId||record.aggregateScanId.length>200||record.aggregateScanId===record.scanId||['madrasati','calendar'].indexOf(record.meetingSource)<0)throw new Error('ربط صورة الاجتماع غير صالح');
  var scannedUrl=typeof record.scannedUrl==='string'?monitorNormalizeTeamsLink_(record.scannedUrl):'';if(!scannedUrl)throw new Error('رابط الاجتماع المفحوص غير صالح');
  fields.aggregateScanId=record.aggregateScanId;fields.meetingSource=record.meetingSource;fields.scannedUrl=scannedUrl;
 }
 if(record.linkResults!==undefined){
  if(fields.aggregateScanId||!Array.isArray(record.linkResults)||!record.linkResults.length||record.linkResults.length>2)throw new Error('نتائج روابط الاجتماع غير صالحة');var ids={},sources={},meetings={};
  fields.linkResults=record.linkResults.map(function(child){
   if(!child||typeof child.scanId!=='string'||!child.scanId||child.scanId.length>200||child.scanId===record.scanId||ids[child.scanId]||['madrasati','calendar'].indexOf(child.source)<0||sources[child.source]||['present','absent','unresolved','no-link'].indexOf(child.status)<0||!Number.isFinite(child.scannedAt)||child.scannedAt<=0||typeof child.url!=='string'||typeof child.detail!=='string'||child.detail.length>3000)throw new Error('نتيجة رابط اجتماع غير صالحة');
   var url=monitorNormalizeTeamsLink_(child.url),key=monitorMeetingKey_(url);if(!url||meetings[key])throw new Error('رابط نتيجة الاجتماع غير صالح أو مكرر');ids[child.scanId]=true;sources[child.source]=true;meetings[key]=true;
   return {scanId:child.scanId,source:child.source,url:url,status:child.status,detail:child.detail,scannedAt:child.scannedAt};
  });
  fields.status=fields.linkResults.some(function(r){return r.status==='present'})?'present':fields.linkResults.some(function(r){return r.status==='absent'})?'absent':'unresolved';
 }
 return fields;
}
function monitorAddCalendarLinks_(root,folder,data,p,props){
 var snap=data&&data.snapshot,date=p.date;if(date!==monitorToday_()||!snap||snap.sourceType!=='madrasati'||snap.date!==date)throw new Error('إضافة روابط التقويم خاصة بجدول الرصد الحالي');
 if(p.expectedRevision!==(snap.scheduleRevision||'legacy')||!monitorDateValid_(p.sourceDate)||p.sourceDate!==snap.sourceScheduleDate)throw new Error('تاريخ أو إصدار جدول التقويم لا يطابق مدرستي');
 if(!Array.isArray(p.entries)||p.entries.length>3500)throw new Error('قائمة روابط التقويم غير صالحة');
 var groups={},completed=[],skippedEntries=[],candidates=p.entries.map(function(entry,index){
  var teacher=entry&&typeof entry.teacherName==='string'?monitorName_(entry.teacherName):'',period=entry&&entry.period,url=entry&&typeof entry.url==='string'?monitorNormalizeTeamsLink_(entry.url):'',eventId=entry&&entry.eventId;
  var candidate={index:index,teacherName:teacher,period:period,url:url,eventId:eventId,key:teacher+'|'+period};
  if(!teacher||teacher.length>180||!Number.isInteger(period)||period<1||period>7||!url||eventId!==undefined&&(typeof eventId!=='string'||eventId.length>2000||/[\u0000-\u001f]/.test(eventId)))candidate.reason='invalid-entry';
  if(!candidate.reason)(groups[candidate.key]=groups[candidate.key]||[]).push(candidate);return candidate;
 });
 candidates.forEach(function(entry){
  var reason=entry.reason,rows=!reason?snap.lessons.filter(function(l){return monitorName_(l.teacherName)===entry.teacherName&&l.period===entry.period}):[];
  if(!reason&&groups[entry.key].some(function(other){return monitorMeetingKey_(other.url)!==monitorMeetingKey_(entry.url)}))reason='ambiguous-calendar';
  if(!reason&&rows.length!==1)reason=rows.length?'ambiguous-lesson':'lesson-not-found';var row=rows[0];
  if(!reason&&monitorMeetingKey_(row.url)===monitorMeetingKey_(entry.url))reason='same-primary';
  if(!reason&&row.calendarUrl)reason=monitorMeetingKey_(row.calendarUrl)===monitorMeetingKey_(entry.url)?'already-linked':'calendar-link-exists';
  if(reason){skippedEntries.push({index:entry.index,teacherName:entry.teacherName,period:entry.period,reason:reason});return}
  row.calendarUrl=entry.url;if(entry.eventId)row.calendarEventId=entry.eventId;completed.push({teacherId:row.teacherId,teacher:row.teacherName,period:row.period,url:row.calendarUrl,eventId:row.calendarEventId||''});
 });
 if(completed.length){
  data.adjustments=data.adjustments||[];completed.forEach(function(entry){data.adjustments.push({type:'calendar-link-add',teacherId:entry.teacherId,period:entry.period,url:entry.url,eventId:entry.eventId,at:Date.now(),sequence:Math.max(0,...data.adjustments.map(function(a){return a.sequence||0}))+1})});
  snap.linksUpdatedAt=Math.max(Date.now(),(Number(props.getProperty('MONITOR_LINKS_VERSION_'+date))||0)+1);monitorWrite_(folder,'attendance.json',data);props.setProperty('MONITOR_LINKS_VERSION_'+date,String(snap.linksUpdatedAt));
  var source=monitorRead_(monitorFile_(root,'mirsad-timetable-source.json'),null);if(source&&source.payload&&source.payload.importedForDate===date&&source.payload.scheduleDate===p.sourceDate){completed.forEach(function(entry){var matches=(source.payload.lessons||[]).filter(function(l){return monitorName_(l.teacher)===monitorName_(entry.teacher)&&Number(l.cellIndex)-1===entry.period});if(matches.length===1){matches[0].calendarUrl=entry.url;if(entry.eventId)matches[0].calendarEventId=entry.eventId}});source.updatedAt=Date.now();monitorWrite_(root,'mirsad-timetable-source.json',source)}
 }
 return {...monitorDayDTO_(data),saved:true,merged:true,calendarLinksSupported:true,date:date,added:completed.length,skipped:skippedEntries.length,completed:completed,skippedEntries:skippedEntries,folderUrl:folder.getUrl()};
}

function monitorSnapshot_(root,payload,date){
 var registry=monitorRead_(monitorFile_(root,'mirsad-teachers.json'),{}),teachers=[],seen={};
 var names=payload.teachers||[];if(!Array.isArray(names)||!Array.isArray(payload.items)||names.length>500||payload.items.length>3500)throw new Error('جدول غير صالح');
 names=names.concat(payload.items.map(function(x){return x.teacher}));
 names.forEach(function(name){var key=monitorName_(name);if(!key||seen[key])return;seen[key]=true;if(!registry[key])registry[key]={id:'teacher-'+Utilities.getUuid(),name:String(name).trim()};teachers.push(registry[key])});
 if(!teachers.length)throw new Error('جدول المعلمين فارغ');
 var used={},lessons=payload.items.map(function(x){var teacher=registry[monitorName_(x.teacher)],n=Number(x.period);if(!teacher||!Number.isInteger(n)||n<1||n>7)throw new Error('تعذر ربط معلم بحصة');var key=teacher.id+'|'+n;if(used[key])throw new Error('يوجد أكثر من سجل للحصة نفسها؛ راجع ربط أعمدة الجدول');used[key]=true;return {teacherId:teacher.id,teacherName:teacher.name,period:n,subject:String(x.subject||''),className:String(x.className||''),url:String(x.url||''),...monitorCalendarFields_(x,x.url)}});
 var count=Number(payload.roundCount);if(!Number.isInteger(count)||count<1||count>3||!lessons.length)throw new Error('عدد الدورات أو الحصص غير صالح');
 if(payload.preview!==true)monitorWrite_(root,'mirsad-teachers.json',registry);var snapshot={date:date,teachers:teachers,lessons:lessons,roundCount:count,createdAt:Date.now()};if(payload.sourceType==='madrasati'&&monitorDateValid_(payload.sourceScheduleDate)&&payload.sourceImportDate===date){snapshot.sourceType='madrasati';snapshot.sourceScheduleDate=payload.sourceScheduleDate;snapshot.sourceImportDate=payload.sourceImportDate}return snapshot;
}
// Append verified scheduled lessons omitted by older readers; existing lessons and evidence stay intact.
function monitorMergeMissingLessons_(data,items,source){
 if(!Array.isArray(items)||data.snapshot.date!==monitorToday_())return 0;
 var added=[],existing={};data.snapshot.lessons.forEach(function(l){existing[l.teacherId+'|'+l.period]=true});
 items.forEach(function(item){if(!item||typeof item!=='object')return;var teacher=data.snapshot.teachers.find(function(t){return monitorName_(t.name)===monitorName_(item.teacher)}),period=Number(item.period);if(!teacher||!Number.isInteger(period)||period<1||period>7||String(item.url||'').trim()||(!String(item.subject||'').trim()&&!String(item.className||'').trim()))return;var key=teacher.id+'|'+period;if(existing[key])return;existing[key]=true;var lesson={teacherId:teacher.id,teacherName:teacher.name,period:period,subject:String(item.subject||''),className:String(item.className||''),url:''};data.snapshot.lessons.push(lesson);added.push(key)});
 if(added.length){data.snapshot.repairs=data.snapshot.repairs||[];data.snapshot.repairs.push({type:'missing-linkless-lessons',at:Date.now(),source:String(source||''),added:added})}return added.length;
}
// Owner runs once to repair today's omitted linkless lessons from today's published timetable.
function repairMissingMonitoringLessons(){
 var lock=LockService.getScriptLock();lock.waitLock(30000);try{
 var props=commercialProperties_(),root=monitorPrivate_(commercialSchoolDrive_().getFolderById(props.getProperty('MONITOR_PRIVATE_ROOT_ID')||MONITOR_ROOT)),date=monitorToday_(),folder=monitorDay_(root,date,false),data=monitorRead_(monitorFile_(folder,'attendance.json'),null);if(!data)throw new Error('لا يوجد سجل لهذا اليوم');
 var response=UrlFetchApp.fetch('COMMERCIAL_ENDPOINT_NOT_CONFIGURED',{muteHttpExceptions:true});if(response.getResponseCode()!==200)throw new Error('تعذر قراءة جدول اليوم');var envelope=JSON.parse(response.getContentText()),payload=envelope.payload;if(!envelope.ok||!payload||!Array.isArray(payload.lessons)||!payload.updatedAt||Utilities.formatDate(new Date(payload.updatedAt),'Asia/Riyadh','yyyy-MM-dd')!==date)throw new Error('يجب رفع جدول اليوم إلى مرصاد قبل إصلاح سجل اليوم');
 var match=/[?&]dayindex=(\d+)/.exec(payload.sourceUrl||'');if(!match||Number(match[1])!==new Date(date+'T12:00:00+03:00').getUTCDay())throw new Error('يوم جدول نقار لا يطابق يوم الرصد');
 var items=payload.lessons.filter(function(l){return !String(l.teams||l.teamsUrl||'').trim()}).map(function(l){return {teacher:l.teacher,period:Number(l.cellIndex)-1,subject:l.title||l.subject||l.lessonTitle||'حصة',className:l.class||l.lesson||l.className||'',url:''}});var count=monitorMergeMissingLessons_(data,items,payload.updatedAt);if(count)monitorWrite_(folder,'attendance.json',data);console.log('أُضيفت '+count+' حصة مفقودة إلى سجل '+date+' مع حفظ جميع النتائج والصور');return count;
 }finally{lock.releaseLock()}
}
function monitorSchedule_(value){
 if(!value)return null;var m=/^(\d{2}):(\d{2})$/.exec(value.manualStart||''),duration=Number(value.periodDuration),gap=Number(value.manualGapMinutes);
 if(!m||Number(m[1])>23||Number(m[2])>59||!Number.isInteger(duration)||duration<1||duration>180||!Number.isInteger(gap)||gap<0||gap>60)throw new Error('توقيت الرصد غير صالح');
 return {manualStart:value.manualStart,periodDuration:duration,manualGapMinutes:gap};
}
function monitorIsTrial_(value){return !!value&&(value.testMode===true||value.backtestMode===true||value.immediateMode===true||['trial','test','experiment'].indexOf(value.environment||value.mode)>=0)}
function monitorExperimentId_(p){var id=p.experimentId;if(p.environment==='experiment'||id){if(typeof id!=='string'||!/^[a-f0-9-]{36}$/.test(id))throw new Error('معرّف التجربة غير صالح');return id}return ''}
function monitorExperimentRoot_(root,id,create){if(!id)return root;var parents=root.getFoldersByName('تجارب مرصاد'),parent=parents.hasNext()?parents.next():create?root.createFolder('تجارب مرصاد'):null;if(!parent)throw new Error('لم تبدأ هذه التجربة');var folders=parent.getFoldersByName(id),folder=folders.hasNext()?folders.next():create?parent.createFolder(id):null;if(!folder)throw new Error('لم تبدأ هذه التجربة');return folder}
function monitorExperimentReader_(p,props){return ['MONITOR_API_KEY','MONITOR_READER_KEY','MONITOR_SITE_PASSWORD'].some(function(k){var key=props.getProperty(k);return !!key&&monitorEqual_(p.key,key)})}
function monitorTeacherToken_(props){var token=props.getProperty('MONITOR_TEACHER_VIEW_KEY')||'';if(token&&(token.length<32||['MONITOR_API_KEY','MONITOR_READER_KEY','MONITOR_SITE_PASSWORD'].some(function(k){return monitorEqual_(token,props.getProperty(k))})))throw new Error('رمز رابط المعلمين يجب أن يكون مستقلًا عن رموز الإدارة');return token}
function monitorTeacherAccess_(p,props){
 if(props.getProperty('MONITOR_EVIDENCE_PRIVATE')!=='true'&&props.getProperty('MONITOR_ARCHIVE_PRIVATE')!=='true')throw new Error('صفحة المعلمين بانتظار إكمال تهيئتها لدى الإدارة');
 var token=monitorTeacherToken_(props);if(token){if(token.length<32||!monitorEqual_(p.viewToken,token))throw new Error('رابط المشاهدة غير مصرح أو انتهت صلاحيته')}else if(props.getProperty('MONITOR_PUBLIC_READ')!=='true')throw new Error('مشاهدة المعلمين غير مفعّلة');
 var domain=String(props.getProperty('MONITOR_TEACHERS_DOMAIN')||'').trim().toLowerCase();if(domain){var email=String(Session.getActiveUser().getEmail()||'').toLowerCase();if(!email||email.split('@')[1]!==domain)throw new Error('يلزم الدخول بحساب المدرسة للمشاهدة')}
}
function monitorHeartbeat_(props,experimentId,includeActivity,snapshot){var raw=props.getProperty('MONITOR_HEARTBEAT_'+(experimentId||'OFFICIAL'));if(!raw)return null;try{var h=JSON.parse(raw),result={at:Number(h.at)||0,running:h.running===true,phase:String(h.phase||'stopped'),period:Number(h.period)||null,cycle:Number(h.cycle)||null,nextCycleAt:Number(h.nextCycleAt)||null,nextCycle:Number(h.nextCycle)||null,totalCycles:Number(h.totalCycles)||null};if(snapshot&&MONITOR_TEACHER_MODEL_.isExcludedPeriod(snapshot.date,result.period,snapshot)){result.period=null;result.cycle=null;result.nextCycleAt=null;result.nextCycle=null;if(result.running)result.phase='waiting'}if(includeActivity&&h.device&&['active','idle','locked','unknown'].indexOf(h.device.sessionState)>=0)result.device=h.device;if(includeActivity&&h.activity&&result.period)result.activity=h.activity;return result}catch(ignore){return null}}
function monitorTeachersLive_(p){
 var props=commercialProperties_(),experimentId=monitorExperimentId_(p);if(experimentId){var trialToken=props.getProperty('MONITOR_EXPERIMENT_VIEW_'+experimentId);if(!monitorExperimentReader_(p,props)&&!(trialToken&&monitorEqual_(p.viewToken,trialToken)))throw new Error('رابط التجربة غير مصرح')}else monitorTeacherAccess_(p,props);var cache=typeof CacheService!=='undefined'?commercialCache_():null,cacheKey='teachers-live-'+experimentId+'-'+monitorToday_();if(cache)try{var cached=cache.get(cacheKey);if(cached){var stored=JSON.parse(cached);stored.serverTime=Date.now();return stored}}catch(ignore){}var date=monitorToday_(),now=new Date(),root=monitorExperimentRoot_(monitorPrivate_(commercialSchoolDrive_().getFolderById(MONITOR_ROOT)),experimentId,false),folders=root.getFoldersByName('توثيق غياب '+date),folder=folders.hasNext()?folders.next():null,data=folder?monitorRead_(monitorFile_(folder,'attendance.json'),null):null;
 var result={heartbeat:monitorHeartbeat_(props,experimentId),feed:'teachers-live-v1',source:experimentId?'experiment':'official',experimentId:experimentId||undefined,date:date,serverTime:now.getTime(),updatedAt:null,schedule:{manualStart:'06:30',periodDuration:45,manualGapMinutes:1},currentPeriod:null,rows:[],summary:{present:0,partial:0,partialAbsence:0,absent:0,unresolved:0}};
 if(!data||!data.snapshot||data.snapshot.date!==date||monitorIsTrial_(data)||monitorIsTrial_(data.snapshot))return result;result.heartbeat=monitorHeartbeat_(props,experimentId,false,data.snapshot);
 data=JSON.parse(JSON.stringify(data));data.records=(data.records||[]).filter(function(r){return !monitorIsTrial_(r)});Object.keys(data.evidence||{}).forEach(function(id){var proof=data.evidence[id];if(proof.record&&!monitorIsTrial_(proof.record)&&!data.records.some(function(r){return r.scanId===id}))data.records.push(proof.record)});data.adjustments=(data.adjustments||[]).filter(function(a){return !monitorIsTrial_(a)});
 result.schedule=monitorSchedule_(data.reportSchedule||data.snapshot.scheduleSettings)||result.schedule;var active=MONITOR_TEACHER_MODEL_.live(data,{now:now});result.currentPeriod=active.period;
 var cells=MONITOR_TEACHER_MODEL_.cells(data,{now:now});result.rows=cells.map(function(c){var view=MONITOR_TEACHER_MODEL_.presentation(c);return {teacherId:c.teacherId,teacher:c.teacherName,period:c.period,status:['present','partial','partial-absence','absent'].indexOf(view.state)>=0?view.state:'unresolved',finalStatus:['present','partial','partial-absence','absent'].indexOf(c.state)>=0?c.state:'unresolved',provisional:view.provisional,cycle:view.cycle,completed:view.completed,total:view.total,pending:c.state==='pending',lastResultAt:c.override?c.override.at:Math.max(0,...c.history.map(function(r){return Number(r.scannedAt)||0}))||null}});
 var times=result.rows.map(function(r){return r.lastResultAt||0});result.updatedAt=Math.max(0,...times)||null;result.rows.forEach(function(r){if(r.pending)return;var key=r.finalStatus==='partial-absence'?'partialAbsence':r.finalStatus;result.summary[key]++});if(cache)try{cache.put(cacheKey,JSON.stringify(result),2)}catch(ignore){}return result;
}
function monitorScheduleHash_(s){var value=s?{source:s.sourceType||'naqar',sourceDate:s.sourceScheduleDate||'',sourceUpload:!s.sourceScheduleDate&&s.sourceType==='naqar'?s.sourceUploadedAt||'':'',roundCount:s.roundCount,teachers:s.teachers.map(function(t){return monitorName_(t.name)}).sort(),lessons:s.lessons.map(function(l){return [monitorName_(l.teacherName),l.period,String(l.subject||'').trim(),String(l.className||'').trim(),String(l.url||'').trim()].concat(l.calendarUrl?[String(l.calendarUrl).trim()]:[])}).sort(function(a,b){return JSON.stringify(a).localeCompare(JSON.stringify(b))})}:null;return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,JSON.stringify(value),Utilities.Charset.UTF_8).map(function(b){return ('0'+((b+256)%256).toString(16)).slice(-2)}).join('')}
function monitorScheduleFolder_(root,date,create){if(create)return monitorDay_(root,date,true);var it=root.getFoldersByName('توثيق غياب '+date);return it.hasNext()?monitorPrivate_(it.next()):null}
function monitorArchiveFolder_(folder,create){if(!folder)return null;var it=folder.getFoldersByName('جداول سابقة');return it.hasNext()?monitorPrivate_(it.next()):create?monitorPrivate_(folder.createFolder('جداول سابقة')):null}
function monitorScheduleVersions_(folder){var archive=monitorArchiveFolder_(folder,false),versions=[];if(!archive)return versions;var files=archive.getFiles();while(files.hasNext()){var f=files.next(),name=f.getName();if(!/^[a-f0-9-]{36}\.json$/.test(name))continue;var d=monitorRead_(f,null);if(!d?.snapshot)continue;versions.push({id:name.slice(0,-5),at:d.archivedAt,source:d.snapshot.sourceType||'naqar',sourceDate:d.snapshot.sourceScheduleDate||null,lessons:d.snapshot.lessons.length,records:(d.records||[]).length})}return versions.sort(function(a,b){return b.at-a.at})}
function monitorArchivedData_(folder,id){if(!/^[a-f0-9-]{36}$/.test(id||''))throw new Error('نسخة جدول غير صالحة');var archive=monitorArchiveFolder_(folder,false),data=archive?monitorRead_(monitorFile_(archive,id+'.json'),null):null;if(!data)throw new Error('نسخة الجدول غير موجودة');return data}
function monitorChildProof_(image,record,child){
 var proof=image&&image.record,key=monitorMeetingKey_(child.url);return !!proof&&proof.scanId===child.scanId&&proof.aggregateScanId===record.scanId&&proof.teacherId===record.teacherId&&Number(proof.period)===Number(record.period)&&Number(proof.cycle)===Number(record.cycle)&&proof.meetingSource===child.source&&!!key&&monitorMeetingKey_(proof.scannedUrl)===key;
}
function monitorDayDTO_(data){
 var result=JSON.parse(JSON.stringify(data));result.records=result.records||[];var evidence=result.evidence||{};
 Object.keys(evidence).forEach(function(id){var image=evidence[id];if(image.record&&!image.record.aggregateScanId&&!result.records.some(function(r){return r.scanId===id}))result.records.push(image.record)});
 result.records=result.records.filter(function(r){return !r.aggregateScanId});
 result.records.forEach(function(r){r.evidenceUrl=evidence[r.scanId]?.url||null;if(Array.isArray(r.linkResults)){r.linkResults.forEach(function(child){var image=evidence[child.scanId];child.evidenceUrl=monitorChildProof_(image,r,child)?image.url||null:null});if(!r.evidenceUrl&&r.status!=='present'){var proof=r.linkResults.find(function(child){return child.status==='absent'&&child.evidenceUrl})||r.linkResults.find(function(child){return child.evidenceUrl});if(proof)r.evidenceUrl=proof.evidenceUrl}}});delete result.evidence;return result;
}
function monitorApplySchedule_(root,date,folder,data,next,p){
 var sourceHash=monitorScheduleHash_(next),currentHash=monitorScheduleHash_(data?.snapshot),changed=!!data&&sourceHash!==currentHash,key=function(l){return l.teacherId+'|'+l.period},shape=function(l){return JSON.stringify([monitorName_(l.teacherName),l.period,String(l.subject||'').trim(),String(l.className||'').trim(),String(l.url||'').trim()].concat(l.calendarUrl?[String(l.calendarUrl).trim()]:[]))},oldMap={},sameSource=!!data&&data.snapshot.roundCount===next.roundCount&&(data.snapshot.sourceType||'naqar')===next.sourceType&&(data.snapshot.sourceScheduleDate||'')===(next.sourceScheduleDate||'')&&(next.sourceType!=='naqar'||next.sourceScheduleDate||(data.snapshot.sourceUploadedAt||'')===(next.sourceUploadedAt||'')),unchanged={};
 (data?.snapshot?.lessons||[]).forEach(function(l){oldMap[key(l)]=shape(l)});next.lessons.forEach(function(l){if(sameSource&&oldMap[key(l)]===shape(l))unchanged[key(l)]=true});
 var preview={changed:changed,date:date,mode:next.sourceType,sourceHash:sourceHash,currentHash:currentHash,previousLessons:data?.snapshot?.lessons?.length||0,nextLessons:next.lessons.length,previousRoundCount:data?.snapshot?.roundCount||null,nextRoundCount:next.roundCount,previousRecords:(data?.records||[]).length,preservedRecords:(data?.records||[]).filter(function(r){return unchanged[key(r)]}).length};
 if(p.previewOnly===true)return {...preview,prepared:false};
 if(changed)throw new Error('جدول اليوم مقفل لحماية التحضير؛ لا يُستبدل أو يُنقل إلا بعد تصفير اليوم صراحة من إدارة الرصد');
 var previousVersion=null;
 if(!data)data={snapshot:next,records:[],evidence:{}};
 if(!data.snapshot.scheduleRevision)data.snapshot.scheduleRevision=Utilities.getUuid();var timing=monitorSchedule_(p.scheduleSettings);if(timing)data.snapshot.scheduleSettings=timing;
 var registry=monitorRead_(monitorFile_(root,'mirsad-teachers.json'),{});data.snapshot.teachers.forEach(function(t){registry[monitorName_(t.name)]=t});monitorWrite_(root,'mirsad-teachers.json',registry);monitorWrite_(folder,'attendance.json',data);
 return {...preview,prepared:true,snapshot:data.snapshot,folderUrl:folder.getUrl(),previousVersion:previousVersion,preservedRecords:(data.records||[]).length};
}

function monitorSetTrashBatch_(ids,trashed){for(var offset=0;offset<ids.length;offset+=20){var requests=ids.slice(offset,offset+20).map(function(id){return {url:'https://www.googleapis.com/drive/v3/files/'+encodeURIComponent(id),method:'patch',headers:{Authorization:'Bearer '+commercialStorageToken_(id)},contentType:'application/json',payload:JSON.stringify({trashed:trashed}),muteHttpExceptions:true}}),responses=UrlFetchApp.fetchAll(requests);if(responses.some(function(r){return ![200,204].includes(r.getResponseCode())}))throw new Error('تعذر إكمال نقل صور السابق إلى سلة Drive؛ أُلغي الاستبدال')}}

function monitorLoadDirect_(root,p){
 var payload=p.payload;if(!payload||payload.source!=='madrasati')throw new Error('مصدر التحميل غير صالح');
 if(payload.source==='madrasati')payload=monitorMadrasatiPayload_(payload);
 if(!Array.isArray(payload.teachers)||!payload.teachers.length||payload.teachers.length>500||!Array.isArray(payload.lessons)||!payload.lessons.length||payload.lessons.length>3500)throw new Error('جدول المصدر ناقص؛ لم يُطبق في الرصد');
 var source=monitorRead_(monitorFile_(root,'mirsad-timetable-source.json'),{mode:'naqar'});if(payload.source==='madrasati'&&source.schoolId&&source.schoolId.toLowerCase()!==payload.schoolId.toLowerCase())throw new Error('جدول المدرسة لا يطابق المدرسة المرتبطة');
 var date=monitorToday_(),items=payload.lessons.map(function(l){return {teacher:l.teacher,period:Number(l.cellIndex)-1,subject:l.title||l.subject||l.lessonTitle||'حصة',className:l.class||l.lesson||l.className||'',url:l.teams||l.teamsUrl||'',...monitorCalendarFields_(l,l.teams||l.teamsUrl||'')}}),sourceDate=payload.scheduleDate||payload.selectedDate||'',input={preview:true,sourceType:payload.source,sourceImportDate:date,teachers:payload.teachers,items:items,roundCount:p.roundCount,scheduleSettings:p.scheduleSettings};if(monitorDateValid_(sourceDate))input.sourceScheduleDate=sourceDate;
 var allowedTeachers={};payload.teachers.forEach(function(n){allowedTeachers[monitorName_(n)]=true});items.forEach(function(l){if(!allowedTeachers[monitorName_(l.teacher)]||l.url&&!/^https:\/\/(teams\.microsoft\.com|teams\.live\.com)\//.test(l.url))throw new Error('بيانات معلم أو رابط غير صالح؛ لم يُطبق الجدول')});var next=monitorSnapshot_(root,input,date);next.sourceType='madrasati';next.siteId=COMMERCIAL_CONTEXT_?.school?._site?.id||payload.schoolId;next.sourceImportDate=date;next.sourceScheduleDate=sourceDate;next.sourceUploadedAt=String(payload.updatedAt||'').slice(0,60);var folder=monitorScheduleFolder_(root,date,false),data=folder?monitorRead_(monitorFile_(folder,'attendance.json'),null):null;
 var hash=function(v){return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,JSON.stringify(v),Utilities.Charset.UTF_8).map(function(b){return ('0'+((b+256)%256).toString(16)).slice(-2)}).join('')},sourceHash=monitorScheduleHash_(next),currentHash=hash(data),response=function(applied,previousVersion){return {saved:true,monitoringPrepared:true,mode:'madrasati',date:sourceDate,importedForDate:date,teachers:payload.teachers.length,lessons:payload.lessons.length,updatedAt:payload.updatedAt,snapshot:applied,folderUrl:folder.getUrl(),previousVersion:previousVersion||null}};
 if(p.importRequestId&&data?.lastDirectImport?.requestId===p.importRequestId&&data.lastDirectImport.sourceHash===sourceHash)return response(data.snapshot,data.lastDirectImport.previousVersion);
 var preview={needsDecision:!!data,previousLessons:data?.snapshot?.lessons?.length||0,previousRecords:(data?.records||[]).length,previousImages:Object.keys(data?.evidence||{}).length,previousSourceDate:data?.snapshot?.sourceScheduleDate||'',nextLessons:next.lessons.length,sourceDate:sourceDate,date:date,sourceHash:sourceHash,currentHash:currentHash};
 if(p.previewOnly===true||data&&p.confirmed!==true)return {...preview,saved:false};
 if(typeof p.importRequestId!=='string'||!/^[A-Za-z0-9_-]{8,120}$/.test(p.importRequestId))throw new Error('معرّف تحميل الجدول غير صالح');
 if(data&&(typeof p.keepPrevious!=='boolean'||p.sourceHash!==sourceHash||p.currentHash!==currentHash))throw new Error('تغيرت بيانات اليوم منذ المعاينة؛ راجع قرار حفظ السابق مرة أخرى');
 var previousSource=JSON.parse(JSON.stringify(source)),previousVersion=null,archiveFile=null,trashed=[];
 folder=folder||monitorDay_(root,date,true);
 try{
  if(data&&p.keepPrevious){previousVersion=Utilities.getUuid();var archive=monitorArchiveFolder_(folder,true);monitorWrite_(archive,previousVersion+'.json',{...data,archiveId:previousVersion,archivedAt:Date.now()});archiveFile=monitorFile_(archive,previousVersion+'.json')}
  if(data&&!p.keepPrevious){var protectedFiles=monitorArchivedImageRefs_(folder),seenFiles={};Object.keys(data.evidence||{}).forEach(function(id){var fileId=data.evidence[id].fileId;if(!fileId||protectedFiles[fileId]||seenFiles[fileId])return;seenFiles[fileId]=true;trashed.push(fileId)});monitorSetTrashBatch_(trashed,true)}
  next.scheduleRevision=Utilities.getUuid();var timing=monitorSchedule_(p.scheduleSettings);if(timing)next.scheduleSettings=timing;
  var replacement={snapshot:next,records:[],evidence:{},lastDirectImport:{requestId:p.importRequestId,sourceHash:sourceHash,previousVersion:previousVersion,keepPrevious:p.keepPrevious===true,at:Date.now()}};
  monitorWrite_(folder,'attendance.json',replacement);source={...source,mode:'madrasati',payload:payload,updatedAt:Date.now(),schoolId:payload.schoolId};monitorWrite_(root,'mirsad-timetable-source.json',source);
  var registry=monitorRead_(monitorFile_(root,'mirsad-teachers.json'),{});next.teachers.forEach(function(t){registry[monitorName_(t.name)]=t});monitorWrite_(root,'mirsad-teachers.json',registry);
  return response(next,previousVersion);
 }catch(error){if(data)monitorWrite_(folder,'attendance.json',data);else{var failedFile=monitorFile_(folder,'attendance.json');if(failedFile)failedFile.setTrashed(true)}monitorWrite_(root,'mirsad-timetable-source.json',previousSource);monitorSetTrashBatch_(trashed,false);if(archiveFile)archiveFile.setTrashed(true);throw error}

}

// Canonical source, not the browser's cached table, supplies every scheduled lesson.
function monitorPrepareCurrent_(root,p){
 var date=monitorToday_(),source=monitorRead_(monitorFile_(root,'mirsad-timetable-source.json'),{mode:'naqar'});
 if(source.mode!=='madrasati')throw new Error('نقار ملغى؛ حمّل جدول مدرستي مباشرة من الإضافة');if(p.sourceType&&p.sourceType!==source.mode)throw new Error('مصدر الطلب لا يطابق المصدر المحفوظ؛ اختر المصدر الصحيح من الحفظ في الإضافة');

 var stored=source.payload,payload=monitorMadrasatiPayload_({...stored,totalTeachers:stored?.teachers?.length,lessons:(stored?.lessons||[]).map(function(l){return {...l,linkState:l.teams?'linked':'unprepared'}})}),items=payload.lessons.map(function(l){return {teacher:l.teacher,period:Number(l.cellIndex)-1,subject:l.title||'',className:l.lesson||'',url:l.teams||'',...monitorCalendarFields_(l,l.teams||'')}});
 if(!items.length)throw new Error('جدول مدرستي بلا حصص؛ انقل الجدول كاملًا أولًا');
 var folder=monitorScheduleFolder_(root,date,p.previewOnly!==true),data=folder?monitorRead_(monitorFile_(folder,'attendance.json'),null):null,input={preview:true,teachers:payload.teachers,items:items,roundCount:p.roundCount===undefined?(data?.snapshot?.roundCount||3):Number(p.roundCount),sourceType:'madrasati',sourceScheduleDate:payload.scheduleDate,sourceImportDate:date},next=monitorSnapshot_(root,input,date);
 return monitorApplySchedule_(root,date,folder,data,next,p);
}

function monitorSaveRecord_(p,data,folder,props,fileName){
 var record=p.record||{};if(MONITOR_TEACHER_MODEL_.isExcludedPeriod(data.snapshot.date,record.period,data.snapshot))return {saved:false,discarded:true};var lesson=data.snapshot.lessons.find(function(l){return monitorName_(l.teacherName)===monitorName_(record.scheduledTeacher)&&l.period===Number(record.period)});
 if(!lesson||typeof record.scanId!=='string'||record.scanId.length>200||!record.scanId)throw new Error('النتيجة لا تطابق جدول اليوم المحفوظ');
 if(!['present','absent','unresolved','no-link'].includes(record.status)||!Number.isInteger(record.cycle)||record.cycle<1||record.cycle>data.snapshot.roundCount)throw new Error('حالة أو دورة غير صالحة');
 var linkFields=monitorLinkRecordFields_(record),storedRecord={scanId:record.scanId,teacherId:lesson.teacherId,teacherName:lesson.teacherName,observedTeacher:String(record.teacher||''),period:record.period,cycle:record.cycle,status:record.status,detail:String(record.detail||'').slice(0,3000),scannedAt:Number(record.scannedAt)||Date.now(),...linkFields};
 if(p.action==='record'&&storedRecord.aggregateScanId)throw new Error('نتيجة الرابط تحفظ داخل نتيجة الحصة فقط');
 if(p.action==='image'){
  if(!['absent','unresolved'].includes(record.status))throw new Error('لا يرفع النظام صور الحاضر');
  if(data.evidence[record.scanId])return data.evidence[record.scanId];
  if(typeof p.image!=='string'||p.image.length>12000000||!/^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(p.image))throw new Error('صورة PNG غير صالحة');
  var bytes=Utilities.base64Decode(p.image.split(',')[1]),signature=[137,80,78,71,13,10,26,10];if(bytes.length<8||signature.some(function(v,i){return (bytes[i]&255)!==v}))throw new Error('محتوى الصورة غير صالح');
  var safe=function(v){return String(v).replace(/[\\/:*?"<>|\u0000-\u001f]/g,'_').slice(0,100)};
  var name=safe(record.teacher||lesson.teacherName)+'_ح'+record.period+'_د'+record.cycle+'_'+(record.status==='absent'?'غائب':'غير محسوم')+'_'+safe(record.scanId)+'.png';
  if(record.localName){if(typeof record.localName!=='string'||record.localName.length>220||/[\\/:*?"<>|\u0000-\u001f]/.test(record.localName)||!record.localName.endsWith('.png'))throw new Error('اسم ملف غير صالح');name=record.localName;}
  var image=monitorFile_(folder,name)||folder.createFile(Utilities.newBlob(bytes,'image/png',name));
  if(props.getProperty('MONITOR_IMAGE_LINKS_PUBLIC')==='true')image.setSharing(commercialSchoolDrive_().Access.ANYONE_WITH_LINK,commercialSchoolDrive_().Permission.VIEW);else image.setSharing(commercialSchoolDrive_().Access.PRIVATE,commercialSchoolDrive_().Permission.NONE);
  var evidence={fileId:image.getId(),url:image.getUrl(),name:name,record:storedRecord};data.evidence[record.scanId]=evidence;monitorWrite_(folder,fileName,data);return evidence;
 }
 if(p.action==='record'){
  if(!data.records.some(function(r){return r.scanId===record.scanId}))data.records.push(storedRecord);
  monitorWrite_(folder,fileName,data);return {saved:true};
 }
 throw new Error('طلب غير مدعوم');
}
function monitorArchiveLate_(folder,p,props){var versions=monitorScheduleVersions_(folder),revision=p.record?.scheduleRevision||'legacy';for(var v of versions){var old=monitorArchivedData_(folder,v.id);if((old.snapshot.scheduleRevision||'legacy')!==revision)continue;if((old.rangePurges||[]).some(function(range){var at=Number(p.record?.scannedAt),cutoff=Number.isFinite(Number(range.at))?Number(range.at):range.until-1;return at>=range.from&&at<range.until&&at<=cutoff}))return {discarded:true,reason:'أُلغي الفحص بتصفير سابق'};var result=monitorSaveRecord_(p,old,monitorArchiveFolder_(folder,false),props,v.id+'.json');return {...result,archived:true,previousVersion:v.id}}return {discarded:true,reason:'أُلغي هذا الفحص بتغيير جدول الرصد أو تصفير اليوم'}}
function monitorArchivedImageRefs_(folder){var refs={};monitorScheduleVersions_(folder).forEach(function(v){var old=monitorArchivedData_(folder,v.id);Object.keys(old.evidence||{}).forEach(function(id){var file=old.evidence[id].fileId;if(file)refs[file]=true})});return refs}
function monitorRequest_(p){
 MONITOR_RESET_EXPERIMENT_=monitorExperimentId_(p);
 if(p.versionId&&p.action!=='day')throw new Error('توثيق الجداول السابقة للقراءة فقط');
 if(p.audience==='teachers'&&p.action!=='teachersLive')throw new Error('رابط المعلمين للمشاهدة فقط');
 if(p.action==='teachersLive')return monitorTeachersLive_(p);
 var experimentId=monitorExperimentId_(p);
 if((monitorIsTrial_(p)&&!experimentId)||monitorIsTrial_(p.record))throw new Error('لا يجوز إرسال بيانات التجربة إلى السجل الرسمي');
 var props=commercialProperties_(),writeKey=props.getProperty('MONITOR_API_KEY'),readKey=props.getProperty('MONITOR_READER_KEY'),sitePassword=props.getProperty('MONITOR_SITE_PASSWORD');
 var writer=String(writeKey||'').length>=32&&monitorEqual_(p.key,writeKey),reader=String(readKey||'').length>=32&&monitorEqual_(p.key,readKey);
 var siteReader=!!sitePassword&&monitorEqual_(p.key,sitePassword);
 var publicRead=props.getProperty('MONITOR_PUBLIC_READ')==='true';
 if(!writer&&!reader&&!siteReader)throw new Error('غير مصرح بالدخول');
 var administrative=['override','resetReport','purgeDay','purgeRange','reportSchedule','setSeventhPeriod','setAutoLinksControl','videoConfigure'].indexOf(p.action)>=0||(p.action==='manualLessonLink'&&siteReader);
 if(p.action==='adminLogin'){if(!siteReader)throw new Error('أدخل كلمة مرور الموقع الإدارية');return {role:'admin',authMode:'site-password'}}
 if(administrative&&sitePassword&&!siteReader)throw new Error('هذه العملية تتطلب دخول إدارة الموقع');
 if(administrative&&!siteReader){var supplied=Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,String(p.adminPin||''),Utilities.Charset.UTF_8).map(function(b){return ('0'+((b+256)%256).toString(16)).slice(-2)}).join('');var expected=props.getProperty('MONITOR_ADMIN_PIN_HASH')||'0e3dc69daef679ae76ca56039591a2002c71041a945a57db4460ee22db2259e5';if(!monitorEqual_(supplied,expected))throw new Error('الرقم السري للإدارة غير صحيح')}
 var reading=['dates','day','teacherLink','experimentInfo','getTimetableSource','scheduleVersions','getAutoLinksControl','videoStatus'].indexOf(p.action)>=0;if(!reading&&!writer&&!administrative)throw new Error('صلاحية القراءة لا تسمح بالرفع');
 if(p.action==='heartbeat'){if(!writer)throw new Error('نبض الأداة يتطلب رمز الرفع');if(typeof p.running!=='boolean'||['scanning','waiting','paused','stopped'].indexOf(p.phase)<0||p.running!==(['scanning','waiting'].indexOf(p.phase)>=0))throw new Error('حالة نبض غير صالحة');var heartbeat={at:Date.now(),running:p.running,phase:p.phase,period:Number.isInteger(p.period)&&p.period>=1&&p.period<=7?p.period:null,cycle:Number.isInteger(p.cycle)&&p.cycle>=1&&p.cycle<=3?p.cycle:null};var nextWait=Number.isFinite(p.nextCycleInMs)&&p.nextCycleInMs>=0&&p.nextCycleInMs<=7200000?p.nextCycleInMs:null;heartbeat.nextCycleAt=heartbeat.running&&heartbeat.phase==='waiting'?(nextWait!==null?Date.now()+nextWait:Number.isFinite(p.nextCycleAt)&&p.nextCycleAt>=Date.now()-60000&&p.nextCycleAt<=Date.now()+7200000?p.nextCycleAt:null):null;heartbeat.nextCycle=heartbeat.nextCycleAt&&Number.isInteger(p.nextCycle)&&p.nextCycle>=1&&p.nextCycle<=3?p.nextCycle:null;heartbeat.totalCycles=Number.isInteger(p.totalCycles)&&p.totalCycles>=1&&p.totalCycles<=3?p.totalCycles:null;if(heartbeat.running&&heartbeat.phase==='scanning'&&p.activity&&typeof p.activity.teacher==='string'&&typeof p.activity.scanId==='string')heartbeat.activity={teacher:p.activity.teacher.slice(0,180),teacherId:typeof p.activity.teacherId==='string'?p.activity.teacherId.slice(0,120):null,scanId:p.activity.scanId.slice(0,200),date:monitorToday_(),period:heartbeat.period,cycle:heartbeat.cycle};heartbeat.device={sessionState:p.device&&['active','idle','locked','unknown'].indexOf(p.device.sessionState)>=0?p.device.sessionState:'unknown',at:Date.now()};props.setProperty('MONITOR_HEARTBEAT_'+(experimentId||'OFFICIAL'),JSON.stringify(heartbeat));return {heartbeatSaved:true,heartbeat:monitorHeartbeat_(props,experimentId,true),linksVersion:Number(props.getProperty('MONITOR_LINKS_VERSION_'+monitorToday_()))||0,autoLinksControl:monitorAutoLinksAck_(p,props)}}
 if(p.action==='getAutoLinksControl'){if(experimentId)throw new Error('التحكم خاص بالرصد الرسمي');return monitorAutoLinksPublic_(props,siteReader)}
 if(p.action==='setAutoLinksControl'){if(experimentId||!siteReader)throw new Error('التحكم يتطلب دخول إدارة الموقع');return monitorAutoLinksSet_(p,props)}
 if(p.action==='restoreArchivedSchedule'){if(experimentId||!writer)throw new Error('الاسترجاع خاص بإضافة المدرسة المرتبطة');return monitorRestoreArchived_(monitorPrivate_(DriveApp.getFolderById(MONITOR_ROOT)),p)}
 if(p.action.startsWith('video')){if(experimentId)throw new Error('الفيديو غير متاح في التجارب');return commercialVideoRequest_(p,props,writer,siteReader)}
 var root=monitorPrivate_(commercialSchoolDrive_().getFolderById(MONITOR_ROOT));
 if(p.action==='setMonitoringTiming'){if(experimentId||!writer)throw new Error('التوقيت خاص بإضافة المدرسة');var timing=monitorSchedule_(p.scheduleSettings);if(!timing)throw new Error('التوقيت غير صالح');var timingDate=monitorToday_(),timingFolder=monitorDay_(root,timingDate,false),timingFile=monitorFile_(timingFolder,'attendance.json'),timingData=monitorRead_(timingFile,null);if(!timingData)throw new Error('حمّل جدول الرصد من الخطوة 1 أولًا');var newCount=p.scheduleSettings.roundCount===undefined?timingData.snapshot.roundCount:Number(p.scheduleSettings.roundCount);if(!Number.isInteger(newCount)||newCount<1||newCount>3)throw new Error('عدد الدورات غير صالح');if(newCount!==timingData.snapshot.roundCount&&((timingData.records||[]).length||Object.keys(timingData.evidence||{}).length||(timingData.adjustments||[]).length))throw new Error('لا يمكن تغيير عدد دورات يوم فيه تحضير محفوظ؛ العدد الحالي '+timingData.snapshot.roundCount);timingData.snapshot.roundCount=newCount;timingData.timingChanges=(timingData.timingChanges||[]).concat([{at:Date.now(),previous:timingData.snapshot.scheduleSettings||null,previousReport:timingData.reportSchedule||null}]);timingData.snapshot.scheduleSettings=timing;if(timingData.reportSchedule)timingData.reportSchedule=timing;monitorWrite_(timingFolder,'attendance.json',timingData);return {saved:true,snapshot:timingData.snapshot,folderUrl:timingFolder.getUrl()}}
 if(p.action==='publishMonitoringTimetable'){if(experimentId||!writer)throw new Error('التحميل المباشر خاص بإضافة المدرسة المرتبطة');return monitorLoadDirect_(root,p)}
 if(p.action==='protectedDayState'){if(experimentId||!writer)throw new Error('العملية خاصة بإضافة المدرسة');var lockedDate=monitorToday_(),lockedFolder=monitorScheduleFolder_(root,lockedDate,false),lockedData=lockedFolder?monitorRead_(monitorFile_(lockedFolder,'attendance.json'),null):null;return {protection:'explicit-reset-only-v1',exists:!!lockedData,snapshot:lockedData?.snapshot||null,folderUrl:lockedFolder?lockedFolder.getUrl():null}}
 if(p.action==='classicStartDay'){if(experimentId||!writer)throw new Error('التشغيل خاص بإضافة المدرسة');if(p.sourceType!=='madrasati'||!String(p.sourcePage||'').startsWith(commercialPortal_()+'/'))throw new Error('يلزم جدول الصفحة الأولى المكتمل');if(!Array.isArray(p.items)||!p.items.length)throw new Error('جدول الصفحة الأولى بلا حصص');var classicDate=monitorToday_(),classicFolder=monitorDay_(root,classicDate,true),classicData=monitorRead_(monitorFile_(classicFolder,'attendance.json'),null),classicNext=monitorSnapshot_(root,{...p,preview:true},classicDate);classicNext.sourceType=p.sourceType;if(monitorDateValid_(p.sourceScheduleDate))classicNext.sourceScheduleDate=p.sourceScheduleDate;if(typeof p.sourceUploadedAt==='string')classicNext.sourceUploadedAt=p.sourceUploadedAt.slice(0,60);var result=monitorApplySchedule_(root,classicDate,classicFolder,classicData,classicNext,{...p,adopt:true,sourceHash:monitorScheduleHash_(classicNext),currentHash:monitorScheduleHash_(classicData?.snapshot)});return result}
 if(p.action==='prepareCurrentTimetable'){if(experimentId)throw new Error('العملية خاصة بالرصد الرسمي');if(!writer)throw new Error('تجهيز الجدول يتطلب رمز الرفع');return monitorPrepareCurrent_(root,p)}
 if(p.action==='scheduleVersions'){var historyDate=p.date||monitorToday_();if(!monitorDateValid_(historyDate))throw new Error('تاريخ غير صالح');return {versions:monitorScheduleVersions_(monitorScheduleFolder_(root,historyDate,false))}}
 if(p.action==='resetState'){var marker=props.getProperty('MONITOR_PURGED_DAY_'+(experimentId?experimentId+'_':'')+p.date),value=marker?JSON.parse(marker):null;return {confirmed:!!value&&value.requestId===p.requestId,purgedAt:value?.at||null,date:p.date}}
 if(p.action==='getTimetableSource'){var source=monitorRead_(monitorFile_(root,'mirsad-timetable-source.json'),{mode:'naqar',payload:null});return {mode:'madrasati',payload:source.payload?.source==='madrasati'?source.payload:null,updatedAt:source.updatedAt||null}}
 if(p.action==='setTimetableSource'||p.action==='publishMadrasatiTimetable'){
  if(experimentId)throw new Error('مصدر الجدول مستقل عن بيانات التجربة');
  if(!writer)throw new Error('تغيير مصدر الجدول يتطلب إضافة مرتبطة برمز الرفع');
  var sourceFile=monitorFile_(root,'mirsad-timetable-source.json'),source=monitorRead_(sourceFile,{mode:'naqar',payload:null});
  if(p.action==='setTimetableSource'){if(p.mode!=='madrasati')throw new Error('مصدر غير صالح');source.mode=p.mode;source.updatedAt=Date.now();monitorWrite_(root,'mirsad-timetable-source.json',source);return {saved:true,mode:source.mode}}
  if(source.mode!=='madrasati')throw new Error('اختر مصدر مدرستي أولًا');
  var payload=monitorMadrasatiPayload_(p.payload);if(source.schoolId&&source.schoolId.toLowerCase()!==payload.schoolId.toLowerCase())throw new Error('جدول المدرسة لا يطابق المدرسة المرتبطة بالخدمة');source.schoolId=payload.schoolId;source.payload=payload;source.updatedAt=Date.now();monitorWrite_(root,'mirsad-timetable-source.json',source);return {saved:true,mode:'madrasati',date:payload.scheduleDate,importedForDate:payload.importedForDate,teachers:payload.teachers.length,lessons:payload.lessons.length,updatedAt:payload.updatedAt};
 }
 if(p.action==='experimentInfo')return {supported:true};
 root=monitorExperimentRoot_(root,experimentId,p.action==='startDay'&&writer);
 if(experimentId&&p.action==='startDay'&&!props.getProperty('MONITOR_EXPERIMENT_VIEW_'+experimentId))props.setProperty('MONITOR_EXPERIMENT_VIEW_'+experimentId,Utilities.getUuid()+Utilities.getUuid());
 if(p.action==='teacherLink'){var token=experimentId?props.getProperty('MONITOR_EXPERIMENT_VIEW_'+experimentId):monitorTeacherToken_(props);return {url:commercialPortal_()+'/teachers-live.html'+(experimentId?'?experiment='+encodeURIComponent(experimentId)+'&view='+encodeURIComponent(token):token?'?view='+encodeURIComponent(token):'')}}
 if(p.action==='dates'){var dates=[],it=root.getFolders();while(it.hasNext()){var f=it.next(),m=/^توثيق غياب (\d{4}-\d{2}-\d{2})$/.exec(f.getName());if(m&&monitorFile_(f,'attendance.json'))dates.push(m[1])}return {dates:dates.sort().reverse(),authMode:siteReader?'site-password':'access-key'}}
 if(administrative&&(typeof p.requestId!=='string'||!/^[A-Za-z0-9_-]{8,120}$/.test(p.requestId)))throw new Error('معرّف العملية غير صالح');
 if(p.action==='purgeDay'){
  if(!monitorDateValid_(p.date))throw new Error('حدد تاريخ اليوم المطلوب حذفه');
  var markerKey='MONITOR_PURGED_DAY_'+(experimentId?experimentId+'_':'')+p.date,previous=props.getProperty(markerKey),marker=previous?JSON.parse(previous):null;
  if(marker&&marker.requestId===p.requestId)return {deleted:true,date:p.date};
  if(!experimentId)monitorVideoReset_(p.date,props,root,p.requestId);
  var matches=root.getFoldersByName('توثيق غياب '+p.date);
  while(matches.hasNext()){
   var doomed=matches.next();if(doomed.getId()===root.getId())throw new Error('تعذر تحديد مجلد اليوم بأمان');
   var response=UrlFetchApp.fetch('https://www.googleapis.com/drive/v3/files/'+encodeURIComponent(doomed.getId()),{method:'delete',headers:{Authorization:'Bearer '+commercialStorageToken_(doomed.getId())},muteHttpExceptions:true});
   var code=response.getResponseCode();if(code!==204&&code!==404)throw new Error('تعذر حذف مجلد اليوم نهائيًا؛ شغّل authorizeMonitoringMaintenance بحساب المالك لمنح الصلاحيات ثم أعد المحاولة');
  }
  props.setProperty(markerKey,JSON.stringify({at:Date.now(),requestId:p.requestId}));
  return {deleted:true,date:p.date};
 }
 if(['record','image'].includes(p.action)){
  var purged=props.getProperty('MONITOR_PURGED_DAY_'+(experimentId?experimentId+'_':'')+(p.date||monitorToday_()));
  if(purged&&(!Number.isFinite(Number(p.record?.scannedAt))||Number(p.record.scannedAt)<=JSON.parse(purged).at))return {discarded:true,reason:'أُلغي هذا الفحص عند تصفير اليوم'};
 }
 var date=p.date||monitorToday_();if(p.action==='startDay'&&date!==monitorToday_())throw new Error('بداية اليوم تكون لتاريخ اليوم في السعودية فقط');var folder=monitorDay_(root,date,p.action==='startDay');
 if(p.action==='day'&&p.versionId)return {...monitorDayDTO_(monitorArchivedData_(folder,p.versionId)),readOnly:true};
 var file=monitorFile_(folder,'attendance.json'),data=monitorRead_(file,null);
 if(p.action==='addCalendarLinks'){if(!writer||experimentId)throw new Error('إضافة روابط التقويم خاصة بإضافة المدرسة المرتبطة');return monitorAddCalendarLinks_(root,folder,data,p,props)}
 if(p.action==='fillMissingLinks'||p.action==='manualLessonLink'){
  if((!writer&&!siteReader)||experimentId)throw new Error('تعديل الرابط يتطلب دخول إدارة الموقع أو إضافة المدرسة المرتبطة');
  if(date!==monitorToday_()||!data||data.snapshot.sourceType!=='madrasati')throw new Error('تعديل الروابط خاص بجدول الرصد الحالي');
  var edits=[],snap=data.snapshot,sourceFile=monitorFile_(root,'mirsad-timetable-source.json'),source=monitorRead_(sourceFile,{mode:'madrasati'});
  if(p.action==='manualLessonLink'){
   if(p.expectedRevision!==(snap.scheduleRevision||'legacy'))throw new Error('تغير الجدول؛ حدّث الصفحة وأعد المحاولة');
   if(typeof p.url!=='string')throw new Error('رابط تيمز غير صالح');var manualUrl=p.url.trim()?monitorNormalizeTeamsLink_(p.url):'';if(p.url.trim()&&!manualUrl)throw new Error('رابط تيمز غير صالح');var row=snap.lessons.find(function(l){return l.teacherId===p.teacherId&&l.period===Number(p.period)});
   if(!row)throw new Error('الحصة غير موجودة؛ حدّث الصفحة');if(row.url===manualUrl)return {merged:true,saved:true,filled:0,snapshot:snap,folderUrl:folder.getUrl()};if(row.url&&(typeof p.expectedUrl!=='string'||p.expectedUrl!==row.url)||!row.url&&p.expectedUrl)throw new Error('تغير رابط الحصة منذ فتح النافذة؛ حدّث الصفحة وأعد المحاولة');
   edits.push({row:row,url:manualUrl,oldUrl:row.url||''});
  }else{
   if(p.expectedRevision&&p.expectedRevision!==(snap.scheduleRevision||'legacy'))throw new Error('تغير جدول اليوم منذ المعاينة؛ أعد فحص الروابط');
   var payload=monitorMadrasatiPayload_(p.payload);
   var boundSchool=source.schoolId||source.payload?.schoolId;if(boundSchool&&boundSchool.toLowerCase()!==payload.schoolId.toLowerCase())throw new Error('المدرسة لا تطابق الجدول المحفوظ');
   if(payload.importedForDate!==date||payload.scheduleDate!==snap.sourceScheduleDate)return {merged:false};
   // A teacher/date/period/class identifies the scheduled slot; a topic-title
   // change or an unrelated timetable difference must not block its URL.
   // Existing URLs and all lesson metadata remain untouched.
   if(p.automaticRefresh===true){var control=monitorAutoLinksRead_(props);if(!control.enabled)throw new Error('أُوقف تحديث الجدول من الموقع');if(p.refreshExisting===true&&control.mode!=='continuous')throw new Error('وضع تحديث الروابط تغير؛ أُلغيت العملية')}if(p.refreshExisting===true&&p.automaticRefresh!==true)throw new Error('تحديث الروابط القائمة خاص بالتحميل التلقائي الموثق');if(p.startPeriod!==undefined&&(!Number.isInteger(p.startPeriod)||p.startPeriod<1||p.startPeriod>7))throw new Error('نطاق الحصص غير صالح');for(var row of snap.lessons){if(row.period<(p.startPeriod||1)||row.url&&p.refreshExisting!==true)continue;var matches=payload.lessons.filter(function(l){return monitorName_(l.teacher)===monitorName_(row.teacherName)&&Number(l.cellIndex)-1===row.period});if(matches.length!==1)continue;var incoming=matches[0];if(!monitorLinkClass_(incoming.lesson)||monitorLinkClass_(incoming.lesson)!==monitorLinkClass_(row.className))continue;if(incoming.teams&&incoming.teams!==row.url)edits.push({row:row,url:incoming.teams,oldUrl:row.url||''})}

  }
  if(edits.length){
   data.adjustments=data.adjustments||[];
   edits.forEach(function(edit){var previousUrl=edit.row.url||'';if(p.action==='manualLessonLink'&&!edit.url&&edit.row.attendanceUrl===undefined)edit.row.attendanceUrl=previousUrl;edit.row.url=edit.url;data.adjustments.push({type:!edit.url?'link-clear':previousUrl?'link-edit':'link-fill',previousUrl:previousUrl,teacherId:edit.row.teacherId,period:edit.row.period,url:edit.url,manual:p.action==='manualLessonLink',at:Date.now(),sequence:Math.max(0,...data.adjustments.map(function(a){return a.sequence||0}))+1});
    if(source.payload?.importedForDate===date&&source.payload?.scheduleDate===snap.sourceScheduleDate){var lesson=source.payload.lessons.find(function(l){return monitorName_(l.teacher)===monitorName_(edit.row.teacherName)&&Number(l.cellIndex)-1===edit.row.period&&monitorLinkClass_(l.lesson)===monitorLinkClass_(edit.row.className)});if(lesson&&(!lesson.teams||(p.action==='manualLessonLink'||p.refreshExisting===true)&&lesson.teams===previousUrl)){lesson.teams=edit.url;lesson.linkState=edit.url?'linked':'unprepared'}}
   });
   data.snapshot.linksUpdatedAt=Math.max(Date.now(),(Number(props.getProperty('MONITOR_LINKS_VERSION_'+date))||0)+1);monitorWrite_(folder,'attendance.json',data);props.setProperty('MONITOR_LINKS_VERSION_'+date,String(data.snapshot.linksUpdatedAt));source.updatedAt=Date.now();monitorWrite_(root,'mirsad-timetable-source.json',source);
  }
  return {merged:true,saved:true,filled:edits.length,added:edits.filter(function(e){return !e.oldUrl}).length,changed:edits.filter(function(e){return !!e.oldUrl}).length,completed:edits.map(function(e){return {teacherId:e.row.teacherId,teacher:e.row.teacherName,period:e.row.period,url:e.url}}),snapshot:snap,folderUrl:folder.getUrl()};
 }
 if(p.action==='startDay'){
  if(!experimentId&&p.sourceType==='naqar')throw new Error('نقار ملغى؛ مدرستي هي المصدر الوحيد');
  var selectedSource=monitorRead_(monitorFile_(root,'mirsad-timetable-source.json'),{mode:'naqar'});if(!experimentId&&selectedSource.mode==='madrasati')return monitorPrepareCurrent_(root,p);
  if(date!==monitorToday_())throw new Error('بداية اليوم تكون لتاريخ اليوم في السعودية فقط');
  if(!data){data={snapshot:monitorSnapshot_(root,p,date),records:[],evidence:{}};monitorWrite_(folder,'attendance.json',data)}
  if(p.repairEmptySchedule===true)throw new Error('استبدال جدول اليوم معطّل؛ يلزم تصفير صريح من إدارة الرصد');
  var requestedCount=Number(p.roundCount);if(p.changeRoundCount===true&&Number.isInteger(requestedCount)&&requestedCount>=1&&requestedCount<=3&&requestedCount!==data.snapshot.roundCount){if((data.records||[]).length||Object.keys(data.evidence||{}).length||(data.adjustments||[]).length||(data.rangePurges||[]).length)throw new Error('عدد الدورات مختلف عن اليوم المسجل؛ صفّر اليوم كاملًا للتجربة أو ابدأ يومًا جديدًا');data.snapshot.roundCount=requestedCount;monitorWrite_(folder,'attendance.json',data)}
  if(monitorMergeMissingLessons_(data,p.items,'extension'))monitorWrite_(folder,'attendance.json',data);
  var actual=monitorSchedule_(p.scheduleSettings);if(actual){data.snapshot.scheduleSettings=actual;monitorWrite_(folder,'attendance.json',data)}
  return {snapshot:data.snapshot,folderUrl:folder.getUrl()};
 }
 if(!data)throw new Error('جدول اليوم غير محفوظ');
 if(p.action==='purgeRange'){
  if(!monitorDateValid_(p.date)||!/^([01]\d|2[0-3]):[0-5]\d$/.test(p.fromTime||'')||!/^([01]\d|2[0-3]):[0-5]\d$/.test(p.toTime||''))throw new Error('حدد التاريخ ووقت البداية والنهاية');
  var offset=Number(p.timezoneOffset);if(p.timezoneOffset===undefined||!Number.isInteger(offset)||offset < -840||offset > 840)throw new Error('تعذر تحديد توقيت الجهاز');
  var from=Date.parse(p.date+'T'+p.fromTime+':00Z')+offset*60000,until=Date.parse(p.date+'T'+p.toTime+':00Z')+offset*60000+60000;
  if(!Number.isFinite(from)||until<=from)throw new Error('وقت النهاية يجب ألا يسبق البداية');
  var videoRangeResult=experimentId?{videos:0}:monitorVideoRangeReset_(p.date,props,root,p.requestId,from,until);
  var previousRange=(data.rangePurges||[]).find(function(x){return x.id===p.requestId});if(previousRange)return {deleted:true,date:date,records:previousRange.records,images:previousRange.images,videos:videoRangeResult.videos};
  var inside=function(at){return Number.isFinite(Number(at))&&Number(at)>=from&&Number(at)<until},removed=(data.records||[]).filter(function(r){return inside(r.scannedAt)}),imageIds=Object.keys(data.evidence||{}).filter(function(id){return inside(data.evidence[id].record?.scannedAt)||removed.some(function(r){return r.scanId===id})});
  var affected=removed.concat(imageIds.map(function(id){return data.evidence[id].record})).filter(Boolean);
  var archivedRefs=monitorArchivedImageRefs_(folder);for(var imageId of imageIds){var evidence=data.evidence[imageId];if(archivedRefs[evidence.fileId])continue;if(!evidence.fileId)throw new Error('تعذر تحديد صورة الفترة بأمان');var deletedImage=UrlFetchApp.fetch('https://www.googleapis.com/drive/v3/files/'+encodeURIComponent(evidence.fileId),{method:'delete',headers:{Authorization:'Bearer '+commercialStorageToken_(evidence.fileId)},muteHttpExceptions:true});if([204,404].indexOf(deletedImage.getResponseCode())<0)throw new Error('لم يكتمل حذف صور الفترة؛ أعد المحاولة لإكمال العملية');}
  data.records=(data.records||[]).filter(function(r){return !inside(r.scannedAt)});imageIds.forEach(function(id){delete data.evidence[id]});
  var keptAdjustments=(data.adjustments||[]).filter(function(a){return a.type!=='override'||!inside(a.at)});var removedOverrides=(data.adjustments||[]).filter(function(a){return a.type==='override'&&inside(a.at)});affected=affected.concat(removedOverrides);data.adjustments=keptAdjustments;
  data.snapshot.lessons.forEach(function(l){if(!affected.some(function(r){return r.teacherId===l.teacherId&&Number(r.period)===l.period}))return;var retained=data.records.some(function(r){return r.teacherId===l.teacherId&&Number(r.period)===l.period})||Object.keys(data.evidence||{}).some(function(id){var r=data.evidence[id].record;return r&&r.teacherId===l.teacherId&&Number(r.period)===l.period})||keptAdjustments.some(function(a){return a.type==='override'&&a.teacherId===l.teacherId&&a.period===l.period});if(!retained)data.adjustments.push({id:p.requestId+'-'+l.teacherId+'-'+l.period,type:'range-reset',teacherId:l.teacherId,period:l.period,at:Date.now(),sequence:Math.max(0,...data.adjustments.map(function(a){return a.sequence||0}))+1})});
  var rangeEntry={id:p.requestId,from:from,until:until,at:Date.now(),records:removed.length,images:imageIds.length};data.rangePurges=data.rangePurges||[];data.rangePurges.push(rangeEntry);monitorWrite_(folder,'attendance.json',data);return {deleted:true,date:date,records:removed.length,images:imageIds.length,videos:videoRangeResult.videos};
 }
 if(['record','image'].includes(p.action)&&data.snapshot.scheduleRevision&&p.record?.scheduleRevision!==data.snapshot.scheduleRevision)return monitorArchiveLate_(folder,p,props);
 if(['record','image'].includes(p.action)&&(data.rangePurges||[]).some(function(range){var at=Number(p.record?.scannedAt),cutoff=Number.isFinite(Number(range.at))?Number(range.at):range.until-1;return at>=range.from&&at<range.until&&at<=cutoff}))return {discarded:true,reason:'أُلغي هذا الفحص عند تصفير الفترة'};
 if(administrative){
  if(typeof p.requestId!=='string'||!/^[A-Za-z0-9_-]{8,120}$/.test(p.requestId))throw new Error('معرّف العملية غير صالح');
  data.adjustments=data.adjustments||[];
  if(data.adjustments.some(function(a){return a.id===p.requestId}))return {saved:true};
  var entry={id:p.requestId,sequence:data.adjustments.length+1,at:Date.now(),type:p.action==='resetReport'?'reset':p.action};
  if(p.action==='override'){
   var selected=data.snapshot.lessons.find(function(l){return l.teacherId===p.teacherId&&l.period===Number(p.period)});
   if(!selected||MONITOR_TEACHER_MODEL_.isExcludedPeriod(data.snapshot.date,selected.period,data.snapshot)||!['present','absent','partial','partial-absence','unresolved'].includes(p.status))throw new Error('اختر حصة وحالة صحيحتين');
   entry.teacherId=selected.teacherId;entry.period=selected.period;entry.status=p.status;entry.note=String(p.note||'').slice(0,1000);
  }
  if(p.action==='setSeventhPeriod'){
   if(typeof p.enabled!=='boolean'||typeof p.expectedEnabled!=='boolean')throw new Error('اختيار الحصة غير صالح');
   if(p.expectedRevision!==(data.snapshot.scheduleRevision||'legacy'))throw new Error('تغير الجدول؛ حدّث الصفحة');
   var enabled=!MONITOR_TEACHER_MODEL_.isExcludedPeriod(date,7,data.snapshot);
   if(enabled!==p.expectedEnabled)throw new Error('تغير اختيار السابعة على جهاز آخر؛ حدّث الصفحة');
   data.snapshot.seventhPeriodEnabled=p.enabled;entry.enabled=p.enabled;
   data.snapshot.linksUpdatedAt=Math.max(Date.now(),(Number(props.getProperty('MONITOR_LINKS_VERSION_'+date))||0)+1);
   props.setProperty('MONITOR_LINKS_VERSION_'+date,String(data.snapshot.linksUpdatedAt));
  }
  if(p.action==='reportSchedule'){
   var schedule=p.schedule||{},start=/^(\d{2}):(\d{2})$/.exec(schedule.manualStart||''),duration=Number(schedule.periodDuration),gap=Number(schedule.manualGapMinutes);
   if(!start||Number(start[1])>23||Number(start[2])>59||!Number.isInteger(duration)||duration<1||duration>180||!Number.isInteger(gap)||gap<0||gap>60)throw new Error('توقيت الحصص غير صالح');
   entry.schedule={manualStart:schedule.manualStart,periodDuration:duration,manualGapMinutes:gap};data.reportSchedule=entry.schedule;
  }
  data.adjustments.push(entry);monitorWrite_(folder,'attendance.json',data);return {saved:true,adjustment:entry};
 }
 if(['record','image'].includes(p.action)&&purged&&Number(p.record?.scannedAt)<Math.max(JSON.parse(purged).at,Number(data.snapshot.createdAt)||0))return {discarded:true,reason:'هذا الفحص يخص التجربة المحذوفة'};
 if(['record','image'].includes(p.action)&&p.scheduleSettings){data.snapshot.scheduleSettings=monitorSchedule_(p.scheduleSettings)}
 if(p.action==='day'){var result=monitorDayDTO_(data);result.heartbeat=monitorHeartbeat_(props,experimentId,true,data.snapshot);if(result.heartbeat)result.serverTime=Date.now();result.calendarLinksSupported=true;return result}
 return monitorSaveRecord_(p,data,folder,props,'attendance.json');
}

function unusedStandaloneDoPost_(e){var result,lock=LockService.getScriptLock();try{var p=JSON.parse(e.postData.contents);if(p.action!=='teachersLive')lock.waitLock(30000);result={ok:true,...monitorRequest_(p)}}catch(error){result={ok:false,error:String(error.message||error)}}finally{if(lock.hasLock())lock.releaseLock()}return ContentService.createTextOutput(JSON.stringify(result)).setMimeType(ContentService.MimeType.JSON)}

// BEGIN SHARED TEACHER MODEL — generated from monitor-model.js; keep in sync.
var MONITOR_TEACHER_MODEL_=(function(){var module={exports:{}};
(function(root){
 'use strict';
 const normalize=s=>String(s||'').normalize('NFKC').replace(/[\u064B-\u065F\u0670\u0640]/g,'').replace(/[أإآ]/g,'ا').replace(/ى/g,'ي').replace(/\s+/g,' ').trim();
 const day=(date=new Date())=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Riyadh',year:'numeric',month:'2-digit',day:'2-digit'}).format(date);
 function state(rounds,count){if(rounds.length!==count||rounds.some(x=>!['present','absent'].includes(x?.status)))return 'unresolved';const n=rounds.filter(x=>x.status==='absent').length;return n===count?'absent':n===0?'present':count===3&&n===2?'partial-absence':'partial'}
 function lessonEvidence(records){return records.flatMap(function(record){var children=Array.isArray(record.linkResults)?record.linkResults:[],proofs=children.filter(r=>r.evidenceUrl&&r.status!=='present').map(child=>({...record,...child,aggregateScanId:record.scanId,meetingSource:child.source,scannedUrl:child.url}));if(record.evidenceUrl&&record.status!=='present'&&!proofs.some(r=>r.evidenceUrl===record.evidenceUrl))proofs.unshift(record);return proofs})}
 const defaultSchedule={manualStart:'06:30',periodDuration:45,manualGapMinutes:1};
 function lessonEnded(data,period,now=new Date()){
  const date=data.snapshot.date,today=day(now);if(date<today)return true;if(date>today)return false;
  const settings={...defaultSchedule,...data.snapshot.scheduleSettings,...data.reportSchedule};
  const match=/^(\d{2}):(\d{2})$/.exec(settings.manualStart||'');if(!match)return false;
  const duration=Number(settings.periodDuration),gap=Number(settings.manualGapMinutes);if(!Number.isFinite(duration)||duration<1||!Number.isFinite(gap)||gap<0)return false;
  const end=Number(match[1])*60+Number(match[2])+(period-1)*(duration+gap)+duration;
  return now.getTime()>=new Date(date+'T00:00:00+03:00').getTime()+end*60000;
 }
 function isExcludedPeriod(date,period,snapshot){if(Number(period)!==7)return false;if(typeof snapshot?.seventhPeriodEnabled==='boolean')return !snapshot.seventhPeriodEnabled;return Number(period)===7&&/^\d{4}-\d{2}-\d{2}$/.test(String(date))&&new Date(date+'T12:00:00Z').getUTCDay()===4}
 function lessonStarted(data,period,now=new Date()){
  const date=data.snapshot.date,today=day(now);if(date<today)return true;if(date>today)return false;
  const settings={...defaultSchedule,...data.snapshot.scheduleSettings,...data.reportSchedule},match=/^(\d{2}):(\d{2})$/.exec(settings.manualStart||'');
  const duration=Number(settings.periodDuration),gap=Number(settings.manualGapMinutes);if(!match||!Number.isFinite(duration)||duration<1||!Number.isFinite(gap)||gap<0)return false;
  const start=Number(match[1])*60+Number(match[2])+(period-1)*(duration+gap);
  return now.getTime()>=new Date(date+'T00:00:00+03:00').getTime()+start*60000;
 }
 function cells(data,options={}){
  if(!data?.snapshot)return [];
  const audit=data.adjustments||[];
  return data.snapshot.lessons.filter(l=>!isExcludedPeriod(data.snapshot.date,l.period,data.snapshot)).map(lesson=>{
   const reset=[...audit].reverse().find(a=>a.type==='reset'||(a.type==='range-reset'&&a.teacherId===lesson.teacherId&&a.period===lesson.period)),cutoff=reset?.at||0;
   const allScans=(data.records||[]).filter(r=>r.teacherId===lesson.teacherId&&Number(r.period)===lesson.period);
   const scans=allScans.filter(r=>!reset||r.scannedAt>cutoff);
   const started=lessonStarted(data,lesson.period,options.now||new Date());
   const rounds=Array.from({length:data.snapshot.roundCount},(_,i)=>scans.filter(r=>r.cycle===i+1).sort((a,b)=>b.scannedAt-a.scannedAt)[0]||{status:'unresolved',pending:true}).map(r=>r.status==='no-link'&&started?{...r,status:'absent',absenceReason:'no-link'}:r);
   const conclusive=rounds.filter(r=>['present','absent'].includes(r.status));
   const override=[...audit].reverse().find(a=>a.type==='override'&&a.teacherId===lesson.teacherId&&a.period===lesson.period&&(!reset||a.sequence>reset.sequence));
   const ended=lessonEnded(data,lesson.period,options.now||new Date());
   const noLinkAbsence=!reset&&!conclusive.some(r=>r.status==='present')&&started&&!(lesson.url||lesson.calendarUrl);
   const unscanned=ended&&!scans.length&&!override&&!reset;const inferred=noLinkAbsence;
   const complete=rounds.every(r=>['present','absent'].includes(r.status));
   const finalState=override?override.status:inferred?'absent':unscanned?'unresolved':data.snapshot.roundCount===3?(complete?state(rounds,3):rounds.some(r=>!r.pending&&!['present','absent'].includes(r.status))?'unresolved':'pending'):conclusive.length?state(conclusive,conclusive.length):scans.some(r=>r.status==='unresolved')?'unresolved':'pending';
   return {...lesson,rounds,state:finalState,displayState:finalState,override:override||null,inferred:!override&&inferred,noLinkAbsence:!override&&noLinkAbsence,ended,started,unscanned,reset:!!reset&&!scans.length&&!override,
    pendingRounds:override||inferred||unscanned?0:rounds.filter(r=>r.pending).length,failedRounds:override?0:rounds.filter(r=>!r.pending&&!['present','absent'].includes(r.status)).length,
    evidence:lessonEvidence(allScans),history:allScans,adjustments:audit.filter(a=>a.type==='reset'||(a.teacherId===lesson.teacherId&&a.period===lesson.period)),
    late:!override&&finalState==='partial'&&rounds[0]?.status==='absent'&&rounds.slice(1).some(r=>r.status==='present')};
  });
 }
 function presentation(cell){
  const recorded=cell.rounds.filter(r=>!r.pending),latest=recorded.slice().sort((a,b)=>Number(b.scannedAt||0)-Number(a.scannedAt||0)||Number(b.cycle||0)-Number(a.cycle||0))[0],provisional=!cell.override&&!cell.inferred&&!cell.reset&&cell.pendingRounds>0&&!!latest;
  return {state:provisional&&['present','absent','unresolved'].includes(latest.status)?latest.status:(cell.displayState||cell.state),provisional,cycle:latest?cell.rounds.indexOf(latest)+1:0,completed:recorded.length,total:cell.rounds.length};
 }
 function stats(days,options={}){const map=new Map();for(const data of days){const rows=cells(data,options);for(const teacher of data.snapshot?.teachers||[]){let stat=map.get(teacher.id)||{...teacher,scheduled:0,absentLessons:0,absentDays:0,present:0,unknown:0,partial:0,partialAbsence:0,late:0};const lessons=rows.filter(x=>x.teacherId===teacher.id);stat.scheduled+=lessons.length;for(const x of lessons){stat.absentLessons+=Number(x.state==='absent');stat.present+=Number(['present','partial'].includes(x.state));stat.unknown+=Number(x.state==='unresolved');stat.partial+=Number(x.state==='partial');stat.partialAbsence+=Number(x.state==='partial-absence');stat.late+=Number(x.late)}stat.absentDays+=Number(lessons.length>0&&lessons.every(x=>x.state==='absent'));stat.percent=stat.scheduled?Math.round(stat.absentLessons/stat.scheduled*1000)/10:0;map.set(teacher.id,stat)}}return [...map.values()]}
 function live(data,options={}){
  const now=options.now||new Date(),date=day(now),empty={date,period:null,alerts:[],cycles:[],latestScanAt:null};
  if(!data?.snapshot||data.snapshot.date!==date)return empty;
  const schedule={...defaultSchedule,...data.snapshot.scheduleSettings,...data.reportSchedule},match=/^(\d{2}):(\d{2})$/.exec(schedule.manualStart||'');
  if(!match)return empty;const duration=Number(schedule.periodDuration),gap=Number(schedule.manualGapMinutes);if(!Number.isFinite(duration)||duration<1||!Number.isFinite(gap)||gap<0)return empty;
  const base=new Date(date+'T00:00:00+03:00').getTime()+(Number(match[1])*60+Number(match[2]))*60000;
  if(!data.reportSchedule&&!data.snapshot.scheduleSettings&&(data.records||[]).some(r=>{
   if(!Number.isInteger(r.period)||r.period<1||r.period>7||!Number.isFinite(r.scannedAt)||day(new Date(r.scannedAt))!==date)return false;
   const start=base+(r.period-1)*(duration+gap)*60000;return r.scannedAt<start-120000||r.scannedAt>start+duration*60000+120000;
  }))return {...empty,timingMismatch:true};
  let period=null,startedAt,endAt;for(let p=1;p<=7;p++){if(isExcludedPeriod(data.snapshot.date,p,data.snapshot))continue;const start=base+(p-1)*(duration+gap)*60000,end=start+duration*60000;if(now.getTime()>=start&&now.getTime()<end){period=p;startedAt=start;endAt=end;break}}
  if(!period)return empty;
  const reset=[...(data.adjustments||[])].reverse().find(a=>a.type==='reset'),cutoff=reset?.at||0;
  const scans=(data.records||[]).filter(r=>Number(r.period)===period&&r.scannedAt>=startedAt&&r.scannedAt<=now.getTime()&&r.scannedAt>cutoff);
  const cycles=Array.from({length:data.snapshot.roundCount},(_,i)=>{const rows=scans.filter(r=>r.cycle===i+1);return {cycle:i+1,count:rows.length,firstResultAt:rows.length?Math.min(...rows.map(r=>r.scannedAt)):null,lastResultAt:rows.length?Math.max(...rows.map(r=>r.scannedAt)):null}});
  const alerts=[];for(const cell of cells(data,{now}).filter(c=>c.period===period)){
   const history=scans.filter(r=>r.teacherId===cell.teacherId).map(r=>r.status==='no-link'?{...r,status:'absent',absenceReason:'no-link'}:r).sort((a,b)=>a.scannedAt-b.scannedAt||a.cycle-b.cycle),conclusive=history.filter(r=>['present','absent'].includes(r.status)),latest=conclusive[conclusive.length-1];
   if(cell.override?cell.override.status!=='absent':latest?.status!=='absent')continue;
   alerts.push({teacherId:cell.teacherId,teacher:cell.teacherName,period,cycle:cell.override?null:latest.cycle,scannedAt:cell.override?cell.override.at:latest.scannedAt,manual:!!cell.override,...(latest?.absenceReason?{absenceReason:latest.absenceReason}:{}),evidenceUrl:latest?.status==='absent'?(latest.evidenceUrl||null):null,evidenceCycle:latest?.status==='absent'?latest.cycle:null,evidenceAt:latest?.status==='absent'?latest.scannedAt:null,cycles:cycles.map(c=>{const rows=history.filter(r=>r.cycle===c.cycle),last=rows[rows.length-1];return {cycle:c.cycle,status:last?.status||'pending',scannedAt:last?.scannedAt||null}})});
  }
  alerts.sort((a,b)=>a.scannedAt-b.scannedAt);
  return {date,period,startedAt,endAt,minutesIntoPeriod:Math.floor((now.getTime()-startedAt)/60000),alerts,cycles,latestScanAt:scans.length?Math.max(...scans.map(r=>r.scannedAt)):null};
 }
 const api={normalize,day,state,cells,presentation,stats,lessonEnded,lessonStarted,isExcludedPeriod,defaultSchedule,live};if(typeof module!=='undefined')module.exports=api;else root.MirsadMonitorModel=api;
})(globalThis);

return module.exports})();
// END SHARED TEACHER MODEL

/* Deploy this generated bundle as a NEW Apps Script service, never the school's existing service. */
var COMMERCIAL_CONTEXT_=null;
// Request-local memo only. Never cache school authorization across requests.
var COMMERCIAL_REQUEST_CACHE_=null;
function commercialOutput_(value){return ContentService.createTextOutput(JSON.stringify(value)).setMimeType(ContentService.MimeType.JSON)}
function commercialHash_(value){return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,String(value),Utilities.Charset.UTF_8).map(function(n){return ('0'+((n+256)%256).toString(16)).slice(-2)}).join('')}
function commercialRandom_(){return commercialHash_(Utilities.getUuid()+Utilities.getUuid()+Date.now())}
function commercialRoot_(){if(COMMERCIAL_REQUEST_CACHE_&&COMMERCIAL_REQUEST_CACHE_.root)return COMMERCIAL_REQUEST_CACHE_.root;var id=PropertiesService.getScriptProperties().getProperty('COMMERCIAL_ROOT_ID');if(!id)throw new Error('لم يكتمل إعداد خدمة مرصاد التجارية');var root=DriveApp.getFolderById(id);if(COMMERCIAL_REQUEST_CACHE_)COMMERCIAL_REQUEST_CACHE_.root=root;return root}
function commercialReadFile_(folder,name,fallback){var it=folder.getFilesByName(name);return it.hasNext()?JSON.parse(it.next().getBlob().getDataAsString()):fallback}
function commercialWriteFile_(folder,name,value){var it=folder.getFilesByName(name),body=JSON.stringify(value);if(it.hasNext())it.next().setContent(body);else folder.createFile(name,body,'application/json')}
function commercialRegistry_(){return createSchoolRegistry({now:function(){return Date.now()},hash:commercialHash_,equal:function(a,b){var diff=a.length^b.length;for(var i=0;i<Math.max(a.length,b.length);i++)diff|=(a.charCodeAt(i)||0)^(b.charCodeAt(i)||0);return diff===0},random:commercialRandom_,uuid:function(){return Utilities.getUuid()},passwordHash:function(password,salt,iterations){return MirsadPasswords.derive(password,salt,iterations)},pinHash:commercialWebsitePinHash_,discoverCampus:commercialDiscoverCampus_,ensureCampus:commercialEnsureCampus_,checkCampusReady:commercialCampusReady_,deleteCampus:commercialDeleteCampus_,validateInvoice:commercialValidateInvoice_,storeInvoice:commercialStoreInvoice_,readInvoice:commercialReadInvoice_,ownerHash:function(){var hash=PropertiesService.getScriptProperties().getProperty('COMMERCIAL_OWNER_PASSWORD_HASH');if(!/^[a-f0-9]{64}$/.test(hash||''))throw new Error('اضبط كلمة مرور مالك الخدمة أولًا');return hash},read:function(){var cache=COMMERCIAL_REQUEST_CACHE_;if(cache&&cache.registryLoaded)return cache.registry;var value=commercialReadFile_(commercialRoot_(),'schools-registry.json',null);if(cache){cache.registry=value;cache.registryLoaded=true}return value},write:function(v){commercialWriteFile_(commercialRoot_(),'schools-registry.json',v);if(COMMERCIAL_REQUEST_CACHE_){COMMERCIAL_REQUEST_CACHE_.registry=v;COMMERCIAL_REQUEST_CACHE_.registryLoaded=true}},provisionSchool:function(id){return commercialPrivate_(commercialRoot_().createFolder('school-'+id)).getId()}})}
function commercialProperties_(){if(!COMMERCIAL_CONTEXT_)throw new Error('لا توجد جلسة مدرسة');var c=COMMERCIAL_CONTEXT_,cache=COMMERCIAL_REQUEST_CACHE_,stored=cache&&cache.properties&&cache.properties[c.school.id+':'+(c.school._site?.localId||'legacy')],folder=stored?stored.folder:DriveApp.getFolderById(c.school.rootId),value=stored?stored.value:commercialReadFile_(folder,'service-properties.json',{});if(cache){cache.properties=cache.properties||{};cache.properties[c.school.id+':'+(c.school._site?.localId||'legacy')]={folder:folder,value:value}}return {getProperty:function(key){if(key==='MONITOR_API_KEY')return c.role==='recorder'?c.key:'not-a-recorder';if(key==='MONITOR_SITE_PASSWORD')return c.role==='admin'?c.key:'not-an-admin';if(key==='MONITOR_READER_KEY')return 'not-a-reader';if(key==='MONITOR_PUBLIC_READ')return 'false';if(key==='MONITOR_TEACHER_VIEW_KEY')return c.school.viewerToken;if(key==='MONITOR_PRIVATE_ROOT_ID')return c.storage?.rootId||c.school.rootId;return value[key]||null},setProperty:function(key,v){value[key]=String(v);commercialWriteFile_(folder,'service-properties.json',value);return this}}}
function commercialCache_(){var cache=CacheService.getScriptCache(),prefix='school:'+COMMERCIAL_CONTEXT_.school.id+':'+(COMMERCIAL_CONTEXT_.school._site?.localId||'legacy')+':';return {get:function(k){return cache.get(prefix+k)},put:function(k,v,t){cache.put(prefix+k,v,t)}}}
function commercialPortal_(){var url=PropertiesService.getScriptProperties().getProperty('COMMERCIAL_PORTAL_URL')||'';if(!/^https:\/\/[A-Za-z0-9.-]+(?::\d+)?(?:\/[A-Za-z0-9_-]+)*\/?$/.test(url))throw new Error('اضبط رابط موقع المدارس التجاري');return url.replace(/\/$/,'')}
// These four actions read without writing registry, attendance, or settings.
// Viewer polling must not queue behind image uploads or block them.
function commercialReadOnlyAction_(action){return ['day','dates','getTimetableSource','commercialServiceVersion','commercialDriveStatus','getAutoLinksControl','commercialOwnerPortal','commercialCustomerPortal'].indexOf(action)>=0}
function doPost(e){var lock=LockService.getScriptLock(),result;COMMERCIAL_REQUEST_CACHE_={};try{var p=JSON.parse(e.postData.contents);if(!commercialReadOnlyAction_(p.action)&&!lock.tryLock(8000)){var busy=new Error('الخدمة مشغولة مؤقتًا؛ ستُعاد محاولة الرفع');busy.code='service-busy';throw busy}var registry=commercialRegistry_();var commerceAction=['commercialOwnerCommerce','commercialInvoiceFile','commercialBillingStatus','commercialInvoiceUpload','commercialBillingLogout'].includes(p.action);if(!commerceAction&&/^a\./.test(p.key||'')){var va=registry.authorize(p.key),vs=va.school.sessions.find(function(x){return x.hash===commercialHash_(p.key)});if(vs?.readOnly&&!['adminLogin','dates','day','getTimetableSource','previewTimetable','resetState','scheduleVersions','teacherLink','teachersLive','getAutoLinksControl','videoStatus','videoConfigure','commercialWebsiteActivity','commercialDriveStatus','commercialDriveBegin','commercialDriveComplete','commercialEvidence','commercialServiceVersion','commercialSchoolSpaces','commercialCustomerPortal','commercialWebsiteLogout'].includes(p.action))throw new Error('الموقع للعرض فقط؛ افتح الإضافة لتغيير الإعدادات')}
 if(commerceAction)result=commercialCommerceRequest_(registry,p);
 else if(['commercialSchoolSpaces','commercialSelectSchool','commercialMonitorSession','commercialResetUsername'].includes(p.action))result=commercialMultiRequest_(registry,p);
 else if(['commercialExtensionCodeRequest','commercialExtensionCodeLogin','commercialRecorderPortal','commercialRecorderStatus','commercialManageAccess','commercialRecorderSignout','commercialSetWebsitePin','commercialWebsitePinLogin'].includes(p.action))result=commercialSimpleRequest_(registry,p);
 else if(p.action==='commercialServiceVersion')result={version:'2.9.53',unlimitedRecorderDevices:true,multiSchoolAccounts:true,oneActiveSchool:true,ownerCommerce:true,ownerAccessControl:true,ownerBulkRestore:true,simpleSetup:true,selfRegistration:true,monthlySubscription:100,videoRecording:true,ownerPortal:true,remoteAutoLinks:true,accounts:true,singleExtensionSession:false,singleMonitoringSession:true,schoolOwnedDrive:true};
 else if(p.action==='commercialDriveStatus')result={drive:schoolDrivePublic_(schoolDriveAdmin_(registry,p))};
 else if(p.action==='commercialDriveBegin')result=schoolDriveBegin_(registry,p);
 else if(p.action==='commercialDriveComplete')result=schoolDriveCallback_(registry,p);
 else if(p.action==='commercialOwnerLogin')result=registry.ownerLogin(p.password);
 else if(p.action==='commercialOwnerAccessControl')result=registry.ownerAccessControl(p.key,p.control);
 else if(p.action==='commercialOwnerPortal')result=registry.ownerPortal(p.key);
 else if(p.action==='commercialOwnerSettings')result=registry.ownerSettings(p.key,p.settings);
 else if(p.action==='commercialCustomerPortal')result=registry.customerPortal(p.key);
 else if(p.action==='commercialCustomerFeedback')result=registry.customerFeedback(p.key,p);
 else if(p.action==='commercialListSchools')result=registry.list(p.key);
 else if(p.action==='commercialCreateSchool')result=commercialSendCredentials_(registry.create(p.key,p));
 else if(p.action==='commercialManageSchool'){result=commercialSendCredentials_(registry.manage(p.key,p));if(p.operation==='disable')result=commercialAccessNotice_(result);}
 else if(p.action==='commercialWebsiteLogin')result=registry.websiteLogin(p);
 else if(p.action==='commercialWebsiteLogout')result=registry.websiteLogout(p.key);
 else if(p.action==='commercialWebsiteActivity')result=registry.websiteActivity(p.key,p);
 else if(p.action==='commercialConfirmEmail')result=registry.confirmEmail(p);
 else if(p.action==='commercialSchoolDevices')result=registry.devices(p.key,p.schoolId);
 else if(p.action==='commercialExtensionLogin'){result=registry.extensionLogin(p);result.handover=commercialReadProgress_(registry.authorize(result.writerKey).school)}
 else if(p.action==='commercialExtensionLogout'){registry.recorderProof(p.key,p);commercialSaveProgress_(registry.authorize(p.key).school,p.progress);result=registry.extensionLogout(p.key,p)}
 else if(p.action==='commercialActivate')result=registry.activate(p);
 else if(p.action==='commercialSchoolSettings')result=registry.spaceSettings(p.key,p);
 else if(p.action==='commercialLoginLink')result=registry.loginLink(p.key);
 else if(p.action==='commercialEvidence')result=commercialEvidence_(registry,p);
 else if(p.action==='commercialEnrollDevice')result=registry.enroll(p.key,p);
 else{
  if(p.experimentId||p.environment)throw new Error('التجارب غير متاحة في حسابات المدارس');
  var reading=['adminLogin','dates','day','getTimetableSource','previewTimetable','resetState','scheduleVersions','teacherLink','teachersLive','getAutoLinksControl','videoStatus'],writer=['heartbeat','setMonitoringTiming','publishMonitoringTimetable','protectedDayState','classicStartDay','prepareCurrentTimetable','record','image','setTimetableSource','publishMadrasatiTimetable','startDay','previewTimetable','adoptTimetable','fillMissingLinks','addCalendarLinks','videoPoll','videoUpdate','videoUploadBegin','videoUploadFinish','restoreArchivedSchedule'],admin=['manualLessonLink','override','setSeventhPeriod','resetReport','purgeDay','purgeRange','reportSchedule','setAutoLinksControl','videoConfigure'];
  if(reading.indexOf(p.action)<0&&writer.indexOf(p.action)<0&&admin.indexOf(p.action)<0)throw new Error('طلب غير مدعوم');
  var actor=p.action==='teachersLive'&&p.viewToken?registry.authorizeView(p.viewToken):registry.authorize(p.key,reading.indexOf(p.action)<0);if(actor.role==='recorder')registry.recorderProof(p.key,p);if(reading.indexOf(p.action)<0&&writer.indexOf(p.action)>=0&&actor.role!=='recorder')throw new Error('العملية تتطلب جهاز الرصد المرتبط');if(admin.indexOf(p.action)>=0&&actor.role!=='admin'&&p.action!=='manualLessonLink')throw new Error('العملية خاصة بإدارة المدرسة');
  actor=commercialCampusActor_(actor,p);commercialMultiBefore_(p,actor);if(actor.role==='recorder'&&p.action==='heartbeat'){commercialSaveProgress_(actor.school,p.progress);registry.recorderActivity(p.key,p)}
  COMMERCIAL_CONTEXT_={school:actor.school,role:actor.role,key:p.key,storage:commercialStorageFor_(actor.school,p.date||monitorToday_())};MONITOR_ROOT=COMMERCIAL_CONTEXT_.storage.rootId;
  if(p.action==='adminLogin'){if(actor.role!=='admin')throw new Error('دخول الإدارة يتطلب حساب المدرسة');result={role:'admin',authMode:'school-session',school:registry.websiteAccess(p.key).school};result=commercialMultiAfter_(p,result,actor)}
  else{result=p.action==='dates'?schoolDriveDates_(actor.school):monitorRequest_(p);result.schoolId=actor.school.id;result=commercialMultiAfter_(p,result,actor);delete result.folderUrl;if(p.action==='teacherLink')result.url+='&service='+encodeURIComponent(ScriptApp.getService().getUrl());if(actor.role!=='viewer'){result.letterhead=actor.school.profile;result.subscription={expiresAt:actor.school.expiresAt,active:actor.school.expiresAt>Date.now(),serverTime:Date.now()}}}
 }
 return commercialOutput_({ok:true,serverTime:Date.now(),...result});
 }catch(error){return commercialOutput_({ok:false,error:String(error.message||error),code:error.code||'request-failed'})}finally{COMMERCIAL_CONTEXT_=null;COMMERCIAL_REQUEST_CACHE_=null;if(lock.hasLock())lock.releaseLock()}}
function setupCommercialService(){var props=PropertiesService.getScriptProperties();if(!props.getProperty('COMMERCIAL_ROOT_ID')){var root=commercialPrivate_(DriveApp.createFolder('مرصاد المدارس — بيانات مستقلة'));props.setProperty('COMMERCIAL_ROOT_ID',root.getId())}return 'اضبط COMMERCIAL_OWNER_PASSWORD_HASH وCOMMERCIAL_PORTAL_URL في خصائص المشروع. لا تشارك كلمة المرور أو رموز المدارس.'}

function commercialEvidence_(registry,p){var actor=registry.authorize(p.key);if(actor.role!=='admin'||!monitorDateValid_(p.date)||typeof p.scanId!=='string'||p.scanId.length>200)throw new Error('طلب إثبات غير صالح');actor=commercialCampusActor_(actor,p);var storage=commercialStorageFor_(actor.school,p.date),drive=storage.remote?schoolDriveAdapter_(actor.school):DriveApp,root=drive.getFolderById(storage.rootId),it=root.getFoldersByName('توثيق غياب '+p.date);if(!it.hasNext())throw new Error('لا يوجد سجل للحصة');var folder=it.next(),data=commercialReadFile_(folder,'attendance.json',null),image=data&&data.evidence&&data.evidence[p.scanId];if(!image)throw new Error('الإثبات غير موجود في سجل المدرسة');var file=drive.getFileById(image.fileId),bytes=file.getBlob().getBytes();if(bytes.length>8000000)throw new Error('حجم الإثبات أكبر من المسموح');return {mime:'image/png',image:'data:image/png;base64,'+Utilities.base64Encode(bytes)}}
function setCommercialOwnerPassword(){var p=PropertiesService.getScriptProperties(),password=p.getProperty('COMMERCIAL_OWNER_PASSWORD');if(!password||password.length<14)throw new Error('ضع كلمة مرور مالك لا تقل عن 14 حرفًا في COMMERCIAL_OWNER_PASSWORD ثم أعد التشغيل');p.setProperty('COMMERCIAL_OWNER_PASSWORD_HASH',commercialHash_(password));p.deleteProperty('COMMERCIAL_OWNER_PASSWORD');var registry=commercialReadFile_(commercialRoot_(),'schools-registry.json',null);if(registry){registry.owners=[];commercialWriteFile_(commercialRoot_(),'schools-registry.json',registry)}return 'حُفظت بصمة كلمة مرور المالك وحُذفت القيمة النصية'}

function commercialPrivate_(folder){var access=folder.getSharingAccess();if(access===DriveApp.Access.ANYONE||access===DriveApp.Access.ANYONE_WITH_LINK)throw new Error('مجلد بيانات المدارس يجب أن يكون خاصًا');return folder}

function commercialSendCredentials_(result){if(!result.password||!result.emailVerificationCode)return result;var verification=JSON.stringify({email:result.school.email,code:result.emailVerificationCode}),link=commercialPortal_()+'/school-settings.html#verify='+encodeURIComponent(verification),body='مرحبًا، حساب مدرستكم في مرصاد جاهز.\nالبريد: '+result.school.email+'\nكلمة المرور: '+result.password+'\nأكد البريد بفتح الرابط التالي خلال 72 ساعة:\n'+link+'\nبعد التأكيد تدخل بالإيميل وكلمة المرور نفسها من أي جوال أو جهاز أو متصفح. الإضافة تقبل جلسة رصد واحدة فقط. يمكن تفعيل أجهزة غير محدودة؛ أوقف الرصد على الجهاز السابق قبل تشغيله على جهاز آخر.\nينتهي الاشتراك: '+Utilities.formatDate(new Date(result.school.expiresAt),'Asia/Riyadh','yyyy-MM-dd');try{MailApp.sendEmail({to:result.school.email,subject:'تفعيل حساب مدرستكم في مرصاد',body:body});result.emailDelivery={sent:true}}catch(error){result.emailDelivery={sent:false,error:'لم تُرسل الرسالة. تحقق من صلاحيات البريد وحصته اليومية ثم أعد إصدار بيانات الدخول.'}}result.welcomeMessage=body;return result}
function commercialProgressFolder_(school,create){var storage=commercialStorageFor_(school,monitorToday_()),drive=storage.remote?schoolDriveAdapter_(school):DriveApp,root=drive.getFolderById(storage.rootId),it=root.getFoldersByName('توثيق غياب '+monitorToday_());return it.hasNext()?it.next():null}
function commercialSaveProgress_(school,progress){if(!progress||progress.date!==monitorToday_())return;var folder=commercialProgressFolder_(school),data=folder&&commercialReadFile_(folder,'attendance.json',null);if(!data||progress.scheduleRevision!==data.snapshot.scheduleRevision)return;if(!Number.isInteger(progress.period)||progress.period<1||progress.period>7||!Number.isInteger(progress.cycle)||progress.cycle<1||progress.cycle>data.snapshot.roundCount||!Number.isInteger(progress.index)||progress.index<0||progress.index>500)throw new Error('موضع الرصد غير صالح');commercialWriteFile_(folder,'recorder-progress.json',{date:monitorToday_(),scheduleRevision:data.snapshot.scheduleRevision,period:progress.period,cycle:progress.cycle,index:progress.index,waitingForCycle2:progress.waitingForCycle2===true,nextCycleAt:Number(progress.nextCycleAt)||null,at:Date.now()})}
function commercialReadProgress_(school){if(school.campuses&&!school.activeSiteId)return null;school=commercialMultiSchool_(school);var folder=commercialProgressFolder_(school),data=folder&&commercialReadFile_(folder,'attendance.json',null);if(!data)return null;var progress=commercialReadFile_(folder,'recorder-progress.json',null);if(progress?.scheduleRevision!==data.snapshot.scheduleRevision)progress=null;if(!progress){var latest=(data.records||[]).filter(function(r){return r.period>=1&&r.period<=7&&r.cycle>=1&&r.cycle<=data.snapshot.roundCount}).sort(function(a,b){return b.scannedAt-a.scannedAt})[0];if(latest)progress={date:monitorToday_(),scheduleRevision:data.snapshot.scheduleRevision,period:latest.period,cycle:latest.cycle,index:0,waitingForCycle2:false,nextCycleAt:null,at:latest.scannedAt}}return {date:monitorToday_(),snapshot:data.snapshot,records:data.records||[],progress:progress}}

function authorizeCommercialMail(){return 'حصة البريد المتبقية اليوم: '+MailApp.getRemainingDailyQuota()}



/* School-owned Drive. Tokens never leave Script Properties or reach the browser. */
function schoolDriveError_(message,code){var e=new Error(message);e.code=code||'school-drive';return e}
function schoolDriveProps_(){return PropertiesService.getScriptProperties()}
function schoolDriveKey_(id){return 'SCHOOL_DRIVE_'+id}
function schoolDriveLink_(id){var value=schoolDriveProps_().getProperty(schoolDriveKey_(id));return value?JSON.parse(value):null}
function schoolDriveSave_(id,value){schoolDriveProps_().setProperty(schoolDriveKey_(id),JSON.stringify(value))}
function schoolDriveConfig_(){var p=schoolDriveProps_(),id=p.getProperty('SCHOOL_GOOGLE_CLIENT_ID'),secret=p.getProperty('SCHOOL_GOOGLE_CLIENT_SECRET'),redirect=commercialPortal_()+'/google-drive-callback.html';if(!id||!id.endsWith('.apps.googleusercontent.com')||!secret||!/^https:\/\//.test(redirect||''))throw schoolDriveError_('يلزم إعداد ربط Google مرة واحدة لدى مالك مرصاد','google-not-configured');return {id:id,secret:secret,redirect:redirect}}
function schoolDrivePublic_(school){var c;try{schoolDriveConfig_();c=true}catch(e){c=false}var v=schoolDriveLink_(school.id);return {configured:c,connected:!!v&&!v.revoked,email:v&&v.email||'',fromDate:v&&v.fromDate||null,folderUrl:v&&v.rootId?'https://drive.google.com/drive/folders/'+v.rootId:null,localBackupSeparate:true}}
function schoolDriveAdmin_(registry,p){var a=registry.authorize(p.key,true);if(a.role!=='admin')throw schoolDriveError_('ربط Drive يتطلب دخول إدارة المدرسة','school-admin-required');return a.school}
function schoolDriveBegin_(registry,p){
 var school=schoolDriveAdmin_(registry,p),c=schoolDriveConfig_(),state=commercialRandom_(),verifier=commercialRandom_()+commercialRandom_(),nonce=commercialRandom_();
 var challenge=Utilities.base64EncodeWebSafe(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,verifier,Utilities.Charset.UTF_8)).replace(/=+$/,'');
 var props=schoolDriveProps_();if(props.getProperties)Object.keys(props.getProperties()).filter(function(k){return k.indexOf('SCHOOL_GOOGLE_STATE_')===0}).forEach(function(k){try{if(Date.now()-JSON.parse(props.getProperty(k)).at>600000)props.deleteProperty(k)}catch(ignore){props.deleteProperty(k)}});
 props.setProperty('SCHOOL_GOOGLE_STATE_'+commercialHash_(state),JSON.stringify({schoolId:school.id,sessionHash:commercialHash_(p.key),at:Date.now(),verifier:verifier,nonce:nonce}));
 var params={client_id:c.id,redirect_uri:c.redirect,response_type:'code',scope:'openid email https://www.googleapis.com/auth/drive.file',access_type:'offline',prompt:'consent select_account',state:state,nonce:nonce,code_challenge:challenge,code_challenge_method:'S256'};
 return {authorizationUrl:'https://accounts.google.com/o/oauth2/v2/auth?'+Object.keys(params).map(function(k){return encodeURIComponent(k)+'='+encodeURIComponent(params[k])}).join('&')};
}
function schoolDriveConsumeState_(state,schoolId,sessionHash){
 if(!/^[a-f0-9]{64}$/.test(state||''))throw schoolDriveError_('رابط الربط غير صالح أو منتهي');var props=schoolDriveProps_(),key='SCHOOL_GOOGLE_STATE_'+commercialHash_(state),raw=props.getProperty(key);if(!raw)throw schoolDriveError_('انتهى رابط الربط؛ اضغط زر الربط مجددًا');var v=JSON.parse(raw);if(v.schoolId!==schoolId||!monitorEqual_(v.sessionHash,sessionHash))throw schoolDriveError_('الربط لا يخص جلسة هذه المدرسة؛ أعد الربط من حسابك');props.deleteProperty(key);if(!Number.isFinite(v.at)||Date.now()-v.at>600000||v.at>Date.now()+10000)throw schoolDriveError_('انتهى رابط الربط');return v;
}
function schoolDriveJsonFetch_(url,options,message){var response=UrlFetchApp.fetch(url,{...options,muteHttpExceptions:true}),code=response.getResponseCode(),value;try{value=JSON.parse(response.getContentText())}catch(ignore){throw schoolDriveError_(message)}if(code<200||code>=300)throw schoolDriveError_(message);return value}
function schoolDriveCallback_(registry,p){
 var school=schoolDriveAdmin_(registry,p),state=schoolDriveConsumeState_(p.state,school.id,commercialHash_(p.key));
 if(p.error||!p.code)throw schoolDriveError_('لم تكتمل موافقة Google؛ لم يتغير الحفظ الحالي');var c=schoolDriveConfig_();
 var token=schoolDriveJsonFetch_('https://oauth2.googleapis.com/token',{method:'post',payload:{grant_type:'authorization_code',code:p.code,client_id:c.id,client_secret:c.secret,redirect_uri:c.redirect,code_verifier:state.verifier}},'تعذر إتمام موافقة Google؛ أعد الربط');
 if(!token.access_token||!String(token.scope||'').split(' ').includes('https://www.googleapis.com/auth/drive.file'))throw schoolDriveError_('لم تُمنح صلاحية ملفات مرصاد المطلوبة');
 var account=schoolDriveJsonFetch_('https://openidconnect.googleapis.com/v1/userinfo',{headers:{Authorization:'Bearer '+token.access_token}},'تعذر التحقق من حساب Google');
 if(!account.sub||!account.email||account.email_verified!==true)throw schoolDriveError_('حساب Google غير مؤكد');var old=schoolDriveLink_(school.id);
 if(old&&old.sub!==account.sub)throw schoolDriveError_('أعد ربط حساب Google نفسه لحماية الأرشيف الموجود؛ تغيير الحساب يحتاج نقلًا منفصلًا');
 var refresh=token.refresh_token||old&&old.refreshToken;if(!refresh)throw schoolDriveError_('لم يُمنح الحفظ المستمر؛ أعد الموافقة على الربط');
 var link={sub:account.sub,email:account.email,refreshToken:refresh,accessToken:token.access_token,expiresAt:Date.now()+Math.max(60,Math.min(3600,Number(token.expires_in)||3600))*1000,rootId:old&&old.rootId||null,fromDate:old&&old.fromDate||null,revoked:false};
 if(link.rootId){var existingRoot=schoolDriveRaw_(link.accessToken,'get','https://www.googleapis.com/drive/v3/files/'+encodeURIComponent(link.rootId)+'?fields=id,mimeType,appProperties,trashed');if(existingRoot.trashed||existingRoot.mimeType!=='application/vnd.google-apps.folder'||existingRoot.appProperties?.mirsadSchool!==school.id)throw schoolDriveError_('مجلد المدرسة غير متاح؛ أعده من سلة Drive أو تواصل مع المالك دون حذف الأرشيف')}
 if(!link.rootId){var q="trashed=false and mimeType='application/vnd.google-apps.folder' and appProperties has { key='mirsadSchool' and value='"+school.id+"' } and appProperties has { key='mirsadKind' and value='root' }",found=schoolDriveRaw_(link.accessToken,'get','https://www.googleapis.com/drive/v3/files?q='+encodeURIComponent(q)+'&fields=files(id)&pageSize=10');if((found.files||[]).length>1)throw schoolDriveError_('وجدت عدة مجلدات للمدرسة؛ يلزم تحديد الأرشيف الصحيح قبل الربط');if(found.files?.length===1)link.rootId=found.files[0].id;}
 if(!link.rootId){var root=schoolDriveRaw_(link.accessToken,'post','https://www.googleapis.com/drive/v3/files?fields=id',{name:'مرصاد — '+String(school.profile.school||school.email).slice(0,160),mimeType:'application/vnd.google-apps.folder',appProperties:{mirsadSchool:school.id,mirsadKind:'root'}});link.rootId=root.id;}
 if(!link.fromDate){var today=monitorToday_(),legacy=DriveApp.getFolderById(school.rootId),it=legacy.getFoldersByName('توثيق غياب '+today);link.fromDate=today;if(it.hasNext()){var day=it.next(),files=day.getFilesByName('attendance.json');if(files.hasNext()){var next=new Date(Date.parse(today+'T12:00:00Z')+86400000);link.fromDate=next.toISOString().slice(0,10)}}}
 schoolDriveSave_(school.id,link);return schoolDrivePublic_(school);
}
function schoolDriveToken_(school){
 var cache=COMMERCIAL_REQUEST_CACHE_;if(cache&&cache.schoolAccessToken)return cache.schoolAccessToken;var link=schoolDriveLink_(school.id);if(!link||link.revoked)throw schoolDriveError_('أعد ربط Google Drive للمدرسة؛ لم يُحوّل الحفظ إلى حساب آخر','google-reconnect');
 if(!link.accessToken||link.expiresAt<Date.now()+60000){var c=schoolDriveConfig_();var response=UrlFetchApp.fetch('https://oauth2.googleapis.com/token',{method:'post',payload:{grant_type:'refresh_token',refresh_token:link.refreshToken,client_id:c.id,client_secret:c.secret},muteHttpExceptions:true}),token;try{token=JSON.parse(response.getContentText())}catch(ignore){throw schoolDriveError_('تعذر الاتصال بـ Google؛ أعد المحاولة')}if(response.getResponseCode()!==200){if(token.error==='invalid_grant'){link.revoked=true;delete link.accessToken;delete link.refreshToken;schoolDriveSave_(school.id,link)}throw schoolDriveError_('تعذر تجديد صلاحية Drive؛ أعد الربط من إعدادات المدرسة','google-reconnect')}if(!token.access_token)throw schoolDriveError_('أعد ربط Drive');link.accessToken=token.access_token;link.expiresAt=Date.now()+(Number(token.expires_in)||3600)*1000;schoolDriveSave_(school.id,link)}
 if(cache)cache.schoolAccessToken=link.accessToken;return link.accessToken;
}
function schoolDriveUses_(school,date){var link=schoolDriveLink_(school.id);return !!link&&monitorDateValid_(date)&&date>=link.fromDate}
function commercialStorageFor_(school,date){var linked=schoolDriveUses_(school,date),site=school._site,rootId=site?(linked?site.remoteRootId:site.localRootId):(linked?schoolDriveLink_(school.id).rootId:school.rootId);if(!rootId)commercialMultiError_('افتح قائمة المدارس لتجهيز مساحة حفظ المدرسة','site-storage-required');return {remote:linked,rootId:rootId}}
function commercialStorageToken_(fileId){if(!COMMERCIAL_CONTEXT_||!COMMERCIAL_CONTEXT_.storage?.remote)return ScriptApp.getOAuthToken();if(fileId)try{commercialSchoolDrive_().getFileById(fileId,true)}catch(error){if(error.httpStatus!==404)throw error;}return schoolDriveToken_(COMMERCIAL_CONTEXT_.school)}
function schoolDriveRaw_(token,method,url,payload,contentType){var options={method:method,headers:{Authorization:'Bearer '+token},muteHttpExceptions:true};if(payload!==undefined){options.contentType=contentType||'application/json';options.payload=typeof payload==='string'||Array.isArray(payload)?payload:JSON.stringify(payload)}var response=UrlFetchApp.fetch(url,options),code=response.getResponseCode();if(code<200||code>=300){var error=schoolDriveError_(code===401||code===403?'تعذر الوصول إلى Drive المدرسة؛ تحقق من الربط والمساحة والصلاحية':'تعذر حفظ ملفات المدرسة في Drive ('+code+')',code===401?'google-reconnect':'school-drive');error.httpStatus=code;throw error;}return code===204?{}:JSON.parse(response.getContentText())}
function schoolDriveAdapter_(school){
 var token=schoolDriveToken_(school),api='https://www.googleapis.com/drive/v3/',cache={};
 var fields='id,name,mimeType,parents,appProperties,trashed,permissions(type,role),size';
 function req(method,url,body,type){var value;try{value=schoolDriveRaw_(token,method,url,body,type)}catch(e){if(e.code==='google-reconnect'){var link=schoolDriveLink_(school.id);link.expiresAt=0;schoolDriveSave_(school.id,link)}throw e}if(method!=='get')cache={};return value}
 function meta(id,allowTrashed){if(!/^[A-Za-z0-9_-]{3,200}$/.test(id||''))throw schoolDriveError_('معرّف ملف غير صالح');var key='meta:'+id;if(!cache[key])cache[key]=req('get',api+'files/'+encodeURIComponent(id)+'?fields='+encodeURIComponent(fields));var m=cache[key];if((m.trashed&&!allowTrashed)||m.appProperties?.mirsadSchool!==school.id)throw schoolDriveError_('الملف لا يتبع هذه المدرسة','school-drive-scope');return m}
 function iterator(values){var index=0;return {hasNext:function(){return index<values.length},next:function(){if(index>=values.length)throw schoolDriveError_('نهاية الملفات');return wrap(values[index++])}}}
 function list(parent,name,folders){meta(parent);var q="'"+parent+"' in parents and trashed=false and appProperties has { key='mirsadSchool' and value='"+school.id+"' }";if(name!==null)q+=" and name='"+String(name).replace(/\\/g,'\\\\').replace(/'/g,"\\'")+"'";q+=folders?" and mimeType='application/vnd.google-apps.folder'":" and mimeType!='application/vnd.google-apps.folder'";var key='list:'+q;if(!cache[key]){var all=[],page='';do{var value=req('get',api+'files?q='+encodeURIComponent(q)+'&pageSize=1000&fields='+encodeURIComponent('nextPageToken,files('+fields+')')+(page?'&pageToken='+encodeURIComponent(page):''));all=all.concat(value.files||[]);page=value.nextPageToken||''}while(page);cache[key]=all}return iterator(cache[key])}
 function create(parent,name,mime,body){meta(parent);var metadata={name:String(name),parents:[parent],mimeType:mime,appProperties:{mirsadSchool:school.id}};if(mime==='application/vnd.google-apps.folder')return wrap(req('post',api+'files?fields='+encodeURIComponent(fields),metadata));var boundary='mirsad_'+Utilities.getUuid().replace(/-/g,''),prefix='--'+boundary+'\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n'+JSON.stringify(metadata)+'\r\n--'+boundary+'\r\nContent-Type: '+mime+'\r\n\r\n',bytes=typeof body==='string'?Utilities.newBlob(body).getBytes():body;var payload=Utilities.newBlob(prefix).getBytes().concat(Array.from(bytes),Utilities.newBlob('\r\n--'+boundary+'--').getBytes());return wrap(req('post','https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields='+encodeURIComponent(fields),payload,'multipart/related; boundary='+boundary))}
 function wrap(m){return {getId:function(){return m.id},getName:function(){return m.name},getUrl:function(){return m.mimeType==='application/vnd.google-apps.folder'?'https://drive.google.com/drive/folders/'+m.id:'https://drive.google.com/file/d/'+m.id+'/view'},getSharingAccess:function(){var v=meta(m.id);if(!Array.isArray(v.permissions))throw schoolDriveError_('تعذر التحقق من خصوصية ملف المدرسة');return v.permissions.some(function(p){return p.type==='anyone'})?DriveApp.Access.ANYONE_WITH_LINK:DriveApp.Access.PRIVATE},setSharing:function(access){if(access!==DriveApp.Access.PRIVATE)throw schoolDriveError_('صور المدرسة خاصة؛ لا تُشارك للعامة');if(this.getSharingAccess()!==DriveApp.Access.PRIVATE)throw schoolDriveError_('ألغِ المشاركة العامة من ملف المدرسة قبل المتابعة');return this},getFilesByName:function(name){return list(m.id,name,false)},getFoldersByName:function(name){return list(m.id,name,true)},getFiles:function(){return list(m.id,null,false)},getFolders:function(){return list(m.id,null,true)},createFolder:function(name){return create(m.id,name,'application/vnd.google-apps.folder')},createFile:function(a,b,c){return typeof a==='string'?create(m.id,a,c||'text/plain',String(b)):create(m.id,a.getName(),a.getContentType(),a.getBytes())},getBlob:function(){meta(m.id);var response=UrlFetchApp.fetch(api+'files/'+encodeURIComponent(m.id)+'?alt=media',{headers:{Authorization:'Bearer '+token},muteHttpExceptions:true});if(response.getResponseCode()!==200)throw schoolDriveError_('تعذر قراءة ملف المدرسة');return response.getBlob()},setContent:function(body){meta(m.id);req('patch','https://www.googleapis.com/upload/drive/v3/files/'+encodeURIComponent(m.id)+'?uploadType=media',String(body),'application/json; charset=UTF-8');return this},setTrashed:function(value){meta(m.id);req('patch',api+'files/'+encodeURIComponent(m.id),{trashed:!!value});return this}}}
 return {Access:DriveApp.Access,Permission:DriveApp.Permission,getFolderById:function(id){var m=meta(id);if(m.mimeType!=='application/vnd.google-apps.folder')throw schoolDriveError_('ليس مجلدًا');return wrap(m)},getFileById:function(id,allowTrashed){return wrap(meta(id,!!allowTrashed))},createFolder:function(){throw schoolDriveError_('لا ينشأ مجلد خارج جذر المدرسة')}};
}
function commercialSchoolDrive_(){if(!COMMERCIAL_CONTEXT_||!COMMERCIAL_CONTEXT_.storage?.remote)return DriveApp;var cache=COMMERCIAL_REQUEST_CACHE_;if(!cache.schoolAdapter)cache.schoolAdapter=schoolDriveAdapter_(COMMERCIAL_CONTEXT_.school);return cache.schoolAdapter}
function schoolDriveDates_(school){var dates={},roots=[{remote:false,rootId:school.rootId}],link=schoolDriveLink_(school.id);if(link&&school._site?.remoteRootId)roots.push({remote:true,rootId:school._site.remoteRootId});else if(link&&!school._site)roots.push({remote:true,rootId:link.rootId});var previous=COMMERCIAL_CONTEXT_,previousRoot=MONITOR_ROOT;try{for(var storage of roots){COMMERCIAL_CONTEXT_={school:school,role:previous.role,key:previous.key,storage:storage};MONITOR_ROOT=storage.rootId;var folders=commercialSchoolDrive_().getFolderById(storage.rootId).getFolders();while(folders.hasNext()){var match=/^توثيق غياب (\d{4}-\d{2}-\d{2})$/.exec(folders.next().getName());if(match&&schoolDriveUses_(school,match[1])===storage.remote)dates[match[1]]=true}}}finally{COMMERCIAL_CONTEXT_=previous;MONITOR_ROOT=previousRoot}return {dates:Object.keys(dates).sort().reverse()}}



/* Per-service / per-school remote choices; no attendance mutation from a website toggle. */
function monitorAutoLinksRead_(props){var v;try{v=JSON.parse(props.getProperty('MONITOR_AUTO_LINKS_CONTROL')||'null')}catch(ignore){}if(!v||typeof v.enabled!=='boolean'||!Number.isInteger(v.revision)||v.revision<1)return {enabled:false,mode:'missing',revision:0,updatedAt:null};v.mode=v.mode==='continuous'?'continuous':'missing';return v}
function monitorAutoLinksPublic_(props,canManage){var c=monitorAutoLinksRead_(props),d=null;try{d=JSON.parse(props.getProperty('MONITOR_AUTO_LINKS_DEVICE')||'null')}catch(ignore){}var ack=!!d&&d.revision===c.revision&&d.enabled===c.enabled&&(d.mode||'missing')===c.mode;return {supported:true,refreshModes:true,canManage:canManage===true,control:{enabled:c.enabled,mode:c.mode,revision:c.revision,updatedAt:c.updatedAt},device:d,acknowledged:ack,serverTime:Date.now()}}
function monitorAutoLinksSet_(p,props){var current=monitorAutoLinksRead_(props),mode=p.mode===undefined?current.mode:p.mode;if(typeof p.enabled!=='boolean'||['continuous','missing'].indexOf(mode)<0||!Number.isInteger(p.expectedRevision)||p.expectedRevision<0||typeof p.requestId!=='string'||!/^[A-Za-z0-9_-]{8,80}$/.test(p.requestId))throw new Error('طلب إعداد غير صالح');if(current.requestId===p.requestId&&current.enabled===p.enabled&&current.mode===mode)return monitorAutoLinksPublic_(props,true);if(current.revision!==p.expectedRevision)throw new Error('تغيّر الإعداد من جهاز آخر؛ حدّث الصفحة ثم أعد الاختيار');props.setProperty('MONITOR_AUTO_LINKS_CONTROL',JSON.stringify({enabled:p.enabled,mode:mode,revision:current.revision+1,updatedAt:Date.now(),requestId:p.requestId}));return monitorAutoLinksPublic_(props,true)}
function monitorAutoLinksAck_(p,props){var c=monitorAutoLinksRead_(props),r=p.autoLinksRemote;if(r&&Number.isInteger(r.revision)&&r.revision===c.revision&&r.enabled===c.enabled&&(r.mode||'missing')===c.mode){var d={revision:c.revision,enabled:r.enabled,mode:c.mode,receivedAt:Date.now(),appliedAt:Number.isFinite(r.appliedAt)?r.appliedAt:null,date:monitorToday_(),remaining:Number.isInteger(r.remaining)&&r.remaining>=0&&r.remaining<=10000?r.remaining:null,complete:r.complete===true,notes:(Array.isArray(r.notes)?r.notes:[]).slice(-5).filter(function(n){return n&&typeof n.text==='string'}).map(function(n){return {at:Number.isFinite(n.at)?n.at:null,text:n.text.slice(0,240),kind:n.kind==='warning'?'warning':'info'}})};props.setProperty('MONITOR_AUTO_LINKS_DEVICE',JSON.stringify(d))}return monitorAutoLinksRead_(props)}



function commercialValidateBankAccounts_(value){
 if(!Array.isArray(value)||value.length>10)throw new Error('يمكن إضافة عشرة حسابات بنكية كحد أقصى');
 return value.map(function(v){
  if(!v||typeof v!=='object')throw new Error('بيانات الحساب البنكي غير صحيحة');
  var bankName=String(v.bankName||'').trim(),beneficiary=String(v.beneficiary||'').trim(),iban=String(v.iban||'').replace(/\s/g,'').toUpperCase(),accountNumber=String(v.accountNumber||'').replace(/\s/g,'');
  if(!bankName||bankName.length>120||!beneficiary||beneficiary.length>160||(!iban&&!accountNumber)||iban&&!/^[A-Z]{2}[0-9]{2}[A-Z0-9]{10,30}$/.test(iban)||accountNumber&&!/^[0-9]{4,34}$/.test(accountNumber))throw new Error('أكمل اسم البنك والمستفيد ورقم الحساب أو الآيبان بشكل صحيح');
  return {bankName:bankName,beneficiary:beneficiary,iban:iban,accountNumber:accountNumber};
 });
}
function commercialOwnerSettingsPublic_(r){var s=r.portalSettings||{};return {accounts:(s.accounts||[]).map(function(a){return {bankName:a.bankName,beneficiary:a.beneficiary,iban:a.iban||'',accountNumber:a.accountNumber||''}}),updatedAt:s.updatedAt||null}}
function commercialUsageTouch_(school,kind,client,active,at){
 if(['website','monitor'].indexOf(kind)<0||typeof active!=='boolean'||!client||!Number.isFinite(at))return;
 var root=school.usage||(school.usage={since:at}),u=root[kind]||(root[kind]={totalMs:0,pulses:0,days:{},clients:{}}),old=u.clients[client],delta=old&&old.active?at-old.at:0;
 if(delta<0||delta>180000)delta=0;
 // Credit only observed connected intervals, split at Riyadh midnight.
 if(delta>0){var start=at-delta;while(start<at){var date=new Date(start+10800000).toISOString().slice(0,10),end=Math.min(at,Date.parse(date+'T00:00:00Z')+86400000-10800000),day=u.days[date]||(u.days[date]={ms:0});day.ms+=end-start;start=end}u.totalMs+=delta}
 u.pulses++;u.lastSeen=at;u.clients[client]={at:at,active:active};
 var dates=Object.keys(u.days).sort();dates.slice(0,Math.max(0,dates.length-90)).forEach(function(k){delete u.days[k]});
 Object.keys(u.clients).filter(function(k){return at-u.clients[k].at>86400000}).forEach(function(k){delete u.clients[k]});
}
function commercialUsageSummary_(school,at){
 function summarize(kind){var u=school.usage&&school.usage[kind],today=new Date(at+10800000).toISOString().slice(0,10),clients=u?Object.values(u.clients||{}).filter(function(c){return at>=c.at&&at-c.at<180000}):[],previous=Object.values(school[kind==='website'?'webDevices':'extensionDevices']||{}).reduce(function(n,d){return Math.max(n,Number(d.lastSeen)||0)},0);return {measured:!!u,connected:clients.length>0,active:clients.some(function(c){return c.active}),totalMs:u?u.totalMs||0:null,todayMs:u&&u.days[today]?u.days[today].ms:0,lastSeen:u?u.lastSeen:previous||null,days:u?Object.keys(u.days).sort().map(function(date){return {date:date,ms:u.days[date].ms}}):[]}}
 function logins(key){return Object.values(school[key]||{}).reduce(function(n,d){return n+(Number(d.logins)||0)},0)}
 return {since:school.usage?school.usage.since:null,website:summarize('website'),monitor:summarize('monitor'),websiteLogins:logins('webDevices'),extensionLogins:logins('extensionDevices')};
}



/* Shared deterministic safety rules; no attendance mutation or timer ownership. */
var MirsadVideoCore=(()=>{
 const SAFETY_MS=30000,MIN_CLIP_MS=5000,MAX_CLIP_MS=600000;
 const normalize=s=>String(s||'').normalize('NFKC').replace(/\s+/g,' ').trim();
 function gap(run,now,minBudget=MIN_CLIP_MS,tail=null){
  if(!run?.running||run.paused||run.testMode||run.backtestMode||run.immediateMode||run.calendarTrial||run.current||run.meetingScan||!Number.isInteger(run.cycle)||run.cycle<1||run.cycle>3)return null;
  if(run.waitingForCycle2&&run.cycle===3)return null;const final= !run.waitingForCycle2;if(final&&(!tail||tail.startedAt!==run.startedAt||(tail.controlEpoch||0)!==(run.controlEpoch||0)||tail.period!==run.period||tail.cycle!==run.cycle||!run.periodItems?.length||run.index<run.periodItems.length))return null;const boundary=final?tail.endAt:run.nextCycleAt;if(!Number.isFinite(boundary))return null;const deadline=boundary-SAFETY_MS,budget=deadline-now;
  if(budget<minBudget||budget>12*60*60*1000)return null;
  return {period:Number(run.period),afterCycle:run.cycle,nextCycleAt:boundary,boundary:final?'lessonEnd':'nextCycle',deadline,budget,key:[run.startedAt,run.controlEpoch||0,run.period,run.cycle,boundary].join('|')};
 }
 function settings(input,roundCount){
  if(!Number.isInteger(input.minutes)||input.minutes<1||input.minutes>10)throw Error('اختر مدة من دقيقة إلى 10 دقائق');
  if(!Array.isArray(input.cycles)||input.cycles.some(c=>!Number.isInteger(c)||c<1||c>roundCount))throw Error('اختر دورة من الدورات المتاحة للحصة');
  return {...input,cycles:[...new Set(input.cycles)].sort(),enabled:input.cycles.length>0};
 }
 function budget(run,job,now,tail=null){const g=gap(run,now,0,tail);if(!g||g.key!==job.gapKey||g.period!==job.period||g.afterCycle!==job.afterCycle)return 0;return Math.max(0,Math.min(job.minutes*60000,g.deadline-now,Number(job.deadline)-now,MAX_CLIP_MS))}
 function shouldStop(run,job,now){return budget(run,job,now)<1}
 function safeName(value){return normalize(value).replace(/[\\/:*?"<>|\u0000-\u001f]/g,'_').replace(/[ .]+$/g,'').slice(0,90)||'معلم'}
 function fileName(job){return safeName(job.teacherName)+'_ح'+job.period+'_بعد'+job.afterCycle+'_'+job.date+'_'+job.id+'.webm'}
 return {SAFETY_MS,MIN_CLIP_MS,MAX_CLIP_MS,gap,settings,budget,shouldStop,safeName,fileName};
})();

/* Queue owns video metadata only. Caller authenticates writer/admin and scopes storage. */
function createMirsadVideoService(env){
 const now=env.now,load=()=>env.load()||{revision:0,configs:[],jobs:[]},save=env.save;
 const publicJob=j=>{const {lease,uploadSession,url,...rest}=j;return rest};
 const view=s=>({supported:true,canManage:env.admin,serverTime:now(),revision:s.revision,generation:s.generation||0,configs:s.configs,jobs:s.jobs.map(publicJob),device:env.deviceRead()});
 const requireAdmin=()=>{if(!env.admin)throw Error('التسجيل يتطلب دخول إدارة الموقع')};
 const requireWriter=()=>{if(!env.writer)throw Error('التسجيل يتطلب جهاز الرصد المرتبط')};
 function currentJob(s,input){const j=s.jobs.find(j=>j.id===input.id);if(!j||j.lease!==input.lease)throw Error('جلسة فيديو غير صالحة');return j}
 return {request(action,p){
  if(!env.admin&&!env.writer)throw Error('دخول غير مصرح لتسجيل الفيديو');const s=load();
  if(action==='videoStatus')return view(s);
  if(action==='videoConfigure'){
   requireAdmin();if(p.expectedRevision!==s.revision)throw Error('تغير اختيار التسجيل؛ أعد فتح إعداداته');
   const snap=env.snapshot();if(p.scheduleRevision!==snap.scheduleRevision)throw Error('تغير جدول الحصص؛ حدّث الجدول');
   const lesson=snap.lessons.find(l=>l.teacherId===p.teacherId&&Number(l.period)===Number(p.period));if(!lesson?.url)throw Error('لا يوجد رابط صالح للحصة المطلوبة');
   const config=MirsadVideoCore.settings({teacherId:lesson.teacherId,teacherName:lesson.teacherName,period:Number(lesson.period),minutes:p.minutes,cycles:p.cycles,scheduleRevision:snap.scheduleRevision},snap.roundCount);
   if(config.enabled)s.configs=s.configs.map(c=>{if(c.teacherId===config.teacherId||c.period!==config.period)return c;const cycles=c.cycles.filter(n=>!config.cycles.includes(n));return {...c,cycles,enabled:cycles.length>0}}).filter(c=>c.teacherId===config.teacherId||c.period!==config.period||c.cycles.length>0);
   const old=s.configs.findIndex(c=>c.teacherId===config.teacherId&&c.period===config.period);if(old<0){if(s.configs.length>=100)throw Error('وصلت اختيارات التسجيل إلى الحد الأقصى');s.configs.push(config)}else s.configs[old]=config;
   s.revision++;save(s);return {...view(s),saved:true};
  }
  if(action==='videoPoll'){
   requireWriter();env.deviceWrite({ready:p.ready===true,at:now(),sessionId:String(p.sessionId||'').slice(0,80),resetPendingDates:Array.isArray(p.resetPendingDates)?p.resetPendingDates.filter(d=>/^\d{4}-\d{2}-\d{2}$/.test(d)).slice(0,200):[]});
   let changed=false;for(const job of s.jobs)if(['joining','recording'].includes(job.phase)&&now()>=job.deadline){job.phase='failed';job.error='انتهى فاصل التسجيل؛ الرصد له الأولوية';job.updatedAt=now();changed=true}
   if(changed)save(s);
   const active=s.jobs.find(j=>['joining','recording'].includes(j.phase));if(active){const selected=s.configs.find(c=>c.teacherId===active.teacherId&&c.period===active.period&&c.scheduleRevision===active.scheduleRevision&&c.enabled&&c.cycles.includes(active.afterCycle));if(!selected){active.phase='failed';active.error='أُلغي اختيار التسجيل';active.updatedAt=now();save(s);return {job:null,cancelled:active.id,serverTime:now()}}if(p.ready&&p.recordingId===active.id&&p.gap?.key===active.gapKey){active.updatedAt=now();save(s)}return {job:{...active},serverTime:now()};}
   if(p.ready!==true||!p.gap||!Number.isFinite(p.gap.nextCycleAt))return {job:null,serverTime:now()};
   const g=p.gap;if(typeof g.key!=='string'||!g.key||g.key.length>200||!Number.isInteger(g.period)||g.period<1||g.period>7||g.deadline!==g.nextCycleAt-30000||g.deadline-now()<5000||g.deadline-now()>12*60*60*1000||![1,2,3].includes(g.afterCycle))return {job:null,serverTime:now()};
   const snap=env.snapshot();if(g.afterCycle>snap.roundCount)return {job:null,serverTime:now()};
   const config=s.configs.find(c=>c.enabled&&c.period===g.period&&c.cycles.includes(g.afterCycle)&&c.scheduleRevision===snap.scheduleRevision);
   if(!config||s.jobs.some(j=>j.gapKey===g.key)||(s.usedGaps||[]).includes(g.key))return {job:null,serverTime:now()};
   if(s.jobs.length>=100)throw Error('وصلت تسجيلات اليوم إلى الحد الأقصى');
   const lesson=snap.lessons.find(l=>l.teacherId===config.teacherId&&Number(l.period)===config.period);if(!lesson?.url)return {job:null,serverTime:now()};
   const job={generation:s.generation||0,id:env.id(),lease:env.id(),date:env.date,teacherId:config.teacherId,teacherName:config.teacherName,period:config.period,afterCycle:g.afterCycle,minutes:config.minutes,deadline:g.deadline,gapKey:g.key,scheduleRevision:snap.scheduleRevision,url:lesson.url,phase:'joining',createdAt:now(),updatedAt:now(),localSaved:false,driveSaved:false};s.jobs.push(job);save(s);return {job,serverTime:now()};
  }
  requireWriter();const j=currentJob(s,p);
  if(action==='videoUpdate'){
   if(!['joining','recording','saving','uploading','saved','failed'].includes(p.phase))throw Error('حالة فيديو غير صالحة');
   if(p.phase==='recording'&&(now()>=j.deadline||!['joining','recording'].includes(j.phase)))throw Error('لا يجوز التسجيل بعد انتهاء الفاصل');
   // Terminal capture failures cannot be turned into a successful recording by a late event.
   if(j.phase==='failed'&&p.phase==='recording')throw Error('جلسة التسجيل منتهية');
   if(j.driveSaved&&p.phase!=='failed')j.phase=j.localSaved||p.localSaved===true?'completed':'saved';else j.phase=p.phase;
   if(p.phase==='recording'&&!j.recordingStartedAt)j.recordingStartedAt=now();
   if(p.localSaved===true)j.localSaved=true;if(p.diskSaved===true){j.diskSaved=true;j.diskPaths=Array.isArray(p.diskPaths)?p.diskPaths.filter(x=>typeof x==='string').map(x=>x.slice(0,700)).slice(0,3):[]}if(typeof p.diskError==='string')j.diskError=p.diskError.slice(0,500);
   if(Number.isFinite(p.durationMs))j.durationMs=Math.max(0,Math.min(600000,p.durationMs));
   if(typeof p.error==='string')j.error=p.error.slice(0,500);j.updatedAt=now();save(s);return {saved:true,job:publicJob(j)};
  }
  if(action==='videoUploadBegin'){
   if(!['saving','uploading','saved'].includes(j.phase))throw Error('الفيديو ليس جاهزًا للرفع');
   if(!Number.isInteger(p.size)||p.size<1||p.size>200*1024*1024||!/^video\/webm(?:;.*)?$/.test(p.mime||''))throw Error('ملف فيديو غير صالح');
   if(j.driveSaved)return {complete:true,job:publicJob(j)};
   if(j.size&&j.size!==p.size)throw Error('تغير حجم ملف التسجيل');j.size=p.size;j.mime=p.mime;
   // Renew only the exact rejected session; keep the same verified destination file.
   if(p.rejectedSession&&p.rejectedSession===j.uploadSession)delete j.uploadSession;
   try{if(!j.uploadSession)j.uploadSession=env.uploadBegin(j)}catch(e){save(s);throw e}
   j.phase='uploading';save(s);return {uploadSession:j.uploadSession};
  }
  if(action==='videoUploadFinish'){
   if(j.driveSaved)return {saved:true,job:publicJob(j)};
   const file=env.uploadVerify(j,String(p.fileId||''));if(!file?.url)throw Error('لم يتأكد حفظ الفيديو في Drive');j.driveSaved=true;j.error='';j.driveUrl=file.url;j.phase=j.localSaved?'completed':'saved';delete j.uploadSession;j.updatedAt=now();save(s);return {saved:true,job:publicJob(j)};
  }
  throw Error('طلب تسجيل غير مدعوم');
 }};
}

// Restores an immutable saved copy; the displaced active table is archived first.
function monitorRestoreArchived_(root,p){
 if(p.date!==monitorToday_())throw new Error('إرجاع جدول الرصد النشط متاح لليوم الحالي فقط؛ الأيام السابقة للعرض');
 if(!/^[A-Za-z0-9_-]{8,120}$/.test(p.requestId||''))throw new Error('معرف الاسترجاع غير صالح');
 var folder=monitorScheduleFolder_(root,p.date,false),current=folder?monitorRead_(monitorFile_(folder,'attendance.json'),null):null;if(!current)throw new Error('لا يوجد جدول نشط؛ لم يُغيّر شيء');
 if(current.lastScheduleRestore?.requestId===p.requestId)return {restored:true,snapshot:current.snapshot,folderUrl:folder.getUrl(),previousVersion:current.lastScheduleRestore.previousVersion};
 if(current.snapshot.scheduleRevision!==p.expectedRevision)throw new Error('تغير الجدول النشط؛ حدّث قائمة النسخ قبل الاسترجاع');
 var saved=monitorArchivedData_(folder,p.restoreId);if(saved.snapshot.date!==p.date||saved.snapshot.sourceType!=='madrasati')throw new Error('النسخة لا تخص جدول مدرستي لهذا اليوم');
 var sourceFile=monitorFile_(root,'mirsad-timetable-source.json'),source=monitorRead_(sourceFile,null),schoolId=source?.schoolId||source?.payload?.schoolId;
 if(!/^[a-f0-9]{32}$/i.test(schoolId||''))throw new Error('تعذر التحقق من مدرسة الجدول؛ لم يُسترجع');
 var restored=JSON.parse(JSON.stringify(saved)),previousVersion=Utilities.getUuid();delete restored.archiveId;delete restored.archivedAt;
 restored.lastScheduleRestore={requestId:p.requestId,restoreId:p.restoreId,previousVersion:previousVersion,at:Date.now()};
 var payload={source:'madrasati',schoolId:schoolId,sourceUrl:'https://schools.madrasati.sa/SchoolManagment/Teachers?SchoolId='+schoolId,scheduleDate:restored.snapshot.sourceScheduleDate,importedForDate:p.date,teachers:restored.snapshot.teachers.map(function(t){return t.name}),lessons:restored.snapshot.lessons.map(function(l){return {teacher:l.teacherName,cellIndex:Number(l.period)+1,title:l.subject||'حصة',lesson:l.className||'غير محدد',time:'الحصة '+l.period,teams:l.url||'',linkState:l.url?'linked':'unprepared',...monitorCalendarFields_(l,l.url||'')}})};payload.totalTeachers=payload.teachers.length;payload.totalLessons=payload.lessons.length;payload=monitorMadrasatiPayload_(payload);
 var archive=monitorArchiveFolder_(folder,true);monitorWrite_(archive,previousVersion+'.json',{...current,archiveId:previousVersion,archivedAt:Date.now()});
 try{monitorWrite_(root,'mirsad-timetable-source.json',{...source,mode:'madrasati',schoolId:schoolId,payload:payload,updatedAt:Date.now()});monitorWrite_(folder,'attendance.json',restored)}catch(e){monitorWrite_(folder,'attendance.json',current);if(source)monitorWrite_(root,'mirsad-timetable-source.json',source);throw e}
 return {restored:true,snapshot:restored.snapshot,folderUrl:folder.getUrl(),previousVersion:previousVersion,records:(restored.records||[]).length,images:Object.keys(restored.evidence||{}).length};
}

function monitorVideoRequest_(p,props,attendanceRoot,writer,admin){
 if(!writer&&!admin)throw new Error('الفيديو خاص بإدارة الموقع وجهاز الرصد');
 var date=p.date||monitorToday_();if(!monitorDateValid_(date))throw new Error('تاريخ الفيديو غير صالح');
 if(['videoConfigure','videoPoll'].includes(p.action)&&date!==monitorToday_())throw new Error('التسجيل خاص بجدول اليوم فقط');
 var school=typeof COMMERCIAL_CONTEXT_!=='undefined'&&COMMERCIAL_CONTEXT_?COMMERCIAL_CONTEXT_.school:null,drive=commercialSchoolDrive_(),root=attendanceRoot,link=null;
 if(school){link=schoolDriveLink_(school.id);if(!link||!link.rootId||link.revoked){if(p.action==='videoStatus')return {supported:true,canManage:admin,driveRequired:true,revision:0,configs:[],jobs:[],device:null,serverTime:Date.now()};throw new Error('اربط Google Drive المدرسة أولًا لحفظ الفيديو في حسابها')}drive=schoolDriveAdapter_(school);root=drive.getFolderById(commercialVideoRoot_(school,link))}
 var stateName='mirsad-video-'+date+'.json',deviceKey='MONITOR_VIDEO_DEVICE_'+date;
 function token(){return school?schoolDriveToken_(school):ScriptApp.getOAuthToken()}
 function folder(){var parents=root.getFoldersByName('Videos'),parent=parents.hasNext()?parents.next():root.createFolder('Videos'),it=parent.getFoldersByName(date),f=it.hasNext()?it.next():parent.createFolder(date);var access=f.getSharingAccess();if(access===DriveApp.Access.ANYONE||access===DriveApp.Access.ANYONE_WITH_LINK)throw new Error('مجلد الفيديو يجب أن يكون خاصًا');return f}
 function google(url,options){options.headers={...(options.headers||{}),Authorization:'Bearer '+token()};options.muteHttpExceptions=true;return UrlFetchApp.fetch(url,options)}
 var service=createMirsadVideoService({date:date,admin:admin,writer:writer,now:Date.now,id:function(){return Utilities.getUuid()},load:function(){return monitorRead_(monitorFile_(root,stateName),null)},save:function(s){monitorWrite_(root,stateName,s)},deviceRead:function(){try{return JSON.parse(props.getProperty(deviceKey)||'null')}catch(e){return null}},deviceWrite:function(s){props.setProperty(deviceKey,JSON.stringify(s))},snapshot:function(){var selectedRoot=typeof attendanceRoot==="function"?attendanceRoot():attendanceRoot;var f=monitorScheduleFolder_(selectedRoot,date,false),data=f?monitorRead_(monitorFile_(f,'attendance.json'),null):null;if(!data||!data.snapshot)throw new Error('حمّل جدول اليوم أولًا');return data.snapshot},uploadBegin:function(job){
  var parent=folder();job.folderId=parent.getId();
  var metadata={name:MirsadVideoCore.fileName(job),mimeType:'video/webm',parents:[job.folderId],appProperties:{mirsadVideoJob:job.id,...school?{mirsadSchool:school.id}:{}}};
  if(!job.fileId){var created=google('https://www.googleapis.com/drive/v3/files?fields=id',{method:'post',contentType:'application/json',payload:JSON.stringify(metadata)});var value;try{value=JSON.parse(created.getContentText())}catch(e){throw new Error('تعذر إنشاء ملف الفيديو')};if(created.getResponseCode()<200||created.getResponseCode()>=300||!value.id)throw new Error('تعذر تجهيز ملف الفيديو في Drive');job.fileId=value.id}
  var response=google('https://www.googleapis.com/upload/drive/v3/files/'+encodeURIComponent(job.fileId)+'?uploadType=resumable&fields=id,webViewLink',{method:'patch',contentType:'application/json',headers:{'X-Upload-Content-Type':'video/webm','X-Upload-Content-Length':String(job.size)},payload:'{}'});
  var location=response.getAllHeaders().Location||response.getAllHeaders().location;
  if(response.getResponseCode()<200||response.getResponseCode()>=300||!/^https:\/\/www\.googleapis\.com\/upload\/drive\/v3\/files(?:\/[A-Za-z0-9_-]+)?\?/.test(String(location||'')))throw new Error('تعذر تجهيز رفع الفيديو إلى Drive');return String(location);
 },uploadVerify:function(job,id){
  if(!/^[A-Za-z0-9_-]{10,200}$/.test(id)||job.fileId&&job.fileId!==id)throw new Error('معرف ملف الفيديو غير صالح');
  var response=google('https://www.googleapis.com/drive/v3/files/'+encodeURIComponent(id)+'?fields=id,size,mimeType,parents,appProperties,webViewLink,trashed',{method:'get'}),file;
  try{file=JSON.parse(response.getContentText())}catch(e){throw new Error('تعذر التحقق من ملف الفيديو')}
  if(response.getResponseCode()!==200||file.trashed||Number(file.size)!==job.size||file.mimeType!=='video/webm'||!file.parents?.includes(job.folderId)||file.appProperties?.mirsadVideoJob!==job.id||school&&file.appProperties?.mirsadSchool!==school.id)throw new Error('ملف الفيديو لا يطابق تسجيل الحصة');
  return {url:'https://drive.google.com/file/d/'+id+'/view'};
 }});
 var result=service.request(p.action,p);if(p.action==='videoStatus')result.driveDeletionPending=monitorVideoPending_(props,date,undefined,'day')||monitorVideoPending_(props,date,undefined,'range');if(p.action==='videoPoll'){result.resets=monitorVideoResets_(props);result.videoDeletes=monitorVideoRangeUpdates_(props,root,p.rangeResetVersions)}return result;
}
function monitorVideoResets_(props){try{return JSON.parse(props.getProperty('MONITOR_VIDEO_RESETS')||'{}')}catch(e){return {}}}
function monitorVideoReset_(date,props,attendanceRoot,requestId){
 if(!monitorDateValid_(date))throw new Error('تاريخ تصفير الفيديو غير صالح');
 var root=attendanceRoot,school=typeof COMMERCIAL_CONTEXT_!=='undefined'&&COMMERCIAL_CONTEXT_?COMMERCIAL_CONTEXT_.school:null;
 if(school){var link=schoolDriveLink_(school.id);if(link&&link.rootId){root=schoolDriveAdapter_(school).getFolderById(link.rootId)}else return}
 var resets=monitorVideoResets_(props),key='MONITOR_VIDEO_RESET_REQUEST_'+date;
 if(props.getProperty(key)!==requestId){resets[date]=(resets[date]||0)+1;var keys=Object.keys(resets);while(keys.length>200)delete resets[keys.shift()];props.setProperty('MONITOR_VIDEO_RESETS',JSON.stringify(resets));props.setProperty(key,requestId)}
 var stateName='mirsad-video-'+date+'.json',old=monitorRead_(monitorFile_(root,stateName),{});monitorWrite_(root,stateName,{revision:(old.revision||0)+1,generation:resets[date],configs:[],jobs:[]});
 monitorVideoPending_(props,date,true,'day');
 function remove(folder){if(folder.getId()===root.getId())throw new Error('تعذر تحديد مجلد الفيديو');var response=UrlFetchApp.fetch('https://www.googleapis.com/drive/v3/files/'+encodeURIComponent(folder.getId()),{method:'delete',headers:{Authorization:'Bearer '+(school?schoolDriveToken_(school):ScriptApp.getOAuthToken())},muteHttpExceptions:true});if(![204,404].includes(response.getResponseCode()))throw new Error('لم يتأكد حذف فيديو اليوم من Drive؛ أعد التصفير')}
 var parents=root.getFoldersByName('Videos');while(parents.hasNext()){var dates=parents.next().getFoldersByName(date);while(dates.hasNext())remove(dates.next())}
 var legacy=root.getFoldersByName('فيديو حصص '+date);while(legacy.hasNext())remove(legacy.next());monitorVideoPending_(props,date,false,'day');monitorVideoPending_(props,date,false,'range');
}
function monitorVideoRangeReset_(date,props,attendanceRoot,requestId,from,until){
 var school=typeof COMMERCIAL_CONTEXT_!=='undefined'&&COMMERCIAL_CONTEXT_?COMMERCIAL_CONTEXT_.school:null,root=attendanceRoot,drive=DriveApp;
 if(school){var link=schoolDriveLink_(school.id);if(!link||!link.rootId)return {videos:0};drive=schoolDriveAdapter_(school);root=drive.getFolderById(commercialVideoRoot_(school,link))}
 var stateName='mirsad-video-'+date+'.json',state=monitorRead_(monitorFile_(root,stateName),{revision:0,configs:[],jobs:[]}),controlName='mirsad-video-range-reset-'+date+'.json',control=monitorRead_(monitorFile_(root,controlName),{version:0,ids:[],pending:[],requests:{}});
 var selected=state.jobs.filter(function(j){var start=Number(j.recordingStartedAt||j.createdAt),duration=Number(j.durationMs),end=Number.isFinite(duration)&&duration>0?start+duration:['joining','recording'].includes(j.phase)?Math.max(start+1,Date.now()):start+1;return Number.isFinite(start)&&start<until&&end>from});
 if(!control.requests[requestId]){var ids=selected.map(function(j){return j.id});control.requests[requestId]=ids;for(var j of selected){if(!control.ids.includes(j.id)){control.ids.push(j.id);control.pending.push({id:j.id,date:j.date,filename:MirsadVideoCore.fileName(j),folderId:j.folderId||'',fileId:j.fileId||'',legacySession:!j.fileId?j.uploadSession||'':'',driveUrl:j.driveUrl||''})}}if(ids.length){control.version++;monitorWrite_(root,controlName,control);var versions=JSON.parse(props.getProperty('MONITOR_VIDEO_RANGE_VERSIONS')||'{}');versions[date]=control.version;props.setProperty('MONITOR_VIDEO_RANGE_VERSIONS',JSON.stringify(versions))}}
 var removed=state.jobs.filter(function(j){return control.ids.includes(j.id)});if(removed.length){state.usedGaps=Array.from(new Set([...(state.usedGaps||[]),...removed.map(function(j){return j.gapKey})]));state.jobs=state.jobs.filter(function(j){return !control.ids.includes(j.id)});state.configs=state.configs.map(function(c){var cycles=c.cycles.filter(function(n){return !removed.some(function(j){return j.teacherId===c.teacherId&&j.period===c.period&&j.afterCycle===n})});return {...c,cycles:cycles,enabled:cycles.length>0}});state.revision++;monitorWrite_(root,stateName,state)}
 function google(url,method){return UrlFetchApp.fetch(url,{method:method,headers:{Authorization:'Bearer '+(school?schoolDriveToken_(school):ScriptApp.getOAuthToken())},muteHttpExceptions:true})}
 var parents=[],it=root.getFoldersByName('Videos');while(it.hasNext()){var dates=it.next().getFoldersByName(date);while(dates.hasNext())parents.push(dates.next())}it=root.getFoldersByName('فيديو حصص '+date);while(it.hasNext())parents.push(it.next());
 if(control.pending.length)monitorVideoPending_(props,date,true,'range');
 for(var target of control.pending){if(target.legacySession){if(!/^https:\/\/www\.googleapis\.com\/upload\/drive\/v3\/files\?/.test(target.legacySession))throw new Error('رابط رفع قديم غير صالح');var cancelled=google(target.legacySession,'delete');if(![200,204,404,410,499].includes(cancelled.getResponseCode()))throw new Error('تعذر إلغاء رفع فيديو قديم جارٍ؛ انتظر توقفه ثم أعد التصفير')}var ids=target.fileId?[target.fileId]:[],match=/^https:\/\/drive\.google\.com\/file\/d\/([A-Za-z0-9_-]+)\/view/.exec(target.driveUrl);if(match)ids.push(match[1]);for(var parent of parents){var files=parent.getFilesByName(target.filename);while(files.hasNext())ids.push(files.next().getId())}for(var id of Array.from(new Set(ids))){var metadata=google('https://www.googleapis.com/drive/v3/files/'+encodeURIComponent(id)+'?fields=id,mimeType,appProperties,trashed','get');if(metadata.getResponseCode()===404)continue;var file;try{file=JSON.parse(metadata.getContentText())}catch(e){throw new Error('تعذر التحقق من فيديو الفترة قبل حذفه')};if(metadata.getResponseCode()!==200||file.mimeType!=='video/webm'||file.appProperties?.mirsadVideoJob!==target.id||school&&file.appProperties?.mirsadSchool!==school.id)throw new Error('تعذر تأكيد ملكية فيديو الفترة؛ لم يُحذف ملف غير مطابق');var response=google('https://www.googleapis.com/drive/v3/files/'+encodeURIComponent(id),'delete');if(![204,404].includes(response.getResponseCode()))throw new Error('لم يكتمل حذف فيديو الفترة من Drive؛ أعد التصفير') }}
 control.pending=[];monitorWrite_(root,controlName,control);monitorVideoPending_(props,date,false,'range');return {videos:(control.requests[requestId]||[]).length};
}
function monitorVideoRangeUpdates_(props,root,known){if(!known||typeof known!=='object')return [];var versions;try{versions=JSON.parse(props.getProperty('MONITOR_VIDEO_RANGE_VERSIONS')||'{}')}catch(e){versions={}};var result=[];for(var date of Object.keys(versions)){if(!monitorDateValid_(date)||Number(known[date]||0)>=versions[date])continue;var control=monitorRead_(monitorFile_(root,'mirsad-video-range-reset-'+date+'.json'),null);if(control)result.push({date:date,version:control.version,ids:control.ids})}return result}

function monitorVideoPending_(props,date,value,kind){var key='MONITOR_VIDEO_DELETE_PENDING_'+kind,map;try{map=JSON.parse(props.getProperty(key)||'{}')}catch(e){map={}}if(value===undefined)return map[date]===true;if(value)map[date]=true;else delete map[date];props.setProperty(key,JSON.stringify(map));return value===true}



function commercialSimpleRequest_(registry,p){
 if(p.action==='commercialExtensionCodeRequest'){if(typeof MailApp.getRemainingDailyQuota==='function'&&MailApp.getRemainingDailyQuota()<1)throw new Error('انتهت حصة إرسال البريد اليومية؛ حاول غدًا أو تواصل مع الدعم');var delivery=registry.requestExtensionCode(p);if(delivery)MailApp.sendEmail({to:delivery.email,subject:'رمز دخول راصد المدارس',body:'رمز الدخول للإضافة: '+delivery.code+'\nصالح لعشر دقائق ويستخدم مرة واحدة. أدخله داخل إضافة راصد المدارس فقط. لا تشاركه مع أحد.'});return {sent:true,message:'أُرسل طلب رمز الدخول إلى بريدك. افحص البريد غير الهام أيضًا.'}}
 if(p.action==='commercialSetWebsitePin')return registry.setWebsitePin(p);
 if(p.action==='commercialWebsitePinLogin')return registry.websitePinLogin(p);
 if(p.action==='commercialRecorderSignout')return registry.recorderSignout(p);
 if(p.action==='commercialRecorderStatus')return registry.recorderStatus(p);
 if(p.action==='commercialManageAccess')return registry.manageAccess(p.key,p);
 if(p.action==='commercialExtensionCodeLogin'){var r=registry.extensionCodeLogin(p);r.handover=commercialReadProgress_(registry.authorize(r.writerKey).school);return r}
 if(p.action==='commercialRecorderPortal')return registry.recorderPortal(p);
 throw new Error('طلب غير مدعوم');
}

function commercialAccessNotice_(result){var text=result.school.subscriptionMessage||'نرجو تسديد الاشتراك: 100 ريال شهريًا. يُفعّل شهر كامل من وقت تأكيد استلام المبلغ. حسابك وبياناتك محفوظة.';try{MailApp.sendEmail({to:result.school.email,subject:'راصد — تفعيل الاشتراك الشهري',body:text+'\nافتح إضافة راصد للاطلاع على حسابات التحويل البنكي.'});result.emailDelivery={sent:true}}catch(error){result.emailDelivery={sent:false,error:'أُوقف الحساب وتظهر المطالبة في الإضافة، لكن تعذر إرسال البريد. تحقق من صلاحيات الإرسال وحصته اليومية.'}}return result}

function commercialWebsitePinHash_(pin,salt){var props=PropertiesService.getScriptProperties(),pepper=props.getProperty('COMMERCIAL_WEBSITE_PIN_PEPPER');if(!pepper){pepper=commercialRandom_();props.setProperty('COMMERCIAL_WEBSITE_PIN_PEPPER',pepper)}return commercialHash_('website-pin|'+pepper+'|'+salt+'|'+pin)}

/* Video state lives in the linked school Drive. Resolve its attendance folder
 * only when a configuration/poll actually needs the current snapshot. */
function commercialVideoRequest_(p,props,writer,admin){return monitorVideoRequest_(p,props,function(){try{return monitorPrivate_(commercialSchoolDrive_().getFolderById(MONITOR_ROOT))}catch(error){if(error.code)throw error;throw new Error('تعذر الوصول إلى مجلد جدول الرصد. تحقق من ربط Google في الإضافة ثم أعد تحميل الجدول؛ لم تُحذف أي بيانات.')}},writer,admin)}



var COMMERCIAL_BILLING_TERMS_VERSION='2026-11-15-v1';
function commercialBillingPublic_(r){var c=r.billingSettings||{},live=c.enabled===true&&c.offerEnabled===true&&Number(c.offerEndsAt)>Date.now();return {providerName:c.providerName||'',supportEmail:c.supportEmail||'',termsApproved:c.termsApproved===true,enabled:c.enabled===true,termsVersion:COMMERCIAL_BILLING_TERMS_VERSION,serverTime:Date.now(),offerActive:live,offerEndsAt:live?c.offerEndsAt:0,offerConfigured:c.offerEnabled===true,configuredOfferEndsAt:c.offerEndsAt||0,accounts:commercialOwnerSettingsPublic_(r).accounts||[],plans:[{id:'week',label:'أسبوع',amount:50},{id:'month',label:'شهر',amount:100},{id:'twoMonths',label:'شهران',amount:live?150:200}],currency:'SAR'}}
function commercialValidateInvoice_(file){file=file||{};var name=String(file.name||'').replace(/[\\/\x00-\x1f]/g,'_').slice(0,140),ext=(name.match(/\.([a-z0-9]+)$/i)||[])[1]?.toLowerCase(),text=String(file.base64||'');if(!text||text.length>5592408||!/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(text))throw new Error('الملف فارغ أو أكبر من 4 ميغابايت');var bytes=Utilities.base64Decode(text);if(!bytes.length||bytes.length>4194304)throw new Error('حجم الفاتورة يتجاوز 4 ميغابايت');var hex=bytes.slice(0,12).map(function(x){return ((x+256)%256).toString(16).padStart(2,'0')}).join(''),mime='';if(ext==='pdf'&&hex.startsWith('255044462d'))mime='application/pdf';else if(ext==='docx'&&hex.startsWith('504b0304'))mime='application/vnd.openxmlformats-officedocument.wordprocessingml.document';else if(ext==='doc'&&hex.startsWith('d0cf11e0a1b11ae1'))mime='application/msword';else if(ext==='png'&&hex.startsWith('89504e470d0a1a0a'))mime='image/png';else if(['jpg','jpeg'].includes(ext)&&hex.startsWith('ffd8ff'))mime='image/jpeg';else if(ext==='webp'&&hex.startsWith('52494646')&&hex.slice(16,24)==='57454250')mime='image/webp';if(!mime)throw new Error('ارفع PDF أو Word أو صورة PNG أو JPG أو WebP صحيحة');var canonical=Utilities.base64Encode(bytes);return {name,ext,mime,bytes,base64:canonical,hash:commercialHash_(canonical)}}
function commercialStoreInvoice_(school,id,file){var root=commercialRoot_(),it=root.getFoldersByName('RasedBillingEvidence'),folder=it.hasNext()?it.next():root.createFolder('RasedBillingEvidence'),name=school+'-'+id+'.'+file.ext,existing=folder.getFilesByName(name);if(existing.hasNext()){var prior=existing.next();if(commercialHash_(Utilities.base64Encode(prior.getBlob().getBytes()))!==file.hash)throw new Error('استخدم طلب رفع جديد لهذا الملف');return {id:prior.getId()}}var saved=folder.createFile(Utilities.newBlob(file.bytes,file.mime,name));saved.setSharing(DriveApp.Access.PRIVATE,DriveApp.Permission.NONE);return {id:saved.getId()}}
function commercialReadInvoice_(invoice){var file=DriveApp.getFileById(invoice.fileId),bytes=file.getBlob().getBytes();if(bytes.length>4194304)throw new Error('تعذر فتح الملف؛ حجمه غير متوقع');return {name:invoice.name,mime:invoice.mime,base64:Utilities.base64Encode(bytes)}}
function commercialCommerceRequest_(registry,p){if(p.action==='commercialOwnerCommerce')return registry.ownerCommerce(p.key,p.input);if(p.action==='commercialInvoiceFile')return registry.invoiceFile(p.key,p);if(p.action==='commercialBillingStatus')return registry.billingStatus(p);if(p.action==='commercialInvoiceUpload')return registry.invoiceUpload(p);if(p.action==='commercialBillingLogout')return registry.billingLogout(p);throw new Error('طلب غير مدعوم')}
function commercialPlanEnd_(start,plan){if(plan==='week')return start+7*86400000;var d=new Date(start+10800000),count=plan==='twoMonths'?2:1,y=d.getUTCFullYear(),m=d.getUTCMonth()+count,last=new Date(Date.UTC(y,m+1,0)).getUTCDate();return Date.UTC(y,m,Math.min(d.getUTCDate(),last),d.getUTCHours(),d.getUTCMinutes(),d.getUTCSeconds(),d.getUTCMilliseconds())-10800000}



function commercialMultiError_(message,code){var e=new Error(message);e.code=code;throw e}
function commercialCampusPublic_(site){return {id:site.id,localId:site.localId,profile:site.profile,legacy:!!site.legacy}}
function commercialDiscoverCampus_(school){var base=commercialStorageFor_(school,monitorToday_()),previous=COMMERCIAL_CONTEXT_;try{COMMERCIAL_CONTEXT_={school:school,storage:base};var root=commercialSchoolDrive_().getFolderById(base.rootId),source=monitorRead_(monitorFile_(root,'mirsad-timetable-source.json'),{});return {id:String(source.schoolId||source.payload?.schoolId||'').toLowerCase(),hasData:root.getFolders().hasNext()}}finally{COMMERCIAL_CONTEXT_=previous}}
function commercialEnsureCampus_(school,site){var base=DriveApp.getFolderById(school.rootId);if(!site.localRootId){var name='مدرسة-'+site.id+'-'+site.localId,it=base.getFoldersByName(name);site.localRootId=commercialPrivate_(it.hasNext()?it.next():base.createFolder(name)).getId()}if(!site.legacy){var local=DriveApp.getFolderById(site.localRootId);if(!monitorFile_(local,'service-properties.json'))commercialWriteFile_(local,'service-properties.json',{MONITOR_EVIDENCE_PRIVATE:'true',MONITOR_ARCHIVE_PRIVATE:'true'})}var link=schoolDriveLink_(school.id);if(link&&!link.revoked&&!site.remoteRootId){if(site.legacy)site.remoteRootId=link.rootId;else{var drive=schoolDriveAdapter_(school),root=drive.getFolderById(link.rootId),name='مدرسة-'+site.id+'-'+site.localId,it=root.getFoldersByName(name);site.remoteRootId=(it.hasNext()?it.next():root.createFolder(name)).getId()}}}
function commercialMultiSchool_(school,id){if(school._site)return school;var site=school.campuses?.find(x=>x.id===(id||school.activeSiteId))||(school.archives||[]).find(x=>!x.deletedAt&&x.archiveId===id);if(!site){if(id)commercialMultiError_('المدرسة غير موجودة في هذا الحساب','site-scope');if(!school.campuses?.length)return school;commercialMultiError_('حمّل جدول المدرسة أولًا من الإضافة','site-required')}return {...school,rootId:site.localRootId,_accountRootId:school.rootId,_site:site,profile:site.profile,viewerToken:site.viewerToken}}
function commercialCampusActor_(actor,p){var requested=actor.siteId||p.siteId;if(actor.school.campuses?.length>1&&!requested&&p.action!=='adminLogin')commercialMultiError_('اختر المدرسة من القائمة أو حدّث الصفحة','site-required');if(actor.role==='viewer'&&p.siteId&&actor.siteId!==p.siteId)commercialMultiError_('رابط المشاهدة خاص بمدرسة أخرى','site-scope');return {...actor,school:commercialMultiSchool_(actor.school,requested)}}
function commercialCampusReady_(school,site){var scoped=commercialMultiSchool_(school,site.id),previous=COMMERCIAL_CONTEXT_;try{var storage=commercialStorageFor_(scoped,monitorToday_());COMMERCIAL_CONTEXT_={school:scoped,storage:storage};var root=commercialSchoolDrive_().getFolderById(storage.rootId),day=monitorScheduleFolder_(root,monitorToday_(),false),data=day&&monitorRead_(monitorFile_(day,'attendance.json'),null);if(!data?.snapshot?.scheduleRevision)commercialMultiError_('حمّل جدول المدرسة لليوم قبل بدء الرصد','site-not-ready')}finally{COMMERCIAL_CONTEXT_=previous}}
function commercialMultiBefore_(p,actor){var s=actor.school,site=s._site,write=['heartbeat','setMonitoringTiming','publishMonitoringTimetable','classicStartDay','prepareCurrentTimetable','record','image','setTimetableSource','publishMadrasatiTimetable','startDay','adoptTimetable','fillMissingLinks','addCalendarLinks','videoPoll','videoUpdate','videoUploadBegin','videoUploadFinish','restoreArchivedSchedule'];if(actor.role==='recorder'&&write.includes(p.action)&&p.workspaceId!==site?.localId)commercialMultiError_('تغيرت مساحة المدرسة؛ حمّل الجدول من جديد','workspace-changed');if(actor.role==='recorder'&&write.includes(p.action)&&s.monitorLease?.until>Date.now()&&s.monitorLease.deviceId!==s.device.id)commercialMultiError_('الرصد يعمل على جهاز آخر لهذا الإيميل؛ أوقفه أولًا','monitor-in-use');if(site?.archiveId&&!['adminLogin','dates','day','teacherLink','teachersLive','getTimetableSource','previewTimetable','scheduleVersions','getAutoLinksControl','videoStatus','commercialEvidence'].includes(p.action))commercialMultiError_('الأرشيف للعرض فقط؛ حمّل جدول المدرسة من جديد للرصد','archive-read-only');if(actor.role==='recorder'&&write.includes(p.action)&&(!site||p.siteId!==site.id||p.multiProtocol!=='multi-v1'))commercialMultiError_('حدّث إضافة المدارس لتحميل المدرسة المطلوبة بأمان','extension-update-required');if(site&&p.payload?.source==='madrasati'&&String(p.payload.schoolId||'').toLowerCase()!==site.id)commercialMultiError_('الجدول يخص مدرسة أخرى؛ أعد تحميل صفحة المدرسة الحالية','site-scope');if(site&&p.record&&(p.record.siteId&&p.record.siteId!==site.id||p.record.accountId&&p.record.accountId!==s.id||p.record.localSchoolId&&p.record.localSchoolId!==site.localId))commercialMultiError_('النتيجة تخص مدرسة أخرى؛ لم تُخلط الأرشيفات','site-scope');var needsLease=['classicStartDay','prepareCurrentTimetable','record','image','startDay'];if(actor.role==='recorder'&&(needsLease.includes(p.action)||p.action==='heartbeat'&&p.running===true||p.action==='videoPoll'&&p.ready===true&&p.gap)){var lease=s.monitorLease;if(!lease||lease.until<=Date.now()||lease.runToken!==p.runToken||lease.siteId!==site.id||lease.deviceId!==s.device.id)commercialMultiError_('لا توجد جلسة رصد صالحة لهذه المدرسة؛ أعد بدء الرصد','monitor-session-expired')}}
function commercialMultiAfter_(p,result,actor){var site=actor.school._site;if(site){result.accountId=actor.school.id;result.schoolId=site.localId;result.siteId=site.id;result.site=commercialCampusPublic_(site);if(result.job){result.job.siteId=site.id;result.job.localSchoolId=site.localId;result.job.accountId=actor.school.id;}if(result.snapshot)result.snapshot.siteId=site.id;if(p.action==='getTimetableSource')result.boundSchoolId=site.id;if(result.school){result.school.profile=site.profile;result.school.siteId=site.id}if(p.action==='teacherLink'&&result.url)result.url+='&siteId='+encodeURIComponent(site.id)}return result}
function commercialMultiRequest_(registry,p){if(p.action==='commercialSchoolSpaces')return registry.spaces(p);if(p.action==='commercialSelectSchool')return registry.selectSpace(p);if(p.action==='commercialMonitorSession')return registry.monitorSession(p);if(p.action==='commercialResetUsername')return registry.resetUsername(p.key,p);throw new Error('طلب غير مدعوم')}

// Delete only the retired workspace. Legacy account roots also contain other workspaces,
// so retain their child workspace folders and remove only the legacy files/date folders.
function commercialDeleteCampus_(school,site){
 function clear(drive,id,legacy){if(!id)return;var root=drive.getFolderById(id);if(!legacy){root.setTrashed(true);return}var protectedIds={};for(var x of [...(school.campuses||[]),...(school.archives||[])])if(x.localId!==site.localId){if(x.localRootId)protectedIds[x.localRootId]=true;if(x.remoteRootId)protectedIds[x.remoteRootId]=true}var files=root.getFiles();while(files.hasNext())files.next().setTrashed(true);var folders=root.getFolders();while(folders.hasNext()){var folder=folders.next();if(!protectedIds[folder.getId()])folder.setTrashed(true)}}
 if(site.remoteRootId)clear(schoolDriveAdapter_(school),site.remoteRootId,site.legacy);
 clear(DriveApp,site.localRootId,site.legacy);
}

function commercialVideoRoot_(school,link){if(school._site){if(!school._site.remoteRootId)commercialMultiError_('أعد تحميل جدول المدرسة لتجهيز مجلد الفيديو','site-storage-required');return school._site.remoteRootId}return link.rootId}

// END MIRSAD SCHOOLS COMPLETE SCRIPT 2.9.53
