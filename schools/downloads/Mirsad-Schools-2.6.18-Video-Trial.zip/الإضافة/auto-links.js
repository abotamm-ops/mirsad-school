/* Optional read/merge only. No replacement, no delete, no automatic login. */
var MirsadAutoLinks=(()=>{
 const TAIL='mirsadAutoLinksFinalGap';const REMOTE='mirsadAutoLinksRemote',PREF='mirsadAutoLinksEnabled',STAGED='mirsadAutoLinksStaged',STATE='mirsadAutoLinksState',NOTES='mirsadAutoLinksNotes',ALARM='mirsad-auto-links-five-minutes';let busy=false,gapBusy=false,applying=false,gapRequested=false,completedGap=null;
 const today=()=>MirsadMonitorModel.day();
 const edition=chrome.runtime.getManifest().name.includes('المدارس')?'schools/':'';
 const home='/'+edition+'automatic-monitoring.html';
 const validSender=s=>{if(!s.tab)return s.id===chrome.runtime.id;try{const u=new URL(s.tab.url);return u.origin==='https://mirsad-school.onrender.com'&&u.pathname===home}catch{return false}};
 const pause=ms=>new Promise(r=>setTimeout(r,ms));
 const missing=s=>(s?.lessons||[]).filter(l=>!MirsadScheduleCore.normalizeTeamsUrl(l.url)&&!MirsadMonitorModel.isExcludedPeriod(s.date,l.period,s)).length;
 async function scope(){const c=(await chrome.storage.local.get('mirsadDriveConfig')).mirsadDriveConfig||{};return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode((c.url||'')+'|'+(c.key||''))))).map(v=>v.toString(16).padStart(2,'0')).join('')}
 async function note(text,kind='info'){const at=Date.now(),s=await chrome.storage.local.get(NOTES),notes=s[NOTES]||[];await chrome.storage.local.set({[NOTES]:[...notes,{at,date:today(),text,kind}].slice(-100),[STATE]:{at,date:today(),text,kind}})}
 async function info(){const s=await chrome.storage.local.get([PREF,STATE,NOTES,'mirsadDriveDay']);const day=s.mirsadDriveDay;return {ok:true,enabled:s[PREF]===true,missing:day?.date===today()?missing(day.snapshot):null,state:s[STATE]||null,notes:(s[NOTES]||[]).filter(n=>n.date===today()).slice(-15)}}
 async function enabled(){const v=await chrome.storage.local.get([PREF,REMOTE]);return v[PREF]===true&&v[REMOTE]?.scope===await scope()&&Date.now()-v[REMOTE].seenAt<180000}
 async function configure(on){if(typeof on!=='boolean')throw Error('خيار غير صالح');await chrome.storage.local.set({[PREF]:on});if(on){await chrome.alarms.create(ALARM,{periodInMinutes:5});await note('التحديث مفعّل: تُفحص صفحة المعلمين كل خمس دقائق بحسب وضع التحميل المختار.')}else{await chrome.alarms.clear(ALARM);await MadrasatiSource.cancelAutomatic?.();await chrome.storage.local.remove(STAGED);await chrome.storage.local.remove('mirsadAutoLinksHealth');await note('تحديث الروابط التلقائي متوقف.')}return info()}
 async function health(tab,until=Date.now()+60000,allowed=enabled){
  if(!await allowed())throw Error('انتهى وقت تحديث صفحة المعلمين');await chrome.tabs.reload(tab.id);const deadline=Math.min(Date.now()+60000,until);
  while(Date.now()<deadline){if(!await allowed())throw Error('انتهى وقت تحديث صفحة المعلمين أو أُلغي التحديث');const t=await chrome.tabs.get(tab.id);if(t.status==='complete'&&!t.pendingUrl){let u;try{u=new URL(t.url)}catch{}if(!u||u.origin!=='https://schools.madrasati.sa'||!/^\/SchoolManagment\/Teachers\/?$/i.test(u.pathname))throw Error('جلسة مدرستي أو صفحة المعلمين غير جاهزة؛ سجّل الدخول وافتح قائمة المعلمين');try{const r=await chrome.tabs.sendMessage(tab.id,{type:'MIRSAD_MADRASATI_READ',kind:'directory'});if(r?.ok&&r.teachers?.length)return r;if(r?.error&&!r.retryable)throw Object.assign(Error(r.error),{fatal:true})}catch(e){if(e.fatal)throw e}}
   await pause(500);
  }throw Error('لم تتأكد جاهزية قائمة المعلمين بعد التحديث؛ بقي الجدول كما هو');
 }
 async function tick(){if(busy||gapBusy||applying||!await enabled())return;busy=true;try{
  const d=(await chrome.storage.local.get('mirsadDriveDay')).mirsadDriveDay;if(d?.date!==today()||d.snapshot?.sourceType!=='madrasati')return;
  const run=await getRun(),mode=await selectedMode(),startPeriod=Math.max(1,run?.period||1),rows=(d.snapshot.lessons||[]).filter(l=>l.period>=startPeriod&&!MirsadMonitorModel.isExcludedPeriod(today(),l.period,d.snapshot));
  if(!rows.length||mode==='missing'&&!rows.some(l=>!MirsadScheduleCore.normalizeTeamsUrl(l.url))){await chrome.storage.local.remove(STAGED);await chrome.storage.local.set({[STATE]:{at:Date.now(),date:today(),text:'اكتملت روابط الحصص القادمة؛ توقف تحديث الصفحة تلقائيًا.',complete:true}});return}
  const source=await MadrasatiSource.info();if(source.state?.running||source.pending)return;
  const tabs=await chrome.tabs.query({url:'https://schools.madrasati.sa/SchoolManagment/Teachers*'}),tab=tabs.find(t=>t.windowId===run?.workspaceWindowId)||tabs[0];if(!tab)throw Error('افتح صفحة معلمي مدرستي؛ لم يُفتح تبويب جديد');
  const fingerprint=await scope();await health(tab);if(!await enabled()||fingerprint!==await scope())return;
  await chrome.storage.local.set({mirsadAutoLinksHealth:{date:today(),at:Date.now(),scope:fingerprint,tabId:tab.id,revision:d.snapshot.scheduleRevision},[STATE]:{at:Date.now(),date:today(),text:'تم تحديث صفحة المعلمين فقط؛ تحميل الجدول ينتظر فاصل دورات الرصد.'}});
 }catch(e){await note('لم تُحدّث صفحة المعلمين: '+e.message,'warning')}finally{busy=false;if(gapRequested){gapRequested=false;void collectGap()}}}

 // Before-school refresh stops once all lesson links are complete, independently of daytime mode.
 const MORNING_ALARM='mirsad-before-first-lesson',MORNING_SLOT='mirsadBeforeFirstLessonSlot';
 async function morningWindow(){
  const run=await getRun();if(!run?.running||run.paused||run.current||run.testMode||run.backtestMode||run.immediateMode||run.calendarTrial)return null;
  const saved=await chrome.storage.local.get(['mirsadDriveDay','mirsadMadrasatiSelectedDate']),day=saved.mirsadDriveDay;if(day?.date!==today()||day.snapshot?.sourceType!=='madrasati'||day.snapshot.scheduleRevision!==run.scheduleRevision)return null;
  // Never pick or overwrite the user's source date. Morning refresh is today-only.
  const sourceDate=saved.mirsadMadrasatiSelectedDate||day.snapshot.sourceScheduleDate;if(sourceDate!==today()||day.snapshot.sourceScheduleDate!==sourceDate)return null;
  if(!missing(day.snapshot))return null;
  if(typeof scheduleSettings!=='object'||typeof periodBounds!=='function')return null;
  const clock=/^(\d{1,2}):(\d{2})$/.exec(scheduleSettings.manualStart||'');if(!clock||Number(clock[1])>23||Number(clock[2])>59)return null;
  const first=Number(clock[1])*60+Number(clock[2]),bounds=periodBounds({n:1,startOffset:first,endOffset:first+Number(scheduleSettings.periodDuration||45)},new Date(),'activeOrNext');
  const start=bounds?.start.getTime();if(!Number.isFinite(start)||start<=Date.now())return null;
  return {run,day,sourceDate,start,opens:start-30*60000};
 }
 async function morningAllowed(pending){const w=await morningWindow();return !!w&&Date.now()>=w.opens&&Date.now()<w.start-1000&&(!pending||pending.morningStart===w.start&&pending.runStartedAt===w.run.startedAt&&pending.epoch===(w.run.controlEpoch||0))}
 async function planMorning(invoke=false){
  if(typeof refreshScheduleSettings==='function')await refreshScheduleSettings();
  const w=await morningWindow();if(!w){await chrome.alarms.clear(MORNING_ALARM);return}
  const now=Date.now(),next=now<w.opens?w.opens:w.opens+(Math.floor((now-w.opens)/300000)+1)*300000;
  if(next<w.start)await chrome.alarms.create(MORNING_ALARM,{when:next});else await chrome.alarms.clear(MORNING_ALARM);
  if(invoke&&now>=w.opens)void collectMorning();
 }
 async function collectMorning(){
  await planMorning();if(busy||gapBusy||applying)return;const w=await morningWindow();if(!w||Date.now()<w.opens)return;
  const fingerprint=await scope(),slot=[fingerprint,today(),w.run.startedAt,w.run.controlEpoch||0,w.start,Math.floor((Date.now()-w.opens)/300000)].join('|');
  if((await chrome.storage.local.get(MORNING_SLOT))[MORNING_SLOT]===slot)return;
  gapBusy=true;try{
   await chrome.storage.local.set({[MORNING_SLOT]:slot});
   const source=await MadrasatiSource.info();if(source.state?.running||source.pending)throw Error('هناك تحميل آخر أو استيراد ينتظر التأكيد');
   const pending={reason:'morning',morningStart:w.start,runStartedAt:w.run.startedAt,epoch:w.run.controlEpoch||0};
   const shouldContinue=async()=>fingerprint===await scope()&&await morningAllowed(pending);
   const tabs=await chrome.tabs.query({url:'https://schools.madrasati.sa/SchoolManagment/Teachers*'}),tab=tabs.find(t=>t.windowId===w.run.workspaceWindowId)||tabs[0];if(!tab)throw Error('افتح صفحة معلمي مدرستي وسجّل الدخول');
   await note('بدأ تحميل الجدول قبل الحصة الأولى؛ يتكرر كل خمس دقائق حتى بداية الحصة.');
   await health(tab,w.start-1000,shouldContinue);if(!await shouldContinue())return;
   const result=await MadrasatiSource.collect(w.sourceDate,{collectOnly:true,directoryTabId:tab.id,shouldContinue,mode:'continuous',startPeriod:1});
   if(!result?.payload||!await shouldContinue())return;
   if(result.payload.scheduleDate!==w.sourceDate||result.payload.importedForDate!==today())throw Error('تاريخ الجدول المستلم لا يطابق تاريخ اليوم الذي اخترته؛ لم يُعدّل الجدول');
   await chrome.storage.local.set({[STAGED]:{...pending,gapKey:slot,date:today(),revision:w.day.snapshot.scheduleRevision,scope:fingerprint,payload:result.payload,at:Date.now(),mode:'continuous',startPeriod:1}});
   await beforeCycle(w.run);
  }catch(e){await note('تحميل ما قبل الحصة الأولى: '+e.message+'؛ بقي الجدول الحالي.',e.cancelled?'info':'warning')}finally{gapBusy=false;await planMorning()}
 }
 chrome.alarms.onAlarm.addListener(a=>{if(a.name===MORNING_ALARM)void collectMorning()});
 chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&(changes.mirsadAutoRun||changes.mirsadDriveDay||changes.mirsadScheduleSettings||changes.mirsadDriveConfig))void planMorning(true).catch(()=>{})});
 void Promise.resolve().then(()=>planMorning(true)).catch(()=>{});

 async function selectedMode(){const v=(await chrome.storage.local.get(REMOTE))[REMOTE];return v?.mode==='continuous'?'continuous':'missing'}

 async function gapWindow(run){
  if(!run?.running||run.paused||run.current)return null;
  if(run.waitingForCycle2&&run.nextCycleAt>Date.now()+2000)return {endAt:run.nextCycleAt,startPeriod:Math.max(1,run.period||1),kind:'cycle'};
  const tail=(await chrome.storage.local.get(TAIL))[TAIL];
  if(tail&&tail.date===today()&&tail.scope===await scope()&&tail.startedAt===run.startedAt&&tail.epoch===(run.controlEpoch||0)&&tail.period===run.period&&tail.cycle===run.cycle&&tail.endAt>Date.now()+2000&&run.index>=run.periodItems?.length)return {...tail,kind:'final'};
  return null;
 }
 async function completed(run,after,nextPeriodNumber){
  if(!run?.running||run.paused||run.current||run.waitingForCycle2||run.period!==after||!run.periodItems?.length||run.index<run.periodItems.length||run.testMode||run.backtestMode||run.immediateMode||run.calendarTrial)return;
  if(run.cycle!==Number(scheduleSettings.roundCount))return;
  const next=PERIODS.find(p=>p.n===nextPeriodNumber);if(!next)return;
  const bounds=periodBounds(next,new Date(),'activeOrNext'),endAt=bounds?.start.getTime();if(!endAt||endAt<=Date.now()+2000)return;
  const live=await getRun();if(!live?.running||live.paused||live.current||live.period!==after||live.startedAt!==run.startedAt||(live.controlEpoch||0)!==(run.controlEpoch||0))return;
  await chrome.storage.local.set({[TAIL]:{date:today(),scope:await scope(),startedAt:run.startedAt,epoch:run.controlEpoch||0,period:after,cycle:run.cycle,endAt,startPeriod:after+1}});
  void collectGap();
 }
 async function collectGap(){if(!await enabled())return;if(gapBusy||applying)return;if(busy){gapRequested=true;return}gapBusy=true;try{
  const run=await getRun(),window=await gapWindow(run);if(!window)return;
  const d=(await chrome.storage.local.get('mirsadDriveDay')).mirsadDriveDay;if(d?.date!==today()||d.snapshot?.sourceType!=='madrasati')return;
  const fingerprint=await scope(),mode=await selectedMode(),startPeriod=window.startPeriod,rows=d.snapshot.lessons.filter(l=>l.period>=startPeriod&&!MirsadMonitorModel.isExcludedPeriod(today(),l.period,d.snapshot));
  if(!rows.length||mode==='missing'&&!rows.some(l=>!MirsadScheduleCore.normalizeTeamsUrl(l.url)))return;
  const shouldContinue=async()=>{if(!await enabled()||fingerprint!==await scope()||mode!==await selectedMode())return false;const r=await getRun(),activeWindow=await gapWindow(r);return !!activeWindow&&activeWindow.kind===window.kind&&activeWindow.endAt===window.endAt&&r.period===run.period&&r.cycle===run.cycle&&r.startedAt===run.startedAt&&(r.controlEpoch??0)===(run.controlEpoch??0)&&Date.now()<window.endAt-1000};
  const gapKey=[fingerprint,run.startedAt,run.controlEpoch||0,run.period,run.cycle,window.kind,window.endAt,mode].join('|');
  const previous=(await chrome.storage.local.get(STAGED))[STAGED];if(completedGap===gapKey||previous?.gapKey===gapKey)return;
  const source=await MadrasatiSource.info();if(source.state?.running||source.pending){await note('تعذر تحميل الجدول في الفاصل: هناك تحميل آخر أو استيراد ينتظر التأكيد.');return}
  let healthState=(await chrome.storage.local.get('mirsadAutoLinksHealth')).mirsadAutoLinksHealth;
  if(!healthState||healthState.date!==today()||healthState.scope!==fingerprint||Date.now()-healthState.at>360000||healthState.revision!==d.snapshot.scheduleRevision){
   const tabs=await chrome.tabs.query({url:'https://schools.madrasati.sa/SchoolManagment/Teachers*'}),tab=tabs.find(t=>t.windowId===run.workspaceWindowId)||tabs[0];
   if(!tab)throw Error('افتح صفحة معلمي مدرستي؛ بقي الجدول الحالي');
   await note('بدأ فاصل الدورات؛ التحقق من صفحة المعلمين قبل تحميل الجدول.');
   await health(tab,window.endAt-1000,shouldContinue);if(!await shouldContinue())return;
   healthState={date:today(),at:Date.now(),scope:fingerprint,tabId:tab.id,revision:d.snapshot.scheduleRevision};await chrome.storage.local.set({mirsadAutoLinksHealth:healthState});
  }
  const sourceDate=d.snapshot.sourceScheduleDate||today();
  await note('بدأ تحميل الجدول في فاصل الدورات للتاريخ '+sourceDate+'.');
  const result=await MadrasatiSource.collect(sourceDate,{collectOnly:true,directoryTabId:healthState.tabId,shouldContinue,mode,startPeriod});
  if(!result?.payload||!await shouldContinue())return;
  await chrome.storage.local.set({[STAGED]:{gapKey,date:today(),revision:d.snapshot.scheduleRevision,scope:fingerprint,payload:result.payload,at:Date.now(),mode,startPeriod}});
  completedGap=gapKey;await beforeCycle(run);
 }catch(e){await note(e.cancelled?e.message:'لم يُحمّل الجدول: '+e.message,e.cancelled?'info':'warning')}finally{gapBusy=false}}
 async function beforeCycle(run){await MadrasatiSource.cancelAutomatic?.();const waiting=(await chrome.storage.local.get(STAGED))[STAGED];if(applying)return;if(waiting?.reason==='morning'){if(!await morningAllowed(waiting)){await chrome.storage.local.remove(STAGED);return}}else if(!await enabled())return;applying=true;try{
  const stored=await chrome.storage.local.get([STAGED,'mirsadDriveDay']),pending=stored[STAGED],d=stored.mirsadDriveDay;if(!pending)return;
  if(pending.reason!=='morning'&&pending.mode!==await selectedMode()||pending.date!==today()||d?.date!==today()||pending.revision!==d.snapshot?.scheduleRevision||pending.scope!==await scope()){await chrome.storage.local.remove(STAGED);return}
  const current=await getRun();if(!current?.running||current.paused||current.current||current.scheduleRevision!==pending.revision||run&&(current.startedAt!==run.startedAt||(current.controlEpoch??0)!==(run.controlEpoch??0)))return;
  if(pending.mode!=='continuous'&&!missing(d.snapshot)){await chrome.storage.local.remove(STAGED);return}
  // Only a delta merge against the existing revision; never stageImport/publish/reset.
  const r=await CloudMonitoring.fillMissingLinks(pending.payload,{requireExisting:true,expectedRevision:pending.revision,automaticRefresh:true,refreshExisting:pending.mode==='continuous',startPeriod:pending.startPeriod});
  if(!r?.merged)throw Error('لم يتأكد تكميل الروابط؛ بقي الجدول الحالي');
  // Earlier versions omitted linkless lessons from run.schedule. Add verified new
  // lessons to the NEXT cycle queue, retaining every existing result and URL.
  if(r.filled&&r.day?.snapshot){const next=await getRun();if(!next?.running||next.paused||next.current||next.startedAt!==current.startedAt||(next.controlEpoch??0)!==(current.controlEpoch??0))return;
   const schedule=Array.isArray(next.schedule)?next.schedule.slice():[],settings=typeof scheduleSettings==='object'?scheduleSettings:{};
   for(const row of r.day.snapshot.lessons||[]){if(!MirsadScheduleCore.normalizeTeamsUrl(row.url)||MirsadMonitorModel.isExcludedPeriod(today(),row.period,r.day.snapshot)||row.period<(settings.startPeriod||1)||row.period>(settings.endPeriod||7))continue;
    const existing=schedule.find(l=>Number(l.period)===Number(row.period)&&MirsadMonitorModel.normalize(l.teacher||l.teacherName)===MirsadMonitorModel.normalize(row.teacherName));
    if(!existing)schedule.push({...row,teacher:row.teacherName,hasLesson:true,validPeriod:true});
   }
   if(schedule.length!==next.schedule?.length){next.schedule=schedule;if(await saveRun(next)===false)return;if(typeof wakeUpdatedLinks==='function')await wakeUpdatedLinks()}
  }

  await chrome.storage.local.remove(STAGED);await note(r.filled?'تم تحميل الجدول: أُضيف '+(r.added??r.filled)+' رابط، وحُدّث '+(r.changed||0)+' رابط.'+(r.completed?.length?' — '+r.completed.slice(0,3).map(l=>l.teacher).join('، '):'')+' النتائج والصور محفوظة.':'تم تحميل الجدول، ولا يوجد جديد.');
 }catch(e){await note('تعذر إضافة الروابط: '+e.message+'؛ يستمر الرصد بالجدول الحالي.','warning')}finally{applying=false}}
 chrome.alarms.onAlarm.addListener(a=>{if(a.name===ALARM)void tick()});
 chrome.storage.onChanged.addListener((changes,area)=>{const n=changes.mirsadAutoRun?.newValue,o=changes.mirsadAutoRun?.oldValue;if(area==='local'&&n?.running&&!n.current&&n.waitingForCycle2&&(!o?.waitingForCycle2||o.nextCycleAt!==n.nextCycleAt))void collectGap()});
 chrome.runtime.onMessage.addListener((m,s,reply)=>{if(!['MIRSAD_AUTO_LINKS_INFO','MIRSAD_AUTO_LINKS_CONFIG'].includes(m?.type)||!validSender(s))return;(m.type==='MIRSAD_AUTO_LINKS_CONFIG'?Promise.reject(Error('غيّر الإعداد من موقع مرصاد؛ التحكم الآن محفوظ عن بُعد')):info()).then(reply).catch(e=>reply({ok:false,error:e.message}));return true});
 void enabled().then(async on=>{if(on){if(!await chrome.alarms.get(ALARM))await chrome.alarms.create(ALARM,{periodInMinutes:5});void collectGap()}});

 async function acceptRemote(control,expectedScope){
  if(!control||typeof control.enabled!=='boolean'||!Number.isInteger(control.revision)||control.revision<0)return false;
  const fingerprint=await scope();if(expectedScope&&expectedScope!==fingerprint)return false;const old=(await chrome.storage.local.get(REMOTE))[REMOTE];
  if(old?.scope===fingerprint&&control.revision<old.revision)return false;
  const changed=old?.scope!==fingerprint||old.revision!==control.revision||old.enabled!==control.enabled||old.mode!==(control.mode||'missing')||(await chrome.storage.local.get(PREF))[PREF]!==control.enabled;
  if(changed)await configure(control.enabled);
  await chrome.storage.local.set({[REMOTE]:{scope:fingerprint,revision:control.revision,enabled:control.enabled,mode:control.mode||'missing',seenAt:Date.now(),appliedAt:changed?Date.now():old.appliedAt}});
  if(changed&&control.enabled)void tick();return changed;
 }
 async function remoteReport(){const v=(await chrome.storage.local.get(REMOTE))[REMOTE];if(!v||v.scope!==await scope())return null;const state=await info();return {revision:v.revision,enabled:state.enabled,mode:v.mode||'missing',appliedAt:v.appliedAt,remaining:state.missing,complete:state.state?.complete===true,notes:state.notes.slice(-5)}}
 chrome.alarms.onAlarm.addListener(a=>{if(a.name==='mirsadAutoLinksRemoteControl')void MirsadLiveSender.sync()});
 void chrome.alarms.get('mirsadAutoLinksRemoteControl').then(a=>{if(!a)return chrome.alarms.create('mirsadAutoLinksRemoteControl',{periodInMinutes:1})});
 return {tick,collectGap,completed,collectMorning,planMorning,morningWindow,beforeCycle,configure,info,acceptRemote,remoteReport,remoteScope:scope};
})();
