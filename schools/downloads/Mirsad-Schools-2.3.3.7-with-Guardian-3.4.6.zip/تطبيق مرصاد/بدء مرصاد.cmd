@echo off
"%~dp0.support\MirsadSchoolFilesHost.exe" --install
start "" "%~dp0MirsadChromeGuardian.exe"
