@echo off
"%~dp0MirsadSchoolFilesHost.exe" --install-native
if errorlevel 1 pause
