const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const babel=require(path.join(path.dirname(require.resolve('playwright')),'lib/transform/babelBundle.js'));
const source=process.argv[2]||'/tmp/mirsad-commercial/extension',out=process.argv[3]||'/tmp/mirsad-chrome-store/extension';
fs.mkdirSync(out,{recursive:true});fs.cpSync(source,out,{recursive:true});const report=[];
function walk(dir){for(const entry of fs.readdirSync(dir,{withFileTypes:true})){const f=path.join(dir,entry.name);if(entry.isDirectory()){walk(f);continue}if(!f.endsWith('.js'))continue;const input=fs.readFileSync(f,'utf8');if(!/\bm[a-f0-9]+_0x[a-f0-9]+\b/.test(input))continue;const result=babel.babelTransform(input,f,false,[[path.resolve('chrome-store/readable-plugin.cjs'),{}]],[]);if(!result?.code)throw Error('No transformed output: '+f);const code=result.code.replace(/^\/\/# sourceMappingURL=.*$/gm,'');if(/\bm[a-f0-9]+_0x[a-f0-9]+\b|\b_0x[a-f0-9]+\b/.test(code))throw Error('Unresolved obfuscation: '+f);new (require('node:vm').Script)(code,{filename:f});fs.writeFileSync(f,code);report.push({file:path.relative(out,f),sourceSha256:crypto.createHash('sha256').update(input).digest('hex'),resultSha256:crypto.createHash('sha256').update(code).digest('hex')})}}
walk(out);fs.writeFileSync(path.join(path.dirname(out),'source-transformation.json'),JSON.stringify(report,null,2)+'\n');console.log('Converted '+report.length+' files to readable source in '+out);

// Chrome Web Store assigns the item identity; sideload key belongs only to trial builds.
const manifestPath=path.join(out,'manifest.json');const manifest=JSON.parse(fs.readFileSync(manifestPath,'utf8'));delete manifest.key;fs.writeFileSync(manifestPath,JSON.stringify(manifest,null,2)+'\n');
