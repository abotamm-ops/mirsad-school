"use strict";

(() => {
  if (window.__mirsadAutoReportBridge) return;
  window.__mirsadAutoReportBridge = true, window.addEventListener("message", _argument => {
    if (_argument.source !== window || _argument.origin !== location.origin || _argument.data?.["source"] !== "mirsad-auto-report") return;
    if (_argument.data.type === "GET_REPORT") chrome.runtime.sendMessage({
      "type": "MIRSAD_GET_LIVE_REPORT"
    }, _argument2 => {
      const _value = chrome.runtime.lastError ? {
        "ok": false,
        "error": chrome.runtime.lastError.message
      } : _argument2;
      window.postMessage({
        "source": "mirsad-auto-report",
        "type": "REPORT_DATA",
        "payload": _value
      }, location.origin);
    });else {
      if (_argument.data.type === "SAVE_SCHEDULE_SETTINGS") chrome.runtime.sendMessage({
        "type": "MIRSAD_SAVE_SCHEDULE_SETTINGS",
        "settings": _argument.data.settings
      }, _argument3 => {
        const _value2 = chrome.runtime.lastError ? {
          "ok": false
        } : _argument3;
        if (_value2?.["ok"]) _value2.message = "\u062A\u0645 \u062D\u0641\u0638 \u0625\u0639\u062F\u0627\u062F\u0627\u062A \u0627\u0644\u062A\u0648\u0642\u064A\u062A \u0627\u0644\u064A\u062F\u0648\u064A. \u0625\u0630\u0627 \u0643\u0627\u0646 \u0627\u0644\u0631\u0635\u062F \u064A\u0646\u062A\u0638\u0631\u060C \u064A\u0639\u064A\u062F \u062D\u0633\u0627\u0628 \u0627\u0644\u0645\u0648\u0639\u062F\u061B \u0648\u0625\u0630\u0627 \u0643\u0627\u0646 \u064A\u0641\u062D\u0635 \u0631\u0627\u0628\u0637\u064B\u0627 \u0627\u0644\u0622\u0646\u060C \u062A\u064F\u0637\u0628\u0651\u0642 \u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A \u0627\u0644\u062C\u062F\u064A\u062F\u0629 \u0628\u0639\u062F \u0627\u0646\u062A\u0647\u0627\u0626\u0647.";
        window.postMessage({
          "source": "mirsad-auto-report",
          "type": "SCHEDULE_SETTINGS_SAVED",
          "payload": _value2
        }, location.origin);
      });else {
        if (_argument.data.type === "SAVE_MAPPING") chrome.runtime.sendMessage({
          "type": "MIRSAD_SAVE_MAPPING",
          "teamsName": _argument.data.teamsName,
          "teacher": _argument.data.teacher
        }, _argument4 => {
          window.postMessage({
            "source": "mirsad-auto-report",
            "type": "MAPPING_SAVED",
            "payload": chrome.runtime.lastError ? {
              "ok": false
            } : _argument4
          }, location.origin);
        });else _argument.data.type === "SET_MANUAL_STATUS" && chrome.runtime.sendMessage({
          "type": "MIRSAD_SET_MANUAL_STATUS",
          "day": _argument.data.day,
          "period": _argument.data.period,
          "teacher": _argument.data.teacher,
          "status": _argument.data.status
        }, _argument5 => {
          window.postMessage({
            "source": "mirsad-auto-report",
            "type": "MANUAL_STATUS_SAVED",
            "payload": chrome.runtime.lastError ? {
              "ok": false
            } : _argument5
          }, location.origin);
        });
      }
    }
  });
})();