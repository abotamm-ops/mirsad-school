"use strict";

(() => {
  const _value = _argument => document.getElementById(_argument),
    _text = "mirsadMadrasatiSelectedDate";
  let _value2 = false,
    _value3 = false,
    _text2 = "",
    _text3 = "";
  const _value4 = _argument2 => /^\d{4}-\d{2}-\d{2}$/.test(_argument2) && Number.isFinite(Date.parse(_argument2 + "T12:00:00Z")) && new Date(_argument2 + "T12:00:00Z").toISOString().slice(0, 10) === _argument2;
  async function _value5() {
    try {
      const _value6 = await chrome.runtime.sendMessage({
        "type": "MIRSAD_SOURCE_INFO"
      });
      if (!_value6?.["ok"]) return;
      if (!_value2) _value("scheduleSource").value = _value6.mode;
      _value("collectMadrasati").hidden = false;
      for (const _value7 of ["madrasatiDateLabel", "madrasatiDateHint"]) _value(_value7).hidden = _value6.mode !== "madrasati";
      _value("madrasatiSourceDate").disabled = !!_value6.state?.["running"] || !!_value6.pending || !!_value6.recording;
      if (_value6.recordingSourceDate) _value("madrasatiSourceDate").value = _value6.recordingSourceDate;
      if (!_value3 && !_value("madrasatiSourceDate").value) _value("madrasatiSourceDate").value = _value6.selectedDate;
      _value("collectMadrasati").disabled = !!_value6.state?.["running"] || !!_value6.pending, _value("scheduleSource").disabled = !!_value6.state?.["running"] || !!_value6.recording;
      if (!_text2) void globalThis.MirsadPopupWorkflow?.["source"](_value6);
      const _value8 = _value("importDecision");
      if (_value6.pending) {
        _value("importDecisionSummary").textContent = "\u0627\u0644\u062C\u062F\u064A\u062F: " + _value6.pending.sourceDate + " \xB7 " + _value6.pending.nextLessons + " \u062D\u0635\u0629. \u0627\u0644\u0633\u0627\u0628\u0642: " + _value6.pending.previousLessons + " \u062D\u0635\u0629 \xB7 " + _value6.pending.previousRecords + " \u0646\u062A\u064A\u062C\u0629 \xB7 " + _value6.pending.previousImages + " \u0635\u0648\u0631\u0629.";
        if (!_value8.open) _value8.showModal();
      } else {
        if (_value8.open && !_value9) _value8.close();
      }
      const _value0 = _value("madrasatiSourceDate").value,
        _value1 = _value6.lastSuccess,
        _value10 = _value6.state?.["error"] ? _value6.state.text : _value1?.["date"] && _value1.date !== _value0 ? "\u0627\u0644\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u0645\u062E\u062A\u0627\u0631: " + _value0 + " \u2014 \u0622\u062E\u0631 \u0646\u0642\u0644 \u0646\u0627\u062C\u062D: " + _value1.date + " (" + _value1.lessons + " \u062D\u0635\u0629)" : _value6.state?.["text"];
      _value("scheduleSourceStatus").textContent = _text2 || (_value6.state?.["running"] ? _value6.state.text : _text3 || _value10) || "\u0627\u0644\u0645\u0635\u062F\u0631 \u0645\u062F\u0631\u0633\u062A\u064A \u2014 \u062C\u0627\u0647\u0632 \u0644\u0644\u062A\u062D\u0645\u064A\u0644 \u0625\u0644\u0649 \u0627\u0644\u0631\u0635\u062F \u0627\u0644\u0622\u0644\u064A";
    } catch {}
  }
  async function _value11(_argument3 = true) {
    _value3 = true;
    const _value12 = _value("madrasatiSourceDate").value;
    if (!_value4(_value12)) return false;
    _text2 = "";
    if (_argument3) _text3 = "\u062C\u0627\u0631\u064D \u062D\u0641\u0638 \u0627\u0644\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u0645\u062E\u062A\u0627\u0631\u2026";
    try {
      const _value13 = await chrome.storage.local.get(["mirsadAutoRun", "mirsadDriveDay"]);
      if (_value13.mirsadAutoRun?.["running"] && _value13.mirsadDriveDay?.["snapshot"]?.["sourceScheduleDate"] !== _value12) return _text2 = "\u0623\u062B\u0646\u0627\u0621 \u0627\u0644\u0631\u0635\u062F \u062D\u062F\u0651\u062B \u0631\u0648\u0627\u0628\u0637 \u062A\u0627\u0631\u064A\u062E \u0627\u0644\u062C\u062F\u0648\u0644 \u0627\u0644\u062C\u0627\u0631\u064A \u0641\u0642\u0637", _value("scheduleSourceStatus").textContent = _text2, false;
      return await chrome.storage.local.set({
        [_text]: _value12
      }), _argument3 && _value("madrasatiSourceDate").value === _value12 && (_text3 = "\u062A\u0645 \u062D\u0641\u0638 \u062A\u0627\u0631\u064A\u062E \u0627\u0644\u062C\u062F\u0648\u0644 " + _value12 + "\u061B \u0627\u0636\u063A\u0637 \xAB\u0646\u0642\u0644 \u0645\u0646 \u0645\u062F\u0631\u0633\u062A\u064A \u0625\u0644\u0649 \u0645\u0631\u0635\u0627\u062F\xBB \u0644\u0628\u062F\u0621 \u0627\u0644\u062C\u0645\u0639.", _value("scheduleSourceStatus").textContent = _text3), true;
    } catch {
      return _text2 = "\u062A\u0639\u0630\u0631 \u062D\u0641\u0638 \u0627\u0644\u062A\u0627\u0631\u064A\u062E\u061B \u0623\u0639\u062F \u0627\u062E\u062A\u064A\u0627\u0631 \u0627\u0644\u062A\u0627\u0631\u064A\u062E \u0642\u0628\u0644 \u0627\u0644\u0646\u0642\u0644", _value("scheduleSourceStatus").textContent = _text2, false;
    }
  }
  _value("scheduleSource").onchange = async () => {
    _value2 = true, _text2 = "", _text3 = "";
    const _value14 = await chrome.runtime.sendMessage({
      "type": "MIRSAD_SOURCE_SELECT",
      "mode": _value("scheduleSource").value
    });
    if (!_value14?.["ok"]) {
      _text2 = _value14?.["error"] || "\u062A\u0639\u0630\u0631 \u062D\u0641\u0638 \u0627\u0644\u0645\u0635\u062F\u0631\u061B \u062D\u062F\u0651\u062B \u0627\u0644\u0633\u0643\u0631\u0628\u062A", _value("scheduleSourceStatus").textContent = _text2;
      return;
    }
    _value2 = false, await _value5();
  }, _value("collectMadrasati").onclick = async () => {
    _text2 = "", _text3 = "";
    const _value15 = globalThis.MirsadPopupWorkflow;
    _value15?.["mark"]("collectMadrasati", "busy"), _value("collectMadrasati").disabled = true;
    try {
      if (!(await _value11(false))) throw new Error("\u0627\u062E\u062A\u0631 \u062A\u0627\u0631\u064A\u062E\u064B\u0627 \u0635\u062D\u064A\u062D\u064B\u0627 \u0642\u0628\u0644 \u0627\u0644\u0646\u0642\u0644");
      _value15?.["sourceStarted"](await chrome.runtime.sendMessage({
        "type": "MIRSAD_SOURCE_INFO"
      }));
      const _value16 = await chrome.runtime.sendMessage({
        "type": "MIRSAD_SOURCE_COLLECT",
        "date": _value("madrasatiSourceDate").value
      });
      if (!_value16?.["ok"]) throw new Error(_value16?.["error"] || "\u062A\u0639\u0630\u0631 \u0628\u062F\u0621 \u0627\u0644\u062C\u0645\u0639");
      _value("scheduleSourceStatus").textContent = "\u062C\u0627\u0631\u064D \u062A\u062D\u0645\u064A\u0644 \u0627\u0644\u062C\u062F\u0648\u0644\u061B \u064A\u0635\u0628\u062D \u0627\u0644\u0632\u0631 \u0623\u062E\u0636\u0631 \u0628\u0639\u062F \u0627\u0643\u062A\u0645\u0627\u0644 \u0627\u0644\u0646\u0642\u0644.";
    } catch (_value17) {
      _text2 = _value17.message, _value15?.["mark"]("collectMadrasati", "error"), _value("scheduleSourceStatus").textContent = _text2;
    } finally {
      _value("collectMadrasati").disabled = false;
    }
  };
  let _value9 = false;
  async function _value18(_argument4) {
    if (_value9) return;
    _value9 = true, _value("importDecisionError").textContent = "\u062C\u0627\u0631\u064D \u062A\u0637\u0628\u064A\u0642 \u0627\u062E\u062A\u064A\u0627\u0631\u0643 \u0648\u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u0627\u0644\u0631\u0635\u062F\u2026";
    for (const _value19 of ["keepPreviousImport", "discardPreviousImport", "cancelPendingImport"]) _value(_value19).disabled = true;
    try {
      const _value20 = await chrome.runtime.sendMessage({
        "type": "MIRSAD_SOURCE_CONFIRM_IMPORT",
        "keepPrevious": _argument4
      });
      if (!_value20?.["ok"]) throw new Error(_value20?.["error"] || "\u0644\u0645 \u064A\u064F\u0637\u0628\u0651\u0642 \u0627\u0644\u062C\u062F\u0648\u0644");
      _text2 = "", _text3 = "\u062A\u0645 \u062A\u0637\u0628\u064A\u0642 \u0627\u0644\u062C\u062F\u0648\u0644 \u0627\u0644\u062C\u062F\u064A\u062F \u0648\u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646\u0647 \u0641\u064A \u0627\u0644\u0631\u0635\u062F", _value("importDecision").close(), await _value5();
    } catch (_value21) {
      _value("importDecisionError").textContent = _value21.message, _text2 = _value21.message, globalThis.MirsadPopupWorkflow?.["mark"]("collectMadrasati", "error");
    } finally {
      _value9 = false;
      for (const _value22 of ["keepPreviousImport", "discardPreviousImport", "cancelPendingImport"]) _value(_value22).disabled = false;
    }
  }
  _value("keepPreviousImport").onclick = () => _value18(true), _value("discardPreviousImport").onclick = () => _value18(false), _value("cancelPendingImport").onclick = async () => {
    if (_value9) return;
    await chrome.runtime.sendMessage({
      "type": "MIRSAD_SOURCE_CANCEL_IMPORT"
    }), _text2 = "", _value("importDecision").close(), await _value5();
  }, _value("importDecision").addEventListener("cancel", _argument5 => {
    _argument5.preventDefault();
    if (!_value9) _value("cancelPendingImport").click();
  }), _value("madrasatiSourceDate").oninput = () => void _value11(), _value("madrasatiSourceDate").onchange = () => void _value11(), void _value5(), setInterval(_value5, 1500);
})();