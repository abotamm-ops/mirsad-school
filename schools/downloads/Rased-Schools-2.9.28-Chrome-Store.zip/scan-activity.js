"use strict";

var MirsadScanActivity = (() => {
  const _text = "mirsadActiveScan";
  let _value = Promise.resolve();
  function _value2(_argument) {
    const _value3 = _value["catch"](() => {}).then(_argument);
    return _value = _value3["catch"](() => {}), _value3;
  }
  async function _value4() {
    return (await chrome.storage.local.get(_text))[_text] || null;
  }
  async function _value5(_argument2) {
    return _value2(async () => {
      const _value6 = await _value4();
      if (_value6?.["tabId"] === _argument2) await chrome.storage.local.set({
        [_text]: null
      });
    });
  }
  function _value7(_argument3, _argument4) {
    const _value8 = _argument4?.["current"];
    if (!_value8 || !Number.isInteger(_argument3)) return Promise.resolve();
    const _options = {
      "active": true,
      "tabId": _argument3,
      "scanId": _value8.scanId,
      "teacher": _value8.teacher,
      "teacherId": _value8.teacherId || null,
      "date": MirsadMonitorModel.day(),
      "period": _argument4.period,
      "cycle": _argument4.cycle,
      "openedAt": Date.now()
    };
    return _value2(async () => {
      try {
        await chrome.tabs.get(_argument3), await chrome.storage.local.set({
          [_text]: _options
        });
      } catch {
        await chrome.storage.local.set({
          [_text]: null
        });
      }
    });
  }
  async function _value9() {
    await _value;
    const _value0 = await _value4();
    if (!_value0) return {
      "ok": true,
      "activity": null
    };
    try {
      return await chrome.tabs.get(_value0.tabId), {
        "ok": true,
        "activity": _value0
      };
    } catch {
      return await _value5(_value0.tabId), {
        "ok": true,
        "activity": null
      };
    }
  }
  return chrome.tabs.onRemoved?.["addListener"](_argument5 => {
    void _value5(_argument5)["catch"](() => {});
  }), chrome.runtime.onStartup?.["addListener"](() => {
    void _value9()["catch"](() => {});
  }), {
    "open": _value7,
    "clearTab": _value5,
    "info": _value9
  };
})();