"use strict";

var MirsadGuardianTabs = (() => {
  const _text = "https://mirsad-school.onrender.com/schools/automatic-monitoring.html";
  let _value = Promise.resolve();
  const _value2 = new Map();
  function _value3(_argument) {
    try {
      const _value4 = new URL(_argument.pendingUrl || _argument.url);
      return _value4.origin === "https://mirsad-school.onrender.com" && _value4.pathname === "/schools/automatic-monitoring.html" && _value4.searchParams.get("guardian") === "1";
    } catch {
      return false;
    }
  }
  async function _value5(_argument2) {
    let _value6;
    try {
      _value6 = await chrome.tabs.get(_argument2);
    } catch {
      return;
    }
    if (!_value3(_value6)) return;
    const _value7 = await chrome.tabs.query({
        "url": _text + "*"
      }),
      _value8 = _value7.filter(_argument3 => _argument3.id !== _argument2 && _argument3.id < _argument2).sort((_argument4, _argument5) => _argument4.id - _argument5.id)[0],
      _value9 = await chrome.storage.local.get("mirsadWorkspaceWindowId");
    let _value0 = _value9.mirsadWorkspaceWindowId;
    if (Number.isInteger(_value0) && chrome.windows?.["get"]) try {
      await chrome.windows.get(_value0);
    } catch {
      _value0 = null;
    }
    if (!Number.isInteger(_value0)) {
      const _value1 = await chrome.tabs.query({
        "url": "https://schools.madrasati.sa/SchoolManagment/Teachers*"
      });
      _value0 = (_value1.find(_argument6 => _argument6.active) || _value1[0] || _value8 || _value6).windowId;
    }
    const _value10 = _value8 || _value6;
    if (Number.isInteger(_value0) && _value10.windowId !== _value0) await chrome.tabs.move(_value10.id, {
      "windowId": _value0,
      "index": -1
    });
    if (_value8) await chrome.tabs.remove(_argument2);
    const _value11 = typeof getRun === "function" ? await getRun() : null;
    if (_value11?.["running"] && _value11.current && Number.isInteger(_value11.tabId)) try {
      const _value12 = await chrome.tabs.get(_value11.tabId);
      if (_value12.windowId === _value0) {
        await chrome.tabs.update(_value12.id, {
          "active": true
        });
        if (chrome.windows?.["update"]) await chrome.windows.update(_value0, {
          "focused": true
        });
      }
    } catch {}
  }
  function _value13(_argument7) {
    _value2["delete"](_argument7.id);
    const _value14 = _value["catch"](() => {}).then(() => _value5(_argument7.id));
    return _value = _value14["catch"](() => {}), _value14;
  }
  return chrome.tabs.onCreated?.["addListener"](_argument8 => {
    if (_value3(_argument8)) {
      void _value13(_argument8);
      return;
    }
    const _value15 = _argument8.pendingUrl || _argument8.url;
    if (!_value15 || _value15 === "about:blank") {
      const _value16 = Date.now();
      for (const [_value17, _value18] of _value2) if (_value16 - _value18 > 30000) _value2["delete"](_value17);
      if (_value2.size < 256) _value2.set(_argument8.id, _value16);
    }
  }), chrome.tabs.onUpdated?.["addListener"]((_argument9, _argument0, _argument1) => {
    if (!_value2.has(_argument9)) return;
    if (_value3(_argument1)) {
      void _value13(_argument1);
      return;
    }
    if (_argument0.url && _argument0.url !== "about:blank") _value2["delete"](_argument9);
  }), chrome.tabs.onRemoved?.["addListener"](_argument10 => _value2["delete"](_argument10)), {
    "repair": _argument11 => _value13(_argument11)
  };
})();