"use strict";

let pauseCommandBusy = false,
  popupRefreshId = 0;
const thirdRoundGapNode = document.getElementById("thirdRoundGapMinutes"),
  startPeriodNode = document.getElementById("startPeriod"),
  endPeriodNode = document.getElementById("endPeriod"),
  statusNode = document.getElementById("status"),
  startNode = document.getElementById("manualStart"),
  durationNode = document.getElementById("periodDuration"),
  gapNode = document.getElementById("manualGapMinutes"),
  delayNode = document.getElementById("scanDelay"),
  roundCountNode = document.getElementById("roundCount"),
  roundGapNode = document.getElementById("roundGapMinutes"),
  previewNode = document.getElementById("preview"),
  linkPeriodNode = document.getElementById("link-period"),
  linkSummaryNode = document.getElementById("link-summary"),
  linkListNode = document.getElementById("link-list");
function periodsFromSettings(_argument) {
  const _value = _argument.periodDuration ?? 45,
    _value2 = _argument.manualGapMinutes ?? 1,
    _value3 = _argument.scanDelay ?? 1,
    _value4 = globalThis.MirsadScheduleCore?.["makeManualPeriods"](_argument.manualStart || "06:30", _value, _value2, 7, _value3) || [];
  if (!_value4.length) return [];
  return ["\u0646\u0637\u0627\u0642 \u0627\u0644\u0631\u0635\u062F: \u0645\u0646 \u0627\u0644\u062D\u0635\u0629 " + (_argument.startPeriod ?? 1) + " \u0625\u0644\u0649 \u0627\u0644\u062D\u0635\u0629 " + (_argument.endPeriod ?? 7), "\u0645\u062F\u0629 \u0627\u0644\u062D\u0635\u0629: " + _value + " \u062F\u0642\u064A\u0642\u0629", "\u0627\u0644\u0641\u0627\u0635\u0644 \u0628\u064A\u0646 \u0627\u0644\u062D\u0635\u0635: " + _value2 + " \u062F\u0642\u064A\u0642\u0629", "\u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u0639\u062F \u0627\u0644\u0628\u062F\u0627\u064A\u0629: " + _value3 + " \u062F\u0642\u064A\u0642\u0629", "\u0623\u0648\u0642\u0627\u062A \u0627\u0644\u062D\u0635\u0635:", ..._value4.filter(_argument2 => _argument2.n >= (_argument.startPeriod ?? 1) && _argument2.n <= (_argument.endPeriod ?? 7)).map(_argument3 => "\u0627\u0644\u062D\u0635\u0629 " + _argument3.n + ": \u062A\u0628\u062F\u0623 " + _argument3.start + " \u0648\u062A\u0646\u062A\u0647\u064A " + _argument3.end + " \u2014 \u0627\u0644\u062F\u062E\u0648\u0644 " + _argument3.scan)];
}
function renderPreview(_argument4) {
  previewNode.textContent = periodsFromSettings(_argument4).join("\n") || "\u062A\u062D\u0642\u0642 \u0645\u0646 \u0642\u064A\u0645 \u0627\u0644\u062A\u0648\u0642\u064A\u062A \u0627\u0644\u0645\u062F\u062E\u0644\u0629.";
}
async function loadSettings() {
  try {
    const _value5 = await chrome.runtime.sendMessage({
        "type": "MIRSAD_GET_LIVE_REPORT"
      }),
      _value6 = _value5?.["scheduleSettings"] || {};
    startPeriodNode.value = String(_value6.startPeriod ?? 1), endPeriodNode.value = String(_value6.endPeriod ?? 7), startNode.value = _value6.manualStart || "06:30", durationNode.value = String(_value6.periodDuration ?? 45), gapNode.value = String(_value6.manualGapMinutes ?? 1), delayNode.value = String(_value6.scanDelay ?? 1), roundCountNode.value = String(_value6.configuredRoundCount ?? _value6.roundCount ?? 3), thirdRoundGapNode.value = String(_value6.thirdRoundGapMinutes ?? 5), roundGapNode.value = String(_value6.roundGapMinutes ?? 5), renderPreview(_value6), MirsadPopupWorkflow.timingLoaded();
  } catch (_value7) {
    previewNode.textContent = "\u062A\u0639\u0630\u0631 \u0642\u0631\u0627\u0621\u0629 \u0625\u0639\u062F\u0627\u062F\u0627\u062A \u0627\u0644\u062A\u0648\u0642\u064A\u062A.";
  }
}
document.getElementById("save-time").addEventListener("click", async () => {
  const _value8 = document.getElementById("save-time");
  _value8.disabled = true, MirsadPopupWorkflow.mark("save-time", "busy");
  try {
    const _options = {
        "startPeriod": Number(startPeriodNode.value),
        "endPeriod": Number(endPeriodNode.value),
        "manualStart": startNode.value,
        "periodDuration": Number(durationNode.value),
        "manualGapMinutes": Number(gapNode.value),
        "scanDelay": Number(delayNode.value),
        "roundCount": Number(roundCountNode.value),
        "thirdRoundGapMinutes": Number(thirdRoundGapNode.value),
        "roundGapMinutes": Number(roundGapNode.value)
      },
      _value9 = await chrome.runtime.sendMessage({
        "type": "MIRSAD_SAVE_SCHEDULE_SETTINGS",
        "settings": _options
      });
    if (!_value9?.["ok"]) {
      MirsadPopupWorkflow.mark("save-time", "error"), statusNode.textContent = _value9?.["reason"] === "invalid" ? "\u062A\u062D\u0642\u0642 \u0645\u0646 \u0646\u0637\u0627\u0642 \u0627\u0644\u062D\u0635\u0635 (\u0627\u0644\u0628\u062F\u0627\u064A\u0629 \u0644\u0627 \u062A\u062A\u062C\u0627\u0648\u0632 \u0627\u0644\u0646\u0647\u0627\u064A\u0629) \u0648\u0627\u0644\u062A\u0648\u0642\u064A\u062A \u0648\u0639\u062F\u062F \u0627\u0644\u062F\u0648\u0631\u0627\u062A (1\u20133) \u0648\u0641\u0627\u0635\u0644 \u0643\u0644 \u062F\u0648\u0631\u0629 (1\u201310 \u062F\u0642\u0627\u0626\u0642)." : _value9?.["detail"] || "\u0627\u0641\u062A\u062D \u0635\u0641\u062D\u0629 \u062C\u062F\u0648\u0644 \u0645\u0631\u0635\u0627\u062F \u0648\u062A\u0623\u0643\u062F \u0645\u0646 \u0638\u0647\u0648\u0631 \u0623\u0639\u0645\u062F\u0629 \u0627\u0644\u062D\u0635\u0635 \u0648\u0623\u0633\u0645\u0627\u0621 \u0627\u0644\u0645\u0639\u0644\u0645\u064A\u0646.";
      return;
    }
    renderPreview(_value9.settings), await MirsadPopupWorkflow.timingSaved(), statusNode.textContent = "\u062D\u064F\u0641\u0638 \u0627\u0644\u062A\u0648\u0642\u064A\u062A \u0627\u0644\u064A\u062F\u0648\u064A. \u0631\u0627\u062C\u0639 \u0623\u0648\u0642\u0627\u062A \u0628\u062F\u0627\u064A\u0629 \u0648\u0646\u0647\u0627\u064A\u0629 \u0627\u0644\u062D\u0635\u0635 \u0648\u0645\u0648\u0639\u062F \u0627\u0644\u062F\u062E\u0648\u0644 \u0623\u062F\u0646\u0627\u0647.";
  } catch (_value0) {
    MirsadPopupWorkflow.mark("save-time", "error"), statusNode.textContent = "\u062A\u0639\u0630\u0631 \u062D\u0641\u0638 \u0625\u0639\u062F\u0627\u062F\u0627\u062A \u0627\u0644\u062A\u0648\u0642\u064A\u062A.";
  } finally {
    _value8.disabled = false;
  }
});
async function refresh() {
  const _value1 = ++popupRefreshId;
  try {
    const _value10 = await chrome.runtime.sendMessage({
      "type": "MIRSAD_STATUS"
    });
    if (_value1 !== popupRefreshId) return;
    let _value11 = _value10?.["status"]?.["text"] || "\u0644\u0627 \u062A\u0648\u062C\u062F \u062D\u0627\u0644\u0629";
    const _value12 = _value10?.["run"];
    MirsadPopupWorkflow.run(_value12);
    const _value13 = document.getElementById("pause-resume");
    _value13.disabled = pauseCommandBusy || !_value12?.["running"] && !_value12?.["paused"], _value13.dataset.paused = String(!!_value12?.["paused"]), _value13.textContent = _value12?.["paused"] ? "\u25B6 \u0627\u0633\u062A\u0626\u0646\u0627\u0641 \u0627\u0644\u0631\u0635\u062F" : "\u23F8 \u0625\u064A\u0642\u0627\u0641 \u0645\u0624\u0642\u062A";
    const _value14 = document.getElementById("brand-icon");
    _value14 && (_value14.src = _value12?.["running"] ? "icons/on-48.png" : "icons/off-48.png", _value14.alt = _value12?.["running"] ? "\u0627\u0644\u0631\u0635\u062F \u064A\u0639\u0645\u0644" : "\u0627\u0644\u0631\u0635\u062F \u0645\u062A\u0648\u0642\u0641");
    if (_value12?.["running"] && _value12.period) _value11 += "\n\u0627\u0644\u062A\u0642\u062F\u0645: \u0627\u0644\u062D\u0635\u0629 " + _value12.period + "\u060C " + _value12.index + "/" + (_value12.periodItems?.["length"] || 0);
    if (_value12?.["results"]?.["length"]) _value11 += "\n\n\u0622\u062E\u0631 \u0627\u0644\u0646\u062A\u0627\u0626\u062C:\n" + _value12.results.slice(-6).map(_argument5 => (_argument5.scheduledTeacher || _argument5.teacher) + " \u2014 " + (_argument5.subject ? _argument5.subject + " | " : "") + "\u0627\u0644\u062D\u0635\u0629 " + (_argument5.period || "\u063A\u064A\u0631 \u0645\u062D\u062F\u062F\u0629") + ": " + (_argument5.status === "present" ? "\u062D\u0627\u0636\u0631" : _argument5.status === "absent" ? "\u063A\u0627\u0626\u0628" : _argument5.status === "late" ? "\u062D\u0627\u0636\u0631" : _argument5.status === "no-link" ? "\u063A\u0627\u0626\u0628 \u2014 \u0644\u0627 \u064A\u0648\u062C\u062F \u0631\u0627\u0628\u0637 Teams" : "\u063A\u064A\u0631 \u0645\u062D\u0633\u0648\u0645")).join("\n");
    statusNode.textContent = _value11;
  } catch (_value15) {
    MirsadPopupWorkflow.mark("start", "error"), statusNode.textContent = "\u062A\u0639\u0630\u0631 \u0642\u0631\u0627\u0621\u0629 \u062D\u0627\u0644\u0629 \u0627\u0644\u0625\u0636\u0627\u0641\u0629.";
  }
}
document.getElementById("start").addEventListener("click", async () => {
  MirsadPopupWorkflow.mark("start", "busy"), statusNode.textContent = "\u062C\u0627\u0631\u064D \u0628\u062F\u0621 \u0627\u0644\u0631\u0635\u062F\u2026";
  try {
    const _value16 = await chrome.runtime.sendMessage({
      "type": "MIRSAD_START"
    });
    if (!_value16?.["ok"]) MirsadPopupWorkflow.mark("start", "error"), statusNode.textContent = _value16?.["error"] || "\u062A\u0639\u0630\u0631 \u0628\u062F\u0621 \u0627\u0644\u0631\u0635\u062F";else await refresh();
  } catch (_value17) {
    MirsadPopupWorkflow.mark("start", "error"), statusNode.textContent = "\u062A\u0639\u0630\u0631 \u0628\u062F\u0621 \u0627\u0644\u0631\u0635\u062F: " + _value17.message;
  }
}), document.getElementById("start-now").addEventListener("click", async () => {
  statusNode.textContent = "\u062C\u0627\u0631\u064D \u0628\u062F\u0621 \u0641\u062D\u0635 \u0641\u0648\u0631\u064A \u062A\u0634\u062E\u064A\u0635\u064A\u2026";
  const _value18 = await chrome.runtime.sendMessage({
    "type": "MIRSAD_START_NOW"
  });
  if (!_value18?.["ok"]) statusNode.textContent = "\u062A\u0639\u0630\u0631 \u0628\u062F\u0621 \u0627\u0644\u0641\u062D\u0635 \u0627\u0644\u0641\u0648\u0631\u064A.";
  setTimeout(refresh, 500);
}), document.getElementById("pause-resume").addEventListener("click", async _argument6 => {
  const _value19 = _argument6.currentTarget;
  if (pauseCommandBusy) return;
  pauseCommandBusy = true, popupRefreshId++, _value19.disabled = true;
  try {
    const _value20 = await chrome.runtime.sendMessage({
      "type": _value19.dataset.paused === "true" ? "MIRSAD_RESUME" : "MIRSAD_PAUSE"
    });
    if (!_value20?.["ok"]) statusNode.textContent = _value20?.["error"] || "\u062A\u0639\u0630\u0631 \u062A\u063A\u064A\u064A\u0631 \u062D\u0627\u0644\u0629 \u0627\u0644\u0631\u0635\u062F";else await refresh();
  } catch (_value21) {
    statusNode.textContent = "\u062A\u0639\u0630\u0631 \u062A\u063A\u064A\u064A\u0631 \u062D\u0627\u0644\u0629 \u0627\u0644\u0631\u0635\u062F: " + _value21.message;
  } finally {
    pauseCommandBusy = false, await refresh();
  }
}), document.getElementById("stop").addEventListener("click", async () => {
  statusNode.textContent = "\u062C\u0627\u0631\u064D \u0625\u064A\u0642\u0627\u0641 \u0627\u0644\u0645\u0631\u0627\u0642\u0628\u0629\u2026", await chrome.runtime.sendMessage({
    "type": "MIRSAD_STOP"
  }), setTimeout(refresh, 300);
}), document.getElementById("show-links").addEventListener("click", async _argument7 => {
  const _value22 = _argument7.currentTarget,
    _value23 = Number(linkPeriodNode.value);
  _value22.disabled = true, linkSummaryNode.textContent = "\u062C\u0627\u0631\u064D \u0642\u0631\u0627\u0621\u0629 \u0631\u0648\u0627\u0628\u0637 \u0627\u0644\u062C\u062F\u0648\u0644\u2026", linkListNode.replaceChildren();
  try {
    const _value24 = await chrome.runtime.sendMessage({
        "type": "MIRSAD_DRIVE_INFO"
      }),
      _value25 = _value24.day?.["snapshot"];
    if (!_value25) {
      linkSummaryNode.textContent = "\u062D\u0645\u0651\u0644 \u062C\u062F\u0648\u0644 \u0627\u0644\u0631\u0635\u062F \u0645\u0646 \u0627\u0644\u062E\u0637\u0648\u0629 1 \u0623\u0648\u0644\u064B\u0627";
      return;
    }
    const _options2 = {
        "items": _value25.lessons.map(_argument8 => ({
          ..._argument8,
          "teacher": _argument8.teacherName,
          "hasLesson": true
        }))
      },
      _value26 = (_options2.items || []).filter(_argument9 => _argument9.teacher && _argument9.hasLesson),
      _value27 = _value26.filter(_argument0 => _argument0.period === _value23 && globalThis.MirsadScheduleCore.validTeamsUrl(_argument0.url)),
      _value28 = _value26.filter(_argument1 => globalThis.MirsadScheduleCore.validTeamsUrl(_argument1.url) && (!Number.isInteger(_argument1.period) || _argument1.period < 1 || _argument1.period > 7));
    linkSummaryNode.textContent = "\u0627\u0644\u062D\u0635\u0629 " + _value23 + ": \u0639\u064F\u062B\u0631 \u0639\u0644\u0649 " + _value27.length + " \u0631\u0627\u0628\u0637\u064B\u0627 \u0635\u0627\u0644\u062D\u064B\u0627." + (_value28.length ? "\n\u0647\u0646\u0627\u0643 " + _value28.length + " \u0631\u0627\u0628\u0637\u064B\u0627 \u0644\u0645 \u064A\u0645\u0643\u0646 \u0631\u0628\u0637\u0647 \u0628\u062D\u0635\u0629\u060C \u0644\u0630\u0644\u0643 \u0644\u0645 \u0623\u062F\u0631\u062C\u0647." : "");
    if (!_value27.length) return;
    for (const _value29 of _value27) {
      const _value30 = document.createElement("div"),
        _value31 = document.createElement("strong"),
        _value32 = document.createElement("a");
      _value30.className = "link-row", _value31.textContent = _value29.teacher, _value32.textContent = _value29.url, _value32.href = _value29.url, _value32.target = "_blank", _value32.rel = "noopener noreferrer", _value30.append(_value31, _value32), linkListNode.append(_value30);
    }
  } catch (_value33) {
    linkSummaryNode.textContent = "\u062A\u0639\u0630\u0631 \u0642\u0631\u0627\u0621\u0629 \u0627\u0644\u0631\u0648\u0627\u0628\u0637: " + String(_value33?.["message"] || _value33);
  } finally {
    _value22.disabled = false;
  }
}), setInterval(refresh, 1500), refresh(), loadSettings();
function csvCell(_argument10) {
  return "\"" + String(_argument10 ?? "").replace(/"/g, "\"\"") + "\"";
}
document.getElementById("export").addEventListener("click", async () => {
  const _value34 = document.getElementById("export");
  _value34.disabled = true;
  try {
    const _value35 = await chrome.runtime.sendMessage({
        "type": "MIRSAD_STATUS"
      }),
      _value36 = _value35?.["run"]?.["results"] || [];
    if (!_value36.length) {
      statusNode.textContent = "\u0644\u0627 \u062A\u0648\u062C\u062F \u0641\u062D\u0648\u0635\u0627\u062A \u0645\u062D\u0641\u0648\u0638\u0629 \u0644\u062A\u0635\u062F\u064A\u0631\u0647\u0627 \u062D\u062A\u0649 \u0627\u0644\u0622\u0646.";
      return;
    }
    const _value37 = await chrome.storage.local.get("mirsadManualMappings"),
      _value38 = _value37.mirsadManualMappings || {},
      _items = ["\u0648\u0642\u062A \u0627\u0644\u0641\u062D\u0635", "\u0627\u0644\u0645\u0639\u0644\u0645 \u0645\u0646 \u0627\u0644\u062C\u062F\u0648\u0644", "\u0627\u0633\u0645 Teams \u0627\u0644\u0645\u0631\u0635\u0648\u062F", "\u0627\u0644\u0645\u0639\u0644\u0645 \u0627\u0644\u0645\u0637\u0627\u0628\u0642 \u064A\u062F\u0648\u064A\u064B\u0627", "\u0631\u0642\u0645 \u0627\u0644\u062D\u0635\u0629", "\u0627\u0644\u0645\u0627\u062F\u0629", "\u0627\u0644\u0641\u0635\u0644", "\u0627\u0644\u062D\u0627\u0644\u0629", "\u0627\u0644\u062A\u0641\u0627\u0635\u064A\u0644"],
      _value39 = [_items, ..._value36.map(_argument11 => [_argument11.scannedAt ? new Date(_argument11.scannedAt).toLocaleString("ar-SA") : "", _argument11.scheduledTeacher || "", _argument11.teacher || "", _value38[_argument11.teacher] || "", _argument11.period || "\u063A\u064A\u0631 \u0645\u062D\u062F\u062F\u0629", _argument11.subject || "", _argument11.className || "", _argument11.status === "present" ? "\u062D\u0627\u0636\u0631" : _argument11.status === "absent" ? "\u063A\u0627\u0626\u0628" : _argument11.status === "late" ? "\u062D\u0627\u0636\u0631" : _argument11.status === "no-link" ? "\u063A\u0627\u0626\u0628 \u2014 \u0644\u0627 \u064A\u0648\u062C\u062F \u0631\u0627\u0628\u0637 Teams" : "\u063A\u064A\u0631 \u0645\u062D\u0633\u0648\u0645", _argument11.detail || ""])].map(_argument12 => _argument12.map(csvCell).join(","));
    await chrome.downloads.download({
      "url": "data:text/csv;charset=utf-8," + encodeURIComponent("\uFEFF" + _value39.join("\r\n")),
      "filename": "mirsad-teams-report-" + new Date().toISOString().slice(0, 10) + ".csv",
      "saveAs": true
    }), statusNode.textContent = "\u062C\u0647\u0632 \u0631\u0627\u0635\u062F \u062A\u0642\u0631\u064A\u0631\u064B\u0627 \u0645\u062D\u0644\u064A\u064B\u0627 \u064A\u062D\u062A\u0648\u064A \u0639\u0644\u0649 " + _value36.length + " \u0646\u062A\u064A\u062C\u0629.";
  } catch (_value40) {
    statusNode.textContent = "\u062A\u0639\u0630\u0631 \u062A\u0646\u0632\u064A\u0644 \u0627\u0644\u062A\u0642\u0631\u064A\u0631.";
  } finally {
    _value34.disabled = false;
  }
}), document.getElementById("diagnose").addEventListener("click", async () => {
  const _value41 = document.getElementById("diagnose");
  _value41.disabled = true, statusNode.textContent = "\u062C\u0627\u0631\u064D \u0641\u062D\u0635 \u0631\u0628\u0637 \u0627\u0644\u062D\u0635\u0635 \u0648\u0627\u0644\u0631\u0648\u0627\u0628\u0637\u2026";
  try {
    const _value42 = await chrome.runtime.sendMessage({
        "type": "MIRSAD_DRIVE_INFO"
      }),
      _value43 = _value42.day?.["snapshot"];
    if (!_value43) {
      statusNode.textContent = "\u062D\u0645\u0651\u0644 \u062C\u062F\u0648\u0644 \u0627\u0644\u0631\u0635\u062F \u0645\u0646 \u0627\u0644\u062E\u0637\u0648\u0629 1 \u0623\u0648\u0644\u064B\u0627";
      return;
    }
    const _options3 = {
        "title": "\u062C\u062F\u0648\u0644 \u0627\u0644\u0631\u0635\u062F \u0627\u0644\u0622\u0644\u064A \u0627\u0644\u0645\u062D\u0641\u0648\u0638"
      },
      _options4 = {
        "items": _value43.lessons.map(_argument13 => ({
          ..._argument13,
          "teacher": _argument13.teacherName,
          "hasLesson": true
        }))
      },
      _value44 = (_options4.items || []).filter(_argument14 => _argument14.teacher && _argument14.hasLesson),
      _value45 = _value44.filter(_argument15 => _argument15.validPeriod === false || !Number.isInteger(_argument15.period) || _argument15.period < 1 || _argument15.period > 7),
      _items2 = ["\u0646\u062A\u064A\u062C\u0629 \u0641\u062D\u0635 \u0627\u0644\u062C\u062F\u0648\u0644:", "\u0627\u0644\u062A\u0628\u0648\u064A\u0628: " + (_options3.title || _options3.url || "\u063A\u064A\u0631 \u0645\u0639\u0631\u0648\u0641"), "\u062E\u0644\u0627\u064A\u0627 \u0627\u0644\u0645\u0639\u0644\u0645\u064A\u0646/\u0627\u0644\u062F\u0631\u0648\u0633: " + _value44.length, "\u0631\u0648\u0627\u0628\u0637 Teams: " + _value44.filter(_argument16 => _argument16.url).length, "\u062E\u0644\u0627\u064A\u0627 \u0644\u0645 \u064A\u0645\u0643\u0646 \u0631\u0628\u0637\u0647\u0627 \u0628\u0631\u0642\u0645 \u062D\u0635\u0629: " + _value45.length, "\u0627\u0644\u062A\u0648\u0642\u064A\u062A \u0645\u062D\u0641\u0648\u0638 \u0641\u064A \u0627\u0644\u0631\u0635\u062F \u0648\u064A\u0638\u0647\u0631 \u0623\u0639\u0644\u0649 \u0623\u0639\u0645\u062F\u0629 \u0627\u0644\u062D\u0635\u0635."];
    for (const _value46 of _value45.slice(0, 8)) _items2.push("\u2022 " + (_value46.reason || _value46.teacher + " \u2014 " + _value46.label));
    statusNode.textContent = _items2.join("\n");
  } catch (_value47) {
    statusNode.textContent = "\u062A\u0639\u0630\u0631 \u0641\u062D\u0635 \u0627\u0644\u062C\u062F\u0648\u0644: " + String(_value47?.["message"] || _value47);
  } finally {
    _value41.disabled = false;
  }
});
let driveInfoLoaded = false,
  driveFormError = "";
async function driveInfo() {
  const _value48 = await chrome.runtime.sendMessage({
    "type": "MIRSAD_DRIVE_INFO"
  });
  !driveInfoLoaded && (document.getElementById("driveUrl").value = _value48.url || "", driveInfoLoaded = true);
  const _value49 = document.getElementById("driveKey");
  !_value49.value && (document.getElementById("drive-key-state").textContent = _value48.configured ? "\uD83D\uDD12 \u0631\u0645\u0632 \u0627\u0644\u0631\u0641\u0639 \u0645\u062D\u0641\u0648\u0638 \u0639\u0644\u0649 \u0647\u0630\u0627 \u0627\u0644\u0645\u062A\u0635\u0641\u062D" : "\u0644\u0645 \u064A\u064F\u062D\u0641\u0638 \u0631\u0645\u0632 \u0627\u0644\u0631\u0641\u0639 \u0628\u0639\u062F", _value49.placeholder = _value48.configured ? "\u0627\u0644\u0631\u0645\u0632 \u0645\u062D\u0641\u0648\u0638\u061B \u0627\u062A\u0631\u0643\u0647 \u0641\u0627\u0631\u063A\u064B\u0627 \u0644\u0644\u0627\u062D\u062A\u0641\u0627\u0638 \u0628\u0647" : "\u0627\u0644\u0635\u0642 \u0642\u064A\u0645\u0629 MONITOR_API_KEY \u0647\u0646\u0627");
  document.getElementById("drive-status").textContent = driveFormError || _value48.status?.["text"] || (_value48.configured ? "\u062D\u0645\u0651\u0644 \u062C\u062F\u0648\u0644 \u0627\u0644\u064A\u0648\u0645" : "\u0623\u0643\u0645\u0644 \u0627\u0644\u0631\u0628\u0637 \u062B\u0645 \u062D\u0645\u0651\u0644 \u062C\u062F\u0648\u0644 \u0627\u0644\u064A\u0648\u0645"), void MirsadPopupWorkflow.drive(_value48);
  const _value50 = document.getElementById("drive-folder");
  _value50.hidden = !_value48.day?.["folderUrl"];
  if (!_value50.hidden) _value50.href = _value48.day.folderUrl;
}
document.getElementById("save-drive").onclick = async () => {
  const _value51 = document.getElementById("save-drive"),
    _value52 = document.getElementById("driveKey");
  _value51.disabled = true;
  try {
    const _value53 = await chrome.runtime.sendMessage({
      "type": "MIRSAD_DRIVE_CONFIG",
      "url": document.getElementById("driveUrl").value.trim(),
      "key": _value52.value.trim()
    });
    if (!_value53?.["ok"]) throw new Error(_value53?.["error"] || "\u062A\u0639\u0630\u0631 \u062D\u0641\u0638 \u0627\u0644\u0631\u0628\u0637");
    driveFormError = "", _value52.value = "", await driveInfo(), document.getElementById("drive-status").textContent = "\u062A\u0645 \u062D\u0641\u0638 \u0627\u0644\u0631\u0628\u0637 \u0648\u0627\u0644\u0631\u0645\u0632 \u0628\u0646\u062C\u0627\u062D\u061B \u0644\u0627 \u064A\u0644\u0632\u0645 \u0625\u062F\u062E\u0627\u0644 \u0627\u0644\u0631\u0645\u0632 \u0645\u0631\u0629 \u062B\u0627\u0646\u064A\u0629. \u062D\u0645\u0651\u0644 \u062C\u062F\u0648\u0644 \u0627\u0644\u064A\u0648\u0645.";
  } catch (_value54) {
    driveFormError = _value54.message, document.getElementById("drive-status").textContent = _value54.message, document.getElementById("drive-key-state").textContent = "\u0644\u0645 \u064A\u064F\u062D\u0641\u0638 \u0627\u0644\u062A\u0639\u062F\u064A\u0644\u061B \u0627\u0644\u0631\u0645\u0632 \u0627\u0644\u0645\u0643\u062A\u0648\u0628 \u0645\u0627 \u0632\u0627\u0644 \u0641\u064A \u0627\u0644\u062E\u0627\u0646\u0629";
  } finally {
    _value51.disabled = false;
  }
}, document.getElementById("driveKey").oninput = () => {
  driveFormError = "", document.getElementById("drive-key-state").textContent = "\u0627\u0636\u063A\u0637 \u062D\u0641\u0638 \u0627\u0644\u0631\u0628\u0637 \u0644\u062D\u0641\u0638 \u0627\u0644\u0631\u0645\u0632 \u0627\u0644\u0645\u0643\u062A\u0648\u0628";
}, document.getElementById("begin-day").onclick = async () => {
  const _value55 = document.getElementById("begin-day");
  _value55.disabled = true, driveFormError = "", MirsadPopupWorkflow.mark("begin-day", "busy");
  try {
    const _value56 = await chrome.runtime.sendMessage({
      "type": "MIRSAD_BEGIN_DAY"
    });
    if (!_value56.ok) throw new Error(_value56.error);
    await MirsadPopupWorkflow.prepared(_value56.day), await driveInfo();
  } catch (_value57) {
    MirsadPopupWorkflow.mark("begin-day", "error"), driveFormError = _value57.message, document.getElementById("drive-status").textContent = _value57.message;
  } finally {
    _value55.disabled = false;
  }
}, document.getElementById("retry-drive").onclick = async () => {
  await chrome.runtime.sendMessage({
    "type": "MIRSAD_DRIVE_RETRY"
  }), await driveInfo();
}, driveInfo(), setInterval(driveInfo, 5000);