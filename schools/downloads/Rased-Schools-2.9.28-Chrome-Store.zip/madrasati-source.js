"use strict";

var MadrasatiSource = (() => {
  const _text = "mirsadMadrasatiCollection";
  let _value = false;
  let automaticSession = null;
  function priorityCancelled() {
    return Object.assign(new Error("\u0623\u064F\u062C\u0651\u0644 \u062C\u0645\u0639 \u0627\u0644\u0631\u0648\u0627\u0628\u0637 \u0644\u0625\u0639\u0637\u0627\u0621 \u062A\u064A\u0645\u0632 \u0623\u0648\u0644\u0648\u064A\u0629 \u0627\u0644\u0641\u062D\u0635 \u0648\u0627\u0644\u062A\u0635\u0648\u064A\u0631"), {
      cancelled: true,
      fatal: true
    });
  }
  async function cancelAutomatic() {
    if (!automaticSession) return false;
    automaticSession.cancelled = true;
    await Promise.allSettled([..._value2].map(id => MirsadTabOwnership.closeCollector(id)));
    return true;
  }
  async function priorityCheckpoint() {
    if (!automaticSession) return;
    if (automaticSession.cancelled) throw priorityCancelled();
    const run = await getRun();
    if (run?.running && run.current || automaticSession.shouldContinue && !(await automaticSession.shouldContinue())) {
      await cancelAutomatic();
      throw priorityCancelled();
    }
  }
  const _value2 = new Set(),
    _value3 = _argument => new Promise(_argument2 => setTimeout(_argument2, _argument)),
    _value4 = new Map(),
    _value5 = new Map();
  if (chrome.webRequest?.["onBeforeRequest"]) {
    chrome.webRequest.onBeforeRequest.addListener(_argument3 => {
      if (_argument3.type !== "xmlhttprequest" || _argument3.tabId < 0 || !/Lesson|Lecture|TimeTable/i.test(_argument3.url)) return;
      if (!_value4.has(_argument3.tabId)) _value4.set(_argument3.tabId, new Set());
      _value4.get(_argument3.tabId).add(_argument3.requestId);
    }, {
      "urls": ["https://schools.madrasati.sa/*"]
    });
    const _value6 = _argument4 => {
      const _value7 = _value4.get(_argument4.tabId);
      if (!_value7?.["has"](_argument4.requestId)) return;
      _value7["delete"](_argument4.requestId), _value5.set(_argument4.tabId, Date.now());
    };
    chrome.webRequest.onCompleted.addListener(_value6, {
      "urls": ["https://schools.madrasati.sa/*"]
    }), chrome.webRequest.onErrorOccurred.addListener(_value6, {
      "urls": ["https://schools.madrasati.sa/*"]
    });
  }
  async function _value8(_argument5) {
    for (let _number = 0; _number < 150; _number++) {
      if (!_value4.get(_argument5)?.["size"] && Date.now() - (_value5.get(_argument5) || 0) >= 400) return;
      await new Promise(_argument6 => setTimeout(_argument6, 200));
    }
    throw Object.assign(new Error("\u0637\u0644\u0628 \u062D\u0635\u0635 \u0645\u062F\u0631\u0633\u062A\u064A \u0644\u0645 \u064A\u0643\u062A\u0645\u0644\u061B \u0644\u0645 \u064A\u064F\u0631\u0633\u0644 \u0627\u0644\u062C\u062F\u0648\u0644 \u0627\u0644\u0633\u0627\u0628\u0642"), {
      "fatal": true
    });
  }
  const _value9 = async () => {
    const _value0 = await chrome.storage.local.get("mirsadDriveConfig"),
      _value1 = _value0.mirsadDriveConfig;
    if (!_value1?.["url"] || !_value1?.["key"]) throw new Error("\u0641\u0639\u0651\u0644 \u0627\u0644\u0645\u062F\u0631\u0633\u0629 \u0648\u0627\u0631\u0628\u0637 \u062C\u0647\u0627\u0632 \u0627\u0644\u0631\u0635\u062F \u0645\u0646 \u0625\u0639\u062F\u0627\u062F\u0627\u062A \u0627\u0644\u0645\u062F\u0631\u0633\u0629 \u0623\u0648\u0644\u064B\u0627");
    return _value1;
  };
  async function _value10(_argument7, _argument8 = {}) {
    const _value11 = await _value9(),
      _value12 = await MirsadServiceTransport.fetch(_value11.url, {
        "method": "POST",
        "headers": {
          "Content-Type": "text/plain;charset=utf-8"
        },
        "body": JSON.stringify({
          "action": _argument7,
          "key": _value11.key,
          ..._argument8,
          ...(await MirsadCommercialAccount.identity())
        }),
        "signal": AbortSignal.timeout(30000)
      });
    if (!_value12.ok) throw new Error("\u062A\u0639\u0630\u0631 \u0627\u0644\u0627\u062A\u0635\u0627\u0644 \u0628\u062E\u062F\u0645\u0629 \u0645\u0631\u0635\u0627\u062F");
    const _value13 = await _value12.json();
    if (!_value13.ok) {
      const _value14 = ["\u0635\u0644\u0627\u062D\u064A\u0629 \u0627\u0644\u0642\u0631\u0627\u0621\u0629 \u0644\u0627 \u062A\u0633\u0645\u062D \u0628\u0627\u0644\u0631\u0641\u0639", "\u0627\u0644\u0646\u062A\u064A\u062C\u0629 \u0644\u0627 \u062A\u0637\u0627\u0628\u0642 \u062C\u062F\u0648\u0644 \u0627\u0644\u064A\u0648\u0645 \u0627\u0644\u0645\u062D\u0641\u0648\u0638", "\u062C\u062F\u0648\u0644 \u0627\u0644\u064A\u0648\u0645 \u063A\u064A\u0631 \u0645\u062D\u0641\u0648\u0638", "\u0644\u0645 \u062A\u0628\u062F\u0623 \u0623\u0631\u0634\u0641\u0629 \u0647\u0630\u0627 \u0627\u0644\u064A\u0648\u0645", "\u062C\u062F\u0648\u0644 \u0645\u062F\u0631\u0633\u062A\u064A \u0646\u0627\u0642\u0635 \u0623\u0648 \u062A\u0627\u0631\u064A\u062E\u0647 \u0644\u064A\u0633 \u0627\u0644\u064A\u0648\u0645"].includes(_value13.error);
      throw new Error(_value14 ? "\u062D\u062F\u0651\u062B \u0633\u0643\u0631\u0628\u062A \u062A\u0648\u062B\u064A\u0642 \u0645\u0631\u0635\u0627\u062F \u0644\u062A\u0641\u0639\u064A\u0644 \u0645\u062F\u0631\u0633\u062A\u064A \u0648\u0627\u062E\u062A\u064A\u0627\u0631 \u0627\u0644\u062A\u0627\u0631\u064A\u062E\u061B \u0644\u0627 \u062A\u063A\u064A\u0631 \u0627\u0644\u0631\u0627\u0628\u0637 \u0623\u0648 \u0627\u0644\u0631\u0645\u0648\u0632" : _value13.error || "\u062A\u0639\u0630\u0631 \u062D\u0641\u0638 \u0627\u0644\u062C\u062F\u0648\u0644");
    }
    return _value13;
  }
  const _value15 = async (_argument9, _argument0 = {}) => chrome.storage.local.set({
    [_text]: {
      "text": _argument9,
      "running": _value,
      "at": Date.now(),
      ..._argument0
    }
  });
  async function _value16(_argument1) {
    if (_argument1 !== "madrasati") throw new Error("\u0645\u062F\u0631\u0633\u062A\u064A \u0647\u064A \u0627\u0644\u0645\u0635\u062F\u0631 \u0627\u0644\u0648\u062D\u064A\u062F\u061B \u0646\u0642\u0627\u0631 \u0645\u0644\u063A\u0649");
    if (_value) throw new Error("\u0627\u0646\u062A\u0638\u0631 \u0627\u0643\u062A\u0645\u0627\u0644 \u062C\u0645\u0639 \u0645\u062F\u0631\u0633\u062A\u064A");
    const _value17 = await getRun();
    if (_value17?.["running"]) throw new Error("\u0623\u0648\u0642\u0641 \u0627\u0644\u0631\u0635\u062F \u0645\u0624\u0642\u062A\u064B\u0627 \u0642\u0628\u0644 \u062A\u063A\u064A\u064A\u0631 \u0645\u0635\u062F\u0631 \u0627\u0644\u062C\u062F\u0648\u0644");
    const _value18 = await _value10("setTimetableSource", {
      "mode": _argument1
    });
    if (!_value18.saved || _value18.mode !== _argument1) throw new Error("\u062D\u062F\u0651\u062B \u0643\u0648\u062F \u0633\u0643\u0631\u0628\u062A \u0627\u0644\u0631\u0635\u062F \u0644\u062A\u0641\u0639\u064A\u0644 \u0627\u062E\u062A\u064A\u0627\u0631 \u0627\u0644\u0645\u0635\u062F\u0631");
    return await chrome.storage.local.set({
      "mirsadTimetableSource": _argument1
    }), await _value15("\u0627\u0644\u0645\u0635\u062F\u0631 \u0645\u062F\u0631\u0633\u062A\u064A \u2014 \u0627\u0641\u062A\u062D \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0645\u0639\u0644\u0645\u064A\u0646 \u062B\u0645 \u0627\u0636\u063A\u0637 \u062A\u062D\u0645\u064A\u0644 \u0627\u0644\u062C\u062F\u0648\u0644"), {
      "ok": true,
      "mode": _argument1
    };
  }
  async function _value19() {
    const _value20 = await chrome.storage.local.get([_text, "mirsadTimetableSource", "mirsadMadrasatiSelectedDate", "mirsadMadrasatiLastSuccess", "mirsadPendingImport", "mirsadDriveDay"]),
      _value21 = await getRun();
    let _value22 = _value20[_text] || null;
    if (_value22?.["running"] && !_value) _value22 = {
      ..._value22,
      "running": false,
      "error": true,
      "text": "\u062A\u0648\u0642\u0641\u062A \u062C\u0644\u0633\u0629 \u0627\u0644\u062C\u0645\u0639 \u0641\u064A \u0627\u0644\u0625\u0636\u0627\u0641\u0629\u061B \u0627\u0636\u063A\u0637 \u0627\u0644\u0646\u0642\u0644 \u0645\u062C\u062F\u062F\u064B\u0627 \u0644\u0644\u062A\u062D\u0642\u0642 \u0648\u0625\u0643\u0645\u0627\u0644 \u0627\u0644\u062C\u0645\u0639"
    };
    if (_value && !_value22?.["running"]) _value22 = {
      "text": "\u062C\u0627\u0631\u064D \u0628\u062F\u0621 \u0642\u0631\u0627\u0621\u0629 \u0645\u062F\u0631\u0633\u062A\u064A\u2026",
      "running": true
    };
    return {
      "ok": true,
      "mode": "madrasati",
      "recording": !!_value21?.["running"],
      "recordingSourceDate": _value21?.["running"] ? _value20.mirsadDriveDay?.["snapshot"]?.["sourceScheduleDate"] : null,
      "state": _value22,
      "selectedDate": _value20.mirsadMadrasatiSelectedDate || MirsadMonitorModel.day(),
      "lastSuccess": _value20.mirsadMadrasatiLastSuccess ? {
        ..._value20.mirsadMadrasatiLastSuccess,
        "activeVerified": _value20.mirsadDriveDay?.["date"] === MirsadMonitorModel.day() && _value20.mirsadDriveDay?.["snapshot"]?.["scheduleRevision"] === _value20.mirsadMadrasatiLastSuccess.revision
      } : null,
      "pending": _value20.mirsadPendingImport?.["preview"] || null
    };
  }
  function _value23(_argument10, _argument11) {
    try {
      const _value24 = new URL(_argument10);
      if (_value24.origin !== "https://schools.madrasati.sa") return false;
      return _argument11 === "directory" ? /^\/SchoolManagment\/Teachers\/?$/i.test(_value24.pathname) : _argument11 === "timetable" ? /^\/SchoolManagment\/Lessons\/TimeTable\/[a-f0-9]+\/?$/i.test(_value24.pathname) : /^\/Teacher\/Lessons\/viewLectureDetails\/?$/i.test(_value24.pathname);
    } catch {
      return false;
    }
  }
  async function _value25(_argument12, _argument13, _argument14 = {}, _argument15 = 90000) {
    const _value26 = Date.now() + _argument15;
    let _value27 = false,
      _text2 = "";
    while (Date.now() < _value26) {
      await priorityCheckpoint();
      const _value28 = await chrome.tabs.get(_argument12);
      if (_value28.pendingUrl || _value28.status === "loading" || !_value23(_value28.url, _argument13)) {
        if (_value28.status === "complete" && !_value28.pendingUrl && !_value23(_value28.url, _argument13)) throw new Error("\u0645\u062F\u0631\u0633\u062A\u064A \u0644\u0645 \u064A\u0641\u062A\u062D \u0627\u0644\u0635\u0641\u062D\u0629 \u0627\u0644\u0645\u0637\u0644\u0648\u0628\u0629\u061B \u062A\u062D\u0642\u0642 \u0645\u0646 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644");
        await _value3(150);
        continue;
      }
      _argument13 !== "directory" && !_value27 && (await _value8(_argument12), _value27 = true);
      try {
        const _value29 = await chrome.tabs.sendMessage(_argument12, {
          "type": "MIRSAD_MADRASATI_READ",
          "kind": _argument13,
          ..._argument14
        });
        if (_value29?.["ok"]) return _value29;
        if (_value29?.["error"]) {
          _text2 = _value29.error;
          if (!_value29.retryable) throw Object.assign(new Error(_value29.error), {
            "fatal": true
          });
        }
      } catch (_value30) {
        if (_value30.fatal) throw _value30;
      }
      await _value3(250);
    }
    throw new Error(_text2 ? _text2 + " \u0628\u0639\u062F \u0627\u0646\u062A\u0638\u0627\u0631 \u0627\u0643\u062A\u0645\u0627\u0644 \u0627\u0644\u062A\u062D\u0645\u064A\u0644\u061B \u0623\u0639\u062F \u0627\u0644\u0646\u0642\u0644 \u0628\u0639\u062F \u0627\u0644\u062A\u0623\u0643\u062F \u0645\u0646 \u0627\u0644\u0635\u0641\u062D\u0629" : "\u062A\u0639\u0630\u0631 \u0642\u0631\u0627\u0621\u0629 \u0635\u0641\u062D\u0629 \u0645\u062F\u0631\u0633\u062A\u064A \u0628\u0639\u062F \u0627\u0646\u062A\u0638\u0627\u0631 \u0627\u0644\u062A\u062D\u0645\u064A\u0644\u061B \u062D\u062F\u0651\u062B \u0635\u0641\u062D\u062A\u0647\u0627 \u0628\u0639\u062F \u062A\u062D\u062F\u064A\u062B \u0627\u0644\u0625\u0636\u0627\u0641\u0629");
  }
  async function _value31(_argument16, _argument17, _argument18, _argument19 = {}, _argument20 = 90000) {
    await priorityCheckpoint();
    if (!_value23(_argument17, _argument18)) throw new Error("\u0631\u0641\u0636 \u0641\u062A\u062D \u0631\u0627\u0628\u0637 \u062E\u0627\u0631\u062C \u0635\u0641\u062D\u0627\u062A \u0642\u0631\u0627\u0621\u0629 \u0645\u062F\u0631\u0633\u062A\u064A");
    if (_argument16.tabId !== null) {
      let current;
      try {
        current = await chrome.tabs.get(_argument16.tabId);
      } catch {}
      if (!current || !(await MirsadTabOwnership.reusableCollector(current))) {
        _value2.delete(_argument16.tabId);
        _argument16.tabId = null;
      }
    }
    if (_argument16.tabId === null) {
      const _value32 = await MirsadTabOwnership.claimCollector(await chrome.tabs.create({
        url: _argument17,
        active: false
      }));
      _argument16.tabId = _value32.id, _value2.add(_value32.id);
    } else await chrome.tabs.update(_argument16.tabId, {
      "url": _argument17
    });
    return _value25(_argument16.tabId, _argument18, _argument19, _argument20);
  }
  async function _value33(_argument21, autoOptions = {}) {
    if (_value) throw new Error("\u0627\u0644\u062C\u0645\u0639 \u0642\u064A\u062F \u0627\u0644\u062A\u0646\u0641\u064A\u0630");
    _value = true;
    automaticSession = autoOptions.collectOnly ? {
      cancelled: false,
      shouldContinue: autoOptions.shouldContinue
    } : null;
    let _value34 = null,
      _value35 = null,
      _value36 = false,
      _text3 = "",
      _value37 = false;
    try {
      const _value38 = MirsadMonitorModel.day(),
        _value39 = _argument21 || _value38;
      _text3 = _value39;
      const _value40 = await chrome.storage.local.get(["mirsadLoadIntent", "mirsadDriveDay"]);
      _value34 = _value40.mirsadLoadIntent, _value35 = _value40.mirsadDriveDay;
      if (!/^\d{4}-\d{2}-\d{2}$/.test(_value39) || !Number.isFinite(Date.parse(_value39 + "T12:00:00Z")) || new Date(_value39 + "T12:00:00Z").toISOString().slice(0, 10) !== _value39) throw new Error("\u0627\u062E\u062A\u0631 \u062A\u0627\u0631\u064A\u062E\u064B\u0627 \u0635\u062D\u064A\u062D\u064B\u0627 \u0644\u062C\u062F\u0648\u0644 \u0645\u062F\u0631\u0633\u062A\u064A");
      await _value15("\u062C\u0627\u0631\u064D \u0628\u062F\u0621 \u062C\u0645\u0639 \u062C\u062F\u0648\u0644 \u0645\u062F\u0631\u0633\u062A\u064A \u0644\u0644\u062A\u0627\u0631\u064A\u062E " + _value39 + "\u2026");
      const _value41 = (await getRun()) || (autoOptions.collectOnly ? {
        scheduleRevision: _value35?.snapshot?.scheduleRevision
      } : null);
      _value37 = !!_value41?.["running"] || autoOptions.collectOnly === true;
      if (_value37 && (_value35?.["date"] !== _value38 || _value35?.["snapshot"]?.["sourceType"] !== "madrasati" || _value35.snapshot.sourceScheduleDate !== _value39 || _value41.scheduleRevision !== _value35.snapshot.scheduleRevision)) throw new Error("\u0623\u062B\u0646\u0627\u0621 \u0627\u0644\u0631\u0635\u062F \u0623\u0639\u062F \u062A\u062D\u0645\u064A\u0644 \u062A\u0627\u0631\u064A\u062E \u0627\u0644\u062C\u062F\u0648\u0644 \u0627\u0644\u062D\u0627\u0644\u064A \u0641\u0642\u0637\u061B \u0644\u0645 \u064A\u062A\u063A\u064A\u0631 \u062C\u062F\u0648\u0644 \u0627\u0644\u0631\u0635\u062F");
      await chrome.storage.local.set({
        "mirsadMadrasatiSelectedDate": _value39
      });
      !_value37 && (await chrome.storage.local.set({
        "mirsadLoadIntent": {
          "date": _value38,
          "sourceDate": _value39,
          "status": "collecting"
        },
        "mirsadPendingImport": null
      }), _value36 = true);
      const _value42 = await _value10("getTimetableSource");
      if (_value42.mode !== "madrasati") throw new Error("\u0627\u062D\u0641\u0638 \u0627\u062E\u062A\u064A\u0627\u0631 \u0645\u0635\u062F\u0631 \u0645\u062F\u0631\u0633\u062A\u064A \u0623\u0648\u0644\u064B\u0627");
      const _value43 = await chrome.tabs.query({
          "url": "https://schools.madrasati.sa/SchoolManagment/Teachers*"
        }),
        _value44 = autoOptions.directoryTabId ? _value43.find(t => t.id === autoOptions.directoryTabId) : _value43.find(_argument22 => _argument22.active) || _value43[0];
      if (!_value44) throw new Error("\u0627\u0641\u062A\u062D \u0625\u062F\u0627\u0631\u0629 \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0645\u0639\u0644\u0645\u064A\u0646 \u0641\u064A \u0645\u062F\u0631\u0633\u062A\u064A\u060C \u0648\u0627\u062A\u0631\u0643 \u0627\u0644\u0642\u0627\u0626\u0645\u0629 \u0645\u0641\u062A\u0648\u062D\u0629");
      await _value15("\u062C\u0627\u0631\u064D \u0642\u0631\u0627\u0621\u0629 \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0645\u0639\u0644\u0645\u064A\u0646\u2026");
      if (Number.isInteger(_value44.windowId)) await chrome.storage.local.set({
        "mirsadWorkspaceWindowId": _value44.windowId
      });
      const _value45 = await _value25(_value44.id, "directory"),
        _value46 = new URL(_value45.sourceUrl),
        _value47 = [..._value46.searchParams].find(([_argument23]) => _argument23.toLowerCase() === "schoolid")?.[1];
      if (!/^[a-f0-9]{32}$/i.test(_value47 || "")) throw new Error("\u062A\u0639\u0630\u0631 \u062A\u062D\u062F\u064A\u062F \u0627\u0644\u0645\u062F\u0631\u0633\u0629 \u0645\u0646 \u0635\u0641\u062D\u0629 \u0627\u0644\u0645\u0639\u0644\u0645\u064A\u0646");
      const _items = [],
        _items2 = [],
        _value48 = new Map(),
        _value49 = autoOptions.collectOnly ? _value45.teachers.filter(t => (_value35.snapshot.lessons || []).some(l => Number(l.period) >= (autoOptions.startPeriod || 1) && (autoOptions.mode === "continuous" || !l.url) && MirsadMonitorModel.normalize(l.teacherName) === MirsadMonitorModel.normalize(t.name))) : _value45.teachers;
      if (!Array.isArray(_value49) || !_value49.length) throw new Error("\u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0645\u0639\u0644\u0645\u064A\u0646 \u0641\u0627\u0631\u063A\u0629");
      let _number2 = 0,
        _number3 = 0,
        _value50 = null;
      async function _value51(_argument24, _argument25) {
        await priorityCheckpoint();
        const _items3 = [],
          _value52 = _value49[_argument25];
        if ([...new URL(_value52.url).searchParams].find(([_argument26]) => _argument26.toLowerCase() === "schoolid")?.[1]?.["toLowerCase"]() !== _value47.toLowerCase()) throw new Error("\u062C\u062F\u0648\u0644 \u0627\u0644\u0645\u0639\u0644\u0645 \u064A\u062A\u0628\u0639 \u0645\u062F\u0631\u0633\u0629 \u0645\u062E\u062A\u0644\u0641\u0629");
        await _value15("\u0642\u0631\u0627\u0621\u0629 \u062C\u062F\u0648\u0644 " + _value52.name + " \xB7 " + (_argument25 + 1) + " \u0645\u0646 " + _value49.length, {
          "done": _number3,
          "total": _value49.length
        });
        let _value53;
        try {
          _value53 = await _value31(_argument24, _value52.url, "timetable", {
            "date": _value39
          });
        } catch (_value54) {
          throw new Error(_value52.name + " \xB7 " + _value54.message);
        }
        ;
        if (_value53.date !== _value39) throw new Error("\u062A\u0627\u0631\u064A\u062E \u062C\u062F\u0648\u0644 " + _value52.name + " \u0644\u0627 \u064A\u0637\u0627\u0628\u0642 \u0627\u0644\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u0645\u062E\u062A\u0627\u0631");
        if (autoOptions.collectOnly) _value53.lessons = _value53.lessons.filter(l => (_value35.snapshot.lessons || []).some(row => Number(row.period) >= (autoOptions.startPeriod || 1) && (autoOptions.mode === "continuous" || !row.url) && Number(row.period) === Number(l.period) && MirsadMonitorModel.normalize(row.teacherName) === MirsadMonitorModel.normalize(_value52.name)));
        await priorityCheckpoint();
        const _items4 = [...new Set(_value53.lessons.filter(_argument27 => !_argument27.teams).map(_argument28 => _argument28.detailUrl).filter(_argument29 => _argument29 && !_value48.has(_argument29)))];
        if (_items4.length) {
          await _value15("\u062C\u0644\u0628 \u0631\u0648\u0627\u0628\u0637 \u062D\u0635\u0635 " + _value52.name + " \u0628\u0627\u0644\u062A\u0648\u0627\u0632\u064A\u2026", {
            "done": _number3,
            "total": _value49.length
          });
          const _value55 = await chrome.tabs.sendMessage(_argument24.tabId, {
            "type": "MIRSAD_MADRASATI_READ",
            "kind": "meetings",
            "urls": _items4
          });
          if (!_value55?.["ok"] || !Array.isArray(_value55.results) || _value55.results.length !== _items4.length) throw new Error(_value55?.["error"] || "\u062D\u062F\u0651\u062B \u0635\u0641\u062D\u0629 \u0645\u062F\u0631\u0633\u062A\u064A \u0644\u062A\u0641\u0639\u064A\u0644 \u0627\u0644\u0646\u0642\u0644 \u0627\u0644\u0633\u0631\u064A\u0639");
          const _value56 = new Set();
          for (const _value57 of _value55.results) {
            if (!_items4.includes(_value57.detailUrl) || _value56.has(_value57.detailUrl)) throw new Error("\u0646\u062A\u0627\u0626\u062C \u0631\u0648\u0627\u0628\u0637 \u0627\u0644\u062D\u0635\u0635 \u063A\u064A\u0631 \u0645\u062A\u0637\u0627\u0628\u0642\u0629");
            _value56.add(_value57.detailUrl);
            if (_value57.ok) {
              if (!_value57.url && !_value57.unprepared) throw new Error("\u0644\u0645 \u062A\u0624\u0643\u062F \u0635\u0641\u062D\u0629 \u0627\u0644\u062F\u0631\u0633 \u063A\u064A\u0627\u0628 \u0627\u0644\u0631\u0627\u0628\u0637");
              _value48.set(_value57.detailUrl, _value57);
            } else {
              if (!_value57.retryable) {
                const _value58 = _value53.lessons.find(_argument30 => _argument30.detailUrl === _value57.detailUrl)?.["period"];
                throw new Error(_value52.name + " \xB7 \u0627\u0644\u062D\u0635\u0629 " + _value58 + " \xB7 " + _value57.error);
              } else _value48.set(_value57.detailUrl, _value57);
            }
          }
        }
        for (const _value59 of _value53.lessons) {
          if (_value59.missingDetails) _items.push({
            "teacher": _value52.name,
            "period": _value59.period
          });
          let _value60 = _value59.teams || "",
            _value61 = _value59.linkSource || "",
            _text4 = "";
          if (!_value60 && _value59.detailUrl) {
            await _value15("\u0642\u0631\u0627\u0621\u0629 \u0631\u0627\u0628\u0637 " + _value52.name + " \xB7 \u0627\u0644\u062D\u0635\u0629 " + _value59.period, {
              "done": _number3,
              "total": _value49.length
            });
            try {
              let _value62 = _value48.get(_value59.detailUrl);
              if (!_value62?.["ok"] && _value62?.["retryable"]) {
                const _value63 = await _value31(_argument24, _value59.detailUrl, "meeting", {}, 20000);
                if (!_value63.url && !_value63.unprepared) throw new Error("\u0644\u0645 \u062A\u0624\u0643\u062F \u0635\u0641\u062D\u0629 \u0627\u0644\u062F\u0631\u0633 \u063A\u064A\u0627\u0628 \u0627\u0644\u0631\u0627\u0628\u0637");
                _value62 = {
                  ..._value63,
                  "ok": true
                }, _value48.set(_value59.detailUrl, _value62), _value61 = "rendered-details";
              }
              if (!_value62?.["ok"]) throw new Error(_value62?.["error"] || "\u062A\u0639\u0630\u0631\u062A \u0627\u0644\u0642\u0631\u0627\u0621\u0629 \u0627\u0644\u0641\u0646\u064A\u0629 \u0644\u0631\u0627\u0628\u0637 \u0627\u0644\u062D\u0635\u0629\u061B \u0644\u0645 \u064A\u064F\u0639\u062A\u0645\u062F \u062C\u062F\u0648\u0644 \u0646\u0627\u0642\u0635");
              _value61 = _value61 || "fast-details", _value60 = _value62.url || "";
              if (!_value60 && _value59.calendarLinkUnverified) throw new Error("\u0645\u062F\u0631\u0633\u062A\u064A \u0623\u0631\u062C\u0639\u062A \u0631\u0627\u0628\u0637\u064B\u0627 \u0644\u0644\u062D\u0635\u0629 \u0644\u0643\u0646 \u062A\u0639\u0630\u0631 \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u0631\u0628\u0637\u0647\u061B \u0644\u0645 \u064A\u064F\u0639\u062A\u0645\u062F \u0643\u0646\u0642\u0635 \u0639\u0627\u062F\u064A");
              if (!_value60) _text4 = "\u0627\u0643\u062A\u0645\u0644\u062A \u0642\u0631\u0627\u0621\u0629 \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u062D\u0635\u0629 \u0648\u062A\u0641\u0627\u0635\u064A\u0644\u0647\u0627 \u0641\u064A \u0645\u062F\u0631\u0633\u062A\u064A \u062F\u0648\u0646 \u0648\u062C\u0648\u062F \u0631\u0627\u0628\u0637 \u0627\u062C\u062A\u0645\u0627\u0639";
            } catch (_value64) {
              throw new Error(_value52.name + " \xB7 \u0627\u0644\u062D\u0635\u0629 " + _value59.period + " \xB7 " + _value64.message);
            }
          } else {
            if (!_value60 && !_value59.unprepared) throw new Error("\u062A\u0639\u0630\u0631 \u062A\u062D\u062F\u064A\u062F \u0631\u0627\u0628\u0637 \u062D\u0635\u0629 " + _value52.name);
          }
          _items3.push({
            "teacher": _value52.name,
            "cellIndex": _value59.period + 1,
            "lesson": _value59.lesson,
            "title": _value59.title,
            "time": _value59.time,
            "teams": _value60,
            "linkState": _value60 ? "linked" : "unprepared",
            "linkSource": _value61,
            "linkReason": _value60 ? "" : _text4 || "\u0644\u0645 \u064A\u0638\u0647\u0631 \u0631\u0627\u0628\u0637 \u0645\u0628\u0627\u0634\u0631 \u0623\u0648 \u0631\u0627\u0628\u0637 \u062A\u0641\u0627\u0635\u064A\u0644 \u0628\u0639\u062F \u0625\u0639\u0627\u062F\u0629 \u0642\u0631\u0627\u0621\u0629 \u062C\u062F\u0648\u0644 \u0627\u0644\u0645\u0639\u0644\u0645"
          });
        }
        _items2[_argument25] = _items3, _number3++, await _value15("\u0627\u0643\u062A\u0645\u0644\u062A \u0642\u0631\u0627\u0621\u0629 " + _number3 + " \u0645\u0646 " + _value49.length + " \u0645\u0639\u0644\u0645\u064B\u0627", {
          "done": _number3,
          "total": _value49.length
        });
      }
      await Promise.all(Array.from({
        "length": Math.min(autoOptions.collectOnly ? 1 : 3, _value49.length)
      }, async () => {
        const _options = {
          "tabId": null
        };
        while (!_value50 && _number2 < _value49.length) {
          const _value65 = _number2++;
          try {
            await _value51(_options, _value65);
          } catch (_value66) {
            _value50 = _value50 || _value66;
          }
        }
      }));
      if (_value50) throw _value50;
      const _value67 = _items2.flat();
      if (MirsadMonitorModel.day() !== _value38) throw new Error("\u062A\u063A\u064A\u0631 \u0627\u0644\u062A\u0627\u0631\u064A\u062E \u0623\u062B\u0646\u0627\u0621 \u0627\u0644\u062C\u0645\u0639\u061B \u0623\u0639\u062F \u0627\u0644\u0639\u0645\u0644\u064A\u0629 \u0644\u0644\u064A\u0648\u0645 \u0627\u0644\u062C\u062F\u064A\u062F");
      const _options2 = {
        "source": "madrasati",
        "sourceUrl": _value45.sourceUrl,
        "schoolId": _value47,
        "scheduleDate": _value39,
        "importedForDate": _value38,
        "totalTeachers": _value49.length,
        "teachers": _value49.map(_argument31 => _argument31.name),
        "totalLessons": _value67.length,
        "lessons": _value67
      };
      await _value15(_value37 ? "\u0627\u0643\u062A\u0645\u0644\u062A \u0627\u0644\u0642\u0631\u0627\u0621\u0629\u061B \u062C\u0627\u0631\u064D \u0625\u0636\u0627\u0641\u0629 \u0627\u0644\u0631\u0648\u0627\u0628\u0637 \u0627\u0644\u0646\u0627\u0642\u0635\u0629 \u062F\u0648\u0646 \u0625\u064A\u0642\u0627\u0641 \u0627\u0644\u0631\u0635\u062F\u2026" : "\u0627\u0643\u062A\u0645\u0644\u062A \u0627\u0644\u0642\u0631\u0627\u0621\u0629\u061B \u062C\u0627\u0631\u064D \u062A\u062C\u0647\u064A\u0632 \u062C\u062F\u0648\u0644 \u0627\u0644\u0631\u0635\u062F\u2026");
      if (autoOptions.collectOnly) {
        await _value15("\u0627\u0643\u062A\u0645\u0644\u062A \u0627\u0644\u0642\u0631\u0627\u0621\u0629\u061B \u0627\u0646\u062A\u0638\u0627\u0631 \u0628\u062F\u0627\u064A\u0629 \u0627\u0644\u062F\u0648\u0631\u0629 \u0644\u0625\u0636\u0627\u0641\u0629 \u0627\u0644\u0631\u0648\u0627\u0628\u0637", {
          running: false
        });
        return {
          ok: true,
          payload: _options2
        };
      }
      const _value68 = await CloudMonitoring.fillMissingLinks?.(_options2, {
        "requireExisting": _value37,
        "expectedRevision": _value35?.["snapshot"]?.["scheduleRevision"]
      });
      if (_value68) return await _value69(_value68, _options2);
      if (_value37) throw new Error("\u062A\u0639\u0630\u0631 \u062A\u0623\u0643\u064A\u062F \u062A\u0643\u0645\u064A\u0644 \u062C\u062F\u0648\u0644 \u0627\u0644\u0631\u0635\u062F \u0627\u0644\u062D\u0627\u0644\u064A\u061B \u0644\u0645 \u064A\u064F\u0633\u062A\u0628\u062F\u0644 \u0627\u0644\u062C\u062F\u0648\u0644");
      const _value70 = await CloudMonitoring.stageImport(_options2);
      if (_value70.pendingDecision) return await _value15("\u0627\u0644\u062C\u062F\u0648\u0644 \u062C\u0627\u0647\u0632\u061B \u0647\u0644 \u062A\u0631\u064A\u062F \u062D\u0641\u0638 \u0627\u0644\u062C\u062F\u0648\u0644 \u0627\u0644\u0633\u0627\u0628\u0642 \u0642\u0628\u0644 \u0627\u0633\u062A\u0628\u062F\u0627\u0644\u0647\u061F", {
        "running": false,
        "pendingDecision": true
      }), {
        "ok": true,
        "pendingDecision": true
      };
      return await _value69(_value70, _options2);
    } catch (_value71) {
      if (automaticSession?.cancelled || _value71.cancelled) {
        const cancelled = priorityCancelled();
        await _value15(cancelled.message, {
          running: false,
          error: false
        });
        throw cancelled;
      }
      if (_value36) await chrome.storage.local.set({
        "mirsadLoadIntent": _value35?.["date"] === MirsadMonitorModel.day() && _value35?.["snapshot"]?.["sourceScheduleDate"] === _text3 && _value34?.["status"] === "verified" ? _value34 : {
          "date": MirsadMonitorModel.day(),
          "status": "error"
        }
      });
      await _value15("\u0644\u0645 \u064A\u064F\u0633\u062A\u0628\u062F\u0644 \u0627\u0644\u062C\u062F\u0648\u0644: " + _value71.message, {
        "error": true,
        "running": false
      });
      throw _value71;
    } finally {
      await Promise.allSettled([..._value2].map(async _argument32 => {
        try {
          await MirsadTabOwnership.closeCollector(_argument32);
        } finally {
          _value4["delete"](_argument32), _value5["delete"](_argument32);
        }
      })), _value2.clear(), automaticSession = null, _value = false;
    }
  }
  async function _value69(_argument33, _argument34) {
    const _value72 = MirsadMonitorModel.day(),
      _value73 = _argument33.day.snapshot,
      _value74 = (_value73.lessons || []).filter(_argument35 => !_argument35.url && !MirsadMonitorModel.isExcludedPeriod?.(_value73.date, _argument35.period, _value73)).map(_argument36 => ({
        "teacher": _argument36.teacherName,
        "period": _argument36.period
      }));
    return await chrome.storage.local.set({
      "mirsadMadrasatiLastSuccess": {
        "date": _argument34.scheduleDate,
        "importedForDate": _value72,
        "monitoringPrepared": true,
        "revision": _value73.scheduleRevision,
        "teachers": _argument34.teachers.length,
        "lessons": _argument34.lessons.length,
        "missingLinks": _value74,
        "pendingLinks": 0,
        "filled": _argument33.filled || 0,
        "updatedAt": _argument33.updatedAt || Date.now()
      },
      "mirsadLoadIntent": {
        "date": _value72,
        "sourceDate": _argument34.scheduleDate,
        "status": "verified"
      }
    }), await _value15((_argument33.merged ? _argument33.filled ? "\u0623\u064F\u0636\u064A\u0641\u062A " + _argument33.filled + " \u0631\u0648\u0627\u0628\u0637 \u0646\u0627\u0642\u0635\u0629 \u062A\u0644\u0642\u0627\u0626\u064A\u064B\u0627\u061B \u0627\u0644\u0631\u0635\u062F \u0648\u0627\u0644\u0646\u062A\u0627\u0626\u062C \u0645\u062D\u0641\u0648\u0638\u0629" : "\u0644\u0627 \u0631\u0648\u0627\u0628\u0637 \u062C\u062F\u064A\u062F\u0629\u061B \u0627\u0644\u0631\u0635\u062F \u0648\u0627\u0644\u0646\u062A\u0627\u0626\u062C \u0645\u062D\u0641\u0648\u0638\u0629" : "\u062A\u0645 \u062A\u0637\u0628\u064A\u0642 \u062C\u062F\u0648\u0644 \u0645\u062F\u0631\u0633\u062A\u064A \u0641\u064A \u0627\u0644\u0631\u0635\u062F \u0627\u0644\u0622\u0644\u064A \u2014 " + _argument34.lessons.length + " \u062D\u0635\u0629") + (_value74.length ? " \xB7 \u0627\u0644\u062E\u0627\u0646\u0627\u062A \u0627\u0644\u062A\u064A \u0628\u0644\u0627 \u0631\u0627\u0628\u0637 \u062A\u0638\u0647\u0631 \u0628\u0627\u0644\u0623\u0632\u0631\u0642" : " \xB7 \u0631\u0648\u0627\u0628\u0637 \u062C\u0645\u064A\u0639 \u0627\u0644\u062D\u0635\u0635 \u0645\u0648\u062C\u0648\u062F\u0629"), {
      "running": false,
      "missingLinks": _value74,
      "filled": _argument33.filled || 0
    }), {
      "ok": true,
      ..._argument33
    };
  }
  async function _value75(_argument37) {
    const _value76 = await getRun();
    if (_value76?.["running"]) throw new Error("\u0623\u0648\u0642\u0641 \u0627\u0644\u0631\u0635\u062F \u0645\u0624\u0642\u062A\u064B\u0627 \u0642\u0628\u0644 \u062A\u0637\u0628\u064A\u0642 \u0627\u0644\u062C\u062F\u0648\u0644");
    try {
      const _value77 = (await chrome.storage.local.get("mirsadPendingImport")).mirsadPendingImport;
      if (!_value77?.["payload"]) throw new Error("\u0644\u0627 \u064A\u0648\u062C\u062F \u062C\u062F\u0648\u0644 \u064A\u0646\u062A\u0638\u0631 \u0642\u0631\u0627\u0631\u0643");
      const _value78 = await CloudMonitoring.confirmImport(_argument37);
      return _value69(_value78, _value77.payload);
    } catch (_value79) {
      await _value15("\u0644\u0645 \u064A\u064F\u0637\u0628\u0651\u0642 \u0627\u0644\u062C\u062F\u0648\u0644: " + _value79.message, {
        "error": true,
        "running": false
      });
      throw _value79;
    }
  }
  return chrome.runtime.onMessage.addListener((_argument38, _argument39, _argument40) => {
    if (!["MIRSAD_SOURCE_INFO", "MIRSAD_SOURCE_SELECT", "MIRSAD_SOURCE_COLLECT", "MIRSAD_SOURCE_CONFIRM_IMPORT", "MIRSAD_SOURCE_CANCEL_IMPORT"].includes(_argument38?.["type"]) || _argument39.tab) return;
    if (_argument38.type === "MIRSAD_SOURCE_CONFIRM_IMPORT") return _value75(_argument38.keepPrevious).then(_argument40)["catch"](_argument41 => _argument40({
      "ok": false,
      "error": _argument41.message
    })), true;
    if (_argument38.type === "MIRSAD_SOURCE_CANCEL_IMPORT") return CloudMonitoring.cancelImport().then(() => _value15("\u0623\u064F\u0644\u063A\u064A \u0627\u0644\u062A\u062D\u0645\u064A\u0644\u061B \u0627\u0644\u062C\u062F\u0648\u0644 \u0627\u0644\u062D\u0627\u0644\u064A \u0648\u062A\u062D\u0636\u064A\u0631\u0647 \u0644\u0645 \u064A\u062A\u063A\u064A\u0631\u0627", {
      "running": false
    })).then(() => _argument40({
      "ok": true
    })), true;
    if (_argument38.type === "MIRSAD_SOURCE_INFO") return _value19().then(_argument40), true;
    if (_argument38.type === "MIRSAD_SOURCE_SELECT") return _value16(_argument38.mode).then(_argument40)["catch"](_argument42 => _argument40({
      "ok": false,
      "error": _argument42.message
    })), true;
    if (_value) return _argument40({
      "ok": false,
      "error": "\u0627\u0644\u062C\u0645\u0639 \u0642\u064A\u062F \u0627\u0644\u062A\u0646\u0641\u064A\u0630"
    }), false;
    return _value33(_argument38.date)["catch"](_argument43 => _value15("\u0644\u0645 \u064A\u064F\u0633\u062A\u0628\u062F\u0644 \u0627\u0644\u062C\u062F\u0648\u0644: " + _argument43.message, {
      "error": true
    })), _argument40({
      "ok": true,
      "started": true
    }), false;
  }), {
    "info": _value19,
    "select": _value16,
    "collect": _value33,
    "cancelAutomatic": cancelAutomatic,
    "confirmImport": _value75
  };
})();