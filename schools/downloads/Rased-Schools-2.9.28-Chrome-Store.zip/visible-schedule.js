"use strict";

(function (_argument) {
  const _text = "mirsad-visible-schedule-v32",
    _value = _argument2 => String(_argument2 || "").normalize("NFKC").replace(/[\u064B-\u065F\u0670\u0640]/g, "").replace(/[أإآ]/g, "\u0627").replace(/ى/g, "\u064A").replace(/\s+/g, " ").trim(),
    _value2 = _argument3 => {
      if (!/^\d{4}-\d{2}-\d{2}$/.test(_argument3 || "")) return "";
      const _value3 = new Date(_argument3 + "T12:00:00Z");
      return Number.isFinite(_value3.getTime()) && _value3.toISOString().slice(0, 10) === _argument3 ? _argument3 : "";
    },
    _value4 = _argument4 => JSON.stringify([_value(_argument4.teacher || _argument4.teacherName), Number(_argument4.period), String(_argument4.subject || "").trim(), String(_argument4.className || "").trim(), String(_argument4.url || "").trim()]);
  function _value5(_argument5, _argument6) {
    const _items = [...new Set([...(_argument5.teachers || []), ...(_argument5.lessons || []).map(_argument7 => _argument7.teacher)].map(_argument8 => String(_argument8 || "").trim()).filter(Boolean))],
      _value6 = (_argument5.lessons || []).map(_argument9 => ({
        "teacher": String(_argument9.teacher || "").trim(),
        "period": Number(_argument9.cellIndex) - 1,
        "subject": String(_argument9.title || _argument9.subject || _argument9.lessonTitle || "\u062D\u0635\u0629"),
        "className": String(_argument9["class"] || _argument9.lesson || _argument9.className || ""),
        "url": String(_argument9.teams || _argument9.teamsUrl || ""),
        "hasLesson": true
      }));
    return {
      "observedForDate": _argument6,
      "observedAt": Date.now(),
      "sourceType": _argument5.source || "naqar",
      "sourceScheduleDate": _value2(_argument5.scheduleDate || _argument5.selectedDate || _argument5.date),
      "sourceImportDate": _argument5.importedForDate || _argument6,
      "sourceUploadedAt": String(_argument5.updatedAt || ""),
      "sourcePage": "https://mirsad-school.onrender.com/schools/index.html",
      "teachers": _items,
      "items": _value6
    };
  }
  function _value7(_argument0, _argument1) {
    if (!_argument0 || !_argument1 || _argument0.date !== _argument1.observedForDate || (_argument0.sourceType || "naqar") !== _argument1.sourceType || (_argument0.sourceScheduleDate || "") !== (_argument1.sourceScheduleDate || "")) return false;
    if (!_argument1.sourceScheduleDate && _argument1.sourceType === "naqar" && (_argument0.sourceUploadedAt || "") !== _argument1.sourceUploadedAt) return false;
    const _value8 = (_argument0.lessons || []).map(_value4).sort(),
      _value9 = (_argument1.items || []).map(_value4).sort(),
      _value0 = _argument10 => [...new Set(_argument10.map(_value))].sort();
    return JSON.stringify(_value8) === JSON.stringify(_value9) && JSON.stringify(_value0((_argument0.teachers || []).map(_argument11 => _argument11.name))) === JSON.stringify(_value0(_argument1.teachers || []));
  }
  const _options = {
    "KEY": _text,
    "reference": _value5,
    "matches": _value7
  };
  if (typeof module !== "object") _argument.MirsadVisibleSchedule = _options;else module.exports = _options;
})(globalThis);