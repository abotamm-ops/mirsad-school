"use strict";

chrome.runtime.onMessage.addListener((_argument, _argument2, _argument3) => {
  if (!["MIRSAD_COMMERCIAL_ENROLL", "MIRSAD_COMMERCIAL_BINDING"].includes(_argument?.["type"])) return;
  let _value = false;
  try {
    const _value2 = new URL(_argument2.tab?.["url"]);
    _value = _value2.origin === "https://mirsad-school.onrender.com" && _value2.pathname === "/schools/school-settings.html";
  } catch {}
  if (!_value) return _argument3({
    "ok": false,
    "error": "\u0645\u0635\u062F\u0631 \u0631\u0628\u0637 \u063A\u064A\u0631 \u0645\u0633\u0645\u0648\u062D"
  }), false;
  const _value3 = _argument.type === "MIRSAD_COMMERCIAL_ENROLL" ? MirsadCommercialAccount.enroll(_argument).then(() => MirsadCommercialAccount.verifyBinding()) : MirsadCommercialAccount.verifyBinding(_argument.schoolId);
  return _value3.then(_argument3)["catch"](_argument4 => _argument3({
    "ok": false,
    "error": _argument4.message
  })), true;
});