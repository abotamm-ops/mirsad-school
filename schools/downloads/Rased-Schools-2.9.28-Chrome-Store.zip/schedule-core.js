"use strict";

(() => {
  const _value = _argument => String(_argument || "").normalize("NFKC").replace(/\s+/g, " ").trim(),
    _value2 = _argument2 => _value(_argument2).replace(/[٠-٩]/g, _argument3 => String("\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669".indexOf(_argument3)));
  function _value3(_argument4, _argument5 = 45, _argument6 = 0, _argument7 = 7, _argument8 = 1) {
    const _value4 = _value2(_argument4),
      _value5 = /^(\d{1,2}):(\d{2})$/.exec(_value4),
      _value6 = _value5 ? Number(_value5[1]) : -1,
      _value7 = _value5 ? Number(_value5[2]) : -1,
      _value8 = Number(_argument5),
      _value9 = Number(_argument6),
      _value0 = Number(_argument7),
      _value1 = Number(_argument8);
    if (_value6 < 0 || _value6 > 23 || _value7 < 0 || _value7 > 59 || !Number.isInteger(_value8) || _value8 < 1 || _value8 > 180 || !Number.isInteger(_value9) || _value9 < 0 || _value9 > 60 || !Number.isInteger(_value0) || _value0 < 1 || _value0 > 7 || !Number.isInteger(_value1) || _value1 < 1 || _value1 > 10) return [];
    const _value10 = _value6 * 60 + _value7;
    return Array.from({
      "length": _value0
    }, (_argument9, _argument0) => {
      const _value11 = _value10 + _argument0 * (_value8 + _value9),
        _value12 = _value11 + _value8,
        _value13 = _value11 + _value1,
        _value14 = _argument1 => String(Math.floor(_argument1 / 60) % 24).padStart(2, "0") + ":" + String(_argument1 % 60).padStart(2, "0");
      return {
        "n": _argument0 + 1,
        "startOffset": _value11,
        "endOffset": _value12,
        "scanOffset": _value13,
        "start": _value14(_value11),
        "end": _value14(_value12),
        "scan": _value14(_value13)
      };
    });
  }
  function _value15(_argument10, _argument11) {
    const _value16 = (Number(_argument11) % 1440 + 1440) % 1440,
      _value17 = (_argument10 || []).filter(_argument12 => {
        const _value18 = _argument12.startOffset % 1440,
          _value19 = _argument12.endOffset % 1440;
        return _value18 < _value19 ? _value16 >= _value18 && _value16 < _value19 : _value16 >= _value18 || _value16 < _value19;
      });
    return _value17.length === 1 ? _value17[0] : null;
  }
  function _value20(_argument13) {
    const _value21 = _value2(_argument13).replace(/[إأآ]/g, "\u0627").replace(/[٫]/g, ":"),
      _value22 = _value21.match(/(\d{1,2}:\d{2})\s*([صم])?\s*[-–—至]\s*(\d{1,2}:\d{2})\s*([صم])?/);
    if (!_value22) return null;
    const _value23 = (_argument14, _argument15) => {
        let [_value24, _value25] = _argument14.split(":").map(Number);
        if (_value25 > 59 || _value24 > 23) return null;
        if (_argument15) {
          if (_value24 < 1 || _value24 > 12) return null;
          _value24 = _argument15 === "\u0635" ? _value24 === 12 ? 0 : _value24 : _value24 === 12 ? 12 : _value24 + 12;
        }
        return _value24 * 60 + _value25;
      },
      _value26 = Boolean(_value22[2]),
      _value27 = Boolean(_value22[4]),
      _value28 = _value23(_value22[1], _value22[2]);
    if (_value28 === null) return null;
    let _value29 = _value23(_value22[3], _value22[4] || _value22[2]);
    if (_value29 === null) return null;
    if (!_value26 && _value27) {
      const _value30 = _value23(_value22[1], _value22[4]),
        _value31 = [_value28, _value30].filter(Number.isFinite).map(_argument16 => {
          let _value32 = _value29;
          if (_value32 <= _argument16) _value32 += 1440;
          return {
            "start": _argument16,
            "end": _value32
          };
        }).filter(_argument17 => _argument17.end > _argument17.start && _argument17.end - _argument17.start <= 180);
      if (!_value31.length) return null;
      _value31.sort((_argument18, _argument19) => _argument18.end - _argument18.start - (_argument19.end - _argument19.start));
      if (_value31.length > 1 && _value31[0].end - _value31[0].start === _value31[1].end - _value31[1].start && _value31[0].start !== _value31[1].start) return null;
      return _value31[0];
    }
    if (_value26 && !_value27) {
      while (_value29 <= _value28) _value29 += 720;
    }
    if (_value29 <= _value28) _value29 += 1440;
    if (_value29 - _value28 > 180) return null;
    return {
      "start": _value28,
      "end": _value29
    };
  }
  function _value33(_argument20) {
    const _value34 = _value(_argument20).replace(/[إأآ]/g, "\u0627"),
      _items = [["\u0627\u0644\u0623\u0648\u0644\u0649", 1], ["\u0627\u0644\u0627\u0648\u0644\u0649", 1], ["\u0627\u0644\u0623\u0648\u0644", 1], ["\u0627\u0644\u0627\u0648\u0644", 1], ["\u0627\u0648\u0644\u0649", 1], ["\u0627\u0648\u0644", 1], ["\u0627\u0644\u062B\u0627\u0646\u064A\u0629", 2], ["\u0627\u0644\u062B\u0627\u0646\u064A", 2], ["\u062B\u0627\u0646\u064A\u0629", 2], ["\u062B\u0627\u0646\u064A", 2], ["\u0627\u0644\u062B\u0627\u0644\u062B\u0629", 3], ["\u0627\u0644\u062B\u0627\u0644\u062B", 3], ["\u062B\u0627\u0644\u062B\u0629", 3], ["\u062B\u0627\u0644\u062B", 3], ["\u0627\u0644\u0631\u0627\u0628\u0639\u0629", 4], ["\u0627\u0644\u0631\u0627\u0628\u0639", 4], ["\u0631\u0627\u0628\u0639\u0629", 4], ["\u0631\u0627\u0628\u0639", 4], ["\u0627\u0644\u062E\u0627\u0645\u0633\u0629", 5], ["\u0627\u0644\u062E\u0627\u0645\u0633", 5], ["\u062E\u0627\u0645\u0633\u0629", 5], ["\u062E\u0627\u0645\u0633", 5], ["\u0627\u0644\u0633\u0627\u062F\u0633\u0629", 6], ["\u0627\u0644\u0633\u0627\u062F\u0633", 6], ["\u0633\u0627\u062F\u0633\u0629", 6], ["\u0633\u0627\u062F\u0633", 6], ["\u0627\u0644\u0633\u0627\u0628\u0639\u0629", 7], ["\u0627\u0644\u0633\u0627\u0628\u0639", 7], ["\u0633\u0627\u0628\u0639\u0629", 7], ["\u0633\u0627\u0628\u0639", 7]],
      _value35 = _value34.match(/^(?:الحصة|حصة|الفترة|درس)\s*(?:ال)?(اولى|اول|ثانية|ثاني|ثالثة|ثالث|رابعة|رابع|خامسة|خامس|سادسة|سادس|سابعة|سابع)(?:\s|$)/);
    if (_value35) {
      const _value36 = _items.find(([_argument21]) => _argument21.replace(/[إأآ]/g, "\u0627") === _value35[1]);
      if (_value36) return _value36[1];
    }
    for (const [_value37, _value38] of _items) if (_value34.includes(_value37)) return _value38;
    const _value39 = _value34.match(/(?:الحصة|الفترة|درس)\s*([1-7١-٧])(?:\D|$)/);
    return _value39 ? Number(_value2(_value39[1])) : null;
  }
  function _value40(_argument22) {
    const _value41 = _argument22.map(_argument23 => ({
      ..._argument23,
      "label": _value(_argument23.label),
      "n": _value33(_argument23.label)
    })).filter(_argument24 => _argument24.n !== null);
    if (_value41.length !== 7) return [];
    _value41.sort((_argument25, _argument26) => _argument25.n - _argument26.n);
    if (_value41.some((_argument27, _argument28) => _argument27.n !== _argument28 + 1)) return [];
    const _value42 = new Set();
    for (const _value43 of _value41) {
      if (!Number.isInteger(_value43.cellIndex) || _value42.has(_value43.cellIndex)) return [];
      _value42.add(_value43.cellIndex);
    }
    return _value41;
  }
  function _value44(_argument29, _argument30, _argument31) {
    if (_argument31 !== null && _argument31 !== undefined && String(_argument31).trim() !== "") {
      const _value45 = _value2(_argument31);
      if (!/^[1-7]$/.test(_value45)) return null;
      return Number(_value45);
    }
    const _value46 = _argument29.filter(_argument32 => {
      const _value47 = Number(_argument32.columnSpan) || 1;
      return _argument30 >= _argument32.cellIndex && _argument30 < _argument32.cellIndex + _value47;
    });
    return _value46.length === 1 ? _value46[0].n : null;
  }
  function _value48(_argument33) {
    let _value49 = String(_argument33 || "").trim();
    for (let _number = 0; _number < 5; _number++) {
      if (!_value49 || _value49.length > 8000 || /[\u0000-\u0020\u007f\\]/.test(_value49)) return "";
      const _value50 = /^https:\/\/(teams\.microsoft\.com|teams\.live\.com)(\/.*)$/i.exec(_value49);
      if (!_value50) return "";
      const _value51 = "https://" + _value50[1].toLowerCase(),
        _value52 = _value50[2];
      if (/^\/(?:l\/meetup-join\/|meet\/)[^/?#]+(?:[/?#].*)?$/.test(_value52)) try {
        const _value53 = _value52.indexOf("#"),
          _value54 = _value53 < 0 ? _value52 : _value52.slice(0, _value53),
          _value55 = _value54.indexOf("?"),
          _value56 = _value55 < 0 ? _value54 : _value54.slice(0, _value55),
          _value57 = _value55 < 0 ? "" : _value54.slice(_value55 + 1),
          _value58 = _value56.split("/").map(_argument34 => encodeURIComponent(decodeURIComponent(_argument34))).join("/"),
          _value59 = _value57 ? _value57.split("&").map(_argument35 => {
            const _value60 = _argument35.indexOf("="),
              _value61 = _value60 < 0 ? _argument35 : _argument35.slice(0, _value60),
              _value62 = _value60 < 0 ? "" : _argument35.slice(_value60 + 1);
            return encodeURIComponent(decodeURIComponent(_value61.replace(/\+/g, " "))) + "=" + encodeURIComponent(decodeURIComponent(_value62.replace(/\+/g, " ")));
          }).sort().join("&") : "";
        return _value51 + _value58 + (_value59 ? "?" + _value59 : "") + (_value53 < 0 ? "" : _value52.slice(_value53));
      } catch {
        return "";
      }
      if (_value52.startsWith("/_#/")) {
        _value49 = _value51 + _value52.slice(3);
        continue;
      }
      if (!/^\/dl\/launcher\/launcher\.html\?/.test(_value52)) return "";
      const _items2 = [];
      try {
        for (const _value63 of _value52.slice(_value52.indexOf("?") + 1).split("#")[0].split("&")) {
          const _value64 = _value63.indexOf("=");
          if (_value64 < 0) continue;
          if (decodeURIComponent(_value63.slice(0, _value64)) === "url") _items2.push(decodeURIComponent(_value63.slice(_value64 + 1).replace(/\+/g, " ")));
        }
      } catch {
        return "";
      }
      if (_items2.length !== 1) return "";
      let _value65 = _items2[0];
      try {
        for (let _number2 = 0; _number2 < 2 && _value65.startsWith("%"); _number2++) _value65 = decodeURIComponent(_value65);
      } catch {
        return "";
      }
      if (_value65.startsWith("/") && !_value65.startsWith("//")) _value49 = _value51 + _value65;else {
        if (/^https:\/\//i.test(_value65)) _value49 = _value65;else return "";
      }
    }
    return "";
  }
  function _value66(_argument36) {
    const _value67 = _value48(_argument36);
    return _value67 ? _value67.split(/[?#]/)[0] : "";
  }
  function _value68(_argument37, _argument38) {
    const _value69 = _value66(_argument37);
    return !!_value69 && _value69 === _value66(_argument38);
  }
  function _value70(_argument39) {
    try {
      const _value71 = new URL(_argument39);
      return _value71.protocol === "https:" && ["teams.microsoft.com", "teams.live.com"].includes(_value71.hostname) && _value71.pathname.length > 1;
    } catch (_value72) {
      return false;
    }
  }
  function _value73(_argument40, _argument41) {
    const _value74 = new Set();
    return _argument40.filter(_argument42 => {
      if (_argument42.period !== _argument41 || !_value70(_argument42.url)) return false;
      const _value75 = _argument42.teacher + "\0" + _argument42.period + "\0" + _argument42.url;
      if (_value74.has(_value75)) return false;
      return _value74.add(_value75), true;
    });
  }
  function _value76(_argument43, _argument44) {
    const _value77 = new Set();
    return (_argument43 || []).filter(_argument45 => {
      if (_argument45.period !== _argument44 || !_argument45.teacher || (_argument45.url ? !_value70(_argument45.url) : _argument45.hasLesson !== true)) return false;
      const _value78 = _argument45.teacher + "\0" + _argument45.period + "\0" + _argument45.url;
      if (_value77.has(_value78)) return false;
      return _value77.add(_value78), true;
    });
  }
  function _value79(_argument46, _argument47) {
    const _value80 = _argument48 => _value(_argument48).split(/[^\p{L}\p{N}]+/u).filter(Boolean).filter(_argument49 => !["\u0628\u0646", "\u0627\u0628\u0646", "\u0627\u0644"].includes(_argument49)),
      _value81 = _value80(_argument46),
      _value82 = new Set(_value80(_argument47));
    return _value81.length >= 2 && _value82.has(_value81[0]) && _value82.has(_value81[_value81.length - 1]);
  }
  function _value83(_argument50, _argument51, _argument52, _argument53 = true, _argument54 = "") {
    const _value84 = _argument55 => String(_argument55 || "").split(/\n+/).some(_argument56 => _value(_argument56) === _value(_argument50));
    if (!_argument50) return {
      "status": "unresolved",
      "teacher": ""
    };
    if (_value84(_argument51)) return {
      "status": "absent",
      "teacher": _argument50
    };
    return {
      "status": "present",
      "teacher": _argument50
    };
  }
  function _value85(_argument57) {
    const _value86 = (_argument57 || []).map(_argument58 => typeof _argument58 === "string" ? _argument58 : _argument58?.["scanStatus"] || _argument58?.["status"]);
    for (let _value87 = _value86.length - 1; _value87 >= 0; _value87--) if (_value86[_value87] === "present" || _value86[_value87] === "absent") return _value86[_value87];
    return "unresolved";
  }
  globalThis.MirsadScheduleCore = Object.freeze({
    "normalize": _value,
    "asciiDigits": _value2,
    "parseTimeRange": _value20,
    "makeManualPeriods": _value3,
    "periodAtMinute": _value15,
    "periodNumber": _value33,
    "mapHeaders": _value40,
    "resolveCellPeriod": _value44,
    "validTeamsUrl": _value70,
    "normalizeTeamsUrl": _value48,
    "teamsMeetingKey": _value66,
    "sameTeamsMeeting": _value68,
    "selectPeriodItems": _value76,
    "selectPeriodLinks": _value73,
    "classifyOrganizerMembership": _value83,
    "summarizeAttendanceStatuses": _value85
  });
})();