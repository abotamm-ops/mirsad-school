"use strict";

async function refreshLocalBackup() {
  try {
    const _value = await chrome.runtime.sendMessage({
      "type": "MIRSAD_LOCAL_BACKUP_INFO"
    });
    if (_value?.["ok"] === false) throw new Error(_value.error || "\u062A\u0639\u0630\u0631 \u0642\u0631\u0627\u0621\u0629 \u0627\u0644\u0635\u0648\u0631 \u0627\u0644\u0645\u062D\u0641\u0648\u0638\u0629");
    const _value2 = document.getElementById("local-backup-summary"),
      _value3 = Number(_value.pendingImages) || 0,
      _value4 = Number(_value.capturedCount) || 0;
    document.getElementById("local-backup-status").textContent = _value.status?.["text"] || "", document.getElementById("extension-id").textContent = _value.extensionId || chrome.runtime.id, _value2.textContent = "\u0627\u0644\u0635\u0648\u0631 \u0627\u0644\u0645\u0644\u062A\u0642\u0637\u0629: " + Math.max(_value4, _value3) + " \u2014 \u0635\u0648\u0631 \u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0646\u0633\u062E \u0627\u0644\u0623\u0642\u0631\u0627\u0635: " + _value3 + (_value.status?.["error"] ? "\n" + _value.status.text : ""), _value2.classList.toggle("warning", _value3 > 0 || !!_value.status?.["error"]);
  } catch (_value5) {
    document.getElementById("local-backup-status").textContent = _value5.message, document.getElementById("local-backup-summary").textContent = "\u062A\u0639\u0630\u0631 \u0642\u0631\u0627\u0621\u0629 \u062D\u0627\u0644\u0629 \u0627\u0644\u0635\u0648\u0631: " + _value5.message;
  }
}
document.getElementById("check-local-backup").onclick = async () => {
  const _value6 = document.getElementById("check-local-backup");
  _value6.disabled = true, document.getElementById("local-backup-status").textContent = "\u062C\u0627\u0631\u064D \u0641\u062D\u0635 \u0627\u0644\u0645\u0633\u0627\u0639\u062F \u0648\u0646\u0633\u062E \u0627\u0644\u0645\u0644\u0641\u0627\u062A \u0627\u0644\u0645\u0639\u0644\u0651\u0642\u0629\u2026";
  try {
    await chrome.runtime.sendMessage({
      "type": "MIRSAD_LOCAL_BACKUP_CHECK"
    }), await refreshLocalBackup();
  } finally {
    _value6.disabled = false;
  }
}, refreshLocalBackup(), setInterval(refreshLocalBackup, 5000);