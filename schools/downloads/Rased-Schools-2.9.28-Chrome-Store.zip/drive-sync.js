"use strict";

var CloudMonitoring = function () {
  const _text = "mirsadDriveConfig",
    _text2 = "mirsadDriveDay",
    _text3 = "mirsadDriveStatus";
  let _value,
    _value2 = false,
    _value3 = false,
    _value4 = false;
  const _value5 = () => _value || (_value = new Promise((_argument, _argument2) => {
    const _value6 = indexedDB.open("mirsad-drive-outbox", 1);
    _value6.onupgradeneeded = () => _value6.result.createObjectStore("jobs", {
      "keyPath": "id"
    }), _value6.onsuccess = () => _argument(_value6.result), _value6.onerror = () => _argument2(_value6.error);
  }));
  async function _value7(_argument3, _argument4) {
    const _value8 = await _value5();
    return new Promise((_argument5, _argument6) => {
      const _value9 = _value8.transaction("jobs", _argument3),
        _value0 = _argument4(_value9.objectStore("jobs"));
      _value9.oncomplete = () => _argument5(_value0.result), _value9.onerror = () => _argument6(_value9.error), _value9.onabort = () => _argument6(_value9.error);
    });
  }
  const _value1 = () => _value7("readonly", _argument7 => _argument7.getAll());
  async function _value10(_argument8, _argument9 = false) {
    await chrome.storage.local.set({
      [_text3]: {
        "text": _argument8,
        "error": _argument9,
        "at": Date.now()
      }
    });
  }
  async function _value11(_argument0, _argument1 = {}, _argument10 = null) {
    const _value12 = (await chrome.storage.local.get(_text))[_text];
    if (!_value12?.["url"] || !_value12?.["key"]) throw new Error("\u0641\u0639\u0651\u0644 \u0627\u0644\u0645\u062F\u0631\u0633\u0629 \u0648\u0627\u0631\u0628\u0637 \u062C\u0647\u0627\u0632 \u0627\u0644\u0631\u0635\u062F \u0623\u0648\u0644\u064B\u0627");
    if (_argument10 && _value12.key !== _argument10) {
      const _value13 = new Error("\u062A\u063A\u064A\u0631\u062A \u062C\u0644\u0633\u0629 \u0627\u0644\u0631\u0641\u0639\u061B \u062D\u064F\u0641\u0638 \u0627\u0644\u0645\u0644\u0641 \u0644\u0644\u0645\u0631\u0627\u062C\u0639\u0629");
      _value13.code = "writer-changed";
      throw _value13;
    }
    const _value14 = await MirsadServiceTransport.fetch(_value12.url, {
      "method": "POST",
      "headers": {
        "Content-Type": "text/plain;charset=utf-8"
      },
      "body": JSON.stringify({
        "action": _argument0,
        "key": _value12.key,
        ..._argument1,
        ...(await MirsadCommercialAccount.identity())
      }),
      "signal": AbortSignal.timeout(25000)
    });
    if (!_value14.ok) throw new Error("\u062A\u0639\u0630\u0631 \u0627\u0644\u0627\u062A\u0635\u0627\u0644 \u0628\u062E\u062F\u0645\u0629 Drive (" + _value14.status + ")");
    const _value15 = await _value14.json();
    if (!_value15.ok) {
      const _value16 = new Error(_value15.error || "\u062A\u0639\u0630\u0631 \u062D\u0641\u0638 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A");
      _value16.code = _value15.code, await MirsadCommercialAccount.denied(_value16, _value12.key);
      throw _value16;
    }
    if (_value15.subscription) await MirsadCommercialAccount.remember(_value15.subscription, _value12.key);
    if (_value15.snapshot && typeof LocalBackup !== "undefined") void LocalBackup.snapshot(_value15).catch(() => {});
    return _value15;
  }
  async function _value17(_argument11, _argument12) {
    if (!/^https:\/\/script\.google\.com\/macros\/s\/[A-Za-z0-9_-]+\/exec$/.test(_argument11)) throw new Error("\u0623\u062F\u062E\u0644 \u0631\u0627\u0628\u0637 \u0646\u0634\u0631 Apps Script \u0627\u0644\u0630\u064A \u064A\u0646\u062A\u0647\u064A \u0628\u0640 /exec");
    const _value18 = (await chrome.storage.local.get(_text))[_text] || {};
    _argument12 = _argument12 || _value18.key;
    if (typeof _argument12 !== "string" || _argument12.length < 32) throw new Error("\u0623\u062F\u062E\u0644 \u0631\u0645\u0632 \u0627\u0644\u0631\u0641\u0639 \u0627\u0644\u0645\u062D\u0641\u0648\u0638 \u0641\u064A \u0625\u0639\u062F\u0627\u062F\u0627\u062A \u0627\u0644\u062E\u062F\u0645\u0629 (32 \u062D\u0631\u0641\u064B\u0627 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644)");
    await chrome.storage.local.set({
      [_text]: {
        "url": _argument11,
        "key": _argument12
      }
    });
    const _value19 = (await chrome.storage.local.get(_text))[_text];
    if (_value19?.["key"] !== _argument12 || _value19?.["url"] !== _argument11) throw new Error("\u062A\u0639\u0630\u0631 \u062A\u062B\u0628\u064A\u062A \u0627\u0644\u0631\u0628\u0637 \u0641\u064A \u062A\u062E\u0632\u064A\u0646 \u0627\u0644\u0645\u062A\u0635\u0641\u062D\u061B \u062D\u0627\u0648\u0644 \u0645\u062C\u062F\u062F\u064B\u0627");
    return await _value10("\u062D\u064F\u0641\u0638 \u0627\u0644\u0631\u0628\u0637\u061B \u062D\u0645\u0651\u0644 \u062C\u062F\u0648\u0644 \u0627\u0644\u064A\u0648\u0645 \u0644\u0625\u0646\u0634\u0627\u0621 \u0627\u0644\u0645\u062C\u0644\u062F"), {
      "ok": true
    };
  }
  async function _value20() {
    try {
      const _value21 = await chrome.tabs.query({
        "url": "https://mirsad-school.onrender.com/schools/automatic-monitoring.html*"
      });
      await Promise.allSettled(_value21.filter(_argument13 => _argument13.id).map(_argument14 => chrome.tabs.sendMessage(_argument14.id, {
        "type": "MIRSAD_MONITOR_CHANGED"
      })));
    } catch {}
  }
  const _value22 = () => ({
    ...MirsadMonitorModel.defaultSchedule,
    ...scheduleSettings
  });
  async function _value23(_argument15) {
    const _value24 = MirsadMonitorModel.normalize,
      _options = {
        "source": _argument15.sourceType,
        "sourceDate": _argument15.sourceScheduleDate || "",
        "sourceUpload": !_argument15.sourceScheduleDate && _argument15.sourceType === "naqar" ? _argument15.sourceUploadedAt || "" : "",
        "roundCount": _argument15.roundCount,
        "teachers": _argument15.teachers.map(_value24).sort(),
        "lessons": _argument15.items.map(_argument16 => [_value24(_argument16.teacher), _argument16.period, String(_argument16.subject || "").trim(), String(_argument16.className || "").trim(), String(_argument16.url || "").trim()]).sort((_argument17, _argument18) => JSON.stringify(_argument17).localeCompare(JSON.stringify(_argument18)))
      };
    return [...new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(JSON.stringify(_options))))].map(_argument19 => _argument19.toString(16).padStart(2, "0")).join("");
  }
  async function _value25() {
    const _value26 = (await chrome.storage.local.get(_text))[_text];
    if (!_value26?.["url"]) return false;
    let _value27 = false;
    const _value28 = await chrome.tabs.query({
      "url": "https://mirsad-school.onrender.com/schools/*"
    });
    for (const _value29 of _value28) {
      try {
        const _value30 = await chrome.tabs.sendMessage(_value29.id, {
          "type": "MIRSAD_CLASSIC_SERVICE",
          "url": _value26.url
        });
        _value30?.["changed"] && (_value27 = true, await chrome.tabs.reload(_value29.id));
      } catch {}
    }
    return _value27;
  }
  async function _value31() {
    let _value32;
    try {
      _value32 = await _value11("protectedDayState");
    } catch (_value33) {
      throw new Error("\u062A\u0639\u0630\u0631 \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u062D\u0645\u0627\u064A\u0629 \u0627\u0644\u064A\u0648\u0645. \u064A\u0644\u0632\u0645 \u0633\u0643\u0631\u0628\u062A 0.6.35\u061B \u0644\u0645 \u064A\u064F\u063A\u064A\u0651\u0631 \u0627\u0644\u062C\u062F\u0648\u0644. " + _value33.message);
    }
    if (_value32.protection !== "explicit-reset-only-v1") throw new Error("\u062D\u062F\u0651\u062B \u0633\u0643\u0631\u0628\u062A \u0627\u0644\u062D\u0645\u0627\u064A\u0629 0.6.35 \u0623\u0648\u0644\u064B\u0627\u061B \u0644\u0645 \u064A\u064F\u063A\u064A\u0651\u0631 \u062C\u062F\u0648\u0644 \u0627\u0644\u064A\u0648\u0645");
    return _value32;
  }
  async function _value34(_argument20) {
    const _options2 = {
      "date": _argument20.snapshot.date,
      "snapshot": _argument20.snapshot,
      "folderUrl": _argument20.folderUrl
    };
    await chrome.storage.local.set({
      [_text2]: _options2
    });
    if (typeof setSeventhPeriodPolicy === "function") await setSeventhPeriodPolicy(_argument20.snapshot);
    return _options2;
  }
  async function _value35(_argument21 = null) {
    const _value36 = await chrome.storage.local.get([_text, _text2, "mirsadMadrasatiSelectedDate", "mirsadMadrasatiLastSuccess", "mirsadLoadIntent"]);
    if (!_value36[_text]?.["key"] && !_value36[_text2]) return;
    if (_value36.mirsadLoadIntent?.["date"] === MirsadMonitorModel.day() && !["verified", "cancelled"].includes(_value36.mirsadLoadIntent.status)) throw new Error("\u062A\u062D\u0645\u064A\u0644 \u0627\u0644\u062C\u062F\u0648\u0644 \u0627\u0644\u0645\u0637\u0644\u0648\u0628 \u0644\u0645 \u064A\u0643\u062A\u0645\u0644 \u0623\u0648 \u064A\u0646\u062A\u0638\u0631 \u0642\u0631\u0627\u0631\u0643\u061B \u0644\u0646 \u064A\u064F\u0633\u062A\u062E\u062F\u0645 \u0627\u0644\u062C\u062F\u0648\u0644 \u0627\u0644\u0642\u062F\u064A\u0645 \u0628\u062F\u0644\u064B\u0627 \u0639\u0646\u0647");
    const _value37 = _value36[_text2],
      _value38 = _value37?.["snapshot"],
      _value39 = _value36.mirsadMadrasatiSelectedDate || MirsadMonitorModel.day(),
      _value40 = _value36.mirsadMadrasatiLastSuccess;
    if (_value37?.["date"] !== MirsadMonitorModel.day() || _value38?.["sourceType"] !== "madrasati") throw new Error("\u0644\u0645 \u064A\u0628\u062F\u0623 \u0627\u0644\u0641\u062D\u0635: \u0645\u062F\u0631\u0633\u062A\u064A \u0647\u064A \u0627\u0644\u0645\u0635\u062F\u0631 \u0627\u0644\u0648\u062D\u064A\u062F. \u062C\u062F\u0648\u0644 \u0627\u0644\u064A\u0648\u0645 \u0627\u0644\u0645\u062D\u0641\u0648\u0638 \u0645\u0646 \u0645\u0635\u062F\u0631 \u0633\u0627\u0628\u0642\u061B \u0644\u0645 \u064A\u064F\u062D\u0645\u0651\u0644 \u062C\u062F\u0648\u0644 \u0645\u062F\u0631\u0633\u062A\u064A \u0627\u0644\u0645\u0637\u0644\u0648\u0628\u060C \u0648\u0644\u0646 \u064A\u064F\u0633\u062A\u062E\u062F\u0645 \u0627\u0644\u062C\u062F\u0648\u0644 \u0627\u0644\u0642\u062F\u064A\u0645");
    if (_value38.sourceScheduleDate !== _value39) throw new Error("\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u062C\u062F\u0648\u0644 \u0627\u0644\u0645\u062D\u0641\u0648\u0638 " + (_value38.sourceScheduleDate || "\u063A\u064A\u0631 \u0645\u062D\u062F\u062F") + " \u064A\u062E\u062A\u0644\u0641 \u0639\u0646 \u0627\u0644\u0645\u0637\u0644\u0648\u0628 " + _value39 + "\u061B \u062D\u0645\u0651\u0644 \u062A\u0627\u0631\u064A\u062E \u0645\u062F\u0631\u0633\u062A\u064A \u0627\u0644\u0645\u0637\u0644\u0648\u0628 \u0623\u0648\u0644\u064B\u0627");
    if (!_value40?.["monitoringPrepared"] || _value40.importedForDate !== MirsadMonitorModel.day() || _value40.date !== _value39 || _value40.revision !== _value38.scheduleRevision) throw new Error("\u0644\u0645 \u064A\u064F\u0624\u0643\u0651\u062F \u062A\u062D\u0645\u064A\u0644 \u062C\u062F\u0648\u0644 \u0645\u062F\u0631\u0633\u062A\u064A \u0627\u0644\u0645\u0637\u0644\u0648\u0628 \u0641\u064A \u0627\u0644\u0631\u0635\u062F\u061B \u0646\u0641\u0651\u0630 \u0627\u0644\u062E\u0637\u0648\u0629 1 \u0623\u0648\u0644\u064B\u0627");
    if (_argument21?.["scheduleRevision"] && _argument21.scheduleRevision !== _value38.scheduleRevision) throw new Error("\u0627\u0644\u062C\u0644\u0633\u0629 \u0627\u0644\u0633\u0627\u0628\u0642\u0629 \u062A\u062E\u0635 \u062C\u062F\u0648\u0644\u064B\u0627 \u0622\u062E\u0631\u061B \u0644\u0646 \u062A\u064F\u0633\u062A\u0623\u0646\u0641 \u0623\u0648 \u062A\u064F\u062E\u0644\u0637 \u0645\u0639 \u0627\u0644\u062C\u062F\u0648\u0644 \u0627\u0644\u0645\u0637\u0644\u0648\u0628");
    return _value37;
  }
  async function _value41(_argument22 = false) {
    const _value42 = (await chrome.storage.local.get(_text))[_text];
    if (!_value42?.["key"]) {
      const _value43 = (await chrome.storage.local.get(_text2))[_text2];
      if (_value43?.["date"] === MirsadMonitorModel.day()) return await _value35(), _value43;
      throw new Error("\u0641\u0639\u0651\u0644 \u0627\u0644\u0645\u062F\u0631\u0633\u0629 \u0648\u0627\u0631\u0628\u0637 \u062C\u0647\u0627\u0632 \u0627\u0644\u0631\u0635\u062F \u0623\u0648\u0644\u064B\u0627");
    }
    const _value44 = await _value31();
    if (_value44.exists) {
      if (_value44.snapshot.sourceType !== "madrasati") throw new Error("\u062C\u062F\u0648\u0644 \u0627\u0644\u064A\u0648\u0645 \u0645\u0646 \u0645\u0635\u062F\u0631 \u0645\u0644\u063A\u0649\u061B \u0644\u0646 \u064A\u064F\u0633\u062A\u062E\u062F\u0645 \u0628\u062F\u0644 \u062C\u062F\u0648\u0644 \u0645\u062F\u0631\u0633\u062A\u064A");
      const _value45 = await _value34(_value44);
      return await _value35(), _value45;
    }
    return _value46();
  }
  async function _value46() {
    const _value47 = await _value31();
    if (!_value47.exists) throw new Error("\u062D\u0645\u0651\u0644 \u0627\u0644\u062C\u062F\u0648\u0644 \u0645\u0646 \u0627\u0644\u062E\u0637\u0648\u0629 1 \u0623\u0648\u0644\u064B\u0627\u061B \u0644\u0645 \u064A\u0635\u0644 \u062C\u062F\u0648\u0644 \u0625\u0644\u0649 \u0627\u0644\u0631\u0635\u062F \u0627\u0644\u0622\u0644\u064A");
    if (_value47.snapshot.sourceType !== "madrasati") throw new Error("\u062C\u062F\u0648\u0644 \u0627\u0644\u064A\u0648\u0645 \u0645\u0646 \u0645\u0635\u062F\u0631 \u0645\u0644\u063A\u0649\u061B \u062D\u0645\u0651\u0644 \u062C\u062F\u0648\u0644 \u0645\u062F\u0631\u0633\u062A\u064A \u0623\u0648\u0644\u064B\u0627");
    const _value48 = await _value34(_value47);
    return await _value35(), await _value10("\u062A\u0645 \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u062C\u062F\u0648\u0644 \u0645\u062F\u0631\u0633\u062A\u064A \u0627\u0644\u0645\u0637\u0644\u0648\u0628 \u0641\u064A \u0627\u0644\u0631\u0635\u062F\u061B \u0627\u0644\u062A\u062D\u0636\u064A\u0631 \u0645\u062D\u0641\u0648\u0638"), _value48;
  }
  let _value49 = null;
  async function _value50(_argument23) {
    if (_value49) return _value49;
    return _value49 = (async () => {
      await MirsadClassicReady;
      const _value51 = await _value31();
      if (_value51.exists) return {
        "ok": true,
        "locked": true
      };
      throw new Error("\u062C\u0647\u0651\u0632 \u062C\u062F\u0648\u0644 \u0627\u0644\u064A\u0648\u0645 \u064A\u062F\u0648\u064A\u064B\u0627 \u0645\u0646 \u0627\u0644\u0625\u0636\u0627\u0641\u0629\u061B \u0644\u0627 \u062A\u0648\u062C\u062F \u0645\u0637\u0627\u0628\u0642\u0629 \u062A\u0644\u0642\u0627\u0626\u064A\u0629 \u062A\u0633\u062A\u0628\u062F\u0644 \u0627\u0644\u0633\u062C\u0644");
    })()["finally"](() => {
      _value49 = null;
    }), _value49;
  }
  async function _value52(_argument24) {
    const _value53 = (await chrome.storage.local.get(_text))[_text];
    if (!_value53?.["key"]) return;
    const _value54 = await _value11("setMonitoringTiming", {
      "scheduleSettings": _argument24
    });
    if (!_value54.saved || !_value54.snapshot) throw new Error("\u0644\u0645 \u064A\u0624\u0643\u062F \u0627\u0644\u0631\u0635\u062F \u062D\u0641\u0638 \u0627\u0644\u062A\u0648\u0642\u064A\u062A\u061B \u062D\u062F\u0651\u062B \u0633\u0643\u0631\u0628\u062A 0.6.38");
    await _value34(_value54), await _value20();
  }
  async function _value55(_argument25, _argument26 = null) {
    const _value56 = await getRun();
    if (!_value56 || _value56.scheduleRevision !== _argument25.scheduleRevision) return;
    if (_value56.running) throw new Error("\u0623\u0648\u0642\u0641 \u0627\u0644\u0631\u0635\u062F \u0645\u0624\u0642\u062A\u064B\u0627 \u0642\u0628\u0644 \u062A\u0639\u062F\u064A\u0644 \u0627\u0644\u0631\u0648\u0627\u0628\u0637");
    runLinkSnapshot = _argument25;
    for (const _value57 of _argument25.lessons.filter(_argument27 => _argument27.url || _argument26?.["teacherId"] === _argument27.teacherId && Number(_argument26.period) === _argument27.period)) {
      const _options3 = {
        ..._value57,
        "teacher": _value57.teacherName,
        "hasLesson": true,
        "validPeriod": true
      };
      for (const _value58 of [_value56.schedule, ...(_value56.period === _value57.period ? [_value56.periodItems] : [])]) {
        if (!Array.isArray(_value58)) continue;
        const _value59 = _value58.find(_argument28 => MirsadMonitorModel.normalize(_argument28.teacher) === MirsadMonitorModel.normalize(_value57.teacherName) && Number(_argument28.period ?? _value56.period) === _value57.period);
        if (_value59) {
          if (!_value59.url || _argument26?.["teacherId"] === _value57.teacherId && Number(_argument26.period) === _value57.period) _value59.url = _value57.url;
        } else {
          if (_value57.url) _value58.push({
            ..._options3
          });
        }
      }
    }
    await saveRun(_value56);
  }
  let runLinkSnapshot = null;
  function reconcileRunLinks(latest, snapshot = runLinkSnapshot) {
    if (!latest || !snapshot || latest.scheduleRevision !== snapshot.scheduleRevision) return latest;
    const same = (item, row) => Number(item.period ?? latest.period) === Number(row.period) && MirsadMonitorModel.normalize(item.scheduledTeacher || item.teacher) === MirsadMonitorModel.normalize(row.teacherName);
    const itemFor = row => ({
      ...row,
      period: Number(row.period),
      teacher: row.teacherName,
      hasLesson: true,
      validPeriod: true
    });
    const update = (list, activePeriod = false) => Array.isArray(list) ? list.map((item, index) => {
      if (activePeriod && (latest.current && index === latest.index || index < latest.index)) return item;
      const row = snapshot.lessons.find(row => same(item, row));
      return row ? {
        ...item,
        url: row.url || ""
      } : item;
    }) : list;
    const next = {
      ...latest,
      schedule: update(latest.schedule),
      periodItems: update(latest.periodItems, true)
    };
    // Initial selection excluded empty links. Admit newly supplied lessons for future cycles/periods.
    if (Array.isArray(next.schedule)) for (const row of snapshot.lessons) {
      if (!MirsadScheduleCore.validTeamsUrl(row.url) || next.schedule.some(item => same(item, row))) continue;
      next.schedule.push(itemFor(row));
    }
    if ((latest.running || latest.paused) && !latest.waitingForCycle2 && Array.isArray(next.periodItems)) for (const row of snapshot.lessons) {
      if (Number(row.period) !== Number(latest.period) || !MirsadScheduleCore.validTeamsUrl(row.url)) continue;
      // A consumed no-link placeholder is not a completed Teams check. Queue it again once a link exists.
      if (next.periodItems.some((item, index) => index >= Number(latest.index || 0) && same(item, row))) continue;
      const history = (latest.results || []).filter(item => same(item, row) && Number(item.cycle) === Number(latest.cycle));
      if (history.some(item => (item.scanStatus || item.status) !== "no-link")) continue;
      const consumed = next.periodItems.filter((item, index) => index < Number(latest.index || 0) && same(item, row));
      if (consumed.some(item => MirsadScheduleCore.validTeamsUrl(item.url)) && !history.some(item => (item.scanStatus || item.status) === "no-link")) continue;
      next.periodItems.push(itemFor(row));
    }
    return Object.assign(latest, next);
  }
  async function _value60(state) {
    const latest = await getRun();
    if (!latest || latest.scheduleRevision !== state.snapshot.scheduleRevision) return null;
    runLinkSnapshot = state.snapshot;
    reconcileRunLinks(latest);
    if ((await saveRun(latest)) === false) return null;
    return latest;
  }
  let _value61 = null;
  async function _value62() {
    if (_value61) return _value61;
    return _value61 = (async () => {
      if (!(await chrome.storage.local.get(_text))[_text]?.["key"]) return null;
      const _value63 = await _value31();
      if (!_value63.exists || _value63.snapshot?.["date"] !== MirsadMonitorModel.day()) return null;
      const _value64 = await _value60(_value63);
      if (!_value64) return null;
      await _value34(_value63);
      if (typeof wakeUpdatedLinks === "function") await wakeUpdatedLinks();
      return await _value20(), {
        "run": _value64,
        "snapshot": _value63.snapshot
      };
    })()["finally"](() => {
      _value61 = null;
    }), _value61;
  }
  async function _value65() {
    const _value66 = await _value31();
    if (!_value66.exists || _value66.snapshot.date !== MirsadMonitorModel.day()) throw new Error("\u0644\u0645 \u064A\u062A\u0623\u0643\u062F \u0648\u062C\u0648\u062F \u062C\u062F\u0648\u0644 \u0627\u0644\u064A\u0648\u0645 \u0627\u0644\u062D\u0627\u0644\u064A");
    return {
      "ok": true,
      "date": _value66.snapshot.date,
      "sourceDate": _value66.snapshot.sourceScheduleDate,
      "revision": _value66.snapshot.scheduleRevision,
      "checkedAt": Date.now(),
      "missing": _value66.snapshot.lessons.filter(_argument29 => !MirsadScheduleCore.normalizeTeamsUrl(_argument29.url) && !MirsadMonitorModel.isExcludedPeriod(_value66.snapshot.date, _argument29.period, _value66.snapshot)).map(_argument30 => ({
        "teacher": _argument30.teacherName,
        "teacherId": _argument30.teacherId,
        "period": _argument30.period,
        "reason": _argument30.url ? "\u0627\u0644\u0631\u0627\u0628\u0637 \u0627\u0644\u0645\u062D\u0641\u0648\u0638 \u064A\u062D\u062A\u0627\u062C \u0645\u0631\u0627\u062C\u0639\u0629 \u0635\u064A\u063A\u062A\u0647" : "\u062E\u0627\u0646\u0629 \u0627\u0644\u0631\u0627\u0628\u0637 \u0641\u0627\u0631\u063A\u0629 \u0641\u064A \u062C\u062F\u0648\u0644 \u0627\u0644\u064A\u0648\u0645"
      }))
    };
  }
  const _value67 = _argument31 => MirsadMonitorModel.normalize(_argument31).replace(/[\u200b-\u200f\u202a-\u202e\u2060-\u2069]/g, "");
  async function _value68(_argument32) {
    const _value69 = await _value31();
    if (!_value69.exists || _value69.snapshot.sourceScheduleDate !== _argument32.scheduleDate) return null;
    const _value70 = await _value11("getTimetableSource");
    if (_value70.payload?.["schoolId"] && _value70.payload.schoolId.toLowerCase() !== _argument32.schoolId.toLowerCase()) throw new Error("\u0627\u0644\u0645\u062F\u0631\u0633\u0629 \u0644\u0627 \u062A\u0637\u0627\u0628\u0642 \u0627\u0644\u062C\u062F\u0648\u0644 \u0627\u0644\u0645\u062D\u0641\u0648\u0638");
    const _value71 = _value69.snapshot,
      _items = [],
      _items2 = [],
      _items3 = [];
    if (_value71.lessons.length !== _argument32.lessons.length || _value71.teachers.length !== _argument32.teachers.length) _items3.push({
      "teacher": "\u0627\u0644\u062C\u062F\u0648\u0644",
      "period": "",
      "reason": "\u0639\u062F\u062F \u0627\u0644\u062D\u0635\u0635 \u0623\u0648 \u0627\u0644\u0645\u0639\u0644\u0645\u064A\u0646 \u062A\u063A\u064A\u0631"
    });
    for (const _value72 of _value71.lessons) {
      if (_value72.url || MirsadMonitorModel.isExcludedPeriod(_value71.date, _value72.period, _value71)) continue;
      const _value73 = _argument32.lessons.filter(_argument33 => MirsadMonitorModel.normalize(_argument33.teacher) === MirsadMonitorModel.normalize(_value72.teacherName) && Number(_argument33.cellIndex) - 1 === _value72.period),
        _value74 = _value73.length === 1 ? _value73[0] : null,
        _options4 = {
          "teacher": _value72.teacherName,
          "teacherId": _value72.teacherId,
          "period": _value72.period
        };
      if (!_value74) {
        _items3.push({
          ..._options4,
          "reason": "\u0644\u0645 \u062A\u0648\u062C\u062F \u062D\u0635\u0629 \u0648\u062D\u064A\u062F\u0629 \u0645\u0637\u0627\u0628\u0642\u0629 \u0644\u0644\u0645\u0639\u0644\u0645 \u0648\u0631\u0642\u0645 \u0627\u0644\u062D\u0635\u0629 \u0641\u064A \u0645\u062F\u0631\u0633\u062A\u064A"
        });
        continue;
      }
      if (!_value67(_value74.lesson) || _value67(_value74.lesson) !== _value67(_value72.className)) {
        _items3.push({
          ..._options4,
          "reason": "\u0627\u0644\u0641\u0635\u0644 \u0645\u062E\u062A\u0644\u0641: \u0627\u0644\u0645\u062D\u0641\u0648\u0638 \xAB" + _value72.className + "\xBB \u0648\u0627\u0644\u0642\u0627\u062F\u0645 \u0645\u0646 \u0645\u062F\u0631\u0633\u062A\u064A \xAB" + _value74.lesson + "\xBB"
        });
        continue;
      }
      if (_value74.teams) _items.push({
        ..._options4,
        "url": _value74.teams,
        "source": _value74.linkSource || "verified-row",
        "notice": _value74.title !== _value72.subject ? "\u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u0645\u0648\u0636\u0648\u0639 \u0641\u064A \u0645\u062F\u0631\u0633\u062A\u064A \u0645\u062E\u062A\u0644\u0641\u061B \u0633\u064A\u0628\u0642\u0649 \u0627\u0644\u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u0645\u062D\u0641\u0648\u0638 \u0643\u0645\u0627 \u0647\u0648" : ""
      });else _items2.push({
        ..._options4,
        "reason": _value74.linkReason || "\u0644\u0645 \u064A\u0638\u0647\u0631 \u0631\u0627\u0628\u0637 \u0628\u0639\u062F \u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u062A\u062D\u0642\u0642"
      });
    }
    const _options5 = {
        "id": crypto.randomUUID(),
        "status": "preview",
        "date": _value71.date,
        "sourceDate": _value71.sourceScheduleDate,
        "revision": _value71.scheduleRevision || "legacy",
        "at": Date.now(),
        "found": _items,
        "completed": [],
        "missing": _items2,
        "conflicts": _items3,
        "payload": _argument32
      },
      _value75 = await chrome.storage.local.get("mirsadLinkCompletionReports");
    return await chrome.storage.local.set({
      "mirsadLinkCompletionReports": [...(_value75.mirsadLinkCompletionReports || []), _options5]
    }), {
      "day": {
        "date": _value71.date,
        "snapshot": _value71,
        "folderUrl": _value69.folderUrl
      },
      "filled": 0,
      "merged": true,
      "pendingLinks": _items.length,
      "previewConflicts": _items3.length,
      "reportId": _options5.id
    };
  }
  async function _value76(_argument34) {
    if (_value4) throw new Error("\u062D\u0641\u0638 \u0627\u0644\u0631\u0648\u0627\u0628\u0637 \u0642\u064A\u062F \u0627\u0644\u062A\u0646\u0641\u064A\u0630");
    _value4 = true;
    try {
      if ((await getRun())?.["running"]) throw new Error("\u0623\u0648\u0642\u0641 \u0627\u0644\u0631\u0635\u062F \u0645\u0624\u0642\u062A\u064B\u0627 \u0642\u0628\u0644 \u0625\u0636\u0627\u0641\u0629 \u0627\u0644\u0631\u0648\u0627\u0628\u0637");
      const _value77 = await chrome.storage.local.get("mirsadLinkCompletionReports"),
        _value78 = _value77.mirsadLinkCompletionReports || [],
        _value79 = _value78.find(_argument35 => _argument35.id === _argument34);
      if (!_value79 || _value79.date !== MirsadMonitorModel.day()) throw new Error("\u0627\u0644\u0645\u0639\u0627\u064A\u0646\u0629 \u0644\u064A\u0633\u062A \u0644\u0644\u064A\u0648\u0645 \u0627\u0644\u062D\u0627\u0644\u064A\u061B \u0623\u0639\u062F \u0627\u0644\u0641\u062D\u0635");
      if (_value79.status === "applied") return {
        "ok": true,
        "saved": true,
        "filled": _value79.completed.length
      };
      if (!_value79.found.length) throw new Error("\u0644\u0627 \u062A\u0648\u062C\u062F \u0631\u0648\u0627\u0628\u0637 \u0642\u0627\u0628\u0644\u0629 \u0644\u0644\u0625\u0636\u0627\u0641\u0629\u061B \u0631\u0627\u062C\u0639 \u0627\u0644\u0646\u0648\u0627\u0642\u0635 \u0648\u0627\u0644\u0627\u062E\u062A\u0644\u0627\u0641\u0627\u062A");
      const _value80 = await _value35(await getRun());
      if (_value80.snapshot.scheduleRevision !== _value79.revision) throw new Error("\u062A\u063A\u064A\u0631 \u0627\u0644\u062C\u062F\u0648\u0644 \u0645\u0646\u0630 \u0627\u0644\u0645\u0639\u0627\u064A\u0646\u0629\u061B \u0623\u0639\u062F \u0627\u0644\u0641\u062D\u0635");
      const _value81 = await _value11("fillMissingLinks", {
        "date": _value79.date,
        "payload": _value79.payload,
        "expectedRevision": _value79.revision
      });
      if (!_value81.merged || !Array.isArray(_value81.completed) || _value81.completed.length !== _value81.filled) throw new Error("\u0644\u0645 \u064A\u062A\u0623\u0643\u062F \u062D\u0641\u0638 \u0627\u0644\u0631\u0648\u0627\u0628\u0637\u061B \u062D\u062F\u0651\u062B \u0633\u0643\u0631\u0628\u062A \u0627\u0644\u062D\u0641\u0638 \u0648\u0623\u0639\u062F \u0627\u0644\u0641\u062D\u0635");
      await _value34(_value81);
      if (_value81.filled) await _value55(_value81.snapshot);
      return Object.assign(_value79, {
        "status": "applied",
        "appliedAt": Date.now(),
        "completed": _value81.completed.map(_argument36 => ({
          ..._argument36,
          "source": _value79.found.find(_argument37 => _argument37.teacherId === _argument36.teacherId && _argument37.period === _argument36.period && _argument37.url === _argument36.url)?.["source"] || "verified-row"
        })),
        "missing": _value81.snapshot.lessons.filter(_argument38 => !_argument38.url && !MirsadMonitorModel.isExcludedPeriod(_value81.snapshot.date, _argument38.period, _value81.snapshot)).map(_argument39 => ({
          "teacher": _argument39.teacherName,
          "period": _argument39.period
        }))
      }), delete _value79.payload, await chrome.storage.local.set({
        "mirsadLinkCompletionReports": _value78
      }), await _value20(), {
        "ok": true,
        "saved": true,
        "filled": _value81.filled
      };
    } finally {
      _value4 = false;
    }
  }
  async function _value82(_argument40, _argument41 = {}) {
    const _value83 = await _value31();
    if (!_value83.exists || _value83.snapshot.sourceScheduleDate !== _argument40.scheduleDate) {
      if (_argument41.requireExisting) throw new Error("\u0627\u0644\u062A\u062D\u0645\u064A\u0644 \u0623\u062B\u0646\u0627\u0621 \u0627\u0644\u0631\u0635\u062F \u064A\u0643\u0645\u0651\u0644 \u0631\u0648\u0627\u0628\u0637 \u0627\u0644\u062C\u062F\u0648\u0644 \u0627\u0644\u062D\u0627\u0644\u064A \u0641\u0642\u0637\u061B \u0644\u0645 \u064A\u064F\u0633\u062A\u0628\u062F\u0644 \u0627\u0644\u062C\u062F\u0648\u0644");
      return null;
    }
    if (_argument41.expectedRevision && _argument41.expectedRevision !== _value83.snapshot.scheduleRevision) throw new Error("\u062A\u063A\u064A\u0631 \u0625\u0635\u062F\u0627\u0631 \u0627\u0644\u062C\u062F\u0648\u0644 \u0623\u062B\u0646\u0627\u0621 \u0627\u0644\u062A\u062D\u0645\u064A\u0644\u061B \u0644\u0645 \u064A\u064F\u0637\u0628\u0642 \u0627\u0644\u062A\u062D\u062F\u064A\u062B");
    const _value84 = await getRun();
    if (_value84?.["running"] && _value84.scheduleRevision !== _value83.snapshot.scheduleRevision) throw new Error("\u062C\u0644\u0633\u0629 \u0627\u0644\u0631\u0635\u062F \u062A\u062E\u0635 \u062C\u062F\u0648\u0644\u064B\u0627 \u0622\u062E\u0631\u061B \u0644\u0645 \u064A\u064F\u0637\u0628\u0642 \u0627\u0644\u062A\u062D\u062F\u064A\u062B");
    const _value85 = await _value11("fillMissingLinks", {
      "payload": _argument40,
      automaticRefresh: _argument41.automaticRefresh === true,
      refreshExisting: _argument41.refreshExisting === true,
      startPeriod: _argument41.startPeriod,
      "date": MirsadMonitorModel.day(),
      "expectedRevision": _value83.snapshot.scheduleRevision || "legacy"
    });
    if (!_value85.merged) throw new Error("\u0627\u062E\u062A\u0644\u0641\u062A \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u062D\u0635\u0635\u061B \u0644\u0645 \u064A\u062A\u063A\u064A\u0631 \u0623\u064A \u0634\u064A\u0621");
    if (_value85.filled && !Array.isArray(_value85.completed) || Array.isArray(_value85.completed) && _value85.completed.length !== _value85.filled) throw new Error("\u0644\u0645 \u064A\u062A\u0623\u0643\u062F \u062A\u0643\u0645\u064A\u0644 \u0627\u0644\u0631\u0648\u0627\u0628\u0637 \u062F\u0648\u0646 \u0627\u0633\u062A\u0628\u062F\u0627\u0644 \u0627\u0644\u062C\u062F\u0648\u0644\u061B \u062D\u062F\u0651\u062B \u0633\u0643\u0631\u0628\u062A \u0627\u0644\u062D\u0641\u0638");
    if (_value85.snapshot?.["date"] !== _value83.snapshot.date || _value85.snapshot?.["scheduleRevision"] !== _value83.snapshot.scheduleRevision) throw new Error("\u062A\u063A\u064A\u0631 \u0627\u0644\u062C\u062F\u0648\u0644 \u0623\u062B\u0646\u0627\u0621 \u062D\u0641\u0638 \u0627\u0644\u0631\u0648\u0627\u0628\u0637\u061B \u0644\u0645 \u062A\u062A\u063A\u064A\u0631 \u062C\u0644\u0633\u0629 \u0627\u0644\u0631\u0635\u062F");
    const _options6 = {
      "date": _value85.snapshot.date,
      "snapshot": _value85.snapshot,
      "folderUrl": _value85.folderUrl
    };
    if (_value85.filled) {
      const _value86 = (await chrome.storage.local.get(_text2))[_text2];
      if (_value86?.["snapshot"]?.["scheduleRevision"] && _value86.snapshot.scheduleRevision !== _value85.snapshot.scheduleRevision) throw new Error("\u062A\u063A\u064A\u0631 \u0627\u0644\u062C\u062F\u0648\u0644 \u0639\u0644\u0649 \u0627\u0644\u062C\u0647\u0627\u0632 \u0623\u062B\u0646\u0627\u0621 \u0627\u0644\u062D\u0641\u0638\u061B \u0644\u0645 \u062A\u062A\u063A\u064A\u0631 \u062C\u0644\u0633\u0629 \u0627\u0644\u0631\u0635\u062F");
      await _value60(_value85), await _value34(_value85);
      if (typeof wakeUpdatedLinks === "function") await wakeUpdatedLinks();
      await _value20();
    }
    return {
      "day": _options6,
      "filled": _value85.filled,
      added: _value85.added,
      changed: _value85.changed,
      completed: _value85.completed,
      "merged": true,
      "automatic": true
    };
  }
  async function _value87(_argument42) {
    if (_value4) throw new Error("\u062D\u0641\u0638 \u0627\u0644\u0631\u0627\u0628\u0637 \u0642\u064A\u062F \u0627\u0644\u062A\u0646\u0641\u064A\u0630");
    _value4 = true;
    try {
      const _value88 = await getRun();
      if (_value88?.["running"]) throw new Error("\u0623\u0648\u0642\u0641 \u0627\u0644\u0631\u0635\u062F \u0645\u0624\u0642\u062A\u064B\u0627 \u0645\u0646 \u0627\u0644\u0625\u0636\u0627\u0641\u0629 \u0642\u0628\u0644 \u0625\u0636\u0627\u0641\u0629 \u0627\u0644\u0631\u0627\u0628\u0637");
      const _value89 = await _value35(_value88);
      if (!_value89 || _argument42.date !== _value89.date || _argument42.expectedRevision !== (_value89.snapshot.scheduleRevision || "legacy")) throw new Error("\u062A\u0627\u0631\u064A\u062E \u0623\u0648 \u0625\u0635\u062F\u0627\u0631 \u0627\u0644\u062C\u062F\u0648\u0644 \u0644\u0627 \u064A\u0637\u0627\u0628\u0642 \u0627\u0644\u0625\u0636\u0627\u0641\u0629");
      const _value90 = await _value11("manualLessonLink", {
        "date": _argument42.date,
        "teacherId": _argument42.teacherId,
        "period": _argument42.period,
        "url": _argument42.url,
        "expectedUrl": _argument42.expectedUrl,
        "expectedRevision": _argument42.expectedRevision,
        "requestId": _argument42.requestId
      });
      if (!_value90.saved || !_value90.snapshot) throw new Error("\u0644\u0645 \u064A\u062A\u0623\u0643\u062F \u062D\u0641\u0638 \u0627\u0644\u0631\u0627\u0628\u0637\u061B \u062D\u062F\u0651\u062B \u0633\u0643\u0631\u0628\u062A \u0627\u0644\u0631\u0635\u062F");
      await _value34(_value90), await _value55(_value90.snapshot, {
        "teacherId": _argument42.teacherId,
        "period": _argument42.period
      });
      const _value91 = (await chrome.storage.local.get("mirsadMadrasatiLastSuccess")).mirsadMadrasatiLastSuccess;
      if (_value91?.["revision"] === _value90.snapshot.scheduleRevision) await chrome.storage.local.set({
        "mirsadMadrasatiLastSuccess": {
          ..._value91,
          "missingLinks": _value90.snapshot.lessons.filter(_argument43 => !_argument43.url && !MirsadMonitorModel.isExcludedPeriod(_value90.snapshot.date, _argument43.period, _value90.snapshot)).map(_argument44 => ({
            "teacher": _argument44.teacherName,
            "period": _argument44.period
          }))
        }
      });
      return await _value20(), {
        "ok": true,
        "saved": true
      };
    } finally {
      _value4 = false;
    }
  }
  async function _value92(_argument45) {
    await refreshScheduleSettings();
    const _options7 = {
        "payload": _argument45,
        "roundCount": scheduleSettings.configuredRoundCount || scheduleSettings.roundCount,
        "scheduleSettings": _value22(),
        "importRequestId": crypto.randomUUID()
      },
      _value93 = await _value11("publishMonitoringTimetable", {
        ..._options7,
        "previewOnly": true
      });
    if (!_value93.sourceHash || !_value93.currentHash) throw new Error("\u062D\u062F\u0651\u062B \u0633\u0643\u0631\u0628\u062A 0.6.39\u061B \u0644\u0645 \u062A\u064F\u062C\u0647\u0651\u0632 \u0645\u0639\u0627\u064A\u0646\u0629 \u0627\u0644\u0627\u0633\u062A\u0628\u062F\u0627\u0644");
    _options7.sourceHash = _value93.sourceHash, _options7.currentHash = _value93.currentHash;
    if (_value93.needsDecision) return await chrome.storage.local.set({
      "mirsadPendingImport": {
        "date": MirsadMonitorModel.day(),
        "payload": _argument45,
        "params": _options7,
        "preview": _value93
      },
      "mirsadLoadIntent": {
        "date": MirsadMonitorModel.day(),
        "sourceDate": _argument45.scheduleDate,
        "status": "awaitingDecision"
      }
    }), {
      "pendingDecision": true
    };
    const _value94 = await _value11("publishMonitoringTimetable", {
        ..._options7,
        "confirmed": true,
        "keepPrevious": false
      }),
      _value95 = await _value96(_value94, _argument45);
    return {
      ..._value94,
      "day": _value95
    };
  }
  async function _value97(_argument46) {
    if (typeof _argument46 !== "boolean") throw new Error("\u062D\u062F\u062F \u062D\u0641\u0638 \u0627\u0644\u0633\u0627\u0628\u0642 \u0623\u0648 \u0627\u0633\u062A\u0628\u062F\u0627\u0644\u0647 \u062F\u0648\u0646 \u062D\u0641\u0638");
    const _value98 = (await chrome.storage.local.get("mirsadPendingImport")).mirsadPendingImport;
    if (!_value98 || _value98.date !== MirsadMonitorModel.day()) throw new Error("\u0645\u0639\u0627\u064A\u0646\u0629 \u0627\u0644\u062C\u062F\u0648\u0644 \u0642\u062F\u064A\u0645\u0629\u061B \u0623\u0639\u062F \u062A\u062D\u0645\u064A\u0644\u0647");
    try {
      const _value99 = await _value11("publishMonitoringTimetable", {
          ..._value98.params,
          "confirmed": true,
          "keepPrevious": _argument46
        }),
        _value100 = await _value96(_value99, _value98.payload);
      return await chrome.storage.local.set({
        "mirsadPendingImport": null
      }), {
        ..._value99,
        "day": _value100
      };
    } catch (_value101) {
      if (_value101.message.includes("\u062A\u063A\u064A\u0631\u062A \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u064A\u0648\u0645")) {
        const _value102 = await _value11("publishMonitoringTimetable", {
          ..._value98.params,
          "previewOnly": true
        });
        await chrome.storage.local.set({
          "mirsadPendingImport": {
            ..._value98,
            "preview": _value102,
            "params": {
              ..._value98.params,
              "sourceHash": _value102.sourceHash,
              "currentHash": _value102.currentHash
            }
          }
        });
      }
      throw _value101;
    }
  }
  async function _value103() {
    await chrome.storage.local.set({
      "mirsadPendingImport": null,
      "mirsadLoadIntent": {
        "date": MirsadMonitorModel.day(),
        "status": "cancelled"
      }
    });
  }
  async function _value96(_argument47, _argument48) {
    if (_argument48?.["source"] !== "madrasati" || _argument47?.["snapshot"]?.["sourceType"] !== "madrasati") throw new Error("\u0645\u062F\u0631\u0633\u062A\u064A \u0647\u064A \u0627\u0644\u0645\u0635\u062F\u0631 \u0627\u0644\u0648\u062D\u064A\u062F \u0627\u0644\u0645\u0633\u0645\u0648\u062D \u0644\u0644\u062A\u062D\u0645\u064A\u0644");
    if (!_argument47?.["monitoringPrepared"] || !_argument47.snapshot?.["scheduleRevision"]) throw new Error("\u0644\u0645 \u064A\u0624\u0643\u062F \u0627\u0644\u062E\u0627\u062F\u0645 \u062A\u0637\u0628\u064A\u0642 \u0627\u0644\u062C\u062F\u0648\u0644 \u0641\u064A \u0627\u0644\u0631\u0635\u062F \u0627\u0644\u0622\u0644\u064A\u061B \u062D\u062F\u0651\u062B \u0633\u0643\u0631\u0628\u062A 0.6.38");
    const _value104 = MirsadVisibleSchedule.reference(_argument48, MirsadMonitorModel.day());
    if (!MirsadVisibleSchedule.matches(_argument47.snapshot, _value104)) throw new Error("\u062C\u062F\u0648\u0644 \u0627\u0644\u0631\u0635\u062F \u0644\u0627 \u064A\u0637\u0627\u0628\u0642 \u0627\u0644\u062C\u062F\u0648\u0644 \u0627\u0644\u0645\u062D\u0645\u0651\u0644\u061B \u0644\u0645 \u062A\u064F\u0633\u062C\u0651\u0644 \u0627\u0644\u0639\u0645\u0644\u064A\u0629 \u0643\u0646\u062C\u0627\u062D");
    const _value105 = await _value31();
    if (!_value105.exists || _value105.snapshot.scheduleRevision !== _argument47.snapshot.scheduleRevision || !MirsadVisibleSchedule.matches(_value105.snapshot, _value104)) throw new Error("\u062A\u0639\u0630\u0631 \u062A\u0623\u0643\u064A\u062F \u062C\u062F\u0648\u0644 \u0627\u0644\u0631\u0635\u062F \u0628\u0639\u062F \u0627\u0644\u062D\u0641\u0638\u061B \u0644\u0645 \u062A\u064F\u0633\u062C\u0651\u0644 \u0627\u0644\u0639\u0645\u0644\u064A\u0629 \u0643\u0646\u062C\u0627\u062D");
    const _value106 = await getRun();
    if (_value106 && _value106.scheduleRevision !== _value105.snapshot.scheduleRevision) await stopAndResetMonitoring();
    const _value107 = await _value34(_value105);
    return await _value10("\u062A\u0645 \u062A\u0637\u0628\u064A\u0642 \u0627\u0644\u062C\u062F\u0648\u0644 \u0648\u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646\u0647 \u0641\u064A \u0627\u0644\u0631\u0635\u062F \u0627\u0644\u0622\u0644\u064A \u2014 " + _value107.snapshot.lessons.length + " \u062D\u0635\u0629"), await _value25(), await _value20(), _value107;
  }
  async function _value108(_argument49, _argument50) {
    if (_argument49 !== MirsadMonitorModel.day()) return {
      "ok": true,
      "ignored": true
    };
    const _value109 = await _value11("resetState", {
      "date": _argument49,
      "requestId": _argument50
    });
    if (!_value109.confirmed) throw new Error("\u0644\u0645 \u062A\u0624\u0643\u062F \u0627\u0644\u062E\u062F\u0645\u0629 \u062A\u0635\u0641\u064A\u0631 \u0627\u0644\u064A\u0648\u0645\u061B \u062D\u062F\u0651\u062B \u0633\u0643\u0631\u0628\u062A \u0631\u0627\u0635\u062F \u062B\u0645 \u0623\u0639\u062F \u0627\u0644\u0645\u062D\u0627\u0648\u0644\u0629");
    return await stopAndResetMonitoring(), await chrome.storage.local.remove(_text2), await _value10("\u0635\u064F\u0641\u0651\u0631 \u064A\u0648\u0645 \u0627\u0644\u0631\u0635\u062F \u0648\u0623\u064F\u0644\u063A\u064A \u062C\u062F\u0648\u0644 \u0627\u0644\u0625\u0636\u0627\u0641\u0629 \u0627\u0644\u0642\u062F\u064A\u0645. \u0627\u0646\u0642\u0644 \u0627\u0644\u062C\u062F\u0648\u0644 \u0627\u0644\u0645\u0637\u0644\u0648\u0628 \u062B\u0645 \u0627\u0628\u062F\u0623 \u0627\u0644\u0631\u0635\u062F."), await _value20(), {
      "ok": true
    };
  }
  const _text4 = "mirsadRecordDelivery";
  let _value110 = Promise.resolve(),
    _value111 = null;
  function _value112(_argument51) {
    const _value113 = _value110["catch"](() => {}).then(async () => {
      const _value114 = await chrome.storage.local.get(_text4),
        _value115 = _value114[_text4] || {
          "pending": {},
          "receipts": {}
        };
      _value115.pending ||= {}, _value115.receipts ||= {};
      const _value116 = _argument51(_value115);
      return await chrome.storage.local.set({
        [_text4]: _value115
      }), _value116;
    });
    return _value110 = _value113["catch"](() => {}), _value113;
  }
  async function _value117(_argument52) {
    await _value110;
    const _value118 = (await chrome.storage.local.get(_text4))[_text4];
    for (const _value119 of Object.values(_value118?.["pending"] || {})) {
      if (_value119.writerKey !== _argument52 || _value119.quarantined) continue;
      const _value120 = await _value7("readonly", _argument53 => _argument53.get(_value119.id));
      if (!_value120) await _value7("readwrite", _argument54 => _argument54.put(_value119));
    }
  }
  async function _value121() {
    await _value110;
    const _value122 = (await chrome.storage.local.get(_text))[_text],
      _value123 = (await chrome.storage.local.get(_text4))[_text4],
      _value124 = new Set((await _value1()).filter(_argument55 => !_argument55.quarantined).map(_argument56 => _argument56.id));
    for (const _value125 of Object.values(_value123?.["pending"] || {})) if (_value125.writerKey === _value122?.["key"] && !_value125.quarantined) _value124.add(_value125.id);
    return _value124.size;
  }
  async function _value126() {
    const _value127 = (await chrome.storage.local.get(_text))[_text];
    await _value112(_argument57 => {
      for (const _value128 of Object.values(_argument57.pending)) if (_value128.writerKey === _value127?.["key"]) _value128.quarantined = true;
    });
  }
  async function _value129(_argument58, _argument59) {
    if (_argument58.action !== "record") return;
    await _value112(_argument60 => {
      delete _argument60.pending[_argument58.id], _argument60.receipts[_argument58.id] = {
        "date": _argument58.date,
        "scanId": _argument58.record.scanId,
        "teacher": _argument58.record.scheduledTeacher,
        "period": _argument58.record.period,
        "cycle": _argument58.record.cycle,
        "writerKey": _argument58.writerKey,
        "at": Date.now(),
        "saved": _argument59.saved === true,
        "discarded": !!_argument59.discarded,
        "reason": _argument59.reason || ""
      };
    });
  }
  async function _value130(_argument61, _argument62, _argument63) {
    const _value131 = await chrome.storage.local.get([_text2, _text]),
      _value132 = _value131[_text2],
      _value133 = _value131[_text]?.["key"];
    if (!_value133) throw new Error("\u0644\u0645 \u064A\u064F\u062D\u0641\u0638 \u0627\u0644\u0641\u062D\u0635: \u062C\u0644\u0633\u0629 \u0631\u0641\u0639 \u0627\u0644\u0645\u062F\u0631\u0633\u0629 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F\u0629");
    if (!_value132 || MirsadMonitorModel.day(new Date(_argument62.scannedAt)) !== _value132.date) throw new Error("\u0644\u0645 \u064A\u064F\u062D\u0641\u0638 \u0627\u0644\u0641\u062D\u0635: \u062A\u0627\u0631\u064A\u062E \u0627\u0644\u0646\u062A\u064A\u062C\u0629 \u0644\u0627 \u064A\u0637\u0627\u0628\u0642 \u064A\u0648\u0645 \u0627\u0644\u0631\u0635\u062F");
    const _value134 = _argument61 + "|" + _argument62.scanId + "|" + _value133,
      _options8 = {
        "id": _value134,
        "writerKey": _value133,
        "action": _argument61,
        "date": _value132.date,
        "record": _argument62,
        "image": _argument63,
        "scheduleSettings": _value22(),
        "queuedAt": Date.now()
      };
    if (_argument61 === "record") await _value112(_argument64 => {
      _argument64.pending[_value134] = _options8;
    });
    try {
      await _value7("readwrite", _argument65 => _argument65.put(_options8));
    } catch (_value135) {
      await chrome.alarms.create("mirsadDriveRetry", {
        "when": Date.now() + 5000
      });
      throw _value135;
    }
    return void _value136()["catch"](() => {}), {
      "queued": true,
      "id": _value134
    };
  }
  async function _value137(_argument66, _argument67, _argument68, _argument69, _argument70) {
    if (_argument66.testMode || _argument66.backtestMode || _argument66.immediateMode) return;
    return _value130("image", {
      "scanId": _argument67.scanId,
      "teacher": _argument67.teacher,
      "scheduledTeacher": _argument66.current.teacher,
      "period": _argument66.period,
      "cycle": _argument66.cycle,
      "status": _argument67.status,
      "scheduleRevision": _argument66.scheduleRevision || "legacy",
      "scannedAt": _argument69,
      "localName": String(_argument70 || "").split(/[\\/]/).pop(),
      "detail": _argument67.detail || ""
    }, _argument68);
  }
  async function _value138(_argument71, _argument72) {
    if (_argument71.testMode || _argument71.backtestMode || _argument71.immediateMode) return;
    return _value130("record", {
      ..._argument72,
      "scheduleRevision": _argument71.scheduleRevision || "legacy",
      "status": _argument72.scanStatus || _argument72.status
    });
  }
  function _value139(_argument73) {
    return _argument73?.["retryable"] === true || ["TimeoutError", "AbortError", "TypeError"].includes(_argument73?.["name"]) || /network|failed to fetch|signal timed out|تعذر الاتصال/i.test(_argument73?.["message"] || "");
  }
  function _value140(_argument74) {
    return ["device-revoked", "device-proof", "invalid-session", "school-disabled", "subscription-expired"].includes(_argument74?.["code"]);
  }
  async function _value141() {
    await _value110;
    const _value142 = (await chrome.storage.local.get(_text))[_text],
      _value143 = (await chrome.storage.local.get(_text4))[_text4] || {},
      _value144 = MirsadMonitorModel.day();
    return {
      "pendingRecords": Object.values(_value143.pending || {}).filter(_argument75 => _argument75.writerKey === _value142?.["key"] && _argument75.date === _value144 && !_argument75.quarantined).length,
      "confirmedRecords": Object.values(_value143.receipts || {}).filter(_argument76 => _argument76.writerKey === _value142?.["key"] && _argument76.date === _value144 && _argument76.saved).length
    };
  }
  async function _value145() {
    const _value146 = (await chrome.storage.local.get(_text))[_text];
    if (!_value146?.["key"]) return;
    await _value117(_value146.key);
    const _value147 = (await _value1()).filter(_argument77 => !_argument77.quarantined).sort((_argument78, _argument79) => (_argument78.action === "image" ? 0 : 1) - (_argument79.action === "image" ? 0 : 1) || _argument78.queuedAt - _argument79.queuedAt),
      _items4 = [];
    for (const _value148 of _value147) if (_value148.writerKey && _value148.writerKey !== _value146.key) await _value7("readwrite", _argument80 => _argument80.put({
      ..._value148,
      "quarantined": true
    }));
    const _value149 = _value147.filter(_argument81 => (!_argument81.writerKey || _argument81.writerKey === _value146.key) && (!_argument81.nextAttemptAt || _argument81.nextAttemptAt <= Date.now()));
    for (const _value150 of _value149.slice(0, 2)) {
      if (_value150.writerKey && _value150.writerKey !== _value146.key) {
        await _value7("readwrite", _argument82 => _argument82.put({
          ..._value150,
          "quarantined": true
        }));
        continue;
      }
      try {
        const _value151 = await _value11(_value150.action, {
          "date": _value150.date,
          "record": _value150.record,
          "scheduleSettings": _value150.scheduleSettings,
          ...(_value150.image ? {
            "image": _value150.image
          } : {})
        }, _value150.writerKey || _value146.key);
        if (!_value151.discarded && (_value150.action === "record" && _value151.saved !== true || _value150.action === "image" && (!_value151.url || !_value151.fileId))) {
          const _value152 = new Error("\u0644\u0645 \u062A\u0624\u0643\u062F \u062E\u062F\u0645\u0629 \u0645\u0631\u0635\u0627\u062F \u062D\u0641\u0638 " + (_value150.action === "image" ? "\u0627\u0644\u0635\u0648\u0631\u0629" : "\u0627\u0644\u0646\u062A\u064A\u062C\u0629"));
          _value152.retryable = true;
          throw _value152;
        }
        if (_value150.action === "image" && !_value151.archived && !_value151.discarded) {
          const _value153 = _argument83 => {
            for (const _value154 of _argument83) _value154.scanId === _value150.record.scanId && (_value154.driveUrl = _value151.url, _value154.driveFileId = _value151.fileId);
            return _argument83;
          };
          if (typeof mutateEvidenceRecords === "function") await mutateEvidenceRecords(_value153);else {
            const _value155 = await chrome.storage.local.get("mirsadEvidenceRecords");
            await chrome.storage.local.set({
              "mirsadEvidenceRecords": _value153(_value155.mirsadEvidenceRecords || [])
            });
          }
        }
        await _value129(_value150, _value151), await _value7("readwrite", _argument84 => _argument84["delete"](_value150.id));
      } catch (_value156) {
        if (_value156.code === "writer-changed") {
          await _value7("readwrite", _argument85 => _argument85.put({
            ..._value150,
            "quarantined": true
          })), await _value112(_argument86 => {
            if (_argument86.pending[_value150.id]) _argument86.pending[_value150.id].quarantined = true;
          });
          break;
        }
        const _value157 = (_value150.attempts || 0) + 1,
          _value158 = Date.now() + Math.min(60000, 5000 * 2 ** Math.min(_value157 - 1, 4));
        await _value7("readwrite", _argument87 => _argument87.put({
          ..._value150,
          "attempts": _value157,
          "nextAttemptAt": _value158,
          "lastError": String(_value156.message || _value156)
        })), _items4.push({
          "teacher": _value150.record.scheduledTeacher || _value150.record.teacher,
          "action": _value150.action,
          "message": _value156.message
        });
        if (_value140(_value156) || _value139(_value156)) break;
      }
    }
    const _value159 = (await _value1()).filter(_argument88 => !_argument88.quarantined),
      _value160 = await _value141(),
      _value161 = _items4.length ? " \xB7 \u062A\u0639\u0630\u0631 \u0631\u0641\u0639 " + _items4[0].teacher + ": " + _items4[0].message : "";
    await _value10(_value159.length ? "\u0648\u0635\u0644 \u0644\u0644\u0645\u0648\u0642\u0639 " + _value160.confirmedRecords + " \u0646\u062A\u064A\u062C\u0629\u061B \u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0631\u0641\u0639 " + _value159.length + " \u0635\u0648\u0631 \u0623\u0648 \u0646\u062A\u0627\u0626\u062C \u0645\u062D\u0641\u0648\u0638\u0629 \u0645\u062D\u0644\u064A\u064B\u0627" + _value161 : "\u062A\u0645 \u062A\u0623\u0643\u064A\u062F \u0648\u0635\u0648\u0644 " + _value160.confirmedRecords + " \u0646\u062A\u064A\u062C\u0629 \u0648\u062C\u0645\u064A\u0639 \u0627\u0644\u0635\u0648\u0631 \u0625\u0644\u0649 \u0627\u0644\u0645\u0648\u0642\u0639", _items4.length > 0);
    if (_value159.length) {
      const _value162 = Math.min(..._value159.map(_argument89 => _argument89.nextAttemptAt || Date.now() + 1000));
      await chrome.alarms.create("mirsadDriveRetry", {
        "when": Math.max(Date.now() + 1000, _value162)
      });
      if (_value159.some(_argument90 => !_argument90.nextAttemptAt || _argument90.nextAttemptAt <= Date.now())) _value3 = true;
    }
    if (_value149.length) await _value20();
  }
  function _value136() {
    if (_value2) return _value3 = true, _value111 || Promise.resolve();
    _value2 = true;
    const _value163 = _value145()["catch"](async _argument91 => {
      await _value10("\u0627\u0644\u0631\u0641\u0639 \u0645\u0624\u062C\u0644 \u0645\u0639 \u062D\u0641\u0638 \u0627\u0644\u0646\u062A\u0627\u0626\u062C \u0645\u062D\u0644\u064A\u064B\u0627: " + _argument91.message, true), await chrome.alarms.create("mirsadDriveRetry", {
        "when": Date.now() + 5000
      });
    })["finally"](() => {
      _value2 = false;
      if (_value111 === _value163) _value111 = null;
      _value3 && (_value3 = false, setTimeout(() => void _value136(), 250));
    });
    return _value111 = _value163, _value163;
  }
  async function _value164() {
    const _value165 = await chrome.storage.local.get([_text, _text2, _text3, "mirsadScheduleAdoption"]);
    let _value166 = null;
    try {
      await _value35();
    } catch (_value167) {
      _value166 = _value167.message;
    }
    return {
      "ready": !_value166 && _value165[_text2]?.["date"] === MirsadMonitorModel.day(),
      "selectionError": _value166,
      "configured": !!_value165[_text]?.["key"],
      "url": _value165[_text]?.["url"] || "",
      "day": _value165[_text2] || null,
      "status": _value165[_text3] || null,
      "pendingAdoption": _value165.mirsadScheduleAdoption || null
    };
  }
  return chrome.alarms.create("mirsadDriveSync", {
    "periodInMinutes": 1
  }), chrome.alarms.onAlarm.addListener(_argument92 => {
    if (_argument92.name === "mirsadDriveSync" || _argument92.name === "mirsadDriveRetry") return _value136();
  }), {
    "deliveryStatus": _value141,
    "pendingCount": _value121,
    "orphanCount": async () => (await _value1()).filter(_argument93 => _argument93.quarantined).length,
    "quarantinePending": async () => {
      for (const _value168 of await _value1()) if (!_value168.quarantined) await _value7("readwrite", _argument94 => _argument94.put({
        ..._value168,
        "quarantined": true
      }));
      await _value126();
    },
    video: (action, payload) => _value11(action, payload),
    reconcileRunLinks: reconcileRunLinks,
    "pullRemoteLinks": _value62,
    "missingLinkState": _value65,
    "previewMissingLinks": _value68,
    "applyMissingReport": _value76,
    "linksBusy": () => _value4,
    "fillMissingLinks": _value82,
    "manualLessonLink": _value87,
    "configure": _value17,
    "beginDay": _value46,
    "syncTiming": _value52,
    "stageImport": _value92,
    "confirmImport": _value97,
    "cancelImport": _value103,
    "acceptDirect": _value96,
    "assertSelected": _value35,
    "syncVisible": _value50,
    "ensureDay": _value41,
    "resetAfterPurge": _value108,
    "capture": _value137,
    "record": _value138,
    "flush": _value136,
    "info": _value164,
    "localSnapshot": () => _value11("day", {
      date: MirsadMonitorModel.day()
    }),
    "heartbeat": _argument95 => _value11("heartbeat", _argument95)
  };
}();