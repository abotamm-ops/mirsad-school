"use strict";

var MirsadDeviceState = (() => {
  async function _value() {
    return new Promise(_argument => {
      let _value2 = false;
      const _value3 = _argument2 => {
          if (_value2) return;
          _value2 = true, clearTimeout(_value4), _argument({
            "sessionState": ["active", "idle", "locked"].includes(_argument2) ? _argument2 : "unknown"
          });
        },
        _value4 = setTimeout(() => _value3("unknown"), 1500);
      try {
        if (!chrome.idle?.["queryState"]) {
          _value3("unknown");
          return;
        }
        chrome.idle.queryState(60, _argument3 => _value3(chrome.runtime.lastError ? "unknown" : _argument3));
      } catch {
        _value3("unknown");
      }
    });
  }
  return chrome.idle?.["onStateChanged"]?.["addListener"](() => {
    if (typeof MirsadLiveSender !== "undefined") void MirsadLiveSender.sync(true);
  }), {
    "read": _value
  };
})();