'use strict';

(() => {
  const _value = _argument => document.getElementById(_argument),
    _value2 = _argument2 => MirsadScheduleCore.normalizeTeamsUrl(_argument2);
  let _items = [],
    _value3 = false;
  const _value4 = _argument3 => new Date(_argument3).toLocaleString("ar-SA", {
      "timeZone": "Asia/Riyadh"
    }),
    _value5 = () => _items.find(_argument4 => _argument4.id === _value("reports").value),
    _value6 = _argument5 => _argument5.status === "applied" ? _argument5.completed : _argument5.found;
  function _value7(_argument6, _argument7, _argument8) {
    _value(_argument6).replaceChildren();
    for (const _value8 of _argument7.length ? _argument7 : [_argument8]) {
      const _value9 = document.createElement("li");
      _value9.textContent = _value8, _value(_argument6).append(_value9);
    }
  }
  function _value0() {
    const _value1 = _value5(),
      _value10 = Number(_value("period").value);
    _value("rows").replaceChildren(), _value("export").disabled = !_value1, _value("apply").disabled = _value3 || !_value1 || _value1.status === "applied" || !_value1.found.length;
    if (!_value1) {
      _value("summary").textContent = "\u0644\u0627 \u062A\u0648\u062C\u062F \u0639\u0645\u0644\u064A\u0627\u062A \u0641\u062D\u0635 \u0645\u062D\u0641\u0648\u0638\u0629 \u0628\u0639\u062F.";
      return;
    }
    const _value11 = _value1.status === "applied";
    _value("summary").textContent = "\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u0631\u0635\u062F: " + _value1.date + " \xB7 \u062A\u0627\u0631\u064A\u062E \u0627\u0644\u062C\u062F\u0648\u0644: " + _value1.sourceDate + " \xB7 \u0648\u0642\u062A \u0627\u0644\u0641\u062D\u0635: " + _value4(_value1.at) + " \xB7 " + (_value11 ? "\u0623\u064F\u0636\u064A\u0641 " + _value1.completed.length + " \u0631\u0627\u0628\u0637 \u0641\u064A " + _value4(_value1.appliedAt) : _value1.found.length ? "\u0627\u0643\u062A\u064F\u0634\u0641 " + _value1.found.length + " \u0631\u0627\u0628\u0637 \u2014 \u0644\u0645 \u062A\u064F\u0636\u0641 \u0628\u0639\u062F\u061B \u0631\u0627\u062C\u0639\u0647\u0627 \u0648\u0648\u0627\u0641\u0642" : "\u0644\u0645 \u064A\u064F\u0639\u062B\u0631 \u0639\u0644\u0649 \u0631\u0648\u0627\u0628\u0637 \u062C\u062F\u064A\u062F\u0629 \u2014 \u0647\u0630\u0627 \u0644\u0627 \u064A\u0639\u0646\u064A \u0627\u0643\u062A\u0645\u0627\u0644 \u0627\u0644\u0631\u0648\u0627\u0628\u0637");
    for (const _value12 of _value6(_value1).filter(_argument9 => !_value10 || _argument9.period === _value10)) {
      const _value13 = document.createElement("tr");
      for (const _value14 of [_value12.teacher, "\u0627\u0644\u062D\u0635\u0629 " + _value12.period]) {
        const _value15 = document.createElement("td");
        _value15.textContent = _value14, _value13.append(_value15);
      }
      const _value16 = document.createElement("td"),
        _value17 = _value2(_value12.url);
      _value16.className = "url";
      if (_value17) {
        const _value18 = document.createElement("a");
        _value18.textContent = _value17, _value18.href = _value17, _value18.target = "_blank", _value18.rel = "noopener noreferrer", _value16.append(_value18);
      } else _value16.textContent = "\u0631\u0627\u0628\u0637 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D \u2014 \u0644\u0645 \u064A\u064F\u0641\u062A\u062D";
      _value13.append(_value16);
      const _value19 = document.createElement("td");
      _value19.textContent = {
        "row-direct": "\u0631\u0627\u0628\u0637 \u0645\u0628\u0627\u0634\u0631 \u0641\u064A \u0635\u0641 \u0627\u0644\u062D\u0635\u0629",
        "calendar": "\u0628\u064A\u0627\u0646\u0627\u062A \u062C\u062F\u0648\u0644 \u0645\u062F\u0631\u0633\u062A\u064A",
        "fast-details": "\u0642\u0631\u0627\u0621\u0629 \u0635\u0641\u062D\u0629 \u0627\u0644\u062A\u0641\u0627\u0635\u064A\u0644",
        "rendered-details": "\u0625\u0639\u0627\u062F\u0629 \u0641\u062A\u062D \u0627\u0644\u062A\u0641\u0627\u0635\u064A\u0644 \u0628\u0639\u062F \u0642\u0631\u0627\u0621\u0629 \u0633\u0631\u064A\u0639\u0629 \u0628\u0644\u0627 \u0631\u0627\u0628\u0637",
        "deep-calendar": "\u0638\u0647\u0631 \u0641\u064A \u0628\u064A\u0627\u0646\u0627\u062A \u0645\u062F\u0631\u0633\u062A\u064A \u062E\u0644\u0627\u0644 \u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0641\u062D\u0635 \u0627\u0644\u0645\u0639\u0645\u0651\u0642",
        "deep-row-direct": "\u0638\u0647\u0631 \u0632\u0631 \u0627\u0644\u062D\u0636\u0648\u0631 \u0627\u0644\u0645\u0628\u0627\u0634\u0631 \u062E\u0644\u0627\u0644 \u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0641\u062D\u0635 \u0627\u0644\u0645\u0639\u0645\u0651\u0642",
        "deep-fast-details": "\u0638\u0647\u0631 \u0641\u064A \u062A\u0641\u0627\u0635\u064A\u0644 \u0627\u0644\u062D\u0635\u0629 \u062E\u0644\u0627\u0644 \u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0641\u062D\u0635 \u0627\u0644\u0645\u0639\u0645\u0651\u0642",
        "deep-rendered-details": "\u0638\u0647\u0631 \u0628\u0639\u062F \u0625\u0639\u0627\u062F\u0629 \u0641\u062A\u062D \u0627\u0644\u062A\u0641\u0627\u0635\u064A\u0644 \u062E\u0644\u0627\u0644 \u0627\u0644\u0641\u062D\u0635 \u0627\u0644\u0645\u0639\u0645\u0651\u0642",
        "verified-row": "\u0635\u0641 \u0627\u0644\u062D\u0635\u0629 \u0627\u0644\u0645\u062A\u062D\u0642\u0642 \u0645\u0646\u0647"
      }[_value12.source] || "\u0635\u0641 \u0627\u0644\u062D\u0635\u0629 \u0627\u0644\u0645\u062A\u062D\u0642\u0642 \u0645\u0646\u0647";
      if (_value12.notice) {
        const _value20 = document.createElement("small");
        _value20.textContent = " \xB7 " + _value12.notice, _value19.append(_value20);
      }
      _value13.append(_value19);
      const _value21 = document.createElement("td"),
        _value22 = document.createElement("button");
      _value22.textContent = "\u0646\u0633\u062E \u0627\u0644\u0631\u0627\u0628\u0637", _value22.disabled = !_value17, _value22.onclick = async () => {
        try {
          await navigator.clipboard.writeText(_value17), _value("feedback").textContent = "\u0646\u064F\u0633\u062E \u0631\u0627\u0628\u0637 " + _value12.teacher + " \u2014 \u0627\u0644\u062D\u0635\u0629 " + _value12.period;
        } catch {
          _value("feedback").textContent = "\u062A\u0639\u0630\u0631 \u0627\u0644\u0646\u0633\u062E \u0627\u0644\u062A\u0644\u0642\u0627\u0626\u064A\u061B \u062D\u062F\u0651\u062F \u0627\u0644\u0631\u0627\u0628\u0637 \u0648\u0627\u0646\u0633\u062E\u0647 \u064A\u062F\u0648\u064A\u064B\u0627";
        }
      }, _value21.append(_value22), _value13.append(_value21), _value("rows").append(_value13);
    }
    const _value23 = _value1.status === "applied" ? _value1.missing : [..._value1.missing, ..._value1.found.map(_argument0 => ({
      ..._argument0,
      "reason": "\u0627\u0644\u0631\u0627\u0628\u0637 \u0645\u0643\u062A\u0634\u0641 \u0648\u0644\u0645 \u064A\u064F\u062D\u0641\u0638 \u0628\u0639\u062F"
    })), ..._value1.conflicts.filter(_argument1 => _argument1.teacherId).map(_argument10 => ({
      ..._argument10,
      "reason": "\u0627\u0644\u0631\u0628\u0637 \u063A\u064A\u0631 \u0645\u062D\u0633\u0648\u0645: " + _argument10.reason
    }))];
    _value7("missing", _value23.filter(_argument11 => !_value10 || _argument11.period === _value10).map(_argument12 => _argument12.teacher + " \u2014 \u0627\u0644\u062D\u0635\u0629 " + _argument12.period + (_argument12.reason ? " \u2014 " + _argument12.reason : "")), "\u0644\u0627 \u062A\u0648\u062C\u062F \u062E\u0627\u0646\u0627\u062A \u0641\u0627\u0631\u063A\u0629 \u0636\u0645\u0646 \u0647\u0630\u0627 \u0627\u0644\u0627\u062E\u062A\u064A\u0627\u0631 \u0641\u064A \u0646\u0633\u062E\u0629 \u0627\u0644\u0641\u062D\u0635 \u0627\u0644\u0645\u062D\u0641\u0648\u0638\u0629\u061B \u0631\u0627\u062C\u0639 \u0627\u0644\u0646\u0648\u0627\u0642\u0635 \u0627\u0644\u062D\u0627\u0644\u064A\u0629 \u0623\u0639\u0644\u0627\u0647."), _value7("conflicts", _value1.conflicts.map(_argument13 => _argument13.teacher + " \u2014 " + _argument13.period + " \u2014 " + _argument13.reason), "\u0644\u0627 \u062A\u0648\u062C\u062F \u0627\u062E\u062A\u0644\u0627\u0641\u0627\u062A \u0645\u0633\u062C\u0644\u0629.");
  }
  async function _value24() {
    const _value25 = _value("reports").value || new URLSearchParams(location.search).get("id"),
      _value26 = await chrome.storage.local.get("mirsadLinkCompletionReports");
    _items = (_value26.mirsadLinkCompletionReports || []).slice().reverse(), _value("reports").replaceChildren();
    for (const _value27 of _items) {
      const _value28 = document.createElement("option");
      _value28.value = _value27.id, _value28.textContent = _value27.date + " \u2014 " + _value4(_value27.at) + " \u2014 " + (_value27.status === "applied" ? "\u0623\u064F\u0636\u064A\u0641 " + _value27.completed.length : "\u0627\u0643\u062A\u064F\u0634\u0641 " + _value27.found.length), _value("reports").append(_value28);
    }
    if (_items.some(_argument14 => _argument14.id === _value25)) _value("reports").value = _value25;
    _value0();
  }
  async function _value29() {
    const _value30 = _value("refreshMissing");
    _value30.disabled = true, _value("liveMissingStatus").textContent = "\u062C\u0627\u0631\u064D \u0642\u0631\u0627\u0621\u0629 \u0627\u0644\u0646\u0648\u0627\u0642\u0635 \u0645\u0646 \u062C\u062F\u0648\u0644 \u0627\u0644\u064A\u0648\u0645 \u0627\u0644\u062D\u0627\u0644\u064A\u2026";
    try {
      const _value31 = await chrome.runtime.sendMessage({
        "type": "MIRSAD_CURRENT_MISSING_LINKS"
      });
      if (!_value31?.["ok"] || !Array.isArray(_value31.missing)) throw new Error(_value31?.["error"] || "\u062A\u0639\u0630\u0631 \u0627\u0644\u062A\u062D\u0642\u0642\u061B \u0644\u0627 \u064A\u0645\u0643\u0646 \u062A\u0623\u0643\u064A\u062F \u0627\u0643\u062A\u0645\u0627\u0644 \u0627\u0644\u0631\u0648\u0627\u0628\u0637");
      _value("liveMissingStatus").textContent = "\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u0631\u0635\u062F " + _value31.date + " \xB7 \u062A\u0627\u0631\u064A\u062E \u0627\u0644\u062C\u062F\u0648\u0644 " + _value31.sourceDate + " \u2014 " + (_value31.missing.length ? _value31.missing.length + " \u062D\u0635\u0629 \u062A\u062D\u062A\u0627\u062C \u0631\u0627\u0628\u0637\u064B\u0627\u061B \u0639\u062F\u0645 \u0627\u0644\u0639\u062B\u0648\u0631 \u0639\u0644\u0649 \u062C\u062F\u064A\u062F \u0644\u0627 \u064A\u0639\u0646\u064A \u0639\u062F\u0645 \u0648\u062C\u0648\u062F \u0646\u0648\u0627\u0642\u0635" : "\u0644\u0627 \u062A\u0648\u062C\u062F \u062E\u0627\u0646\u0627\u062A \u0646\u0627\u0642\u0635\u0629 \u0641\u064A \u0627\u0644\u062C\u062F\u0648\u0644 \u0627\u0644\u062D\u0627\u0644\u064A \u0627\u0644\u0645\u062A\u062D\u0642\u0642 \u0645\u0646\u0647"), _value7("liveMissing", _value31.missing.map(_argument15 => _argument15.teacher + " \u2014 \u0627\u0644\u062D\u0635\u0629 " + _argument15.period + " \u2014 " + _argument15.reason), "\u0627\u0643\u062A\u0645\u0644\u062A \u062E\u0627\u0646\u0627\u062A \u0627\u0644\u0631\u0648\u0627\u0628\u0637 \u0641\u064A \u062C\u062F\u0648\u0644 \u0627\u0644\u064A\u0648\u0645 \u0627\u0644\u0645\u062A\u062D\u0642\u0642 \u0645\u0646\u0647.");
    } catch (_value32) {
      _value("liveMissingStatus").textContent = _value32.message, _value7("liveMissing", [], "\u0644\u0645 \u064A\u062A\u0645 \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u0627\u0643\u062A\u0645\u0627\u0644 \u0631\u0648\u0627\u0628\u0637 \u0627\u0644\u064A\u0648\u0645.");
    } finally {
      _value30.disabled = false;
    }
  }
  _value("refreshMissing").onclick = _value29, void _value29(), _value("reports").onchange = _value0, _value("period").onchange = _value0, _value("print").onclick = () => window.print(), _value("apply").onclick = async () => {
    const _value33 = _value5();
    if (!_value33 || _value3 || !confirm("\u0625\u0636\u0627\u0641\u0629 \u0627\u0644\u0631\u0648\u0627\u0628\u0637 \u0625\u0644\u0649 \u0627\u0644\u062E\u0627\u0646\u0627\u062A \u0627\u0644\u0641\u0627\u0631\u063A\u0629 \u0627\u0644\u0645\u0637\u0627\u0628\u0642\u0629 \u0641\u0642\u0637\u061F \u0627\u0644\u0646\u062A\u0627\u0626\u062C \u0648\u0627\u0644\u0631\u0648\u0627\u0628\u0637 \u0627\u0644\u0645\u0648\u062C\u0648\u062F\u0629 \u0645\u062D\u0641\u0648\u0638\u0629.")) return;
    _value3 = true, _value0(), _value("feedback").textContent = "\u062C\u0627\u0631\u064D \u0627\u0644\u062A\u062D\u0642\u0642 \u0648\u0627\u0644\u062D\u0641\u0638\u2026";
    try {
      const _value34 = await chrome.runtime.sendMessage({
        "type": "MIRSAD_APPLY_MISSING_LINKS",
        "reportId": _value33.id
      });
      if (!_value34?.["ok"] || !_value34.saved) throw new Error(_value34?.["error"] || "\u0644\u0645 \u064A\u062A\u0623\u0643\u062F \u0627\u0644\u062D\u0641\u0638");
      await _value24(), _value("feedback").textContent = _value34.filled ? "\u062D\u064F\u0641\u0638 " + _value34.filled + " \u0631\u0627\u0628\u0637. \u0627\u0644\u0633\u062C\u0644 \u064A\u0639\u0631\u0636 \u0645\u0627 \u0623\u064F\u0636\u064A\u0641 \u0641\u0639\u0644\u064B\u0627." : "\u0644\u0627 \u062C\u062F\u064A\u062F \u2014 \u0627\u0644\u0631\u0648\u0627\u0628\u0637 \u0623\u0635\u0628\u062D\u062A \u0645\u0648\u062C\u0648\u062F\u0629 \u0648\u0644\u0645 \u064A\u064F\u0633\u062A\u0628\u062F\u0644 \u0634\u064A\u0621.";
    } catch (_value35) {
      _value("feedback").textContent = _value35.message;
    } finally {
      _value3 = false, _value0();
    }
  }, _value("export").onclick = () => {
    const _value36 = _value5();
    if (!_value36) return;
    const _value37 = _argument16 => "\"" + String(_value38(_argument16 ?? "")).replace(/"/g, "\"\"") + "\"",
      _value38 = _argument17 => /^(?:[\t\r\n]|\s*[=+@\-])/.test(String(_argument17)) ? "'" + _argument17 : _argument17,
      _items2 = [["\u0627\u0644\u062D\u0627\u0644\u0629", "\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u0631\u0635\u062F", "\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u062C\u062F\u0648\u0644", "\u0648\u0642\u062A \u0627\u0644\u0641\u062D\u0635", "\u0627\u0644\u0645\u0639\u0644\u0645", "\u0627\u0644\u062D\u0635\u0629", "\u0627\u0644\u0631\u0627\u0628\u0637"], ..._value6(_value36).map(_argument18 => [_value36.status === "applied" ? "\u0645\u0636\u0627\u0641" : "\u0644\u0644\u0645\u0631\u0627\u062C\u0639\u0629", _value36.date, _value36.sourceDate, _value4(_value36.at), _value38(_argument18.teacher), _argument18.period, _argument18.url])],
      _value39 = new Blob(["\uFEFF" + _items2.map(_argument19 => _argument19.map(_value37).join(",")).join("\r\n")], {
        "type": "text/csv;charset=utf-8"
      }),
      _value40 = URL.createObjectURL(_value39),
      _value41 = document.createElement("a");
    _value41.href = _value40, _value41.download = "Mirsad-links-" + _value36.date + "-" + _value36.id + ".csv", _value41.click(), setTimeout(() => URL.revokeObjectURL(_value40), 1000);
  }, _value24()["catch"](() => {
    _value("summary").textContent = "\u062A\u0639\u0630\u0631 \u0642\u0631\u0627\u0621\u0629 \u0633\u062C\u0644 \u0627\u0644\u0641\u062D\u0635 \u0627\u0644\u0645\u062D\u0641\u0648\u0638";
  });
})();