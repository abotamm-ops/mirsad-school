"use strict";

(() => {
  const _value = document.createElement("section");
  _value.className = "settings", _value.style.margin = "8px", _value.innerHTML = "<h3>\u062D\u0633\u0627\u0628 \u0627\u0644\u0645\u062F\u0631\u0633\u0629</h3><p id=\"commercial-binding-status\" role=\"status\"></p><form id=\"school-login\"><label for=\"school-email\">\u0625\u064A\u0645\u064A\u0644 \u0627\u0644\u0645\u062F\u0631\u0633\u0629</label><input id=\"school-email\" type=\"email\" autocomplete=\"username\" required><label for=\"school-password\">\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631</label><input id=\"school-password\" type=\"password\" autocomplete=\"current-password\" required><p class=\"commercial-password-help\" style=\"font-size:12px;line-height:1.8;color:#536f80\">\u0627\u0643\u062A\u0628 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u0623\u0648 \u0627\u0646\u0633\u062E\u0647\u0627 \u0643\u0627\u0645\u0644\u0629 \u0645\u0646 \u0623\u0648\u0644 \u062D\u0631\u0641 \u0625\u0644\u0649 \u0622\u062E\u0631 \u062D\u0631\u0641\u060C \u062F\u0648\u0646 \u0632\u064A\u0627\u062F\u0629 \u0623\u0648 \u0646\u0642\u0635\u060C \u0648\u062A\u0623\u0643\u062F \u0645\u0646 \u0639\u062F\u0645 \u0648\u062C\u0648\u062F \u0645\u0633\u0627\u0641\u0627\u062A \u0632\u0627\u0626\u062F\u0629 \u0642\u0628\u0644\u0647\u0627 \u0623\u0648 \u0628\u0639\u062F\u0647\u0627.</p><button type=\"submit\">\u062F\u062E\u0648\u0644 \u0627\u0644\u0625\u0636\u0627\u0641\u0629</button></form><button id=\"school-logout\" type=\"button\" hidden>\u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062E\u0631\u0648\u062C \u0645\u0646 \u0627\u0644\u0625\u0636\u0627\u0641\u0629</button><p class=\"commercial-session-note\" style=\"font-size:12px;line-height:1.8;color:#536f80\">\u0644\u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0627\u0644\u0625\u0636\u0627\u0641\u0629 \u0639\u0644\u0649 \u062C\u0647\u0627\u0632 \u0622\u062E\u0631\u060C \u0633\u062C\u0651\u0644 \u0627\u0644\u062E\u0631\u0648\u062C \u0645\u0646 \u0627\u0644\u062D\u0633\u0627\u0628 \u0641\u064A \u0625\u0636\u0627\u0641\u0629 \u0627\u0644\u062C\u0647\u0627\u0632 \u0627\u0644\u0623\u0648\u0644\u060C \u062B\u0645 \u0627\u062F\u062E\u0644 \u0641\u064A \u0627\u0644\u062C\u0647\u0627\u0632 \u0627\u0644\u0622\u062E\u0631. \u062E\u062F\u0645\u0629 \u0631\u0627\u0635\u062F \u062A\u0642\u0628\u0644 \u0627\u0644\u0631\u0635\u062F \u0645\u0646 \u062C\u0644\u0633\u0629 \u0625\u0636\u0627\u0641\u0629 \u0648\u0627\u062D\u062F\u0629 \u0641\u0642\u0637\u061B \u0627\u0644\u0645\u0648\u0642\u0639 \u0645\u062A\u0627\u062D \u0644\u0644\u062C\u0645\u064A\u0639 \u0644\u0644\u0645\u062A\u0627\u0628\u0639\u0629 \u0648\u0627\u0644\u062A\u0639\u062F\u064A\u0644.</p><p id=\"school-login-feedback\" role=\"status\"></p>", document.querySelector("header").after(_value);
  const _value2 = _argument => document.getElementById(_argument);
  let _value3 = false;
  async function _value4() {
    const _value5 = await chrome.storage.local.get(["mirsadDriveConfig", "mirsadCommercialSchool"]),
      _value6 = !!_value5.mirsadDriveConfig?.["key"] && !!_value5.mirsadCommercialSchool?.["id"];
    _value2("commercial-binding-status").textContent = _value6 ? "\u0645\u0633\u062C\u0651\u0644 \u0628\u0627\u0633\u0645: " + (_value5.mirsadCommercialSchool.profile?.["school"] || _value5.mirsadCommercialSchool.email) : "\u0633\u062C\u0651\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0645\u0631\u0629 \u0648\u0627\u062D\u062F\u0629\u061B \u062A\u0628\u0642\u0649 \u062C\u0644\u0633\u062A\u0643 \u0645\u062D\u0641\u0648\u0638\u0629 \u0628\u0639\u062F \u0625\u063A\u0644\u0627\u0642 \u0627\u0644\u062C\u0647\u0627\u0632.", document.querySelector("main").hidden = !_value6, _value2("school-login").hidden = _value6, _value2("school-logout").hidden = !_value6;
  }
  _value2("school-login").onsubmit = async _argument2 => {
    _argument2.preventDefault();
    if (_value3) return;
    _value3 = true, _argument2.submitter.disabled = true, _value2("school-login-feedback").textContent = "\u062C\u0627\u0631\u064D \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644\u2026";
    try {
      const _value7 = await chrome.runtime.sendMessage({
        "type": "MIRSAD_SCHOOL_LOGIN",
        "email": _value2("school-email").value,
        "password": _value2("school-password").value
      });
      if (!_value7?.["ok"]) throw new Error(_value7?.["error"] || "\u062A\u0639\u0630\u0631 \u0627\u0644\u062F\u062E\u0648\u0644");
      _value2("school-password").value = "", _value2("school-login-feedback").textContent = "\u062A\u0645 \u0627\u0644\u062F\u062E\u0648\u0644. \u062D\u0645\u0651\u0644 \u0627\u0644\u062C\u062F\u0648\u0644 \u0623\u0648 \u062A\u0627\u0628\u0639 \u0645\u0646 \u0645\u0648\u0636\u0639 \u0627\u0644\u0631\u0635\u062F \u0627\u0644\u0645\u062D\u0641\u0648\u0638.", await _value4();
    } catch (_value8) {
      _value2("school-login-feedback").textContent = _value8.message;
    } finally {
      _value3 = false, _argument2.submitter.disabled = false;
    }
  }, _value2("school-logout").onclick = async () => {
    if (_value3) return;
    _value3 = true, _value2("school-logout").disabled = true, _value2("school-login-feedback").textContent = "\u062C\u0627\u0631\u064D \u062D\u0641\u0638 \u0627\u0644\u062A\u0642\u062F\u0645 \u0648\u0631\u0641\u0639 \u0627\u0644\u0646\u062A\u0627\u0626\u062C \u062B\u0645 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062E\u0631\u0648\u062C\u2026";
    try {
      const _value9 = await chrome.runtime.sendMessage({
        "type": "MIRSAD_SCHOOL_LOGOUT"
      });
      if (!_value9?.["ok"]) throw new Error(_value9?.["error"] || "\u062A\u0639\u0630\u0631 \u0627\u0644\u062E\u0631\u0648\u062C");
      _value2("school-login-feedback").textContent = _value9.warning || "\u062A\u0645 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062E\u0631\u0648\u062C. \u064A\u0645\u0643\u0646\u0643 \u062A\u0634\u063A\u064A\u0644 \u0627\u0644\u0625\u0636\u0627\u0641\u0629 \u0641\u064A \u062C\u0647\u0627\u0632 \u0622\u062E\u0631.", await _value4();
    } catch (_value0) {
      _value2("school-login-feedback").textContent = _value0.message;
    } finally {
      _value3 = false, _value2("school-logout").disabled = false;
    }
  }, void _value4(), chrome.storage.onChanged.addListener(() => void _value4());
})();