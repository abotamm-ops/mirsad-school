"use strict";

(() => {
  if (location.origin !== "https://mirsad-school.onrender.com" || location.pathname !== "/schools/school-settings.html") return;
  async function _value(_argument) {
    if (_argument.source !== window || _argument.origin !== location.origin || _argument.data?.["source"] !== "mirsad-schools-page" || !["enroll", "binding"].includes(_argument.data.type)) return;
    const _value2 = _argument.data;
    try {
      const _value3 = await chrome.runtime.sendMessage({
        "type": _value2.type === "enroll" ? "MIRSAD_COMMERCIAL_ENROLL" : "MIRSAD_COMMERCIAL_BINDING",
        "endpoint": _value2.endpoint,
        "adminKey": _value2.adminKey,
        "schoolId": _value2.schoolId
      });
      window.postMessage({
        "source": "mirsad-schools-extension",
        "requestId": _value2.requestId,
        "ok": !!_value3?.["ok"],
        "configured": _value3?.["configured"],
        "schoolId": _value3?.["schoolId"],
        "schoolName": _value3?.["schoolName"],
        "version": _value3?.["version"],
        "error": _value3?.["error"]
      }, location.origin);
    } catch (_value4) {
      const _value5 = /extension context invalidated/i.test(String(_value4?.["message"] || _value4));
      if (_value5) window.removeEventListener("message", _value);
      window.postMessage({
        "source": "mirsad-schools-extension",
        "requestId": _value2.requestId,
        "ok": false,
        "error": _value5 ? "\u062A\u062D\u062F\u0651\u062B\u062A \u0627\u0644\u0625\u0636\u0627\u0641\u0629 \u0623\u062B\u0646\u0627\u0621 \u0641\u062A\u062D \u0627\u0644\u0635\u0641\u062D\u0629\u061B \u062D\u062F\u0651\u062B \u0635\u0641\u062D\u0629 \u0625\u0639\u062F\u0627\u062F\u0627\u062A \u0627\u0644\u0645\u062F\u0631\u0633\u0629 \u0644\u0644\u0627\u062A\u0635\u0627\u0644 \u0628\u0627\u0644\u0646\u0633\u062E\u0629 \u0627\u0644\u062C\u062F\u064A\u062F\u0629." : "\u062A\u0639\u0630\u0631 \u0627\u0644\u0627\u062A\u0635\u0627\u0644 \u0628\u0627\u0644\u0625\u0636\u0627\u0641\u0629\u061B \u0623\u0639\u062F \u062A\u062D\u0645\u064A\u0644 \u0627\u0644\u0625\u0636\u0627\u0641\u0629 \u062B\u0645 \u062D\u062F\u0651\u062B \u0635\u0641\u062D\u0629 \u0627\u0644\u0645\u062F\u0631\u0633\u0629"
      }, location.origin);
    }
  }
  window.addEventListener("message", _value);
})();