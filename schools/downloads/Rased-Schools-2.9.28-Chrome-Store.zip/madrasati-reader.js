"use strict";

(() => {
  if (globalThis.__mirsadMadrasatiReader) return;
  globalThis.__mirsadMadrasatiReader = true;
  const _text = "https://schools.madrasati.sa",
    _value = _argument => String(_argument || "").replace(/\s+/g, " ").trim(),
    _value2 = _argument2 => String(_argument2).replace(/[٠-٩]/g, _argument3 => String("\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669".indexOf(_argument3))),
    _value3 = (_argument4, _argument5) => {
      try {
        const _value4 = new URL(_argument4, _text);
        return _value4.origin === _text && _argument5.test(_value4.pathname) ? _value4.href : null;
      } catch {
        return null;
      }
    },
    _items = ["\u064A\u0646\u0627\u064A\u0631", "\u0641\u0628\u0631\u0627\u064A\u0631", "\u0645\u0627\u0631\u0633", "\u0623\u0628\u0631\u064A\u0644", "\u0645\u0627\u064A\u0648", "\u064A\u0648\u0646\u064A\u0648", "\u064A\u0648\u0644\u064A\u0648", "\u0623\u063A\u0633\u0637\u0633", "\u0633\u0628\u062A\u0645\u0628\u0631", "\u0623\u0643\u062A\u0648\u0628\u0631", "\u0646\u0648\u0641\u0645\u0628\u0631", "\u062F\u064A\u0633\u0645\u0628\u0631"];
  function _value5(_argument6 = document) {
    const _value6 = _value2(_value(_argument6.querySelector("#dategeo")?.["textContent"])),
      _value7 = /^(\d{1,2})\s+(\S+)\s+(\d{4})$/.exec(_value6);
    if (!_value7) throw new Error("\u062A\u0639\u0630\u0631 \u0642\u0631\u0627\u0621\u0629 \u062A\u0627\u0631\u064A\u062E \u0623\u0633\u0628\u0648\u0639 \u0645\u062F\u0631\u0633\u062A\u064A");
    const _value8 = _items.findIndex(_argument7 => _argument7.replace(/[أإآ]/g, "\u0627") === _value7[2].replace(/[أإآ]/g, "\u0627"));
    if (_value8 < 0) throw new Error("\u0634\u0647\u0631 \u0627\u0644\u062C\u062F\u0648\u0644 \u063A\u064A\u0631 \u0645\u0639\u0631\u0648\u0641");
    const _value9 = new Date(Date.UTC(+_value7[3], _value8, +_value7[1])),
      _value0 = Number(_argument6.querySelector(".dayIcon:has(a.active)")?.["getAttribute"]("dayindex"));
    if (!Number.isInteger(_value0) || _value0 < 0 || _value0 > 6) throw new Error("\u062A\u0639\u0630\u0631 \u062A\u062D\u062F\u064A\u062F \u064A\u0648\u0645 \u0627\u0644\u062C\u062F\u0648\u0644 \u0627\u0644\u0645\u062E\u062A\u0627\u0631");
    if (_value9.getUTCDay() === 0) _value9.setUTCDate(_value9.getUTCDate() + _value0);else {
      if (_value9.getUTCDay() !== _value0) throw new Error("\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u062C\u062F\u0648\u0644 \u0644\u0627 \u064A\u0637\u0627\u0628\u0642 \u0627\u0644\u064A\u0648\u0645 \u0627\u0644\u0645\u062E\u062A\u0627\u0631");
    }
    return _value9.toISOString().slice(0, 10);
  }
  function _value1(_argument8 = document) {
    const _value10 = [..._argument8.querySelectorAll("a[href]")].filter(_argument9 => _value3(_argument9.getAttribute("href"), /^\/SchoolManagment\/Lessons\/TimeTable\/[A-Fa-f0-9]+\/?$/)),
      _value11 = new Set(),
      _items2 = [];
    for (const _value12 of _value10) {
      const _value13 = _value3(_value12.getAttribute("href"), /^\/SchoolManagment\/Lessons\/TimeTable\/[A-Fa-f0-9]+\/?$/),
        _value14 = _value12.closest(".card"),
        _value15 = _value(_value14?.["querySelector"]("h5")?.["textContent"]),
        _value16 = new URL(_value13).pathname.split("/").filter(Boolean).pop();
      if (!_value15) throw new Error("\u062A\u0639\u0630\u0631 \u0631\u0628\u0637 \u062C\u062F\u0648\u0644 \u0628\u0627\u0633\u0645 \u0627\u0644\u0645\u0639\u0644\u0645");
      if (_value11.has(_value16)) continue;
      _value11.add(_value16), _items2.push({
        "id": _value16,
        "name": _value15,
        "url": _value13
      });
    }
    if (!_items2.length) throw new Error("\u0627\u0641\u062A\u062D \u0625\u062F\u0627\u0631\u0629 \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0645\u0639\u0644\u0645\u064A\u0646 \u0641\u064A \u0645\u062F\u0631\u0633\u062A\u064A \u062D\u062A\u0649 \u062A\u0638\u0647\u0631 \u0628\u0637\u0627\u0642\u0627\u062A \u0627\u0644\u0645\u0639\u0644\u0645\u064A\u0646");
    if (_argument8.querySelector(".pagination .next:not(.disabled) a[href],.pagination [aria-label=\"Next\"]:not([aria-disabled=\"true\"])")) throw new Error("\u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0645\u0639\u0644\u0645\u064A\u0646 \u0645\u0648\u0632\u0639\u0629 \u0639\u0644\u0649 \u0635\u0641\u062D\u0627\u062A\u061B \u0627\u0639\u0631\u0636 \u0627\u0644\u0642\u0627\u0626\u0645\u0629 \u0643\u0627\u0645\u0644\u0629 \u0642\u0628\u0644 \u0627\u0644\u062C\u0645\u0639");
    return _items2;
  }
  function _value17(_argument0) {
    const _value18 = [..._argument0.querySelectorAll("a[href]")].map(_argument1 => MirsadScheduleCore.normalizeTeamsUrl(_argument1.getAttribute("href"))).filter(Boolean),
      _items3 = [...new Map(_value18.map(_argument10 => [MirsadScheduleCore.teamsMeetingKey(_argument10), _argument10])).values()];
    if (_items3.length > 1) throw new Error("\u0648\u062C\u062F \u0623\u0643\u062B\u0631 \u0645\u0646 \u0631\u0627\u0628\u0637 \u0627\u062C\u062A\u0645\u0627\u0639\u061B \u0644\u0645 \u064A\u064F\u062E\u062A\u064E\u0631 \u0631\u0627\u0628\u0637 \u0628\u0627\u0644\u062A\u062E\u0645\u064A\u0646");
    return _items3[0] || "";
  }
  function _value19(_argument11 = document) {
    const _value20 = _value5(_argument11),
      _items4 = [..._argument11.querySelectorAll("#divDayLectures tr[id^=\"hessaNumber\"]")],
      _items5 = [];
    if (!_argument11.querySelector("#divDayLectures")) throw new Error("\u0644\u0645 \u064A\u0638\u0647\u0631 \u062C\u062F\u0648\u0644 \u0627\u0644\u062D\u0635\u0635\u061B \u062A\u062D\u0642\u0642 \u0645\u0646 \u062C\u0644\u0633\u0629 \u0645\u062F\u0631\u0633\u062A\u064A");
    for (const _value21 of _items4) {
      const _value22 = Number(_value21.id.replace("hessaNumber", ""));
      if (!Number.isInteger(_value22) || _value22 < 1 || _value22 > 7) throw new Error("\u0631\u0642\u0645 \u062D\u0635\u0629 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D");
      const _value23 = _value21.querySelector(".event-title"),
        _value24 = _value(_value23?.["querySelector"]("h6")?.["textContent"]);
      if (!_value24) {
        if (!_value(_value23?.["textContent"]) || /لا توجد (حصة|دروس)|لا يوجد درس/.test(_value(_value23?.["textContent"]))) continue;
        throw new Error("\u062D\u0635\u0629 \u063A\u064A\u0631 \u0645\u0642\u0631\u0648\u0621\u0629\u061B \u0644\u0645 \u064A\u064F\u0631\u0633\u0644 \u062C\u062F\u0648\u0644 \u0646\u0627\u0642\u0635");
      }
      const _value25 = [..._value23.querySelectorAll("a[href]")].map(_argument12 => _value3(_argument12.getAttribute("href"), /^\/Teacher\/Lessons\/viewLectureDetails\/?$/i)).filter(Boolean);
      if (_value25.length > 1) throw new Error("\u064A\u0648\u062C\u062F \u0623\u0643\u062B\u0631 \u0645\u0646 \u062F\u0631\u0633 \u0644\u0644\u062D\u0635\u0629 \u0646\u0641\u0633\u0647\u0627\u061B \u064A\u0644\u0632\u0645 \u0645\u0631\u0627\u062C\u0639\u0629 \u0627\u0644\u0631\u0628\u0637");
      const _value26 = _value(_value23.querySelector(".text-black-2")?.["textContent"]),
        _value27 = _value(_value23.querySelector(".fs-sm.text-body")?.["textContent"]);
      if (!_value26 || !_value27) throw new Error("\u0628\u064A\u0627\u0646\u0627\u062A \u0648\u0642\u062A \u0627\u0644\u062D\u0635\u0629 \u0623\u0648 \u0627\u0644\u0641\u0635\u0644 \u0646\u0627\u0642\u0635\u0629");
      const _value28 = _value17(_value23),
        _value29 = /لم يتم (?:إعداد|اعداد|تحضير)|غير معد/.test(_value(_value23.textContent)),
        _value30 = _argument11.readyState === "complete" && !_argument11.querySelector("[aria-busy=\"true\"],#divDayLectures .loading"),
        _value31 = [..._value23.querySelectorAll("a[href]")].some(_argument13 => /viewLectureDetails/i.test(_argument13.getAttribute("href") || ""));
      if (!_value25.length && (!_value30 || _value31)) throw Object.assign(new Error("\u0627\u0644\u062D\u0635\u0629 " + _value22 + " \xB7 " + (!_value30 ? "\u062C\u062F\u0648\u0644 \u0645\u062F\u0631\u0633\u062A\u064A \u0644\u0645 \u064A\u0643\u062A\u0645\u0644 \u062A\u062D\u0645\u064A\u0644\u0647" : "\u0631\u0627\u0628\u0637 \u062A\u0641\u0627\u0635\u064A\u0644 \u0627\u0644\u062D\u0635\u0629 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D\u061B \u064A\u0644\u0632\u0645 \u0645\u0631\u0627\u062C\u0639\u062A\u0647")), {
        "retryable": !_value30
      });
      const _value32 = !_value28 && !_value25.length && !_value29;
      _items5.push({
        "period": _value22,
        "title": _value24,
        "lesson": _value27,
        "time": _value26,
        "teams": _value28,
        "linkSource": _value28 ? "row-direct" : "",
        "detailUrl": _value25[0] || "",
        "unprepared": !_value28 && (_value29 || _value32),
        "missingDetails": _value32
      });
    }
    return {
      "date": _value20,
      "lessons": _items5
    };
  }
  function _value33(_argument14 = document) {
    const _value34 = _value17(_argument14);
    if (_value34) return _value34;
    const _value35 = _argument14.readyState === "complete" && [..._argument14.querySelectorAll(".titlesection2")].some(_argument15 => _value(_argument15.textContent) === "\u062A\u0643\u0644\u064A\u0641\u0627\u062A \u0627\u0644\u062D\u0635\u0629") && !_argument14.querySelector("[aria-busy=\"true\"],#divDayLectures .loading"),
      _value36 = [..._argument14.querySelectorAll("a[href]")].some(_argument16 => {
        try {
          return /(^|\.)teams\.(microsoft\.com|live\.com)$/.test(new URL(_argument16.getAttribute("href"), _text).hostname);
        } catch {
          return false;
        }
      });
    if (_value35 && !_value36) return "";
    throw Object.assign(new Error(_value36 ? "\u0631\u0627\u0628\u0637 \u062A\u064A\u0645\u0632 \u0641\u064A \u0627\u0644\u062F\u0631\u0633 \u063A\u064A\u0631 \u0645\u0639\u062A\u0645\u062F\u061B \u064A\u0644\u0632\u0645 \u0645\u0631\u0627\u062C\u0639\u062A\u0647" : "\u062A\u0641\u0627\u0635\u064A\u0644 \u0627\u0644\u062F\u0631\u0633 \u0644\u0645 \u062A\u0643\u062A\u0645\u0644 \u0628\u0639\u062F"), {
      "retryable": !_value36
    });
  }
  async function _value37(_argument17) {
    if (!Array.isArray(_argument17) || _argument17.length > 7) throw new Error("\u0639\u062F\u062F \u0631\u0648\u0627\u0628\u0637 \u0627\u0644\u062D\u0635\u0635 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D");
    const _items6 = [...new Set(_argument17)];
    if (_items6.some(_argument18 => typeof _argument18 !== "string" || !_value3(_argument18, /^\/Teacher\/Lessons\/viewLectureDetails\/?$/i))) throw new Error("\u0631\u0627\u0628\u0637 \u062A\u0641\u0627\u0635\u064A\u0644 \u062E\u0627\u0631\u062C \u0645\u062F\u0631\u0633\u062A\u064A");
    const _value38 = new Array(_items6.length);
    let _number = 0;
    return await Promise.all(Array.from({
      "length": Math.min(4, _items6.length)
    }, async () => {
      while (_number < _items6.length) {
        const _value39 = _number++,
          _value40 = _items6[_value39];
        try {
          const _value41 = await fetch(_value40, {
            "method": "GET",
            "credentials": "same-origin",
            "redirect": "error",
            "cache": "no-store",
            "signal": AbortSignal.timeout(20000)
          });
          if (!_value41.ok) throw new Error("\u062A\u0639\u0630\u0631 \u062A\u062D\u0645\u064A\u0644 \u062A\u0641\u0627\u0635\u064A\u0644 \u0627\u0644\u062F\u0631\u0633 (" + _value41.status + ")");
          if (!_value3(_value41.url, /^\/Teacher\/Lessons\/viewLectureDetails\/?$/i)) throw new Error("\u0627\u0646\u062A\u0647\u062A \u062C\u0644\u0633\u0629 \u0645\u062F\u0631\u0633\u062A\u064A\u061B \u0633\u062C\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0645\u062C\u062F\u062F\u064B\u0627");
          const _value42 = await _value41.text();
          if (_value42.length > 4000000) throw new Error("\u062D\u062C\u0645 \u0635\u0641\u062D\u0629 \u0627\u0644\u062F\u0631\u0633 \u063A\u064A\u0631 \u0645\u062A\u0648\u0642\u0639");
          const _value43 = new DOMParser().parseFromString(_value42, "text/html"),
            _value44 = _value33(_value43);
          _value38[_value39] = {
            "detailUrl": _value40,
            "ok": true,
            "url": _value44,
            "unprepared": !_value44
          };
        } catch (_value45) {
          _value38[_value39] = {
            "detailUrl": _value40,
            "ok": false,
            "error": _value45.message,
            "retryable": !!_value45.retryable
          };
        }
      }
    })), _value38;
  }
  function _value46(_argument19) {
    const _value47 = _value2(_value(_argument19));
    if (/^\d{4}-\d{2}-\d{2}$/.test(_value47) && _value48(_value47)) return _value47;
    const _value49 = /^(\d{1,2})\s+(\S+)\s+(\d{4})$/.exec(_value47);
    if (!_value49) return "";
    const _value50 = _items.findIndex(_argument20 => _argument20.replace(/[أإآ]/g, "\u0627") === _value49[2].replace(/[أإآ]/g, "\u0627")),
      _value51 = _value49[3] + "-" + String(_value50 + 1).padStart(2, "0") + "-" + _value49[1].padStart(2, "0");
    return _value50 >= 0 && _value48(_value51) ? _value51 : "";
  }
  async function _value52(_argument21) {
    if (!_argument21.lessons.length) return _argument21;
    const _value53 = new URL(location.href),
      _value54 = _value53.pathname.split("/").filter(Boolean).pop(),
      _value55 = [..._value53.searchParams].find(([_argument22]) => _argument22.toLowerCase() === "schoolid")?.[1],
      _value56 = document.querySelector("#_hndSchoolId")?.["value"],
      _value57 = document.querySelector("#_hndTeacherId")?.["value"];
    if (!/^[a-f0-9]{32}$/i.test(_value54 || "") || !/^[a-f0-9]{32}$/i.test(_value55 || "") || _value56 && _value56.toLowerCase() !== _value55.toLowerCase() || _value57 && _value57.toLowerCase() !== _value54.toLowerCase()) throw new Error("\u0647\u0648\u064A\u0629 \u0627\u0644\u0645\u062F\u0631\u0633\u0629 \u0623\u0648 \u0627\u0644\u0645\u0639\u0644\u0645 \u0641\u064A \u062C\u062F\u0648\u0644 \u0645\u062F\u0631\u0633\u062A\u064A \u063A\u064A\u0631 \u0645\u0637\u0627\u0628\u0642\u0629");
    if (_value5() !== _argument21.date) throw new Error("\u062A\u063A\u064A\u0631 \u062A\u0627\u0631\u064A\u062E \u0627\u0644\u062C\u062F\u0648\u0644 \u0642\u0628\u0644 \u062C\u0644\u0628 \u0631\u0648\u0627\u0628\u0637 \u0627\u0644\u062D\u0635\u0635");
    const _value58 = document.querySelector("#_hndCurrentDate")?.["value"],
      _value59 = document.querySelector(".dayIcon:has(a.active)")?.["getAttribute"]("dayindex"),
      _value60 = document.querySelector("#csrfid")?.["value"];
    if (!_value58 || !_value60 || !/^\d$/.test(_value59 || "") || Number(_value59) !== new Date(_argument21.date + "T12:00:00Z").getUTCDay()) throw new Error("\u0644\u0645 \u062A\u0643\u062A\u0645\u0644 \u0628\u064A\u0627\u0646\u0627\u062A \u0637\u0644\u0628 \u0631\u0648\u0627\u0628\u0637 \u0645\u062F\u0631\u0633\u062A\u064A\u061B \u062D\u062F\u0651\u062B \u0635\u0641\u062D\u0629 \u0627\u0644\u062C\u062F\u0648\u0644 \u062B\u0645 \u0623\u0639\u062F \u0627\u0644\u062A\u062D\u0645\u064A\u0644");
    const _value61 = new URLSearchParams({
        "Date": _value58,
        "index": _value59,
        "SchoolId": _value55,
        "TechearId": _value54
      }),
      _value62 = await fetch(_text + "/SchoolManagment/Lessons/GetCal", {
        "method": "POST",
        "credentials": "same-origin",
        "redirect": "error",
        "cache": "no-store",
        "headers": {
          "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
          "X-Requested-With": "XMLHttpRequest",
          "requestverificationtoken": _value60
        },
        "body": _value61.toString(),
        "signal": AbortSignal.timeout(20000)
      });
    if (!_value62.ok) throw new Error("\u062A\u0639\u0630\u0631 \u062C\u0644\u0628 \u0631\u0648\u0627\u0628\u0637 \u0645\u062F\u0631\u0633\u062A\u064A \u0645\u0646 GetCal (" + _value62.status + ")\u061B \u0644\u0645 \u064A\u064F\u0633\u062A\u0628\u062F\u0644 \u0627\u0644\u062C\u062F\u0648\u0644");
    if (!_value3(_value62.url, /^\/SchoolManagment\/Lessons\/GetCal\/?$/i)) throw new Error("\u0627\u0646\u062A\u0647\u062A \u062C\u0644\u0633\u0629 \u0645\u062F\u0631\u0633\u062A\u064A \u0623\u062B\u0646\u0627\u0621 \u062C\u0644\u0628 \u0627\u0644\u0631\u0648\u0627\u0628\u0637\u061B \u0633\u062C\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0645\u062C\u062F\u062F\u064B\u0627");
    let _value63;
    try {
      _value63 = await _value62.json();
    } catch {
      throw new Error("\u0631\u062F \u0631\u0648\u0627\u0628\u0637 \u0645\u062F\u0631\u0633\u062A\u064A \u0644\u064A\u0633 \u0628\u064A\u0627\u0646\u0627\u062A \u062C\u062F\u0648\u0644\u061B \u062A\u062D\u0642\u0642 \u0645\u0646 \u062C\u0644\u0633\u0629 \u0627\u0644\u062F\u062E\u0648\u0644");
    }
    if (!Array.isArray(_value63?.["TimeTable"]) || _value46(_value63.CurrentSelectedDateString) !== _argument21.date || _value5() !== _argument21.date) throw new Error("\u062A\u0627\u0631\u064A\u062E \u0628\u064A\u0627\u0646\u0627\u062A \u0631\u0648\u0627\u0628\u0637 \u0645\u062F\u0631\u0633\u062A\u064A \u0644\u0627 \u064A\u0637\u0627\u0628\u0642 \u0627\u0644\u062C\u062F\u0648\u0644 \u0627\u0644\u0645\u062E\u062A\u0627\u0631\u061B \u0644\u0645 \u064A\u064F\u0631\u0633\u0644 \u062C\u062F\u0648\u0644 \u0645\u062E\u062A\u0644\u0641");
    const _value64 = new Map();
    for (const _value65 of _value63.TimeTable) {
      const _value66 = Number(_value65.SlotNumber);
      if (!Number.isInteger(_value66) || _value66 < 1 || _value66 > 7) {
        if (_value65.PresenterUrl) throw new Error("\u0631\u0642\u0645 \u062D\u0635\u0629 \u0631\u0627\u0628\u0637 \u0645\u062F\u0631\u0633\u062A\u064A \u063A\u064A\u0631 \u0635\u0627\u0644\u062D");
        continue;
      }
      if (_value64.has(_value66)) throw new Error("\u064A\u0648\u062C\u062F \u0623\u0643\u062B\u0631 \u0645\u0646 \u062F\u0631\u0633 \u0644\u0644\u062D\u0635\u0629 \u0646\u0641\u0633\u0647\u0627 \u0641\u064A \u0628\u064A\u0627\u0646\u0627\u062A \u0645\u062F\u0631\u0633\u062A\u064A");
      _value64.set(_value66, _value65);
    }
    for (const [_value67, _value68] of _value64) if (_value68.PresenterUrl && !_argument21.lessons.some(_argument23 => _argument23.period === _value67)) throw new Error("\u0631\u0648\u0627\u0628\u0637 \u0645\u062F\u0631\u0633\u062A\u064A \u0644\u0627 \u062A\u0637\u0627\u0628\u0642 \u0627\u0644\u062D\u0635\u0635 \u0627\u0644\u0638\u0627\u0647\u0631\u0629\u061B \u0623\u0639\u062F \u0627\u0644\u062A\u062D\u0645\u064A\u0644");
    const _value69 = _argument21.lessons.map(_argument24 => {
      const _value70 = _value64.get(_argument24.period);
      if (!_value70) throw new Error("\u0627\u0644\u062D\u0635\u0629 " + _argument24.period + " \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F\u0629 \u0641\u064A \u0628\u064A\u0627\u0646\u0627\u062A \u0631\u0648\u0627\u0628\u0637 \u0645\u062F\u0631\u0633\u062A\u064A");
      if (_value70.ClassRoomName && _value(_value70.ClassRoomName) !== _value(_argument24.lesson)) throw new Error("\u0641\u0635\u0644 \u0627\u0644\u062D\u0635\u0629 " + _argument24.period + " \u0644\u0627 \u064A\u0637\u0627\u0628\u0642 \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0631\u0648\u0627\u0628\u0637");
      const _value71 = _value70.SubjectName && _value(_value70.SubjectName) !== _value(_argument24.title);
      if (_value71 && !_value70.ClassRoomName) {
        if (_argument24.teams || _argument24.detailUrl) return {
          ..._argument24,
          "linkResolution": "row-fallback",
          "calendarLinkUnverified": !!_value70.PresenterUrl
        };
        throw new Error("\u0645\u0627\u062F\u0629 \u0627\u0644\u062D\u0635\u0629 " + _argument24.period + " \u062A\u062E\u062A\u0644\u0641 \u0639\u0646 \u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u062F\u0631\u0633 \u0648\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0641\u0635\u0644 \u063A\u064A\u0631 \u0645\u062A\u0627\u062D\u0629 \u0644\u0644\u062A\u062D\u0642\u0642");
      }
      const _value72 = _value70.PresenterUrl;
      if (_value72 === null || _value72 === undefined || _value72 === "") return _argument24;
      const _value73 = MirsadScheduleCore.normalizeTeamsUrl(_value72);
      if (!_value73) throw new Error("\u0631\u0627\u0628\u0637 \u062A\u064A\u0645\u0632 \u0641\u064A \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u062D\u0635\u0629 " + _argument24.period + " \u063A\u064A\u0631 \u0635\u0627\u0644\u062D");
      if (_argument24.teams && !MirsadScheduleCore.sameTeamsMeeting(_argument24.teams, _value73)) throw new Error("\u0631\u0627\u0628\u0637 \u0627\u0644\u062D\u0635\u0629 " + _argument24.period + " \u064A\u062E\u062A\u0644\u0641 \u0628\u064A\u0646 \u0627\u0644\u062C\u062F\u0648\u0644 \u0648\u0628\u064A\u0627\u0646\u0627\u062A \u0645\u062F\u0631\u0633\u062A\u064A");
      return {
        ..._argument24,
        "teams": _argument24.teams || _value73,
        "linkSource": _argument24.teams ? "row-direct" : "calendar",
        "unprepared": false,
        "missingDetails": false
      };
    });
    return {
      ..._argument21,
      "lessons": _value69
    };
  }
  function _value48(_argument25) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(_argument25)) return false;
    const _value74 = new Date(_argument25 + "T12:00:00Z");
    return Number.isFinite(_value74.getTime()) && _value74.toISOString().slice(0, 10) === _argument25;
  }
  const _value75 = _argument26 => {
    const _value76 = new Date(_argument26 + "T12:00:00Z");
    return _value76.setUTCDate(_value76.getUTCDate() - _value76.getUTCDay()), _value76.toISOString().slice(0, 10);
  };
  async function _value77(_argument27, _argument28) {
    if (!_argument27 || _argument27.disabled || _argument27.getAttribute("aria-disabled") === "true") throw new Error("\u0645\u062F\u0631\u0633\u062A\u064A \u0644\u0627 \u064A\u062A\u064A\u062D \u0627\u0644\u0627\u0646\u062A\u0642\u0627\u0644 \u0625\u0644\u0649 \u0627\u0644\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u0645\u0637\u0644\u0648\u0628");
    const _value78 = document.querySelector("#divDayLectures");
    if (!_value78) throw new Error("\u062C\u062F\u0648\u0644 \u0645\u062F\u0631\u0633\u062A\u064A \u0644\u0645 \u064A\u0643\u062A\u0645\u0644");
    let _value79 = false,
      _number2 = 0;
    const _value80 = performance.now(),
      _value81 = document.querySelector(".hijriSchedule") || _value78.parentElement,
      _value82 = new MutationObserver(() => {
        _value79 = true, _number2 = Date.now();
      });
    _value82.observe(_value81, {
      "subtree": true,
      "childList": true,
      "characterData": true
    });
    try {
      _argument27.click();
      for (let _number3 = 0; _number3 < 150; _number3++) {
        await new Promise(_argument29 => setTimeout(_argument29, 200));
        const _value83 = performance.getEntriesByType("resource").some(_argument30 => _argument30.startTime >= _value80 && ["xmlhttprequest", "fetch"].includes(_argument30.initiatorType) && /Lesson|Lecture|TimeTable/i.test(_argument30.name));
        if ((_value79 || _value83) && Date.now() - _number2 >= 600) try {
          if (_argument28() && !document.querySelector("#divDayLectures .loading")) return;
        } catch {}
      }
      throw new Error("\u0644\u0645 \u064A\u0643\u062A\u0645\u0644 \u062A\u062D\u0645\u064A\u0644 \u0627\u0644\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u0645\u0637\u0644\u0648\u0628\u061B \u0644\u0646 \u064A\u064F\u0631\u0633\u0644 \u062C\u062F\u0648\u0644 \u0645\u062E\u062A\u0644\u0641");
    } finally {
      _value82.disconnect();
    }
  }
  async function _value84(_argument31) {
    if (!_value48(_argument31)) throw new Error("\u062A\u0627\u0631\u064A\u062E \u063A\u064A\u0631 \u0635\u0627\u0644\u062D");
    const _value85 = _value75(_argument31);
    let _value86 = _value5(),
      _number4 = 0;
    while (_value75(_value86) !== _value85) {
      if (++_number4 > 260) throw new Error("\u0627\u0644\u062A\u0627\u0631\u064A\u062E \u0628\u0639\u064A\u062F\u061B \u0627\u0641\u062A\u062D \u0623\u0633\u0628\u0648\u0639\u0647 \u0641\u064A \u0645\u062F\u0631\u0633\u062A\u064A \u062B\u0645 \u0623\u0639\u062F \u0627\u0644\u0646\u0642\u0644");
      const _value87 = _value75(_value86),
        _value88 = _value87 < _value85;
      await _value77(document.querySelector(_value88 ? ".nextCalendar" : ".prevCalendar"), () => _value75(_value5()) !== _value87);
      const _value89 = _value5();
      if (_value88 ? _value75(_value89) <= _value87 : _value75(_value89) >= _value87) throw new Error("\u0623\u0633\u0628\u0648\u0639 \u0645\u062F\u0631\u0633\u062A\u064A \u0644\u0645 \u064A\u062A\u062D\u0631\u0643 \u0641\u064A \u0627\u0644\u0627\u062A\u062C\u0627\u0647 \u0627\u0644\u0645\u062A\u0648\u0642\u0639");
      _value86 = _value89;
    }
    if (_value86 !== _argument31) {
      const _value90 = new Date(_argument31 + "T12:00:00Z").getUTCDay();
      await _value77(document.querySelector(".dayIcon[dayindex=\"" + _value90 + "\"] a"), () => _value5() === _argument31);
    }
    const _value91 = _value19();
    if (_value91.date !== _argument31) throw new Error("\u0627\u0644\u062C\u062F\u0648\u0644 \u0627\u0644\u0645\u0642\u0631\u0648\u0621 \u0644\u0627 \u064A\u0637\u0627\u0628\u0642 \u0627\u0644\u062A\u0627\u0631\u064A\u062E \u0627\u0644\u0645\u062E\u062A\u0627\u0631");
    return _value91;
  }
  globalThis.MirsadMadrasatiReader = {
    "directory": _value1,
    "timetable": _value19,
    "meeting": _value33,
    "displayedDate": _value5,
    "meetingBatch": _value37,
    "calendarTimetable": _value52
  }, chrome.runtime.onMessage.addListener((_argument32, _argument33, _argument34) => {
    if (_argument32?.["type"] !== "MIRSAD_MADRASATI_READ") return;
    try {
      if (location.origin !== _text) throw new Error("\u0647\u0630\u0647 \u0644\u064A\u0633\u062A \u0635\u0641\u062D\u0629 \u0645\u062F\u0631\u0633\u062A\u064A");
      if (_argument32.kind === "directory") {
        if (!/^\/SchoolManagment\/Teachers\/?$/i.test(location.pathname)) throw new Error("\u0627\u0641\u062A\u062D \u0635\u0641\u062D\u0629 \u0625\u062F\u0627\u0631\u0629 \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0645\u0639\u0644\u0645\u064A\u0646");
        _argument34({
          "ok": true,
          "teachers": _value1(),
          "sourceUrl": location.href
        });
        return;
      }
      if (_argument32.kind === "timetable") {
        if (!/^\/SchoolManagment\/Lessons\/TimeTable\//i.test(location.pathname)) throw new Error("\u0644\u0645 \u062A\u0641\u062A\u062D \u0635\u0641\u062D\u0629 \u0627\u0644\u062C\u062F\u0648\u0644\u061B \u062A\u062D\u0642\u0642 \u0645\u0646 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644");
        return _value84(_argument32.date).then(_value52).then(_argument35 => _argument34({
          "ok": true,
          ..._argument35
        }))["catch"](_argument36 => _argument34({
          "ok": false,
          "error": _argument36.message,
          "retryable": !!_argument36.retryable
        })), true;
      }
      if (_argument32.kind === "meetings") {
        if (!/^\/SchoolManagment\/Lessons\/TimeTable\//i.test(location.pathname)) throw new Error("\u0644\u0645 \u062A\u0641\u062A\u062D \u0635\u0641\u062D\u0629 \u062C\u062F\u0648\u0644 \u0627\u0644\u0645\u0639\u0644\u0645");
        return _value37(_argument32.urls).then(_argument37 => _argument34({
          "ok": true,
          "results": _argument37
        }))["catch"](_argument38 => _argument34({
          "ok": false,
          "error": _argument38.message,
          "retryable": !!_argument38.retryable
        })), true;
      }
      if (_argument32.kind === "meeting") {
        if (!/^\/Teacher\/Lessons\/viewLectureDetails\/?$/i.test(location.pathname)) throw new Error("\u0644\u0645 \u062A\u0641\u062A\u062D \u062A\u0641\u0627\u0635\u064A\u0644 \u0627\u0644\u062F\u0631\u0633\u061B \u062A\u062D\u0642\u0642 \u0645\u0646 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644");
        const _value92 = _value33();
        _argument34({
          "ok": true,
          "url": _value92,
          "unprepared": !_value92
        });
        return;
      }
      throw new Error("\u0637\u0644\u0628 \u0642\u0631\u0627\u0621\u0629 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D");
    } catch (_value93) {
      _argument34({
        "ok": false,
        "error": _value93.message,
        "retryable": !!_value93.retryable
      });
    }
    return false;
  });
})();