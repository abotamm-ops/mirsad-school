"use strict";

(() => {
  if (window.__mirsadScheduleBridge) return;
  window.__mirsadScheduleBridge = true;
  const _value = globalThis.MirsadScheduleCore;
  if (!_value) return;
  const _value2 = _value.normalize,
    _value3 = _argument => [..._argument.querySelectorAll("tr,[role=row]")].filter(_argument2 => {
      const _items = [..._argument2.querySelectorAll("th,td,[role=columnheader]")];
      if (_items.length < 7) return false;
      return _value.mapHeaders(_items.map(_argument3 => ({
        "label": _argument3.innerText || _argument3.textContent,
        "cellIndex": Number.isInteger(_argument3.cellIndex) ? _argument3.cellIndex : [...(_argument3.parentElement?.["children"] || [])].indexOf(_argument3),
        "columnSpan": _argument3.colSpan || 1
      }))).length === 7;
    }),
    _value4 = _argument4 => {
      const _value5 = _value3(_argument4);
      for (const _value6 of _value5) {
        const _items2 = [..._value6.querySelectorAll("th,td,[role=columnheader]")],
          _value7 = _value.mapHeaders(_items2.map(_argument5 => ({
            "label": _argument5.innerText || _argument5.textContent,
            "cellIndex": Number.isInteger(_argument5.cellIndex) ? _argument5.cellIndex : [...(_argument5.parentElement?.["children"] || [])].indexOf(_argument5),
            "columnSpan": _argument5.colSpan || 1
          })));
        if (_value7.length === 7) return _value7;
      }
      return [];
    },
    _value8 = _argument6 => {
      return new Map(_value4(_argument6).map(_argument7 => [_argument7.cellIndex, _argument7.n]));
    },
    _value9 = _argument8 => {
      const _value0 = new Set(_value3(_argument8));
      return [..._argument8.querySelectorAll("tr")].filter(_argument9 => !_value0.has(_argument9) && _argument9.querySelectorAll("td,th").length >= 2);
    },
    _value1 = _argument0 => {
      const _value10 = _value3(_argument0),
        _value11 = _value10.flatMap(_argument1 => [..._argument1.querySelectorAll("th,td,[role=columnheader]")]),
        _value12 = _value11.find(_argument10 => /معلم|teacher|اسم المعلم/i.test(_value2(_argument10.innerText || _argument10.textContent)));
      if (_value12) return Number.isInteger(_value12.cellIndex) ? _value12.cellIndex : [...(_value12.parentElement?.["children"] || [])].indexOf(_value12);
      const _value13 = _value4(_argument0),
        _value14 = new Set(_value13.map(_argument11 => _argument11.cellIndex));
      return _value11.find(_argument12 => !_value14.has(_argument12.cellIndex))?.["cellIndex"] ?? 0;
    };
  function _value15(_argument13 = false) {
    const _items3 = [],
      _items4 = [...document.querySelectorAll("table")],
      _value16 = _items4.map(_argument14 => ({
        "headers": _value4(_argument14),
        "ordinalColumns": _value8(_argument14),
        "teacherColumn": _value1(_argument14)
      })),
      _value17 = _value16.find(_argument15 => _argument15.headers.length === 7 && _argument15.ordinalColumns.size === 7) || _value16.find(_argument16 => _argument16.headers.length === 7) || null;
    for (let _number = 0; _number < _items4.length; _number++) {
      const _value18 = _items4[_number],
        _value19 = _value16[_number],
        _value20 = _value19.headers.length === 7 ? _value19.headers : _value17?.["headers"] || _value19.headers,
        _value21 = _value19.ordinalColumns.size === 7 ? _value19.ordinalColumns : _value17?.["ordinalColumns"] || _value19.ordinalColumns,
        _value22 = _value19.headers.length === 7 || !_value17 ? _value19.teacherColumn : _value17.teacherColumn;
      for (const _value23 of _value9(_value18)) {
        const _items5 = [..._value23.querySelectorAll("td,th")],
          _value24 = _items5.find(_argument17 => _argument17.cellIndex === _value22) || _items5[0],
          _value25 = _value2(_value23.getAttribute("data-teacher") || _value23.querySelector(".teacher-name")?.["innerText"] || _value24?.["innerText"] || _value24?.["textContent"]);
        if (!_value25) continue;
        for (const _value26 of _items5) {
          if (_value26.cellIndex === _value22) continue;
          const _value27 = _value26.querySelector(".lesson"),
            _value28 = _value27 || _value26,
            _items6 = [..._value28.querySelectorAll("a[href]")],
            _value29 = _items6.find(_argument18 => _value.validTeamsUrl(_argument18.href || _argument18.getAttribute("href"))),
            _value30 = _value29 ? _value29.href || _value29.getAttribute("href") : "",
            _value31 = [_value26.getAttribute("data-period"), _value27?.["getAttribute"]("data-period"), _value27?.["querySelector"]("[data-period]")?.["getAttribute"]("data-period")].find(_argument19 => _argument19 != null && String(_argument19).trim() !== ""),
            _value32 = _value2(_value27?.["innerText"] || _value27?.["textContent"] || _value26.innerText || _value26.textContent),
            _value33 = /^[—–−\-↔←→↖↗↘↙⇐⇒➜➝➞➤›»]+$/u.test(_value32);
          if (!_value30 && (!_value32 || _value33 || /^(لا توجد حصة|لا يوجد درس|لا يوجد رابط تيمز|لا يوجد رابط Teams)$/i.test(_value32))) continue;
          const _value34 = Number.isInteger(_value26.cellIndex) ? _value26.cellIndex : [...(_value26.parentElement?.["children"] || [])].indexOf(_value26),
            _value35 = Math.abs(_value34 - _value22),
            _value36 = _argument13 && _value35 >= 1 && _value35 <= 7 ? _value35 : null;
          let _value37 = _value36 || (_value31 != null ? _value.resolveCellPeriod(_value20, _value34, _value31) : null) || _value.resolveCellPeriod(_value20, _value34) || _value21.get(_value34) || null;
          const _options = {
            "teacher": _value25,
            "period": _value37,
            "url": _value30,
            "hasLesson": true,
            "validPeriod": Number.isInteger(_value37),
            "label": _value32
          };
          if (!_options.validPeriod) {
            _items3.push({
              ..._options,
              "period": null,
              "cellIndex": _value34,
              "reason": "\u0627\u0644\u0645\u0639\u0644\u0645 \xAB" + _value25 + "\xBB\u060C \u0646\u0635 \u0627\u0644\u062E\u0644\u064A\u0629 \xAB" + (_value32 || "(\u0641\u0627\u0631\u063A\u0629)") + "\xBB\u060C \u0645\u0648\u0636\u0639 \u0627\u0644\u0639\u0645\u0648\u062F " + _value34 + ": \u062A\u0639\u0630\u0631 \u0631\u0628\u0637 \u0627\u0644\u062E\u0644\u064A\u0629 \u0628\u0631\u0642\u0645 \u062D\u0635\u0629."
            });
            continue;
          }
          _items3.push({
            ..._options,
            "className": _value2(_value27?.["querySelector"](".class")?.["innerText"]),
            "subject": _value2(_value27?.["querySelector"](".lesson-title")?.["innerText"])
          });
        }
      }
    }
    return _items3;
  }
  chrome.runtime.onMessage.addListener((_argument20, _argument21, _argument22) => {
    if (_argument20?.["type"] === "MIRSAD_CLASSIC_SERVICE") {
      const _value38 = String(_argument20.url || "");
      if (!/^https:\/\/script\.google\.com\/macros\/s\/[A-Za-z0-9_-]+\/exec$/.test(_value38)) return _argument22({
        "ok": false
      }), false;
      const _value39 = localStorage.getItem("mirsad-schools-api-v2") || "";
      if (_value39 !== _value38) localStorage.setItem("mirsad-schools-api-v2", _value38);
      return _argument22({
        "ok": true,
        "changed": _value39 !== _value38
      }), false;
    }
    if (_argument20?.["type"] === "MIRSAD_GET_SCHEDULE") {
      if (location.origin !== "https://mirsad-school.onrender.com" || !["/", "/index.html"].includes(location.pathname)) return _argument22({
        "ok": false,
        "items": [],
        "error": "\u0645\u0635\u062F\u0631 \u0627\u0644\u062D\u0635\u0635 \u0647\u0648 \u062C\u062F\u0648\u0644 \u0627\u0644\u0645\u0639\u0644\u0645\u064A\u0646 \u0641\u0642\u0637"
      }), false;
      if (document.documentElement.dataset.mirsadSource === "madrasati") {
        const _value40 = new Intl.DateTimeFormat("en-CA", {
          "timeZone": "Asia/Riyadh",
          "year": "numeric",
          "month": "2-digit",
          "day": "2-digit"
        }).format(new Date());
        if ((document.documentElement.dataset.mirsadImportDate || document.documentElement.dataset.mirsadSourceDate) !== _value40) return _argument22({
          "ok": false,
          "items": [],
          "error": "\u062C\u062F\u0648\u0644 \u0645\u062F\u0631\u0633\u062A\u064A \u0644\u0647\u0630\u0627 \u0627\u0644\u064A\u0648\u0645 \u0644\u0645 \u064A\u0643\u062A\u0645\u0644 \u062A\u062D\u0645\u064A\u0644\u0647"
        }), false;
      }
      return _argument22({
        "ok": true,
        "sourceType": document.documentElement.dataset.mirsadSource,
        "sourceDate": document.documentElement.dataset.mirsadSourceDate,
        "sourceImportDate": document.documentElement.dataset.mirsadImportDate,
        "sourceUploadedAt": document.documentElement.dataset.mirsadUploadedAt,
        "items": _value15(true),
        "teachers": [...document.querySelectorAll("tr[data-teacher]")].map(_argument23 => _argument23.dataset.teacher),
        "page": location.href,
        "title": document.title
      }), false;
    }
  });
})();