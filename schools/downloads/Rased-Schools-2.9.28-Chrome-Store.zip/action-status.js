"use strict";

var MirsadActionStatus = (() => {
  const _text = "mirsadAutoRun";
  let _value = Promise.resolve(),
    _value2;
  async function _value3() {
    if (!chrome.action) return;
    const _value4 = await chrome.storage.local.get(_text),
      _value5 = _value4[_text]?.["running"] === true;
    if (_value2 === _value5) return;
    const _value6 = _value5 ? "on" : "off",
      _value7 = Object.fromEntries([16, 32, 48, 128].map(_argument => [_argument, "icons/" + _value6 + "-" + _argument + ".png"]));
    await Promise.all([chrome.action.setIcon({
      "path": _value7
    }), chrome.action.setTitle({
      "title": _value5 ? "\u0631\u0627\u0635\u062F \u2014 \u0627\u0644\u0631\u0635\u062F \u064A\u0639\u0645\u0644 (\u064A\u0634\u0645\u0644 \u0627\u0646\u062A\u0638\u0627\u0631 \u0627\u0644\u062D\u0635\u0635)" : "\u0631\u0627\u0635\u062F \u2014 \u0627\u0644\u0631\u0635\u062F \u0645\u062A\u0648\u0642\u0641"
    })]), _value2 = _value5;
  }
  function _value8() {
    return _value = _value["catch"](() => {}).then(_value3)["catch"](() => {}), _value;
  }
  return chrome.storage.onChanged?.["addListener"]((_argument2, _argument3) => {
    if (_argument3 === "local" && _argument2[_text]) void _value8();
  }), chrome.runtime.onStartup?.["addListener"](() => void _value8()), chrome.runtime.onInstalled?.["addListener"](() => void _value8()), void _value8(), {
    "refresh": _value8
  };
})();