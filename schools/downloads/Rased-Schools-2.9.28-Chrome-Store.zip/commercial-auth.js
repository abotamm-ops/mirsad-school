"use strict";

(() => {
  const _text = "https://script.google.com/macros/s/AKfycbzo55pn4OanCfwNauTRtGu4Fq7B2_51UNsBQCGqTZiBMF-Sy3cJ-zKHKNE5dWzd6qH3/exec";
  let _value = false;
  const _value2 = () => {
    const _value3 = navigator.userAgent;
    return (/Edg/.test(_value3) ? "Edge" : "Chrome") + " \xB7 " + (/Windows/.test(_value3) ? "Windows" : /Mac/.test(_value3) ? "Mac" : "\u062C\u0647\u0627\u0632 \u0627\u0644\u0631\u0635\u062F");
  };
  async function _value4(_argument, _argument2 = {}) {
    const _value5 = (await chrome.storage.local.get("mirsadDriveConfig")).mirsadDriveConfig,
      _value6 = await fetch(_value5?.["url"] || _text, {
        "method": "POST",
        "headers": {
          "Content-Type": "text/plain;charset=utf-8"
        },
        "body": JSON.stringify({
          "action": _argument,
          "key": _value5?.["key"],
          ...(await MirsadCommercialAccount.identity()),
          ..._argument2
        }),
        "signal": AbortSignal.timeout(60000)
      }),
      _value7 = await _value6.json();
    if (!_value6.ok || !_value7.ok) {
      const _value8 = new Error(_value7.error || "\u062A\u0639\u0630\u0631 \u0627\u0644\u0627\u062A\u0635\u0627\u0644 \u0628\u062E\u062F\u0645\u0629 \u0631\u0627\u0635\u062F");
      _value8.code = _value7.code;
      throw _value8;
    }
    return _value7;
  }
  async function _value9(_argument3) {
    if (_value) throw new Error("\u0627\u0646\u062A\u0638\u0631 \u0627\u0643\u062A\u0645\u0627\u0644 \u0627\u0644\u0625\u062C\u0631\u0627\u0621 \u0627\u0644\u0633\u0627\u0628\u0642");
    _value = true;
    try {
      if ((await chrome.storage.local.get("mirsadDriveConfig")).mirsadDriveConfig?.["key"]) throw new Error("\u0627\u0644\u062C\u0644\u0633\u0629 \u0645\u062D\u0641\u0648\u0638\u0629\u061B \u0633\u062C\u0651\u0644 \u0627\u0644\u062E\u0631\u0648\u062C \u0642\u0628\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u062D\u0633\u0627\u0628 \u0622\u062E\u0631");
      let _value0 = await MirsadCommercialAccount.identity();
      !_value0.deviceId && (_value0 = {
        "deviceId": crypto.randomUUID(),
        "deviceSecret": [...crypto.getRandomValues(new Uint8Array(32))].map(_argument4 => _argument4.toString(16).padStart(2, "0")).join("")
      }, await chrome.storage.local.set({
        "mirsadCommercialDevice": _value0
      }));
      const _value1 = await _value4("commercialExtensionLogin", {
        "email": String(_argument3.email || "").trim(),
        "password": String(_argument3.password || ""),
        "deviceLabel": _value2()
      });
      return await chrome.storage.local.set({
        "mirsadDriveConfig": {
          "url": _text,
          "key": _value1.writerKey
        },
        "mirsadCommercialSchool": _value1.school,
        "mirsadCommercialSubscription": {
          "active": _value1.school.active,
          "expiresAt": _value1.school.expiresAt,
          "at": Date.now()
        }
      }), await _value10(_value1.handover), {
        "ok": true,
        "school": _value1.school
      };
    } finally {
      _value = false;
    }
  }
  async function _value11(_argument5, _argument6 = "") {
    return await chrome.storage.local.remove(["mirsadDriveConfig", "mirsadDriveDay", "mirsadCommercialSchool", "mirsadCommercialSubscription", "mirsadMadrasatiLastSuccess", "mirsadLoadIntent", "mirsadPendingImport"]), _argument5 && (_argument5.running = false, _argument5.paused = false, _argument5.autoResume = false, _argument5.current = null, await chrome.storage.local.set({
      "mirsadAutoRun": _argument5
    })), await setStatus(_argument6 || "\u062A\u0645 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062E\u0631\u0648\u062C \u0645\u0646 \u0627\u0644\u0625\u0636\u0627\u0641\u0629. \u064A\u0645\u0643\u0646 \u0627\u0644\u062F\u062E\u0648\u0644 \u0645\u0646 \u062C\u0647\u0627\u0632 \u0622\u062E\u0631\u061B \u0627\u0644\u0646\u062A\u0627\u0626\u062C \u0648\u0627\u0644\u062A\u0648\u0642\u064A\u062A \u0645\u062D\u0641\u0648\u0638\u0629 \u0641\u064A \u062D\u0633\u0627\u0628 \u0627\u0644\u0645\u062F\u0631\u0633\u0629."), {
      "ok": true,
      "warning": _argument6
    };
  }
  async function _value12() {
    if (_value) throw new Error("\u0627\u0646\u062A\u0638\u0631 \u0627\u0643\u062A\u0645\u0627\u0644 \u0627\u0644\u0625\u062C\u0631\u0627\u0621 \u0627\u0644\u0633\u0627\u0628\u0642");
    _value = true;
    try {
      const _value13 = await getRun();
      if (_value13?.["running"]) await pauseMonitoring();
      if (typeof evidenceCaptureQueues !== "undefined") await Promise.allSettled([...evidenceCaptureQueues.values()]);
      for (let _number = 0; _number < 100 && typeof resolvingScans !== "undefined" && resolvingScans.size; _number++) await new Promise(_argument7 => setTimeout(_argument7, 100));
      if ((await getRun())?.["running"]) await pauseMonitoring();
      const _value14 = await getRun(),
        _value15 = _value16(_value14);
      try {
        const _value17 = await MirsadCommercialAccount.verifyBinding();
        if (!_value17.configured) throw new Error("\u062A\u0639\u0630\u0631 \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u062C\u0644\u0633\u0629 \u0627\u0644\u0625\u0636\u0627\u0641\u0629\u061B \u062A\u062D\u0642\u0642 \u0645\u0646 \u0627\u0644\u0627\u062A\u0635\u0627\u0644 \u0648\u0623\u0639\u062F \u0627\u0644\u0645\u062D\u0627\u0648\u0644\u0629.");
      } catch (_value18) {
        if (!["device-revoked", "school-disabled", "invalid-session", "device-proof"].includes(_value18.code)) throw _value18;
        await CloudMonitoring.quarantinePending();
        const _value19 = await CloudMonitoring.orphanCount();
        return await _value11(_value14, _value19 ? "\u0627\u0646\u062A\u0647\u062A \u0627\u0644\u062C\u0644\u0633\u0629 \u0627\u0644\u0633\u0627\u0628\u0642\u0629. \u0628\u0642\u064A\u062A " + _value19 + " \u0645\u0644\u0641\u0627\u062A \u0623\u0648 \u0646\u062A\u0627\u0626\u062C \u0645\u062D\u0641\u0648\u0638\u0629 \u0645\u062D\u0644\u064A\u064B\u0627 \u0644\u0644\u0645\u0631\u0627\u062C\u0639\u0629\u060C \u0648\u0644\u0646 \u062A\u064F\u0631\u0633\u0644 \u0628\u0627\u0633\u0645 \u062C\u0644\u0633\u0629 \u062C\u062F\u064A\u062F\u0629." : "\u0627\u0646\u062A\u0647\u062A \u0627\u0644\u062C\u0644\u0633\u0629 \u0627\u0644\u0633\u0627\u0628\u0642\u0629\u061B \u064A\u0645\u0643\u0646\u0643 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0645\u062C\u062F\u062F\u064B\u0627.");
      }
      for (let _number2 = 0; _number2 < 40; _number2++) {
        await CloudMonitoring.flush();
        if (!(await CloudMonitoring.pendingCount())) break;
        const _value20 = (await chrome.storage.local.get("mirsadDriveStatus")).mirsadDriveStatus;
        if (_value20?.["error"]) throw new Error("\u062A\u0639\u0630\u0631 \u0631\u0641\u0639 \u0628\u0639\u0636 \u0627\u0644\u0646\u062A\u0627\u0626\u062C \u0648\u0627\u0644\u0635\u0648\u0631. \u062A\u062D\u0642\u0642 \u0645\u0646 \u0627\u0644\u0627\u062A\u0635\u0627\u0644 \u062B\u0645 \u0623\u0639\u062F \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062E\u0631\u0648\u062C\u061B \u0628\u0642\u064A\u062A \u0627\u0644\u062C\u0644\u0633\u0629 \u0648\u0627\u0644\u0645\u0644\u0641\u0627\u062A \u0645\u062D\u0641\u0648\u0638\u0629.");
        await new Promise(_argument8 => setTimeout(_argument8, 500));
      }
      if (await CloudMonitoring.pendingCount()) throw new Error("\u062A\u0648\u062C\u062F \u0646\u062A\u0627\u0626\u062C \u0623\u0648 \u0635\u0648\u0631 \u0644\u0645 \u064A\u0643\u062A\u0645\u0644 \u0631\u0641\u0639\u0647\u0627\u061B \u062A\u062D\u0642\u0642 \u0645\u0646 \u0627\u0644\u0627\u062A\u0635\u0627\u0644 \u0648\u0623\u0639\u062F \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062E\u0631\u0648\u062C \u062D\u062A\u0649 \u0644\u0627 \u062A\u0641\u0642\u062F\u0647\u0627.");
      return await _value4("commercialExtensionLogout", {
        "progress": _value15
      }), await _value11(_value14);
    } finally {
      _value = false;
    }
  }
  function _value16(_argument9) {
    return _argument9?.["period"] ? {
      "date": MirsadMonitorModel.day(),
      "scheduleRevision": _argument9.scheduleRevision,
      "period": _argument9.period,
      "cycle": _argument9.cycle,
      "index": _argument9.index || 0,
      "waitingForCycle2": !!_argument9.waitingForCycle2,
      "nextCycleAt": _argument9.nextCycleAt || _argument9.pausedNextAt || null
    } : null;
  }
  async function _value10(_argument0) {
    if (!_argument0?.["snapshot"] || _argument0.date !== MirsadMonitorModel.day()) return;
    const _value21 = _argument0.snapshot,
      _options = {
        ...DEFAULT_SCHEDULE_SETTINGS,
        ..._value21.scheduleSettings,
        "configuredRoundCount": _value21.roundCount,
        "roundCount": _value21.roundCount
      };
    await chrome.storage.local.set({
      "mirsadDriveDay": {
        "date": _argument0.date,
        "snapshot": _value21
      },
      "mirsadScheduleSettings": _options,
      "mirsadMadrasatiSelectedDate": _value21.sourceScheduleDate,
      "mirsadMadrasatiLastSuccess": {
        "date": _value21.sourceScheduleDate,
        "importedForDate": _argument0.date,
        "revision": _value21.scheduleRevision,
        "monitoringPrepared": true,
        "lessons": _value21.lessons.length,
        "teachers": _value21.teachers.length
      },
      "mirsadLoadIntent": {
        "date": _argument0.date,
        "sourceDate": _value21.sourceScheduleDate,
        "status": "verified"
      }
    }), await refreshScheduleSettings();
    const _value22 = _argument0.progress;
    if (!_value22) return;
    const _value23 = PERIODS.flatMap(_argument1 => MirsadScheduleCore.selectPeriodItems(_value21.lessons.map(_argument10 => ({
        ..._argument10,
        "teacher": _argument10.teacherName,
        "hasLesson": true,
        "validPeriod": true
      })), _argument1.n).sort((_argument11, _argument12) => _argument11.teacher.localeCompare(_argument12.teacher, "ar", {
        "sensitivity": "base",
        "numeric": true
      }))),
      _value24 = new Set((_argument0.records || []).filter(_argument13 => _argument13.period === _value22.period && _argument13.cycle === _value22.cycle).map(_argument14 => MirsadMonitorModel.normalize(_argument14.teacherName))),
      _value25 = _value23.filter(_argument15 => _argument15.period === _value22.period && !_value24.has(MirsadMonitorModel.normalize(_argument15.teacher))),
      _value26 = PERIODS.find(_argument16 => _argument16.n === _value22.period),
      _value27 = _value26 && periodBounds(_value26, new Date(), "active");
    await chrome.storage.local.set({
      "mirsadAutoRun": {
        "running": false,
        "paused": true,
        "autoResume": false,
        "pauseAutoResume": true,
        "scheduleRevision": _value21.scheduleRevision,
        "schedule": _value23,
        "periods": PERIODS,
        "period": _value22.period,
        "periodStartedAt": _value27?.["start"]?.["getTime"]() || null,
        "periodItems": _value25,
        "index": 0,
        "cycle": _value22.cycle,
        "current": null,
        "tabId": null,
        "probeTabIds": [],
        "results": [],
        "waitingForCycle2": _value22.waitingForCycle2,
        "nextCycleAt": _value22.nextCycleAt,
        "pausedNextAt": _value22.waitingForCycle2 ? _value22.nextCycleAt : null,
        "startedAt": Date.now()
      }
    }), await setStatus("\u0627\u0633\u062A\u064F\u0639\u064A\u062F \u062A\u0648\u0642\u064A\u062A \u0627\u0644\u0645\u062F\u0631\u0633\u0629 \u0648\u0645\u0648\u0636\u0639 \u0627\u0644\u0631\u0635\u062F \u0627\u0644\u0645\u062D\u0641\u0648\u0638\u061B \u0627\u0636\u063A\u0637 \u062A\u0634\u063A\u064A\u0644 \u0627\u0644\u0631\u0635\u062F \u0644\u0644\u0645\u062A\u0627\u0628\u0639\u0629 \u062F\u0648\u0646 \u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0645\u0643\u062A\u0645\u0644.");
  }
  globalThis.MirsadSchoolSession = {
    "login": _value9,
    "logout": _value12,
    "progress": _value16,
    "restore": _value10
  }, chrome.runtime.onMessage.addListener((_argument17, _argument18, _argument19) => {
    if (!["MIRSAD_SCHOOL_LOGIN", "MIRSAD_SCHOOL_LOGOUT"].includes(_argument17?.["type"])) return;
    if (_argument18.url !== chrome.runtime.getURL("popup.html")) return _argument19({
      "ok": false,
      "error": "\u0645\u0635\u062F\u0631 \u063A\u064A\u0631 \u0645\u0633\u0645\u0648\u062D"
    }), false;
    const _value28 = _argument17.type === "MIRSAD_SCHOOL_LOGIN" ? _value9(_argument17) : _value12();
    return _value28.then(_argument19)["catch"](_argument20 => _argument19({
      "ok": false,
      "error": _argument20.message,
      "code": _argument20.code
    })), true;
  });
})();