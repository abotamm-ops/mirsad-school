"use strict";

var MirsadClassicReady = (async () => {
  await chrome.alarms.create("mirsadLiveHeartbeat", {
    "periodInMinutes": 0.5
  });
})();