"use strict";

(() => {
  'use strict';

  if (window.__mirsadMonitorBridge) return;
  window.__mirsadMonitorBridge = true;
  let _value = false;
  const _value2 = (_argument, _argument2) => window.postMessage({
    "source": "mirsad-monitor-extension",
    "type": _argument,
    "payload": _argument2
  }, location.origin);
  async function _value3(_argument3, _argument4 = {}) {
    try {
      return await chrome.runtime.sendMessage({
        "type": _argument3,
        ..._argument4
      });
    } catch {
      return {
        "ok": false
      };
    }
  }
  chrome.storage.onChanged.addListener((_argument5, _argument6) => {
    if (_value && _argument6 === "local" && _argument5.mirsadActiveScan) _value2("activity", {
      "ok": true,
      "activity": _argument5.mirsadActiveScan.newValue || null
    });
  }), chrome.runtime.onMessage.addListener((_argument7, _argument8, _argument9) => {
    if (_argument7?.["type"] === "MIRSAD_CLASSIC_SERVICE") return _argument9({
      "ok": true,
      "changed": false
    }), false;
    if (_argument7?.["type"] === "MIRSAD_MONITOR_CHANGED") _value2("changed", {});
  });
  async function _value4(_argument0) {
    try {
      if (_argument0.source !== window || _argument0.origin !== location.origin || _argument0.data?.["source"] !== "mirsad-monitor-control") return;
      const _value5 = (await chrome.storage.local.get("mirsadCommercialSchool")).mirsadCommercialSchool;
      _value = !!_value5?.["id"] && _argument0.data.schoolId === _value5.id;
      if (!_value) {
        _value2("state", {
          "ok": false,
          "error": "\u0627\u0644\u0625\u0636\u0627\u0641\u0629 \u063A\u064A\u0631 \u0645\u0631\u062A\u0628\u0637\u0629 \u0628\u062D\u0633\u0627\u0628 \u0627\u0644\u0645\u062F\u0631\u0633\u0629 \u0627\u0644\u0645\u0641\u062A\u0648\u062D"
        });
        return;
      }
      const _value6 = _argument0.data;
      _value6.type === "state" && (_value2("activity", await _value3("MIRSAD_SCAN_ACTIVITY")), _value2("state", await _value3("MIRSAD_GET_LIVE_REPORT")));
      if (_value6.type === "remoteLinksUpdated") _value2("remoteLinksUpdated", await _value3("MIRSAD_REFRESH_REMOTE_LINKS"));
      if (_value6.type === "schedule") _value2("settings", await _value3("MIRSAD_DASHBOARD_SCHEDULE", {
        "settings": _value6.settings
      }));
      if (_value6.type === "rounds") _value2("settings", await _value3("MIRSAD_DASHBOARD_ROUNDS", {
        "count": _value6.count,
        "gap": _value6.gap,
        "thirdGap": _value6.thirdGap
      }));
      if (_value6.type === "purgedDay") _value2("purgedDay", await _value3("MIRSAD_PURGED_DAY", {
        "date": _value6.date,
        "requestId": _value6.requestId
      }));
    } catch (_value7) {
      if (/extension context invalidated/i.test(String(_value7?.["message"] || _value7))) _value = false, window.removeEventListener("message", _value4), _value2("state", {
        "ok": false,
        "error": "\u062A\u062D\u062F\u0651\u062B\u062A \u0627\u0644\u0625\u0636\u0627\u0641\u0629\u061B \u062D\u062F\u0651\u062B \u0635\u0641\u062D\u0629 \u0645\u0631\u0635\u0627\u062F \u0644\u0644\u0627\u062A\u0635\u0627\u0644 \u0628\u0627\u0644\u0646\u0633\u062E\u0629 \u0627\u0644\u062C\u062F\u064A\u062F\u0629"
      });else _value2("state", {
        "ok": false,
        "error": "\u062A\u0639\u0630\u0631 \u0627\u0644\u0627\u062A\u0635\u0627\u0644 \u0628\u0625\u0636\u0627\u0641\u0629 \u0627\u0644\u0645\u062F\u0631\u0633\u0629"
      });
    }
  }
  window.addEventListener("message", _value4);
})();