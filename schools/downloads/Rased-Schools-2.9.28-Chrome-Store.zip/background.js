"use strict";

importScripts("video/core.js", "video/store.js", "video/disk.js", "video/controller.js", "video/restore-controller.js");
importScripts("service-transport.js");
importScripts("tab-ownership.js");
importScripts("commercial-account.js", "restore-official.js", "schedule-core.js", "monitor-model.js", "visible-schedule.js", "drive-sync.js", "local-backup.js", "action-status.js", "scan-activity.js", "madrasati-source.js", "classic-restore.js", "device-state.js", "live-heartbeat.js");
const scheduleCore = globalThis.MirsadScheduleCore,
  KEY = "mirsadAutoRun",
  STATUS_KEY = "mirsadAutoStatus",
  NEXT_ALARM = "mirsadNextAction",
  SCAN_TIMEOUT_ALARM = "mirsadScanTimeout",
  SCHEDULE_SETTINGS_KEY = "mirsadScheduleSettings",
  SCAN_TIMEOUT_MS = 90000,
  RECONNECT_RETRY_MS = 15000,
  MAX_UNRESOLVED_RETRIES = 2,
  resolvingScans = new Set(),
  DEFAULT_SCHEDULE_SETTINGS = {
    "manualStart": "06:30",
    "periodDuration": 45,
    "manualGapMinutes": 1,
    "periodCount": 7,
    "startPeriod": 1,
    "endPeriod": 7,
    "scanDelay": 1,
    "roundCount": 3,
    "roundGapMinutes": 5,
    "thirdRoundGapMinutes": 5
  };
let scheduleSettings = {
    ...DEFAULT_SCHEDULE_SETTINGS
  },
  PERIODS = [],
  seventhPeriodPolicy = null;
function periodDisabled(_argument, _argument2) {
  return MirsadMonitorModel.isExcludedPeriod(_argument, _argument2, seventhPeriodPolicy?.["date"] === _argument ? seventhPeriodPolicy : null);
}
async function setSeventhPeriodPolicy(_argument3) {
  const _value = seventhPeriodPolicy;
  seventhPeriodPolicy = {
    "date": _argument3.date,
    "seventhPeriodEnabled": _argument3.seventhPeriodEnabled
  };
  if (!_value || _value.date !== _argument3.date) return;
  const _value2 = MirsadMonitorModel.isExcludedPeriod(_argument3.date, 7, _value),
    _value3 = periodDisabled(_argument3.date, 7);
  if (_value2 === _value3) return;
  const _value4 = await getRun();
  if (!_value4?.["running"]) return;
  if (_value3 && _value4.period === 7) {
    await closeProbeTab(_value4), _value4.current = null, _value4.waitingForCycle2 = false, _value4.nextCycleAt = null, await saveRun(_value4), await chrome.alarms.clear(SCAN_TIMEOUT_ALARM), await advancePeriod(_value4, 7);
    return;
  }
  if (!_value3 && !_value4.current && _value4.period !== 7) {
    const _value5 = PERIODS.find(_argument4 => _argument4.n === 7),
      _value6 = _value5 ? periodBounds(_value5, new Date(), "active") : null;
    if (_value6 && Date.now() >= _value6.start.getTime() && Date.now() < _value6.end.getTime()) await chrome.alarms.create(NEXT_ALARM, {
      "when": Date.now() + 1000
    });
  }
}
function clockText(_argument5) {
  return _argument5 = (_argument5 % 1440 + 1440) % 1440, String(Math.floor(_argument5 / 60)).padStart(2, "0") + ":" + String(_argument5 % 60).padStart(2, "0");
}
function parseClock(_argument6) {
  const _value7 = /^(\d{1,2}):(\d{2})$/.exec(scheduleCore.asciiDigits(_argument6 || ""));
  if (!_value7) return null;
  const _value8 = Number(_value7[1]),
    _value9 = Number(_value7[2]);
  return _value8 < 24 && _value9 < 60 ? _value8 * 60 + _value9 : null;
}
function makePeriods(_argument7) {
  if (!Array.isArray(_argument7) || _argument7.length !== 7) return [];
  const _items = [];
  let _value0 = null;
  for (let _number = 0; _number < _argument7.length; _number++) {
    const _value1 = _argument7[_number] || {};
    let _value10 = Number(_value1.startOffset),
      _value11 = Number(_value1.endOffset);
    if (!Number.isFinite(_value10) || !Number.isFinite(_value11)) return [];
    _value10 = (_value10 % 1440 + 1440) % 1440, _value11 = (_value11 % 1440 + 1440) % 1440;
    if (_value0 !== null && _value10 < _value0) _value10 += 1440;
    if (_value11 <= _value10) _value11 += 1440;
    if (_value11 - _value10 > 180) return [];
    _items.push({
      "n": _number + 1,
      "startOffset": _value10,
      "endOffset": _value11
    }), _value0 = _value10;
  }
  return _items.map(_argument8 => ({
    "n": _argument8.n,
    "startOffset": _argument8.startOffset,
    "endOffset": _argument8.endOffset,
    "start": clockText(_argument8.startOffset),
    "end": clockText(_argument8.endOffset)
  }));
}
function makeManualPeriods(_argument9, _argument0, _argument1 = 45, _argument10 = 7, _argument11 = 1) {
  return scheduleCore.makeManualPeriods(_argument9, _argument1, _argument0, _argument10, _argument11);
}
function activePeriods(_argument12) {
  return makeManualPeriods(_argument12.manualStart, _argument12.manualGapMinutes, _argument12.periodDuration, _argument12.periodCount, _argument12.scanDelay).filter(_argument13 => _argument13.n >= (_argument12.startPeriod ?? 1) && _argument13.n <= (_argument12.endPeriod ?? 7));
}
async function refreshScheduleSettings() {
  await MirsadOfficialReady;
  const _value12 = await chrome.storage.local.get([SCHEDULE_SETTINGS_KEY, "mirsadDriveDay"]),
    _value13 = _value12[SCHEDULE_SETTINGS_KEY] || {},
    _value14 = Number(_value13.scanDelay),
    _value15 = Number(_value13.periodDuration);
  scheduleSettings = {
    ...DEFAULT_SCHEDULE_SETTINGS,
    ..._value13,
    "manualStart": _value13.manualStart || DEFAULT_SCHEDULE_SETTINGS.manualStart,
    "periodDuration": Number.isInteger(_value15) && _value15 >= 1 && _value15 <= 180 ? _value15 : DEFAULT_SCHEDULE_SETTINGS.periodDuration,
    "periodCount": 7,
    "scanDelay": Number.isInteger(_value14) && _value14 >= 1 && _value14 <= 10 ? _value14 : DEFAULT_SCHEDULE_SETTINGS.scanDelay,
    "roundCount": Number.isInteger(Number(_value13.roundCount)) && Number(_value13.roundCount) >= 1 && Number(_value13.roundCount) <= 3 ? Number(_value13.roundCount) : 3,
    "thirdRoundGapMinutes": Number.isInteger(Number(_value13.thirdRoundGapMinutes)) && Number(_value13.thirdRoundGapMinutes) >= 1 && Number(_value13.thirdRoundGapMinutes) <= 10 ? Number(_value13.thirdRoundGapMinutes) : 5,
    "roundGapMinutes": Number.isInteger(Number(_value13.roundGapMinutes)) && Number(_value13.roundGapMinutes) >= 1 && Number(_value13.roundGapMinutes) <= 10 ? Number(_value13.roundGapMinutes) : 5
  };
  const _value16 = Number(_value13.configuredRoundCount ?? _value13.roundCount ?? 3);
  return scheduleSettings.configuredRoundCount = Number.isInteger(_value16) && _value16 >= 1 && _value16 <= 3 ? _value16 : 3, scheduleSettings.roundCount = scheduleSettings.configuredRoundCount, (!Number.isInteger(scheduleSettings.startPeriod) || !Number.isInteger(scheduleSettings.endPeriod) || scheduleSettings.startPeriod < 1 || scheduleSettings.endPeriod > 7 || scheduleSettings.startPeriod > scheduleSettings.endPeriod) && (scheduleSettings.startPeriod = 1, scheduleSettings.endPeriod = 7), seventhPeriodPolicy = _value12.mirsadDriveDay?.["snapshot"] || null, PERIODS = activePeriods(scheduleSettings), scheduleSettings;
}
refreshScheduleSettings()["catch"](() => {});
async function loadPeriodsFromSchedule(_argument14, _argument15) {
  const _value17 = _argument15 || scheduleSettings,
    _value18 = await chrome.tabs.sendMessage(_argument14, {
      "type": "MIRSAD_GET_SCHEDULE",
      "manualPeriodMapping": true
    }),
    _value19 = (_value18?.["items"] || []).filter(_argument16 => _argument16.teacher && _argument16.hasLesson),
    _value20 = _value19.find(_argument17 => _argument17.validPeriod === false || !Number.isInteger(_argument17.period) || _argument17.period < 1 || _argument17.period > 7);
  if (_value20) throw new Error("\u062A\u0639\u0630\u0631 \u062A\u062D\u062F\u064A\u062F \u0631\u0642\u0645 \u0627\u0644\u062D\u0635\u0629 \u0645\u0646 \u0639\u0645\u0648\u062F \u0627\u0644\u062C\u062F\u0648\u0644 \u0628\u0623\u0645\u0627\u0646\u061B \u0644\u0645 \u064A\u064F\u0641\u062A\u062D \u0623\u064A \u0631\u0627\u0628\u0637. \u0627\u0644\u062E\u0644\u064A\u0629 \u0627\u0644\u062A\u064A \u062A\u0639\u0630\u0631 \u0631\u0628\u0637\u0647\u0627: " + (_value20.reason || _value20.teacher || "\u063A\u064A\u0631 \u0645\u0639\u0631\u0648\u0641\u0629"));
  const _value21 = activePeriods(_value17);
  if (!_value21.length) throw new Error("\u0623\u062F\u062E\u0644 \u0628\u062F\u0627\u064A\u0629 \u0627\u0644\u062D\u0635\u0629 \u0627\u0644\u0623\u0648\u0644\u0649 \u0648\u0627\u0644\u0645\u062F\u0629 \u0648\u0627\u0644\u0641\u0627\u0635\u0644 \u0648\u0639\u062F\u062F \u0627\u0644\u062D\u0635\u0635 \u0648\u062A\u0623\u062E\u064A\u0631 \u0627\u0644\u0631\u0635\u062F \u0628\u0634\u0643\u0644 \u0635\u062D\u064A\u062D.");
  return scheduleSettings = {
    ...DEFAULT_SCHEDULE_SETTINGS,
    ..._value17
  }, await chrome.storage.local.set({
    [SCHEDULE_SETTINGS_KEY]: scheduleSettings
  }), PERIODS = _value21, {
    "items": _value19,
    "periods": _value21
  };
}
async function setStatus(_argument18, _argument19 = {}) {
  await chrome.storage.local.set({
    [STATUS_KEY]: {
      "text": _argument18,
      "at": Date.now(),
      ..._argument19
    }
  });
}
const RUN_CONTROL_KEY = "mirsadRunControlEpoch";
let runWriteSerial = Promise.resolve(),
  runCommandSerial = Promise.resolve();
function queueRunWrite(_argument20) {
  const _value22 = runWriteSerial["catch"](() => {}).then(_argument20);
  return runWriteSerial = _value22["catch"](() => {}), _value22;
}
function queueRunCommand(_argument21) {
  const _value23 = runCommandSerial["catch"](() => {}).then(_argument21);
  return runCommandSerial = _value23["catch"](() => {}), _value23;
}
async function getRun() {
  await MirsadOfficialReady, await MirsadClassicReady;
  const _value24 = await chrome.storage.local.get([KEY, RUN_CONTROL_KEY]);
  return _value24[KEY] ? {
    ..._value24[KEY],
    "controlEpoch": _value24[KEY].controlEpoch ?? _value24[RUN_CONTROL_KEY] ?? 0
  } : null;
}
async function saveRun(_argument22) {
  CloudMonitoring.reconcileRunLinks?.(_argument22);
  return queueRunWrite(async () => {
    const _value25 = await chrome.storage.local.get(RUN_CONTROL_KEY);
    if ((_argument22.controlEpoch ?? 0) !== (_value25[RUN_CONTROL_KEY] ?? 0)) return false;
    return await chrome.storage.local.set({
      [KEY]: _argument22
    }), void MirsadLiveSender.sync(), true;
  });
}
async function isRunCurrent(_argument23) {
  const _value26 = await getRun();
  return !!_value26?.["running"] && !_value26.paused && _value26.controlEpoch === (_argument23.controlEpoch ?? 0);
}
async function createRunAlarm(_argument24, _argument25, _argument26) {
  if (!(await isRunCurrent(_argument24))) return false;
  return await chrome.alarms.create(_argument25, _argument26), true;
}
async function commitRunControl(_argument27) {
  return queueRunWrite(async () => {
    const _value27 = await chrome.storage.local.get([KEY, RUN_CONTROL_KEY]);
    if (!_value27[KEY]) return null;
    const _options = {
      ..._value27[KEY]
    };
    return _argument27(_options), _options.controlEpoch = (_value27[RUN_CONTROL_KEY] ?? 0) + 1, await chrome.storage.local.set({
      [KEY]: _options,
      [RUN_CONTROL_KEY]: _options.controlEpoch
    }), void MirsadLiveSender.sync(), _options;
  });
}
async function pauseMonitoring() {
  return queueRunCommand(async () => {
    const _value28 = await getRun();
    if (_value28?.["paused"]) return {
      "ok": true
    };
    if (!_value28?.["running"]) return {
      "ok": false,
      "error": "\u0627\u0644\u0631\u0635\u062F \u063A\u064A\u0631 \u0645\u0634\u063A\u0651\u0644"
    };
    const _value29 = await chrome.alarms.get(NEXT_ALARM),
      _value30 = await commitRunControl(_argument28 => {
        _argument28.current && (_argument28.results || []).some(_argument29 => _argument29.scanId === _argument28.current.scanId) && (_argument28.index = (_argument28.index || 0) + 1), _argument28.paused = true, _argument28.running = false, _argument28.pauseAutoResume = _argument28.autoResume, _argument28.autoResume = false, _argument28.pausedNextAt = _value29?.["scheduledTime"] || null, _argument28.current = null, _argument28.waitingForReconnect = false;
      });
    return recoveryInProgress = null, await chrome.alarms.clear(NEXT_ALARM), await chrome.alarms.clear(SCAN_TIMEOUT_ALARM), await closeProbeTab(_value30), await setStatus("\u0627\u0644\u0631\u0635\u062F \u0645\u062A\u0648\u0642\u0641 \u0645\u0624\u0642\u062A\u064B\u0627\u061B \u0627\u0636\u063A\u0637 \u0627\u0633\u062A\u0626\u0646\u0627\u0641 \u0644\u0644\u0645\u062A\u0627\u0628\u0639\u0629 \u0645\u0646 \u0645\u0648\u0636\u0639 \u0627\u0644\u062A\u0648\u0642\u0641."), {
      "ok": true
    };
  });
}
async function resumeMonitoring() {
  return queueRunCommand(async () => {
    const _value31 = await getRun();
    if (_value31?.["running"] && !_value31.paused) return {
      "ok": true
    };
    if (!_value31?.["paused"]) return {
      "ok": false,
      "error": "\u0644\u0627 \u064A\u0648\u062C\u062F \u0631\u0635\u062F \u0645\u062A\u0648\u0642\u0641 \u0645\u0624\u0642\u062A\u064B\u0627"
    };
    if (CloudMonitoring.linksBusy?.()) throw new Error("\u0627\u0646\u062A\u0638\u0631 \u0627\u0643\u062A\u0645\u0627\u0644 \u062D\u0641\u0638 \u0631\u0627\u0628\u0637 \u0627\u0644\u062D\u0635\u0629");
    await CloudMonitoring.assertSelected(_value31);
    const _value32 = await commitRunControl(_argument30 => {
      _argument30.paused = false, _argument30.running = true, _argument30.autoResume = _argument30.pauseAutoResume !== false, _argument30.current = null, _argument30.waitingForReconnect = !_argument30.immediateMode, _argument30.pausedNextAt = null;
    });
    recoveryInProgress = null, await chrome.alarms.clear(SCAN_TIMEOUT_ALARM), await chrome.alarms.clear(NEXT_ALARM), await chrome.alarms.create(NEXT_ALARM, {
      "when": Date.now() + 1000
    }), await setStatus("\u062A\u0645 \u0627\u0633\u062A\u0626\u0646\u0627\u0641 \u0627\u0644\u0631\u0635\u062F\u061B \u064A\u0643\u0645\u0644 \u0645\u0646 \u0645\u0648\u0636\u0639 \u0627\u0644\u062A\u0648\u0642\u0641 \u0645\u0639 \u0645\u0631\u0627\u0639\u0627\u0629 \u0648\u0642\u062A \u0627\u0644\u062D\u0635\u0629.");
    await MirsadAutoLinks.beforeCycle(_value32);
    if (CloudMonitoring.pullRemoteLinks) void CloudMonitoring.pullRemoteLinks()["catch"](() => {});
    return {
      "ok": true
    };
  });
}
async function stopAndResetMonitoring() {
  return queueRunCommand(async () => {
    const _value33 = await commitRunControl(_argument31 => Object.assign(_argument31, {
      "running": false,
      "paused": false,
      "autoResume": false,
      "current": null,
      "period": null,
      "periodItems": [],
      "index": 0,
      "cycle": 1,
      "results": [],
      "waitingForCycle2": false,
      "waitingForReconnect": false,
      "nextCycleAt": null,
      "pausedNextAt": null,
      "suspendedRun": null,
      "suspendedNextAt": null
    }));
    recoveryInProgress = null, await chrome.alarms.clear(NEXT_ALARM), await chrome.alarms.clear(SCAN_TIMEOUT_ALARM);
    if (_value33) await closeProbeTab(_value33);
    return await setStatus("\u062A\u0645 \u0625\u064A\u0642\u0627\u0641 \u0627\u0644\u0631\u0635\u062F \u0648\u062A\u0635\u0641\u064A\u0631 \u062A\u0642\u062F\u0651\u0645 \u0627\u0644\u062A\u0634\u063A\u064A\u0644\u061B \u0627\u0644\u0623\u0631\u0634\u064A\u0641 \u0648\u0627\u0644\u0635\u0648\u0631 \u0645\u062D\u0641\u0648\u0638\u0629."), {
      "ok": true
    };
  });
}
let evidenceWriteSerial = Promise.resolve();
function mutateEvidenceRecords(_argument32) {
  const _value34 = evidenceWriteSerial["catch"](() => {}).then(async () => {
    const _value35 = await chrome.storage.local.get("mirsadEvidenceRecords"),
      _value36 = _argument32(_value35.mirsadEvidenceRecords || []);
    return await chrome.storage.local.set({
      "mirsadEvidenceRecords": _value36
    }), _value36;
  });
  return evidenceWriteSerial = _value34["catch"](() => {}), _value34;
}
const DAILY_REPORT_KEY = "mirsadDailyAttendanceReports";
function localDayKey(_argument33 = new Date()) {
  const _value37 = _argument33.getFullYear(),
    _value38 = String(_argument33.getMonth() + 1).padStart(2, "0"),
    _value39 = String(_argument33.getDate()).padStart(2, "0");
  return _value37 + "-" + _value38 + "-" + _value39;
}
async function appendDailyReport(_argument34) {
  const _value40 = localDayKey(new Date(_argument34.scannedAt || Date.now())),
    _value41 = await chrome.storage.local.get(DAILY_REPORT_KEY),
    _value42 = _value41[DAILY_REPORT_KEY] && typeof _value41[DAILY_REPORT_KEY] === "object" ? _value41[DAILY_REPORT_KEY] : {};
  _value42[_value40] = Array.isArray(_value42[_value40]) ? _value42[_value40] : [], _argument34.scanStatus = _argument34.scanStatus || _argument34.status || "unresolved";
  if (_argument34.scanId) {
    const _value43 = _value42[_value40].findIndex(_argument35 => _argument35.scanId === _argument34.scanId);
    if (_value43 >= 0) _value42[_value40][_value43] = _argument34;else _value42[_value40].push(_argument34);
  } else _value42[_value40].push(_argument34);
  const _value44 = _argument36 => String(_argument36.scheduledTeacher || _argument36.teacher || "") + "|" + String(_argument36.period || "") + "|" + String(_argument36.className || _argument36.url || ""),
    _value45 = new Map();
  for (const _value46 of _value42[_value40]) {
    const _value47 = _value44(_value46);
    if (!_value45.has(_value47)) _value45.set(_value47, []);
    _value45.get(_value47).push(_value46);
  }
  for (const _value48 of _value45.values()) {
    _value48.sort((_argument37, _argument38) => (_argument37.scannedAt || 0) - (_argument38.scannedAt || 0));
    const _value49 = _value48.filter(_argument39 => _argument39.scanStatus === "present" || _argument39.scanStatus === "absent"),
      _value50 = _value49.filter(_argument40 => _argument40.scanStatus === "present").length,
      _value51 = _value49.length ? Math.round(_value50 / _value49.length * 100) : 0,
      _value52 = scheduleCore.summarizeAttendanceStatuses(_value48);
    for (const _value53 of _value48) {
      _value53.attendanceStatus = _value52, _value53.attendancePercent = _value51, _value53.presentCycles = _value50, _value53.countedCycles = _value49.length, _value53.status = _value53.scanStatus === "no-link" ? "no-link" : _value53.attendanceStatus;
    }
  }
  const _value54 = Object.keys(_value42).sort();
  while (_value54.length > 45) delete _value42[_value54.shift()];
  await chrome.storage.local.set({
    [DAILY_REPORT_KEY]: _value42
  });
}
async function closeProbeTab(_argument41) {
  if (!_argument41) return;
  const _value55 = new Set([...(_argument41.probeTabIds || []), _argument41.tabId].filter(_argument42 => Number.isInteger(_argument42)));
  for (const _value56 of _value55) {
    try {
      await MirsadTabOwnership.closeProbe(_value56);
    } catch (_value57) {}
  }
  _argument41.tabId = null, _argument41.probeTabIds = [];
  if (!(await saveRun(_argument41))) return;
}
async function trackProbeTab(tab) {
  if (!Number.isInteger(tab?.id) || !Number.isInteger(tab?.openerTabId)) return;
  const run = await getRun();
  if (!run?.running || !Number.isInteger(run.tabId) || !(await MirsadTabOwnership.popup(tab, run.tabId))) return;
  run.probeTabIds = Array.isArray(run.probeTabIds) ? run.probeTabIds : [];
  if (!run.probeTabIds.includes(tab.id)) run.probeTabIds.push(tab.id);
  await saveRun(run);
}
chrome.tabs.onCreated.addListener(_argument43 => {
  trackProbeTab(_argument43)["catch"](() => {});
});
function isTeamsMeetingUrl(_argument44) {
  try {
    const _value58 = new URL(_argument44);
    return _value58.protocol === "https:" && (_value58.hostname === "teams.microsoft.com" || _value58.hostname === "teams.live.com") && _value58.pathname.length > 1;
  } catch (_value59) {
    return false;
  }
}
async function ensureProbeTab(run) {
  return MirsadWorkspace.ensureProbeTab(run);
}
function dateAtOffset(_argument45, _argument46) {
  const _value60 = new Date(_argument45);
  return _value60.setHours(0, 0, 0, 0), _value60.setMinutes(_argument46), _value60;
}
function schoolDay(_argument47) {
  return true;
}
function periodBounds(_argument48, _argument49 = new Date(), _argument50 = "activeOrNext") {
  const _items2 = [];
  for (let _value61 = -2; _value61 <= 2; _value61++) {
    const _value62 = new Date(_argument49);
    _value62.setDate(_value62.getDate() + _value61), _value62.setHours(0, 0, 0, 0);
    if (!schoolDay(_value62)) continue;
    const _value63 = dateAtOffset(_value62, _argument48.startOffset),
      _value64 = dateAtOffset(_value62, _argument48.endOffset);
    _items2.push({
      "start": _value63,
      "end": _value64,
      "anchor": _value62
    });
  }
  const _value65 = _items2.find(_argument51 => _argument49 >= _argument51.start && _argument49 < _argument51.end);
  if (_value65) return _value65;
  if (_argument50 === "future") {
    const _value66 = _items2.filter(_argument52 => _argument52.start > _argument49).sort((_argument53, _argument54) => _argument53.start - _argument54.start);
    if (_value66.length) return _value66[0];
  }
  const _value67 = _items2.filter(_argument55 => _argument55.start <= _argument49).sort((_argument56, _argument57) => _argument57.start - _argument56.start);
  if (_argument50 === "past" && _value67.length) return _value67[0];
  const _value68 = _items2.filter(_argument58 => _argument58.start > _argument49).sort((_argument59, _argument60) => _argument59.start - _argument60.start);
  if (_value68.length) return _value68[0];
  return _value67[0] || _items2[0];
}
function periodNow(_argument61 = new Date()) {
  const _items3 = [];
  for (const _value69 of PERIODS) {
    if (periodDisabled(MirsadMonitorModel.day(_argument61), _value69.n)) continue;
    const _value70 = periodBounds(_value69, _argument61, "active");
    if (_value70 && _argument61 >= _value70.start && _argument61 < _value70.end) _items3.push({
      "period": _value69,
      "bounds": _value70
    });
  }
  if (!_items3.length) return null;
  return _items3.sort((_argument62, _argument63) => _argument63.bounds.start.getTime() - _argument62.bounds.start.getTime() || _argument63.period.n - _argument62.period.n), _items3[0].period;
}
function nextPeriod(_argument64 = new Date()) {
  const _items4 = [];
  for (let _value71 = -1; _value71 <= 8; _value71++) {
    const _value72 = new Date(_argument64);
    _value72.setDate(_value72.getDate() + _value71), _value72.setHours(0, 0, 0, 0);
    if (!schoolDay(_value72)) continue;
    for (const _value73 of PERIODS) {
      const _value74 = dateAtOffset(_value72, _value73.startOffset);
      if (_value74 > _argument64 && !periodDisabled(MirsadMonitorModel.day(_value74), _value73.n)) _items4.push({
        "period": _value73,
        "when": _value74.getTime()
      });
    }
  }
  _items4.sort((_argument65, _argument66) => _argument65.when - _argument66.when);
  if (_items4.length) return _items4[0];
  const _value75 = new Date(_argument64);
  _value75.setDate(_value75.getDate() + 1);
  while (!schoolDay(_value75)) _value75.setDate(_value75.getDate() + 1);
  return {
    "period": PERIODS[0],
    "when": dateAtOffset(_value75, PERIODS[0].startOffset).getTime()
  };
}
function isTimetablePage(_argument67) {
  try {
    const _value76 = new URL(_argument67);
    return _value76.origin === "https://mirsad-school.onrender.com" && ["/schools/", "/schools/index.html", "/schools/automatic-monitoring.html"].includes(_value76.pathname);
  } catch {
    return false;
  }
}
let openingScheduleTab = null;
async function getScheduleTab(_argument68 = false) {
  const _value77 = await chrome.tabs.query({
      "url": "https://mirsad-school.onrender.com/schools/*"
    }),
    _value78 = _value77.filter(_argument69 => isTimetablePage(_argument69.url)).sort((_argument70, _argument71) => Number(Boolean(_argument71.active)) - Number(Boolean(_argument70.active)) || (_argument71.lastAccessed || 0) - (_argument70.lastAccessed || 0));
  async function _value79(_argument72) {
    let _value80;
    try {
      const _value81 = await Promise.race([chrome.tabs.sendMessage(_argument72.id, {
        "type": "MIRSAD_GET_SCHEDULE",
        "manualPeriodMapping": true
      }), new Promise((_argument73, _argument74) => {
        _value80 = setTimeout(() => _argument74(new Error("\u0627\u0646\u062A\u0647\u062A \u0645\u0647\u0644\u0629 \u0642\u0631\u0627\u0621\u0629 \u0635\u0641\u062D\u0629 \u0631\u0627\u0635\u062F")), 2000);
      })]);
      if (_value81?.["ok"] && _value81.sourceType === "madrasati" && _value81.sourceImportDate === MirsadMonitorModel.day() && Array.isArray(_value81.items) && !_value81.items.length) throw Object.assign(new Error("\u062C\u062F\u0648\u0644 \u0631\u0627\u0635\u062F \u064A\u062D\u062A\u0648\u064A \u0623\u0633\u0645\u0627\u0621 \u0627\u0644\u0645\u0639\u0644\u0645\u064A\u0646 \u0641\u0642\u0637 \u062F\u0648\u0646 \u062D\u0635\u0635\u061B \u0627\u062E\u062A\u0631 \u0627\u0644\u062A\u0627\u0631\u064A\u062E \u0648\u0627\u0636\u063A\u0637 \xAB\u0646\u0642\u0644 \u0645\u0646 \u0645\u062F\u0631\u0633\u062A\u064A \u0625\u0644\u0649 \u0631\u0627\u0635\u062F\xBB \u0623\u0648\u0644\u064B\u0627\u060C \u0648\u0627\u0646\u062A\u0638\u0631 \u0646\u062C\u0627\u062D \u0646\u0642\u0644 \u0627\u0644\u062D\u0635\u0635 \u0642\u0628\u0644 \u062A\u0634\u063A\u064A\u0644 \u0627\u0644\u0631\u0635\u062F"), {
        "emptyImportedSchedule": true
      });
      return _value81?.["ok"] && Array.isArray(_value81.items) && _value81.items.some(_argument75 => _argument75.teacher && _argument75.hasLesson) ? _argument72 : null;
    } catch (_value82) {
      if (_value82.emptyImportedSchedule) throw _value82;
      return null;
    } finally {
      clearTimeout(_value80);
    }
  }
  let _value83 = null;
  for (const _value84 of _value78) {
    try {
      const _value85 = await _value79(_value84);
      if (_value85) return _value85;
    } catch (_value86) {
      if (_value86.emptyImportedSchedule) {
        _value83 = _value86;
        continue;
      }
      throw _value86;
    }
  }
  if (_value83) throw _value83;
  if (!_argument68) return null;
  if (!openingScheduleTab) openingScheduleTab = (async () => {
    await setStatus("\u062C\u0627\u0631\u064D \u0642\u0631\u0627\u0621\u0629 \u0627\u0644\u062D\u0635\u0635 \u0627\u0644\u0645\u062D\u0641\u0648\u0638\u0629 \u0641\u064A \u0645\u0648\u0642\u0639 \u0631\u0627\u0635\u062F\u2026");
    const _value87 = _value78[0];
    if (!_value87) throw new Error("\u0627\u0641\u062A\u062D \u0627\u0644\u0635\u0641\u062D\u0629 \u0627\u0644\u0623\u0648\u0644\u0649 \u0645\u0646 \u0631\u0627\u0635\u062F \u0628\u0646\u0641\u0633\u0643\u060C \u0648\u0627\u0646\u062A\u0638\u0631 \u0627\u0644\u062C\u062F\u0648\u0644 \u062B\u0645 \u0627\u0628\u062F\u0623 \u0627\u0644\u0631\u0635\u062F");
    for (let _number2 = 0; _number2 < 25; _number2++) {
      const _value88 = await _value79(_value87);
      if (_value88) return _value88;
      await new Promise(_argument76 => setTimeout(_argument76, 600));
    }
    throw new Error("\u062C\u062F\u0648\u0644 \u0627\u0644\u0645\u0639\u0644\u0645\u064A\u0646 \u0644\u0645 \u064A\u0643\u062A\u0645\u0644 \u062A\u062D\u0645\u064A\u0644\u0647\u061B \u062A\u0623\u0643\u062F \u0645\u0646 \u0638\u0647\u0648\u0631 \u062D\u0635\u0635 \u0627\u0644\u064A\u0648\u0645 \u0648\u0631\u0648\u0627\u0628\u0637 \u062A\u064A\u0645\u0632 \u062B\u0645 \u0634\u063A\u0651\u0644 \u0627\u0644\u0631\u0635\u062F");
  })()["finally"](() => {
    openingScheduleTab = null;
  });
  return openingScheduleTab;
}
async function startMonitoring(_argument77 = false) {
  if (CloudMonitoring.linksBusy?.()) throw new Error("\u0627\u0646\u062A\u0638\u0631 \u0627\u0643\u062A\u0645\u0627\u0644 \u062D\u0641\u0638 \u0631\u0627\u0628\u0637 \u0627\u0644\u062D\u0635\u0629");
  await MirsadClassicReady, await refreshScheduleSettings();
  const _value89 = await getRun();
  try {
    await CloudMonitoring.assertSelected(_value89?.["running"] || _value89?.["paused"] ? _value89 : null);
  } catch (_value90) {
    if (_value89?.["running"]) await pauseMonitoring();
    throw _value90;
  }
  if (!_argument77 && _value89?.["paused"]) {
    await resumeMonitoring();
    return;
  }
  if (!_argument77 && _value89?.["running"]) {
    await recoverPersistedRunAfterBrowserStart();
    return;
  }
  if (_value89?.["running"] && _argument77 && _value89.current) {
    await setStatus("\u0627\u0644\u0645\u0631\u0627\u0642\u0628\u0629 \u062A\u0639\u0645\u0644 \u0628\u0627\u0644\u0641\u0639\u0644\u061B \u0644\u0646 \u064A\u064F\u0641\u062A\u062D \u0641\u062D\u0635 \u0641\u0648\u0631\u064A \u0623\u062B\u0646\u0627\u0621 \u0641\u062D\u0635 \u0631\u0627\u0628\u0637.", {
      "period": _value89.period,
      "waiting": !_value89.period
    });
    return;
  }
  const _value91 = _argument77 && _value89?.["running"] ? _value89 : null,
    _value92 = _value91 && chrome.alarms.get ? await chrome.alarms.get(NEXT_ALARM) : null;
  await CloudMonitoring.ensureDay(true), await CloudMonitoring.assertSelected();
  const _value93 = await getScheduleTab(),
    _value94 = (await chrome.storage.local.get("mirsadDriveDay")).mirsadDriveDay,
    _value95 = _value94?.["date"] === MirsadMonitorModel.day() ? _value94.snapshot : null;
  if (!_value93 && !_value95) {
    await setStatus("\u0627\u0641\u062A\u062D \u062C\u062F\u0648\u0644 \u0645\u0631\u0635\u0627\u062F \u0623\u0648 \u062D\u0645\u0651\u0644 \u062C\u062F\u0648\u0644 \u0627\u0644\u064A\u0648\u0645 \u0644\u062D\u0641\u0638 \u062C\u062F\u0648\u0644 \u0627\u0644\u064A\u0648\u0645 \u0623\u0648\u0644\u064B\u0627.");
    return;
  }
  let _value96;
  try {
    _value96 = _value95 ? {
      "items": _value95.lessons.map(_argument78 => ({
        ..._argument78,
        "teacher": _argument78.teacherName,
        "hasLesson": true,
        "validPeriod": true
      })),
      "periods": PERIODS
    } : await loadPeriodsFromSchedule(_value93.id);
  } catch (_value97) {
    await setStatus(_value97?.["message"] || "\u062A\u0639\u0630\u0631\u062A \u0642\u0631\u0627\u0621\u0629 \u0623\u0633\u0645\u0627\u0621 \u0627\u0644\u0645\u0639\u0644\u0645\u064A\u0646 \u0648\u0631\u0628\u0637 \u0627\u0644\u062D\u0635\u0635 \u0645\u0646 \u062C\u062F\u0648\u0644 \u0645\u0631\u0635\u0627\u062F.");
    return;
  }
  _value95 && (scheduleSettings.roundCount = _value95.roundCount, await chrome.storage.local.set({
    [SCHEDULE_SETTINGS_KEY]: scheduleSettings
  }));
  const _value98 = _value96.items,
    _value99 = PERIODS.flatMap(_argument79 => scheduleCore.selectPeriodItems(_value98, _argument79.n).slice().sort((_argument80, _argument81) => _argument80.teacher.localeCompare(_argument81.teacher, "ar", {
      "sensitivity": "base",
      "numeric": true
    }))),
    _value100 = Array.from({
      "length": 7
    }, (_argument82, _argument83) => _value98.filter(_argument84 => _argument84.period === _argument83 + 1).length),
    _value101 = Array.from({
      "length": 7
    }, (_argument85, _argument86) => scheduleCore.selectPeriodLinks(_value98, _argument86 + 1).length);
  if (!_value99.length) {
    await setStatus(_value98.length ? "\u062C\u062F\u0648\u0644 \u0627\u0644\u064A\u0648\u0645 \u0645\u062D\u0641\u0648\u0638\u060C \u0644\u0643\u0646 \u0644\u0627 \u062A\u0648\u062C\u062F \u0631\u0648\u0627\u0628\u0637 \u062A\u064A\u0645\u0632 \u0635\u0627\u0644\u062D\u0629 \u0641\u064A \u0646\u0637\u0627\u0642 \u0627\u0644\u062D\u0635\u0635 \u0627\u0644\u0645\u062D\u062F\u062F\u061B \u0631\u0627\u062C\u0639 \u0645\u0646 \u0627\u0644\u062D\u0635\u0629 \u0648\u0625\u0644\u0649 \u0627\u0644\u062D\u0635\u0629 \u0641\u064A \u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A." : "\u0644\u0645 \u062A\u064F\u0642\u0631\u0623 \u062D\u0635\u0635 \u0627\u0644\u064A\u0648\u0645 \u0645\u0646 \u062C\u062F\u0648\u0644 \u0627\u0644\u0645\u0639\u0644\u0645\u064A\u0646 \u0627\u0644\u0623\u0635\u0644\u064A\u061B \u0627\u0641\u062A\u062D \u062C\u062F\u0648\u0644 \u0627\u0644\u0645\u0639\u0644\u0645\u064A\u0646 \u0648\u0627\u0646\u062A\u0638\u0631 \u062A\u062D\u0645\u064A\u0644\u0647 \u062B\u0645 \u0623\u0639\u062F \u0627\u0644\u0645\u062D\u0627\u0648\u0644\u0629.", {
      "diagnostic": true,
      "totalItems": _value98.length,
      "periodCounts": _value100,
      "validLinkCounts": _value101
    });
    return;
  }
  await chrome.alarms.clear(NEXT_ALARM), await chrome.alarms.clear(SCAN_TIMEOUT_ALARM);
  const _options2 = {
    "controlEpoch": _value89?.["controlEpoch"] ?? 0,
    "running": true,
    "scheduleRevision": _value95?.["scheduleRevision"] || null,
    "autoResume": !_argument77,
    "schedule": _value99,
    "periods": PERIODS,
    "diagnostic": {
      "totalItems": _value98.length,
      "periodCounts": _value100,
      "validLinkCounts": _value101
    },
    "tabId": null,
    "probeTabIds": [],
    "startedAt": Date.now(),
    "results": [],
    "period": null,
    "periodItems": [],
    "index": 0,
    "cycle": 1,
    "current": null,
    "backtestMode": _argument77,
    "immediateMode": _argument77,
    "suspendedRun": _value91,
    "suspendedNextAt": _value92?.["scheduledTime"] || null
  };
  if (!(await saveRun(_options2))) return;
  const _value102 = _argument77 ? periodNow() || PERIODS[0] : periodNow();
  if (_value102) await beginPeriod(_options2, _value102.n);else {
    const _value103 = new Date(),
      _value104 = nextPeriod(_value103);
    await setStatus("\u0644\u0627 \u062A\u0648\u062C\u062F \u062D\u0635\u0629 \u0646\u0634\u0637\u0629 \u0627\u0644\u0622\u0646. \u0627\u0644\u0648\u0642\u062A \u0627\u0644\u062D\u0627\u0644\u064A " + _value103.toLocaleTimeString("en-GB", {
      "hour": "2-digit",
      "minute": "2-digit"
    }) + ". \u0623\u0642\u0631\u0628 \u0645\u0648\u0639\u062F: \u0627\u0644\u062D\u0635\u0629 " + _value104.period.n + " \u0639\u0646\u062F " + _value104.period.start + ".", {
      "waiting": true,
      "period": _value104.period.n,
      "now": _value103.toISOString(),
      "nextAt": _value104.when,
      "periods": PERIODS
    }), await chrome.alarms.clear(NEXT_ALARM), await createRunAlarm(_options2, NEXT_ALARM, {
      "when": _value104.when
    });
  }
}
async function restoreSuspendedRun(_argument87) {
  if (!_argument87?.["immediateMode"]) return false;
  await closeProbeTab(_argument87);
  const _value105 = _argument87.suspendedRun;
  if (_value105?.["running"]) {
    if (!(await saveRun(_value105))) return;
    if (Number.isFinite(_argument87.suspendedNextAt)) await createRunAlarm(_argument87, NEXT_ALARM, {
      "when": Math.max(Date.now() + 1000, _argument87.suspendedNextAt)
    });else {
      if (_value105.period) await navigateCurrent(_value105);else {
        const _value106 = periodNow(),
          _value107 = _value106 ? null : nextPeriod();
        if (_value106) await beginPeriod(_value105, _value106.n);else await createRunAlarm(_argument87, NEXT_ALARM, {
          "when": _value107.when
        });
      }
    }
  } else {
    _argument87.running = false, _argument87.current = null, _argument87.immediateMode = false;
    if (!(await saveRun(_argument87))) return;
  }
  return true;
}
async function wakeUpdatedLinks() {
  const _value108 = await getRun();
  if (!_value108?.["running"] || _value108.paused || _value108.current || _value108.waitingForCycle2 || _value108.periodItems?.["length"]) return;
  const _value109 = periodNow();
  if (!_value109 || _value109.n !== _value108.period || !scheduleCore.selectPeriodItems(_value108.schedule, _value109.n).length) return;
  await createRunAlarm(_value108, NEXT_ALARM, {
    "when": Date.now() + 1000
  });
}
async function beginPeriod(_argument88, _argument89) {
  await MirsadAutoLinks.beforeCycle(_argument88);
  const freshAutoRun = await getRun();
  if (!freshAutoRun?.running || freshAutoRun.paused || freshAutoRun.startedAt !== _argument88.startedAt || (freshAutoRun.controlEpoch ?? 0) !== (_argument88.controlEpoch ?? 0)) return;
  Object.assign(_argument88, freshAutoRun);
  if (!_argument88?.["running"]) return;
  if (periodDisabled(MirsadMonitorModel.day(), _argument89)) {
    await advancePeriod(_argument88, _argument89);
    return;
  }
  const _value110 = PERIODS.find(_argument90 => _argument90.n === _argument89);
  if (!_value110) return;
  const _value111 = new Date(),
    _value112 = periodBounds(_value110, _value111, "activeOrNext"),
    _value113 = _value112.start,
    _value114 = _value112.end;
  if (!_argument88.backtestMode && _value111 < _value113) {
    await chrome.alarms.clear(NEXT_ALARM), await createRunAlarm(_argument88, NEXT_ALARM, {
      "when": _value113.getTime()
    }), await setStatus("\u064A\u0646\u062A\u0638\u0631 \u0628\u062F\u0627\u064A\u0629 \u0627\u0644\u062D\u0635\u0629 " + _value110.n + " \u0639\u0646\u062F " + _value110.start, {
      "waiting": true,
      "period": _value110.n
    });
    return;
  }
  if (!_argument88.backtestMode && _value111 >= _value114) {
    await advancePeriod(_argument88, _argument89);
    return;
  }
  const _value115 = scheduleCore.selectPeriodItems(_argument88.schedule, _value110.n);
  _argument88.periodStartedAt = _value113.getTime(), _argument88.period = _value110.n, _argument88.periodItems = _value115, _argument88.index = 0, _argument88.current = null, _argument88.cycle = 1, _argument88.waitingForCycle2 = false;
  if (!(await saveRun(_argument88))) return;
  if (!_value115.length) {
    if (_argument88.immediateMode) {
      await setStatus("\u0644\u0627 \u064A\u0648\u062C\u062F \u0631\u0627\u0628\u0637 Teams \u0635\u0627\u0644\u062D \u0644\u0644\u062D\u0635\u0629 " + _value110.n + "\u061B \u0644\u0645 \u064A\u064F\u0641\u062A\u062D \u0631\u0627\u0628\u0637 \u062D\u0635\u0629 \u0623\u062E\u0631\u0649. \u0627\u0646\u062A\u0647\u0649 \u0627\u0644\u0641\u062D\u0635 \u0627\u0644\u0641\u0648\u0631\u064A \u062F\u0648\u0646 \u062A\u063A\u064A\u064A\u0631 \u0633\u062C\u0644 \u0627\u0644\u062D\u0636\u0648\u0631.", {
        "diagnostic": true,
        "period": _value110.n,
        "immediateMode": true,
        "guard": "no-links-for-active-period"
      }), await restoreSuspendedRun(_argument88);
      return;
    }
    const _value116 = nextPeriod(_value111);
    await setStatus("\u0644\u0627 \u064A\u0648\u062C\u062F \u0631\u0627\u0628\u0637 Teams \u0635\u0627\u0644\u062D \u0644\u0644\u062D\u0635\u0629 \u0627\u0644\u062C\u0627\u0631\u064A\u0629 \u0631\u0642\u0645 " + _value110.n + ". \u0644\u0645 \u064A\u064F\u0641\u062A\u062D \u0631\u0627\u0628\u0637 \u062D\u0635\u0629 \u0623\u062E\u0631\u0649\u061B \u064A\u0646\u062A\u0638\u0631 \u0631\u0627\u0635\u062F \u0645\u0648\u0639\u062F \u0627\u0644\u062D\u0635\u0629 \u0627\u0644\u062A\u0627\u0644\u064A\u0629 \u0639\u0646\u062F " + _value116.period.start + ".", {
      "diagnostic": true,
      "period": _value110.n,
      "totalItems": _argument88.schedule.length,
      "periodCounts": _argument88.diagnostic?.["periodCounts"] || [],
      "validLinkCounts": _argument88.diagnostic?.["validLinkCounts"] || [],
      "guard": "no-links-for-active-period"
    }), await chrome.alarms.clear(NEXT_ALARM), await createRunAlarm(_argument88, NEXT_ALARM, {
      "when": _value116.when
    });
    return;
  }
  const _value117 = Math.max(1, Math.min(10, Number(scheduleSettings.scanDelay) || 1)),
    _value118 = _value113.getTime() + _value117 * 60 * 1000;
  if (!_argument88.backtestMode && _value111.getTime() < _value118) {
    await setStatus("\u0627\u0644\u0631\u0635\u062F \u062C\u0627\u0647\u0632 \u0644\u0644\u062D\u0635\u0629 " + _value110.n + ". \u064A\u0628\u062F\u0623 \u0627\u0644\u0641\u062D\u0635 \u0628\u0639\u062F \u0645\u0631\u0648\u0631 " + _value117 + " \u062F\u0642\u064A\u0642\u0629 \u0645\u0646 \u0628\u062F\u0627\u064A\u0629 \u0627\u0644\u062D\u0635\u0629.", {
      "period": _value110.n,
      "waiting": true,
      "cycle": 1,
      "total": _value115.length
    }), await chrome.alarms.clear(NEXT_ALARM), await createRunAlarm(_argument88, NEXT_ALARM, {
      "when": _value118
    });
    return;
  }
  _value111.getTime() > _value113.getTime() + 10 * 60 * 1000 ? await setStatus("\u0628\u062F\u0623 \u0627\u0644\u062A\u0634\u063A\u064A\u0644 \u0628\u0639\u062F \u0646\u0627\u0641\u0630\u0629 \u0627\u0644\u062F\u0648\u0631\u0629 \u0627\u0644\u0623\u0648\u0644\u0649\u061B \u064A\u0628\u062F\u0623 \u0627\u0644\u0631\u0635\u062F \u0627\u0644\u0622\u0646 \u062D\u062A\u0649 \u0644\u0627 \u062A\u064F\u0641\u0642\u062F \u0627\u0644\u062D\u0635\u0629.", {
    "period": _value110.n,
    "cycle": 1,
    "total": _value115.length
  }) : await setStatus("\u0628\u062F\u0623\u062A \u0627\u0644\u062F\u0648\u0631\u0629 \u0627\u0644\u0623\u0648\u0644\u0649 \u0644\u0644\u062D\u0635\u0629 " + _value110.n + ": " + _value115.length + " \u0631\u0627\u0628\u0637\u064B\u0627.", {
    "period": _value110.n,
    "done": 0,
    "total": _value115.length,
    "cycle": 1
  }), await navigateCurrent(_argument88);
}
async function navigateCurrent(_argument91) {
  await MirsadVideo.beforeScan();
  if (!_argument91?.["running"]) return;
  if (periodDisabled(MirsadMonitorModel.day(), _argument91.period)) {
    _argument91.current = null, _argument91.waitingForCycle2 = false, _argument91.nextCycleAt = null;
    if (!(await saveRun(_argument91))) return;
    await advancePeriod(_argument91, _argument91.period);
    return;
  }
  try {
    await MirsadCommercialAccount.assertActive(), await CloudMonitoring.assertSelected(_argument91);
    if (!(await isRunCurrent(_argument91))) return;
  } catch (_value119) {
    if (!(await isRunCurrent(_argument91))) return;
    if (MirsadCommercialAccount.transient(_value119)) {
      const _value120 = await getRun();
      if (!_value120?.["running"] || _value120.paused) return;
      _value120.waitingForReconnect = true;
      if (!(await saveRun(_value120))) return;
      await createRunAlarm(_argument91, NEXT_ALARM, {
        "when": Date.now() + 15000
      }), await setStatus("\u062A\u0623\u062E\u0631 \u0627\u0644\u0627\u062A\u0635\u0627\u0644 \u0628\u062E\u062F\u0645\u0629 \u0631\u0627\u0635\u062F\u061B \u0627\u0644\u062A\u0642\u062F\u0645 \u0645\u062D\u0641\u0648\u0638 \u0648\u0633\u062A\u062A\u0645 \u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0645\u062D\u0627\u0648\u0644\u0629 \u062A\u0644\u0642\u0627\u0626\u064A\u064B\u0627.", {
        "waiting": true,
        "waitingForReconnect": true
      });
      return;
    }
    await pauseMonitoring(), await setStatus(_value119.message);
    return;
  }
  if (!_argument91.backtestMode) {
    const _value121 = new Date(),
      _value122 = periodNow(_value121);
    if (!_value122) {
      _argument91.current = null;
      if (!(await saveRun(_argument91))) return;
      const _value123 = nextPeriod(_value121);
      await chrome.alarms.clear(NEXT_ALARM), await createRunAlarm(_argument91, NEXT_ALARM, {
        "when": Math.max(Date.now() + 1000, _value123.when)
      }), await setStatus("\u062D\u0645\u0627\u064A\u0629 \u0627\u0644\u0648\u0642\u062A: \u0644\u0627 \u062A\u0648\u062C\u062F \u062D\u0635\u0629 \u0645\u062A\u0632\u0627\u0645\u0646\u0629 \u0627\u0644\u0622\u0646\u061B \u0644\u0645 \u064A\u064F\u0641\u062A\u062D \u0623\u064A \u0631\u0627\u0628\u0637. \u064A\u0646\u062A\u0638\u0631 \u0627\u0644\u062D\u0635\u0629 " + _value123.period.n + " \u0639\u0646\u062F " + _value123.period.start + ".", {
        "waiting": true,
        "guard": "no-active-period",
        "period": _value123.period.n
      });
      return;
    }
    if (_value122.n !== _argument91.period) {
      _argument91.periodStartedAt = periodBounds(_value122, _value121, "active").start.getTime(), _argument91.period = _value122.n, _argument91.periodItems = scheduleCore.selectPeriodItems(_argument91.schedule, _value122.n), _argument91.index = 0, _argument91.cycle = 1, _argument91.waitingForCycle2 = false, _argument91.current = null;
      if (!(await saveRun(_argument91))) return;
      await setStatus("\u062A\u063A\u064A\u0651\u0631 \u0648\u0642\u062A \u0627\u0644\u062D\u0635\u0629 \u0623\u062B\u0646\u0627\u0621 \u0627\u0644\u0631\u0635\u062F\u061B \u0623\u0644\u063A\u0649 \u0645\u0631\u0635\u0627\u062F \u0627\u0644\u0631\u0627\u0628\u0637 \u0627\u0644\u0642\u062F\u064A\u0645 \u0648\u0627\u0646\u062A\u0642\u0644 \u0625\u0644\u0649 \u0627\u0644\u062D\u0635\u0629 \u0627\u0644\u0645\u062A\u0632\u0627\u0645\u0646\u0629 \u0631\u0642\u0645 " + _value122.n + " \u0641\u0642\u0637.", {
        "period": _value122.n,
        "guard": "period-resync"
      });
      if (!_argument91.periodItems.length) {
        if (_argument91.immediateMode) {
          await setStatus("\u0644\u0627 \u062A\u0648\u062C\u062F \u062E\u0644\u0627\u064A\u0627 \u0645\u0642\u0631\u0648\u0621\u0629 \u0644\u0644\u062D\u0635\u0629 " + _value122.n + ". \u0627\u0646\u062A\u0647\u0649 \u0627\u0644\u0641\u062D\u0635 \u0627\u0644\u0641\u0648\u0631\u064A \u062F\u0648\u0646 \u062A\u063A\u064A\u064A\u0631 \u0633\u062C\u0644 \u0627\u0644\u062D\u0636\u0648\u0631.", {
            "period": _value122.n,
            "immediateMode": true,
            "guard": "no-items-for-active-period"
          }), await restoreSuspendedRun(_argument91);
          return;
        }
        const _value124 = nextPeriod(_value121);
        await setStatus("\u0644\u0627 \u062A\u0648\u062C\u062F \u062E\u0644\u0627\u064A\u0627 \u0645\u0639\u0644\u0645\u064A\u0646 \u0645\u0642\u0631\u0648\u0621\u0629 \u0644\u0644\u062D\u0635\u0629 \u0627\u0644\u062C\u0627\u0631\u064A\u0629 \u0631\u0642\u0645 " + _value122.n + "\u061B \u0644\u0645 \u064A\u064F\u0641\u062A\u062D \u0623\u064A \u0631\u0627\u0628\u0637 \u0622\u062E\u0631\u060C \u0648\u064A\u0646\u062A\u0638\u0631 \u0645\u0631\u0635\u0627\u062F \u0627\u0644\u062D\u0635\u0629 " + _value124.period.n + ".", {
          "period": _value122.n,
          "guard": "no-items-for-active-period",
          "waiting": true
        }), await chrome.alarms.clear(NEXT_ALARM), await createRunAlarm(_argument91, NEXT_ALARM, {
          "when": _value124.when
        });
        return;
      }
    }
  }
  const _value125 = PERIODS.find(_argument92 => _argument92.n === _argument91.period);
  if (!_value125) return;
  if (!_argument91.backtestMode) {
    const _value126 = periodBounds(_value125, new Date(), "past"),
      _value127 = Date.now(),
      _value128 = periodNow(new Date(_value127));
    if (!_value126 || _value127 < _value126.start.getTime() || _value127 >= _value126.end.getTime() || !_value128 || _value128.n !== _value125.n) {
      _argument91.current = null;
      if (!(await saveRun(_argument91))) return;
      const _value129 = nextPeriod(new Date(_value127));
      await chrome.alarms.clear(NEXT_ALARM), await createRunAlarm(_argument91, NEXT_ALARM, {
        "when": Math.max(_value127 + 1000, _value129.when)
      }), await setStatus("\u0645\u0646\u0639 \u0631\u0627\u0635\u062F \u0641\u062A\u062D \u0627\u0644\u0631\u0627\u0628\u0637: \u0631\u0642\u0645 \u0627\u0644\u062D\u0635\u0629 \u0644\u0627 \u064A\u0637\u0627\u0628\u0642 \u0627\u0644\u062D\u0635\u0629 \u0627\u0644\u0646\u0634\u0637\u0629 \u0623\u0648 \u0623\u0646 \u0627\u0644\u0648\u0642\u062A \u062E\u0627\u0631\u062C \u0646\u0627\u0641\u0630\u062A\u0647\u0627.", {
        "period": _value125.n,
        "waiting": true,
        "guard": "period-time-mismatch",
        "activePeriod": _value128?.["n"] || null
      });
      return;
    }
  }
  if (_argument91.index >= _argument91.periodItems.length) {
    _argument91.current = null, await chrome.alarms.clear(SCAN_TIMEOUT_ALARM), await chrome.alarms.clear(NEXT_ALARM);
    if (_argument91.backtestMode) await setStatus("\u0627\u0643\u062A\u0645\u0644 \u0627\u0644\u0641\u062D\u0635 \u0627\u0644\u0641\u0648\u0631\u064A \u0627\u0644\u062A\u0634\u062E\u064A\u0635\u064A \u0644\u0644\u062D\u0635\u0629 " + _value125.n + ". \u0627\u0644\u0646\u062A\u0627\u0626\u062C \u0644\u0627 \u062A\u063A\u064A\u0651\u0631 \u0633\u062C\u0644 \u0627\u0644\u062D\u0636\u0648\u0631.", {
      "period": _value125.n,
      "immediateMode": true,
      "done": _argument91.periodItems.length,
      "total": _argument91.periodItems.length
    }), await restoreSuspendedRun(_argument91);else {
      if (_argument91.cycle < scheduleSettings.roundCount) {
        const _value130 = periodBounds(_value125, new Date(), "past"),
          _value131 = _argument91.cycle === 2 ? scheduleSettings.thirdRoundGapMinutes : scheduleSettings.roundGapMinutes,
          _value132 = Date.now() + _value131 * 60000;
        if (_value130 && _value132 < _value130.end.getTime()) {
          _argument91.waitingForCycle2 = true, _argument91.nextCycleAt = _value132;
          if (!(await saveRun(_argument91))) return;
          await createRunAlarm(_argument91, NEXT_ALARM, {
            "when": _value132
          });
          void MirsadAutoLinks.collectGap();
          await setStatus("\u0627\u0643\u062A\u0645\u0644\u062A \u0627\u0644\u062F\u0648\u0631\u0629 " + _argument91.cycle + " \u0644\u0644\u062D\u0635\u0629 " + _value125.n + "\u061B \u062A\u0646\u062A\u0638\u0631 \u0627\u0644\u062F\u0648\u0631\u0629 " + (_argument91.cycle + 1) + " \u0628\u0639\u062F " + _value131 + " \u062F\u0642\u0627\u0626\u0642.", {
            "period": _value125.n,
            "cycle": _argument91.cycle,
            "waiting": true,
            "nextAt": _value132
          });
        } else await setStatus("\u0627\u0646\u062A\u0647\u0649 \u0627\u0644\u0631\u0635\u062F \u0644\u0644\u062D\u0635\u0629 " + _value125.n + "\u061B \u0644\u0627 \u062A\u0643\u0641\u064A \u0627\u0644\u0645\u062F\u0629 \u0644\u062F\u0648\u0631\u0629 \u0623\u062E\u0631\u0649 \u062F\u0627\u062E\u0644 \u0627\u0644\u062D\u0635\u0629.", {
          "period": _value125.n,
          "cycle": _argument91.cycle
        }), await advancePeriod(_argument91, _value125.n);
      } else await setStatus("\u0627\u0643\u062A\u0645\u0644 \u0627\u0644\u0631\u0635\u062F \u0644\u0644\u062D\u0635\u0629 " + _value125.n + " \u0628\u0639\u062F " + _argument91.cycle + " \u062F\u0648\u0631\u0627\u062A.", {
        "period": _value125.n,
        "done": _argument91.periodItems.length,
        "total": _argument91.periodItems.length
      }), await advancePeriod(_argument91, _value125.n);
    }
    return;
  }
  const _value133 = _argument91.periodItems[_argument91.index];
  if (!_value133.url) {
    const _options3 = {
      "scanId": "no-link-" + _argument91.period + "-" + _argument91.cycle + "-" + _argument91.index + "-" + Date.now(),
      "teacher": _value133.teacher,
      "scheduledTeacher": _value133.teacher,
      "period": _argument91.period,
      "subject": _value133.subject || "",
      "className": _value133.className || "",
      "url": "",
      "status": "no-link",
      "detail": "\u063A\u0627\u0626\u0628 \u0625\u062F\u0627\u0631\u064A\u064B\u0627 \u0644\u0639\u062F\u0645 \u062A\u0648\u0641\u0631 \u0631\u0627\u0628\u0637 Teams \u0639\u0646\u062F \u0631\u0635\u062F \u0627\u0644\u062D\u0635\u0629\u061B \u0642\u0627\u0628\u0644 \u0644\u0644\u062A\u0639\u062F\u064A\u0644\u060C \u062F\u0648\u0646 \u0625\u062B\u0628\u0627\u062A \u0645\u0635\u0648\u0651\u0631.",
      "scannedAt": Date.now(),
      "cycle": _argument91.cycle || 0
    };
    _argument91.results.push(_options3);
    !_argument91.testMode && !_argument91.backtestMode && (await appendDailyReport(_options3), await CloudMonitoring.record(_argument91, _options3)["catch"](() => {}));
    _argument91.index++, _argument91.current = null;
    if (!(await saveRun(_argument91))) return;
    await setStatus("\u0627\u0644\u062D\u0635\u0629 " + _value125.n + " \u2014 " + _value133.teacher + ": \u063A\u0627\u0626\u0628 \u0644\u0639\u062F\u0645 \u062A\u0648\u0641\u0631 \u0631\u0627\u0628\u0637 Teams\u061B \u064A\u0645\u0643\u0646 \u062A\u0639\u062F\u064A\u0644 \u0627\u0644\u062D\u0627\u0644\u0629 \u0648\u0625\u0636\u0627\u0641\u0629 \u0627\u0644\u0631\u0627\u0628\u0637\u060C \u0648\u064A\u062A\u0627\u0628\u0639 \u0631\u0627\u0635\u062F \u0627\u0644\u0645\u0639\u0644\u0645 \u0627\u0644\u062A\u0627\u0644\u064A.", {
      "period": _value125.n,
      "teacher": _value133.teacher,
      "done": _argument91.index,
      "total": _argument91.periodItems.length,
      "cycle": _argument91.cycle,
      "last": _options3
    }), await navigateCurrent(_argument91);
    return;
  }
  if (!isTeamsMeetingUrl(_value133.url)) {
    _argument91.results.push({
      "teacher": _value133.teacher,
      "scheduledTeacher": _value133.teacher,
      "period": _argument91.period,
      "subject": _value133.subject || "",
      "className": _value133.className || "",
      "status": "unresolved",
      "detail": "\u062A\u062C\u0627\u0648\u0632 \u0631\u0627\u0635\u062F \u0631\u0627\u0628\u0637\u064B\u0627 \u0644\u0627 \u064A\u0637\u0627\u0628\u0642 \u0646\u0637\u0627\u0642\u0627\u062A Teams \u0627\u0644\u0645\u0633\u0645\u0648\u062D\u0629\u061B \u0644\u0645 \u064A\u0641\u062A\u062D\u0647.",
      "scannedAt": Date.now(),
      "cycle": _argument91.cycle
    }), _argument91.index++, _argument91.current = null;
    if (!(await saveRun(_argument91))) return;
    await navigateCurrent(_argument91);
    return;
  }
  _argument91.current = {
    ..._value133,
    "retryCount": scanRetryState(_argument91)?.["attempts"]["length"] || 0,
    "scanDeadlineAt": Date.now() + SCAN_TIMEOUT_MS,
    "scanId": String(_argument91.period) + "-" + String(_argument91.cycle) + "-" + String(_argument91.index) + "-" + String(Date.now()) + "-ctl" + String(_argument91.controlEpoch ?? 0) + "-retry" + String(scanRetryState(_argument91)?.["attempts"]["length"] || 0)
  };
  if (!(await saveRun(_argument91))) return;
  await chrome.alarms.clear(SCAN_TIMEOUT_ALARM), await createRunAlarm(_argument91, SCAN_TIMEOUT_ALARM, {
    "when": Date.now() + SCAN_TIMEOUT_MS
  }), await setStatus("\u0627\u0644\u062D\u0635\u0629 " + _value125.n + " \u2014 " + _value133.teacher + " (" + (_argument91.index + 1) + "/" + _argument91.periodItems.length + ")\u060C \u0627\u0644\u062F\u0648\u0631\u0629 " + _argument91.cycle + (_argument91.current.retryCount ? " \u2014 \u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0641\u062D\u0635 " + _argument91.current.retryCount + " \u0645\u0646 2" : ""), {
    "period": _value125.n,
    "teacher": _value133.teacher,
    "done": _argument91.index,
    "total": _argument91.periodItems.length,
    "cycle": _argument91.cycle
  });
  try {
    const _value134 = await ensureProbeTab(_argument91);
    if (!Number.isInteger(_value134) || !(await isRunCurrent(_argument91))) return;
    const _value135 = await chrome.tabs.update(_value134, {
      "url": scheduleCore.normalizeTeamsUrl(_value133.url) || _value133.url,
      "active": true
    });
    if (chrome.windows?.["update"] && Number.isInteger(_value135.windowId)) await chrome.windows.update(_value135.windowId, {
      "focused": true
    });
    void MirsadScanActivity.open(_value134, _argument91)["catch"](() => {});
  } catch (_value136) {
    await receiveResult({
      "scanId": _argument91.current.scanId,
      "result": {
        "status": "unresolved",
        "teacher": _value133.teacher,
        "detail": "\u062A\u0639\u0630\u0631 \u0641\u062A\u062D \u0627\u0644\u0631\u0627\u0628\u0637"
      }
    });
  }
}
async function advancePeriod(_argument93, _argument94) {
  await MirsadVideo.completed(_argument93, _argument94).catch(() => {});
  if (!_argument93?.["running"]) return;
  const _value137 = PERIODS.find(_argument95 => _argument95.n > _argument94 && !periodDisabled(MirsadMonitorModel.day(), _argument95.n));
  if (!_value137) {
    const _value138 = nextPeriod(new Date(Date.now() + 1000));
    await setStatus("\u0627\u0646\u062A\u0647\u062A \u062D\u0635\u0635 \u0627\u0644\u064A\u0648\u0645. \u064A\u0646\u062A\u0638\u0631 \u0631\u0627\u0635\u062F \u0627\u0644\u062D\u0635\u0629 " + _value138.period.n + " \u0641\u064A " + _value138.period.start + " \u0641\u064A \u064A\u0648\u0645 \u062F\u0631\u0627\u0633\u064A \u0642\u0627\u062F\u0645.", {
      "waiting": true,
      "period": _value138.period.n
    }), await chrome.alarms.clear(NEXT_ALARM), await createRunAlarm(_argument93, NEXT_ALARM, {
      "when": _value138.when
    });
    return;
  }
  await beginPeriod(_argument93, _value137.n);
  void MirsadAutoLinks.completed(_argument93, _argument94, _value137.n).catch(() => {});
}
function scanRetryState(_argument96) {
  const _value139 = _argument96.scanRetry;
  return _value139 && _value139.period === _argument96.period && _value139.cycle === _argument96.cycle && _value139.index === _argument96.index && _value139.day === localDayKey(new Date()) ? _value139 : null;
}
function retryDetail(_argument97, _argument98) {
  const _value140 = scanRetryState(_argument97);
  if (!_value140?.["attempts"]["length"]) return _argument98;
  return "\u062A\u0645\u062A \u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0641\u062D\u0635 " + _value140.attempts.length + " \u0645\u0631\u0629 \u0636\u0645\u0646 \u0627\u0644\u062F\u0648\u0631\u0629 " + _argument97.cycle + " \u0644\u0646\u0641\u0633 \u0627\u0644\u0645\u0639\u0644\u0645 \u0648\u0627\u0644\u062D\u0635\u0629 \u0628\u0633\u0628\u0628 \u0646\u062A\u064A\u062C\u0629 \u063A\u064A\u0631 \u0645\u062D\u0633\u0648\u0645\u0629. " + _argument98 + " \xB7 \u0623\u0633\u0628\u0627\u0628 \u0627\u0644\u0645\u062D\u0627\u0648\u0644\u0627\u062A \u0627\u0644\u0633\u0627\u0628\u0642\u0629: " + _value140.attempts.map((_argument99, _argument100) => _argument100 + 1 + ": " + _argument99.detail).join(" | ");
}
async function retryUnresolved(_argument101, _argument102, _argument103) {
  const _value141 = scanRetryState(_argument101),
    _value142 = _value141?.["attempts"] || [];
  if (_value142.length >= MAX_UNRESOLVED_RETRIES) return false;
  if (!_argument101.backtestMode) {
    const _value143 = PERIODS.find(_argument104 => _argument104.n === _argument101.period),
      _value144 = _value143 && periodBounds(_value143, new Date(), "past"),
      _value145 = periodNow(new Date());
    if (!_value144 || !_value145 || _value145.n !== _argument101.period || Date.now() >= _value144.end.getTime()) return false;
  }
  _argument101.scanRetry = {
    "period": _argument101.period,
    "cycle": _argument101.cycle,
    "index": _argument101.index,
    "day": localDayKey(new Date()),
    "attempts": [..._value142, {
      "scanId": _argument102.scanId,
      "at": Date.now(),
      "detail": String(_argument103).slice(0, 350)
    }]
  };
  const _value146 = new Set([...(_argument101.probeTabIds || []), _argument101.tabId].filter(_argument105 => Number.isInteger(_argument105)));
  _argument101.current = null, _argument101.tabId = null, _argument101.probeTabIds = [];
  if (!(await saveRun(_argument101))) return;
  await chrome.alarms.clear(SCAN_TIMEOUT_ALARM);
  for (const _value147 of _value146) {
    try {
      await MirsadTabOwnership.closeProbe(_value147);
    } catch {}
  }
  const _value148 = await getRun();
  if (!_value148?.["running"] || _value148.period !== _argument101.period || _value148.cycle !== _argument101.cycle || _value148.index !== _argument101.index) return true;
  return await setStatus("\u063A\u064A\u0631 \u0645\u062D\u0633\u0648\u0645 \u2014 \u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u062F\u062E\u0648\u0644 \u0644\u0646\u0641\u0633 \u0627\u0644\u0645\u0639\u0644\u0645 " + _argument102.teacher + "\u061B \u0627\u0644\u0645\u062D\u0627\u0648\u0644\u0629 \u0627\u0644\u0625\u0636\u0627\u0641\u064A\u0629 " + _argument101.scanRetry.attempts.length + " \u0645\u0646 " + MAX_UNRESOLVED_RETRIES + " \u0636\u0645\u0646 \u0627\u0644\u062F\u0648\u0631\u0629 " + _argument101.cycle, {
    "period": _argument101.period,
    "teacher": _argument102.teacher,
    "cycle": _argument101.cycle,
    "retry": _argument101.scanRetry.attempts.length
  }), await navigateCurrent(_value148), true;
}
async function receiveResult(_argument106) {
  if (!_argument106.scanId || resolvingScans.has(_argument106.scanId)) return;
  resolvingScans.add(_argument106.scanId);
  try {
    return await receiveResultOnce(_argument106);
  } finally {
    resolvingScans["delete"](_argument106.scanId);
  }
}
async function receiveResultOnce(_argument107) {
  const _value149 = await getRun();
  if (!_value149?.["running"] || !_value149.current) return;
  const _value150 = _value149.current;
  if (!_argument107.scanId || _argument107.scanId !== _value150.scanId) return;
  await chrome.alarms.clear(SCAN_TIMEOUT_ALARM);
  const _value151 = Date.now();
  let _value152 = _argument107.result?.["status"] || "unresolved",
    _value153 = _argument107.result?.["detail"] || "\u0644\u0645 \u062A\u064F\u0631\u062C\u0639 \u0648\u0627\u062C\u0647\u0629 Teams \u0646\u062A\u064A\u062C\u0629 \u0648\u0627\u0636\u062D\u0629";
  const _value154 = _argument107.result?.["teacher"] || _value150.teacher,
    _value155 = _argument107.result?.["evidenceTeacher"] || _value154;
  if (_value152 === "absent") {
    const _value156 = await chrome.storage.local.get("mirsadEvidenceRecords"),
      _value157 = Array.isArray(_value156.mirsadEvidenceRecords) && _value156.mirsadEvidenceRecords.some(_argument108 => _argument108.status === "absent" && _argument108.evidenceVerified === true && _argument108.scanId === _argument107.scanId && String(_argument108.teacher) === String(_value155) && String(_argument108.period) === String(_value149.period));
    !_value157 && (_value152 = "unresolved", _value153 = "\u0644\u0645 \u064A\u064F\u0639\u062A\u0645\u062F \u0627\u0644\u063A\u064A\u0627\u0628 \u0644\u0639\u062F\u0645 \u0648\u062C\u0648\u062F \u0644\u0642\u0637\u0629 \u0645\u062D\u0641\u0648\u0638\u0629 \u0648\u0645\u062A\u062D\u0642\u0642 \u0645\u0646\u0647\u0627 \u0644\u0627\u0633\u0645 \u0627\u0644\u0645\u0639\u0644\u0645 \u0636\u0645\u0646 \u0627\u0644\u0645\u062F\u0639\u0648\u064A\u0646\u061B \u0627\u0644\u062D\u0627\u0644\u0629 \u063A\u064A\u0631 \u0645\u062D\u0633\u0648\u0645\u0629.");
  }
  if (_value152 === "unresolved" && (await retryUnresolved(_value149, _value150, _value153))) return;
  _value153 = retryDetail(_value149, _value153);
  const _value158 = scanRetryState(_value149)?.["attempts"]["length"] || 0;
  _value149.scanRetry = null;
  const _options4 = {
    "retryCount": _value158,
    "scanId": _value150.scanId,
    "teacher": _value154,
    "scheduledTeacher": _value150.teacher,
    "period": _value149.period,
    "subject": _value150.subject || "",
    "className": _value150.className || "",
    "url": _value150.url,
    "status": _value152,
    "detail": _value153,
    "scannedAt": _value151,
    "cycle": _value149.cycle || 0
  };
  _value149.results.push(_options4);
  if (!(await saveRun(_value149))) return;
  !_value149.testMode && !_value149.backtestMode && (await appendDailyReport(_options4), await LocalBackup.enqueue(_options4)["catch"](_argument109 => setStatus("\u062A\u0639\u0630\u0631 \u062A\u062B\u0628\u064A\u062A \u0627\u0644\u0646\u0633\u062E\u0629 \u0627\u0644\u0645\u062D\u0644\u064A\u0629: " + String(_argument109.message))), await CloudMonitoring.record(_value149, _options4)["catch"](() => {}));
  _value149.index++, _value149.current = null;
  if (_value149.testMode && !_value149.backtestMode) {
    _value149.running = false;
    if (!(await saveRun(_value149))) return;
    await closeProbeTab(_value149), await setStatus("\u0627\u0643\u062A\u0645\u0644 \u0627\u0644\u0627\u062E\u062A\u0628\u0627\u0631 \u0627\u0644\u0645\u0628\u0627\u0634\u0631 \u0644\u0631\u0627\u0628\u0637 \u0648\u0627\u062D\u062F: " + _value150.teacher + " \u2014 " + (_argument107.result?.["detail"] || _argument107.result?.["status"] || "\u063A\u064A\u0631 \u0645\u062D\u0633\u0648\u0645") + ". \u0623\u064F\u063A\u0644\u0642\u062A \u0635\u0641\u062D\u0629 \u0627\u0644\u0627\u062E\u062A\u0628\u0627\u0631 \u062A\u0644\u0642\u0627\u0626\u064A\u064B\u0627. \u0627\u0644\u0646\u062A\u064A\u062C\u0629 \u062A\u0634\u062E\u064A\u0635\u064A\u0629 \u0641\u0642\u0637.", {
      "testMode": true,
      "last": _value149.results[_value149.results.length - 1]
    });
    return;
  }
  if (!(await saveRun(_value149))) return;
  await closeProbeTab(_value149), await setStatus("\u062A\u0645 \u0641\u062D\u0635 " + _value149.index + " \u0645\u0646 " + _value149.periodItems.length + " \u0641\u064A \u0627\u0644\u062D\u0635\u0629 " + _value149.period + "\u061B \u0623\u064F\u063A\u0644\u0642 \u062A\u0628\u0648\u064A\u0628 \u0627\u0644\u0641\u062D\u0635.", {
    "period": _value149.period,
    "done": _value149.index,
    "total": _value149.periodItems.length,
    "cycle": _value149.cycle,
    "last": _value149.results[_value149.results.length - 1]
  }), await navigateCurrent(_value149);
}
chrome.alarms.onAlarm.addListener(async _argument110 => {
  await refreshScheduleSettings();
  const _value159 = await getRun();
  if (!_value159?.["running"]) return;
  if (_argument110.name === SCAN_TIMEOUT_ALARM) {
    if (!_value159.current) return;
    const _value160 = _value159.current;
    if (Number.isFinite(_value160.scanDeadlineAt) && Date.now() < _value160.scanDeadlineAt) {
      await createRunAlarm(_value159, SCAN_TIMEOUT_ALARM, {
        "when": _value160.scanDeadlineAt
      });
      return;
    }
    const _value161 = await chrome.storage.local.get("mirsadEvidenceRecords"),
      _value162 = (_value161.mirsadEvidenceRecords || []).find(_argument111 => _argument111.scanId === _value160.scanId && _argument111.status === "absent" && _argument111.evidenceVerified === true && Number(_argument111.period) === Number(_value159.period));
    if (_value162) {
      await receiveResult({
        "scanId": _value160.scanId,
        "result": {
          "status": "absent",
          "teacher": _value162.teacher,
          "evidenceTeacher": _value162.teacher,
          "detail": "\u063A\u0627\u0626\u0628: \u062D\u064F\u0641\u0638 \u0625\u062B\u0628\u0627\u062A \u0645\u062A\u062D\u0642\u0642 \u0645\u0646\u0647 \u0644\u0627\u0633\u0645 \u0627\u0644\u0645\u0646\u0638\u0651\u0645 \u0636\u0645\u0646 \u0627\u0644\u0645\u062F\u0639\u0648\u064A\u0646\u061B \u0627\u0639\u062A\u0645\u062F\u062A \u0627\u0644\u0644\u0642\u0637\u0629 \u0627\u0644\u0645\u062D\u0641\u0648\u0638\u0629 \u0631\u063A\u0645 \u062A\u0623\u062E\u0631 \u0648\u0635\u0648\u0644 \u0631\u0633\u0627\u0644\u0629 Teams \u0627\u0644\u0646\u0647\u0627\u0626\u064A\u0629."
        }
      });
      return;
    }
    if (typeof navigator !== "undefined" && navigator.onLine === false) {
      _value159.current = null, _value159.waitingForReconnect = true;
      if (!(await saveRun(_value159))) return;
      await closeProbeTab(_value159), await chrome.alarms.clear(SCAN_TIMEOUT_ALARM), await createRunAlarm(_value159, NEXT_ALARM, {
        "when": Date.now() + RECONNECT_RETRY_MS
      }), await setStatus("\u0627\u0646\u0642\u0637\u0639 \u0627\u062A\u0635\u0627\u0644 \u0627\u0644\u0625\u0646\u062A\u0631\u0646\u062A \u0623\u062B\u0646\u0627\u0621 \u0627\u0644\u062D\u0635\u0629 " + _value159.period + "\u061B \u0623\u0648\u0642\u0641 \u0645\u0631\u0635\u0627\u062F \u062A\u0633\u062C\u064A\u0644 \u0646\u062A\u064A\u062C\u0629 \u0645\u0624\u0642\u062A\u0629 \u0648\u0633\u064A\u0633\u062A\u0623\u0646\u0641 \u0645\u0646 \u0627\u0644\u0645\u0639\u0644\u0645 \u063A\u064A\u0631 \u0627\u0644\u0645\u0643\u062A\u0645\u0644 \u0639\u0646\u062F \u0639\u0648\u062F\u0629 \u0627\u0644\u0627\u062A\u0635\u0627\u0644.", {
        "period": _value159.period,
        "waiting": true,
        "waitingForReconnect": true
      });
      return;
    }
    const _value163 = await captureTimeoutDiagnostic(_value159, _value160),
      _value164 = await getRun();
    if (!_value164?.["running"] || _value164.current?.["scanId"] !== _value160.scanId) return;
    const _value165 = await chrome.storage.local.get("mirsadEvidenceRecords"),
      _value166 = (_value165.mirsadEvidenceRecords || []).find(_argument112 => _argument112.scanId === _value160.scanId && _argument112.status === "absent" && _argument112.evidenceVerified === true && Number(_argument112.period) === Number(_value159.period));
    if (_value166) {
      await receiveResult({
        "scanId": _value160.scanId,
        "result": {
          "status": "absent",
          "teacher": _value166.teacher,
          "evidenceTeacher": _value166.teacher,
          "detail": "\u063A\u0627\u0626\u0628: \u0625\u062B\u0628\u0627\u062A \u0627\u0644\u0645\u0646\u0638\u0651\u0645 \u0636\u0645\u0646 \u0627\u0644\u0645\u062F\u0639\u0648\u064A\u0646 \u0645\u062D\u0641\u0648\u0638 \u0648\u0645\u062A\u062D\u0642\u0642 \u0645\u0646\u0647 \u0644\u0646\u0641\u0633 \u0627\u0644\u0641\u062D\u0635."
        }
      });
      return;
    }
    await receiveResult({
      "scanId": _value160.scanId,
      "result": {
        "status": "unresolved",
        "teacher": _value160.teacher,
        "detail": "\u062A\u0639\u0630\u0631 \u0625\u0643\u0645\u0627\u0644 \u0641\u062D\u0635 Teams \u062E\u0644\u0627\u0644 \u0645\u0647\u0644\u0629 \u0627\u0644\u062A\u062D\u0645\u064A\u0644 \u0648\u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645 (90 \u062B\u0627\u0646\u064A\u0629). " + (_value163.ok ? "\u062D\u064F\u0641\u0638\u062A \u0635\u0648\u0631\u0629 \u062A\u0634\u062E\u064A\u0635\u064A\u0629 \u0628\u0627\u0633\u0645 \u0627\u0644\u0645\u0639\u0644\u0645 \u0648\u0627\u0644\u062D\u0635\u0629." : "\u062A\u0639\u0630\u0631 \u062D\u0641\u0638 \u0627\u0644\u0635\u0648\u0631\u0629 \u0627\u0644\u062A\u0634\u062E\u064A\u0635\u064A\u0629: " + _value163.error)
      }
    });
    return;
  }
  if (_argument110.name !== NEXT_ALARM) return;
  if (_value159.immediateMode) {
    await navigateCurrent(_value159);
    return;
  }
  if (_value159.waitingForReconnect) {
    if (typeof navigator !== "undefined" && navigator.onLine === false) {
      await createRunAlarm(_value159, NEXT_ALARM, {
        "when": Date.now() + RECONNECT_RETRY_MS
      });
      return;
    }
    await recoverPersistedRunAfterBrowserStart();
    return;
  }
  if (_value159.period) {
    const _value167 = PERIODS.find(_argument113 => _argument113.n === _value159.period);
    if (_value167 && Date.now() < periodBounds(_value167, new Date(), "past").end.getTime()) {
      if (_value159.waitingForCycle2) {
        const _value168 = new Date(),
          _value169 = periodBounds(_value167, _value168, "past"),
          _value170 = periodNow(_value168);
        if (!_value169 || _value168.getTime() < _value169.start.getTime() || _value168.getTime() >= _value169.end.getTime() || !_value170 || _value170.n !== _value167.n) {
          _value159.waitingForCycle2 = false;
          if (!(await saveRun(_value159))) return;
          await setStatus("\u0623\u064F\u0644\u063A\u064A\u062A \u0627\u0644\u062F\u0648\u0631\u0629 \u0627\u0644\u062A\u0627\u0644\u064A\u0629 \u0644\u0644\u062D\u0635\u0629 " + _value167.n + " \u0644\u0623\u0646 \u0627\u0644\u0648\u0642\u062A \u0627\u0644\u062D\u0627\u0644\u064A \u0644\u0645 \u064A\u0639\u062F \u062F\u0627\u062E\u0644 \u0646\u0627\u0641\u0630\u0629 \u0627\u0644\u062D\u0635\u0629 \u0646\u0641\u0633\u0647\u0627.", {
            "period": _value167.n,
            "cycle": 1,
            "cycle2Skipped": true
          }), await advancePeriod(_value159, _value167.n);
          return;
        }
        if (CloudMonitoring.pullRemoteLinks) {
          try {
            await CloudMonitoring.pullRemoteLinks();
          } catch (_value171) {
            await setStatus("\u062A\u0639\u0630\u0631 \u062A\u062D\u062F\u064A\u062B \u0631\u0648\u0627\u0628\u0637 \u0627\u0644\u062C\u0648\u0627\u0644\u061B \u064A\u0633\u062A\u0645\u0631 \u0627\u0644\u0631\u0635\u062F \u0628\u0627\u0644\u0631\u0648\u0627\u0628\u0637 \u0627\u0644\u0645\u062D\u0641\u0648\u0638\u0629. " + String(_value171.message));
          }
          const _value172 = await getRun();
          if (!_value172?.["running"] || _value172.paused || _value172.period !== _value159.period || _value172.cycle !== _value159.cycle || !_value172.waitingForCycle2) return;
          Object.assign(_value159, _value172);
        }
        _value159.waitingForCycle2 = false, _value159.nextCycleAt = null, _value159.cycle = Math.min(_value159.cycle + 1, scheduleSettings.roundCount), _value159.index = 0, _value159.periodItems = scheduleCore.selectPeriodItems(_value159.schedule, _value159.period);
        if (!(await saveRun(_value159))) return;
        await setStatus("\u0628\u062F\u0623\u062A \u0627\u0644\u062F\u0648\u0631\u0629 " + _value159.cycle + " \u0644\u0644\u062D\u0635\u0629 " + _value167.n + " \u0628\u0639\u062F \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u0631\u0642\u0645 \u0627\u0644\u062D\u0635\u0629 \u0648\u0648\u0642\u062A\u0647\u0627.", {
          "period": _value167.n,
          "cycle": _value159.cycle,
          "done": 0,
          "total": _value159.periodItems.length
        }), await navigateCurrent(_value159);
        return;
      }
      !_value159.current && _value159.index === 0 && (_value159.cycle || 1) === 1 ? await beginPeriod(_value159, _value159.period) : await navigateCurrent(_value159);
      return;
    }
    await advancePeriod(_value159, _value159.period);
    return;
  }
  const _value173 = new Date(),
    _value174 = periodNow(_value173);
  if (_value174) await beginPeriod(_value159, _value174.n);else {
    const _value175 = nextPeriod(_value173);
    await setStatus("\u0644\u0627 \u062A\u0648\u062C\u062F \u062D\u0635\u0629 \u0646\u0634\u0637\u0629 \u0627\u0644\u0622\u0646. \u0627\u0644\u0648\u0642\u062A \u0627\u0644\u062D\u0627\u0644\u064A " + _value173.toLocaleTimeString("en-GB", {
      "hour": "2-digit",
      "minute": "2-digit"
    }) + ". \u0623\u0642\u0631\u0628 \u0645\u0648\u0639\u062F: \u0627\u0644\u062D\u0635\u0629 " + _value175.period.n + " \u0639\u0646\u062F " + _value175.period.start + ".", {
      "waiting": true,
      "period": _value175.period.n,
      "now": _value173.toISOString(),
      "nextAt": _value175.when,
      "periods": PERIODS
    }), await createRunAlarm(_value159, NEXT_ALARM, {
      "when": _value175.when
    });
  }
});
let recoveryInProgress = null;
function recoverPersistedRunAfterBrowserStart() {
  if (recoveryInProgress) return recoveryInProgress;
  const _value176 = recoverSavedProgress();
  return recoveryInProgress = _value176, _value176["finally"](() => {
    if (recoveryInProgress === _value176) recoveryInProgress = null;
  })["catch"](() => {}), _value176;
}
async function recoverSavedProgress() {
  await refreshScheduleSettings();
  const _value177 = await getRun();
  if (!_value177?.["running"] || _value177.autoResume === false) return;
  try {
    await MirsadCommercialAccount.assertActive(), await CloudMonitoring.assertSelected(_value177);
    if (!(await isRunCurrent(_value177))) return;
  } catch (_value178) {
    if (!(await isRunCurrent(_value177))) return;
    if (MirsadCommercialAccount.transient(_value178)) {
      const _value179 = await getRun();
      if (!_value179?.["running"] || _value179.paused) return;
      _value179.waitingForReconnect = true;
      if (!(await saveRun(_value179))) return;
      await createRunAlarm(_value177, NEXT_ALARM, {
        "when": Date.now() + 15000
      }), await setStatus("\u062A\u0623\u062E\u0631 \u0627\u0644\u0627\u062A\u0635\u0627\u0644 \u0628\u062E\u062F\u0645\u0629 \u0631\u0627\u0635\u062F\u061B \u0627\u0644\u062A\u0642\u062F\u0645 \u0645\u062D\u0641\u0648\u0638 \u0648\u0633\u062A\u062A\u0645 \u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0645\u062D\u0627\u0648\u0644\u0629 \u062A\u0644\u0642\u0627\u0626\u064A\u064B\u0627.", {
        "waiting": true,
        "waitingForReconnect": true
      });
      return;
    }
    await pauseMonitoring(), await setStatus(_value178.message);
    return;
  }
  const _value180 = chrome.alarms.get ? await chrome.alarms.get(NEXT_ALARM) : null,
    _value181 = periodNow(new Date()),
    _value182 = _value181 ? periodBounds(_value181, new Date(), "active") : null,
    _value183 = _value177.periodStartedAt || _value177.current?.["scanDeadlineAt"] || _value177.results?.[_value177.results.length - 1]?.["scannedAt"] || _value177.startedAt,
    _value184 = _value181 && _value181.n === _value177.period && Number.isFinite(_value183) && _value183 >= _value182.start.getTime() && _value183 < _value182.end.getTime();
  await chrome.alarms.clear(NEXT_ALARM), await chrome.alarms.clear(SCAN_TIMEOUT_ALARM);
  if (_value184 && _value177.current && (_value177.results || []).some(_argument114 => _argument114.scanId === _value177.current.scanId)) {
    const _value185 = _value177.results.find(_argument115 => _argument115.scanId === _value177.current.scanId);
    !_value177.testMode && !_value177.backtestMode && (await appendDailyReport(_value185), await LocalBackup.enqueue(_value185)["catch"](() => {}), await CloudMonitoring.record(_value177, _value185)["catch"](() => {}));
    _value177.index++, _value177.current = null;
    if (!(await saveRun(_value177))) return;
  }
  if (_value184 && _value177.current) {
    const _value186 = await chrome.storage.local.get("mirsadEvidenceRecords"),
      _value187 = (_value186.mirsadEvidenceRecords || []).find(_argument116 => _argument116.scanId === _value177.current.scanId && _argument116.status === "absent" && _argument116.evidenceVerified === true && Number(_argument116.period) === Number(_value177.period));
    if (_value187) {
      await receiveResult({
        "scanId": _value177.current.scanId,
        "result": {
          "status": "absent",
          "teacher": _value187.teacher,
          "evidenceTeacher": _value187.teacher,
          "detail": "\u063A\u0627\u0626\u0628: \u0627\u0633\u062A\u0639\u064A\u062F \u0625\u062B\u0628\u0627\u062A \u0627\u0644\u063A\u064A\u0627\u0628 \u0627\u0644\u0645\u062D\u0641\u0648\u0638 \u0642\u0628\u0644 \u0627\u0644\u0627\u0646\u0642\u0637\u0627\u0639 \u0644\u0646\u0641\u0633 \u0627\u0644\u0645\u0639\u0644\u0645 \u0648\u0627\u0644\u0641\u062D\u0635."
        }
      });
      return;
    }
  }
  _value177.current = null, _value177.waitingForReconnect = false, await closeProbeTab(_value177);
  if (typeof navigator !== "undefined" && navigator.onLine === false) {
    _value177.waitingForReconnect = true;
    if (!(await saveRun(_value177))) return;
    await createRunAlarm(_value177, NEXT_ALARM, {
      "when": Date.now() + RECONNECT_RETRY_MS
    }), await setStatus("\u0627\u0644\u062A\u0642\u062F\u0645 \u0645\u062D\u0641\u0648\u0638\u061B \u064A\u0646\u062A\u0638\u0631 \u0645\u0631\u0635\u0627\u062F \u0639\u0648\u062F\u0629 \u0627\u0644\u0627\u062A\u0635\u0627\u0644 \u0644\u0627\u0633\u062A\u0626\u0646\u0627\u0641 \u0627\u0644\u0631\u0635\u062F \u062F\u0648\u0646 \u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0646\u062A\u0627\u0626\u062C.");
    return;
  }
  if (_value181) {
    if (!_value184) {
      await beginPeriod(_value177, _value181.n);
      return;
    }
    _value177.periodStartedAt = _value182.start.getTime();
    if (!(await saveRun(_value177))) return;
    await setStatus("\u0627\u0633\u062A\u0623\u0646\u0641 \u0631\u0627\u0635\u062F \u0645\u0646 \u0645\u0648\u0636\u0639 \u0627\u0644\u062A\u0648\u0642\u0641: \u0627\u0644\u062D\u0635\u0629 " + _value177.period + "\u060C \u0627\u0644\u062F\u0648\u0631\u0629 " + _value177.cycle + "\u060C \u0627\u0643\u062A\u0645\u0644 " + _value177.index + " \u0645\u0646 " + _value177.periodItems.length + " \u0645\u0639\u0644\u0645\u064B\u0627.", {
      "period": _value177.period,
      "cycle": _value177.cycle,
      "done": _value177.index,
      "recovered": true
    });
    if (_value177.waitingForCycle2) {
      const _value188 = _value177.nextCycleAt || _value180?.["scheduledTime"] || Date.now();
      await createRunAlarm(_value177, NEXT_ALARM, {
        "when": Math.max(Date.now() + 1000, _value188)
      });
      return;
    }
    const _value189 = _value182.start.getTime() + scheduleSettings.scanDelay * 60000;
    if (_value177.index === 0 && _value177.cycle === 1 && Date.now() < _value189) {
      await createRunAlarm(_value177, NEXT_ALARM, {
        "when": _value189
      });
      return;
    }
    await navigateCurrent(_value177);
    return;
  }
  if (!(await saveRun(_value177))) return;
  const _value190 = nextPeriod(new Date());
  await createRunAlarm(_value177, NEXT_ALARM, {
    "when": _value190.when
  }), await setStatus("\u0627\u0644\u062A\u0642\u062F\u0645 \u0645\u062D\u0641\u0648\u0638\u061B \u064A\u0646\u062A\u0638\u0631 \u0631\u0627\u0635\u062F \u0627\u0644\u062D\u0635\u0629 " + _value190.period.n + " \u062F\u0648\u0646 \u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u062D\u0635\u0635 \u0627\u0644\u0645\u0643\u062A\u0645\u0644\u0629.", {
    "period": _value190.period.n,
    "waiting": true,
    "recovered": true
  });
}
chrome.tabs.onRemoved?.["addListener"](_argument117 => {
  (async () => {
    const _value191 = await getRun();
    if (!_value191?.["running"] || _value191.immediateMode || !_value191.current || _value191.tabId !== _argument117) return;
    _value191.tabId = null, _value191.probeTabIds = [], _value191.waitingForReconnect = true;
    if (!(await saveRun(_value191))) return;
    await chrome.alarms.clear(SCAN_TIMEOUT_ALARM), await createRunAlarm(_value191, NEXT_ALARM, {
      "when": Date.now() + 1000
    }), await setStatus("\u0623\u064F\u063A\u0644\u0642\u062A \u0635\u0641\u062D\u0629 \u0627\u0644\u0641\u062D\u0635\u061B \u0627\u0644\u062A\u0642\u062F\u0645 \u0645\u062D\u0641\u0648\u0638 \u0648\u0633\u064A\u064F\u0633\u062A\u0623\u0646\u0641 \u0627\u0644\u0645\u0639\u0644\u0645 \u063A\u064A\u0631 \u0627\u0644\u0645\u0643\u062A\u0645\u0644 \u062A\u0644\u0642\u0627\u0626\u064A\u064B\u0627.");
  })()["catch"](() => {});
}), chrome.runtime.onStartup?.["addListener"](() => {
  recoverPersistedRunAfterBrowserStart()["catch"](() => {});
}), chrome.runtime.onInstalled?.["addListener"](() => {
  (async () => {
    await MirsadClassicReady;
    const _value192 = await getRun();
    try {
      await CloudMonitoring.assertSelected(_value192?.["running"] || _value192?.["paused"] ? _value192 : null);
    } catch (_value193) {
      if (_value192?.["running"]) await pauseMonitoring();
      await setStatus(_value193.message);
    }
  })()["catch"](() => {});
});
async function labelEvidenceCapture(_argument118, _argument119, _argument120, _argument121, _argument122) {
  const _value194 = await createImageBitmap(await (await fetch(_argument118)).blob());
  try {
    const _value195 = new OffscreenCanvas(Math.max(_value194.width, 600), _value194.height + 100),
      _value196 = _value195.getContext("2d");
    if (!_value196) throw new Error("Unable to annotate evidence");
    _value196.fillStyle = "#ffffff", _value196.fillRect(0, 0, _value195.width, _value195.height), _value196.drawImage(_value194, 0, 0);
    const _value197 = String(_argument119 || "\u0645\u0639\u0644\u0645") + " \u2014 " + (_argument120 === "absent" ? "\u063A\u0627\u0626\u0628" : "\u063A\u064A\u0631 \u0645\u062D\u0633\u0648\u0645");
    _value196.fillStyle = _argument120 === "absent" ? "#991b1b" : "#854d0e", _value196.fillRect(0, _value194.height, _value195.width, 100), _value196.fillStyle = "#ffffff", _value196.direction = "rtl", _value196.textAlign = "right", _value196.textBaseline = "top", _value196.font = "bold 28px Arial", _value196.fillText(_value197, _value195.width - 20, _value194.height + 14, _value195.width - 40), _value196.font = "18px Arial", _value196.fillText("\u0627\u0644\u062D\u0635\u0629 " + String(_argument121 || "") + " \u2014 \u0627\u0644\u062F\u0648\u0631\u0629 " + String(_argument122 || "") + " \u2014 " + new Date().toLocaleString("ar-SA"), _value195.width - 20, _value194.height + 59, _value195.width - 40);
    const _value198 = new Uint8Array(await (await _value195.convertToBlob({
      "type": "image/png"
    })).arrayBuffer());
    let _text = "";
    for (let _number3 = 0; _number3 < _value198.length; _number3 += 32768) _text += String.fromCharCode(..._value198.subarray(_number3, _number3 + 32768));
    return "data:image/png;base64," + btoa(_text);
  } finally {
    _value194.close();
  }
}
async function waitForEvidenceDownload(_argument123) {
  for (let _number4 = 0; _number4 < 40; _number4++) {
    const [_value199] = await chrome.downloads.search({
      "id": _argument123
    });
    if (_value199?.["state"] === "complete") return _value199;
    if (_value199?.["state"] === "interrupted") throw new Error(_value199.error || "Evidence download interrupted");
    await new Promise(_argument124 => setTimeout(_argument124, 250));
  }
  throw new Error("Evidence download did not complete");
}
async function captureTimeoutDiagnostic(_argument125, _argument126) {
  const _items5 = [...new Set([...(_argument125.probeTabIds || []), _argument125.tabId].filter(Number.isInteger))];
  for (const _value200 of _items5) {
    try {
      const _value201 = await chrome.tabs.get(_value200),
        _value202 = (await chrome.tabs.query({
          "active": true,
          "windowId": _value201.windowId
        }))[0];
      if (_value202?.["id"] !== _value200) continue;
      if (!/^https:\/\/(?:teams\.microsoft\.com|teams\.live\.com)\//i.test(_value201.url || "")) continue;
      return await captureEvidenceForScan({
        "scanId": _argument126.scanId,
        "teacher": _argument126.teacher,
        "period": _argument125.period,
        "status": "unresolved",
        "detail": "\u0645\u0647\u0644\u0629 Teams \u0627\u0646\u062A\u0647\u062A \u062F\u0648\u0646 \u0627\u0643\u062A\u0645\u0627\u0644 \u0627\u0644\u062A\u062D\u0642\u0642\u061B \u0644\u0642\u0637\u0629 \u062A\u0634\u062E\u064A\u0635\u064A\u0629 \u0648\u0644\u064A\u0633\u062A \u062F\u0644\u064A\u0644 \u063A\u064A\u0627\u0628."
      }, {
        "tab": _value201
      });
    } catch {}
  }
  return {
    "ok": false,
    "error": "\u0644\u0645 \u064A\u062A\u0648\u0641\u0631 \u062A\u0628\u0648\u064A\u0628 Teams \u0646\u0634\u0637 \u062A\u0627\u0628\u0639 \u0644\u0647\u0630\u0627 \u0627\u0644\u0641\u062D\u0635\u061B \u0644\u0645 \u062A\u064F\u0635\u0648\u0651\u0631 \u0635\u0641\u062D\u0629 \u0623\u062E\u0631\u0649"
  };
}
const evidenceCaptureQueues = new Map();
function captureEvidenceForScan(_argument127, _argument128) {
  const _value203 = String(_argument127.scanId || ""),
    _value204 = (evidenceCaptureQueues.get(_value203) || Promise.resolve())["catch"](() => {}).then(() => performEvidenceCapture(_argument127, _argument128));
  evidenceCaptureQueues.set(_value203, _value204);
  const _value205 = () => {
    if (evidenceCaptureQueues.get(_value203) === _value204) evidenceCaptureQueues["delete"](_value203);
  };
  return _value204.then(_value205, _value205), _value204;
}
async function performEvidenceCapture(_argument129, _argument130) {
  const _value206 = _argument129.evidence,
    _value207 = _argument129.status === "absent",
    _value208 = _argument129.status === "unresolved";
  if (!_value207 && !_value208 || !_argument130.tab?.["id"] || !_argument130.tab?.["windowId"] || _value207 && (_value206?.["verified"] !== true || _value206?.["teacherInInvitees"] !== true || _value206?.["teacherNotPresent"] !== true || _value206?.["inviteesReadable"] !== true)) return {
    "ok": false
  };
  try {
    const _value209 = await getRun();
    if (!_value209?.["running"] || _value209.current?.["scanId"] !== _argument129.scanId || ![_value209.tabId, ...(_value209.probeTabIds || [])].includes(_argument130.tab.id)) return {
      "ok": false,
      "error": "Stale or unrelated scan"
    };
    if (_value208) {
      const _value210 = await chrome.storage.local.get("mirsadEvidenceRecords"),
        _value211 = (_value210.mirsadEvidenceRecords || []).find(_argument131 => _argument131.scanId === _argument129.scanId && _argument131.status === "absent" && _argument131.evidenceVerified === true && Number(_argument131.period) === Number(_argument129.period));
      if (_value211) return {
        "ok": true,
        "filename": _value211.filename,
        "proofAlreadySaved": true
      };
    }
    _argument130.tab = await MirsadWorkspace.prepareCapture(_argument130.tab.id);
    if (chrome.windows?.["update"]) await chrome.windows.update(_argument130.tab.windowId, {
      "focused": true
    });
    const [_value212, _value213] = await Promise.all([chrome.tabs.query({
      "active": true,
      "windowId": _argument130.tab.windowId
    }).then(_argument132 => _argument132[0]), chrome.tabs.get(_argument130.tab.id)]);
    if (_value212?.["id"] !== _argument130.tab.id || !/^https:\/\/(?:teams\.microsoft\.com|teams\.live\.com)\//i.test(_value213.url || "")) return {
      "ok": false,
      "error": "Teams tab is not active"
    };
    const _value214 = await MirsadWorkspace.captureTeams(_argument130.tab.id, _argument129.scanId),
      _value215 = await labelEvidenceCapture(_value214, _argument129.teacher, _argument129.status, _argument129.period, _value209.cycle),
      _value216 = Date.now(),
      _value217 = String(_argument129.teacher || "\u0645\u0639\u0644\u0645").replace(/[\\/:*?"<>|]/g, "_").slice(0, 70),
      _value218 = "Data Copy/\u062A\u0648\u062B\u064A\u0642 \u063A\u064A\u0627\u0628 " + MirsadMonitorModel.day(new Date(_value216)) + "/" + _value217 + "_" + (_value207 ? "\u063A\u0627\u0626\u0628" : "\u063A\u064A\u0631_\u0645\u062D\u0633\u0648\u0645") + "_\u062D" + String(_argument129.period || "").replace(/[^0-9]/g, "") + "_" + new Date(_value216).toISOString().replace(/[:.]/g, "-") + ".png";
    await LocalBackup.enqueue({
      "scanId": _argument129.scanId,
      "teacher": _argument129.teacher,
      "scheduledTeacher": _value209.current.teacher,
      "period": _value209.period,
      "cycle": _value209.cycle,
      "status": _argument129.status,
      "detail": _argument129.detail || "",
      "scannedAt": _value216
    }, _value215, _value218.split("/").pop(), true);
    const _value219 = _value218;
    await CloudMonitoring.capture(_value209, _argument129, _value215, _value216, _value219);
    const _text2 = "mirsadEvidenceRecords";
    return await mutateEvidenceRecords(_argument133 => {
      return _argument133.push({
        "teacher": _argument129.teacher || "",
        "period": _argument129.period || "",
        "status": _argument129.status,
        "detail": _argument129.detail || "",
        "capturedAt": _value216,
        "filename": _value219,
        "localBackupPending": true,
        "scanId": _argument129.scanId || "",
        "evidenceVerified": _value207,
        "tabId": _argument130.tab.id,
        "tabUrl": _value213.url
      }), _argument133.slice(-1000);
    }), void LocalBackup.flush()["catch"](() => {}), {
      "ok": true,
      "filename": "\u0645\u062D\u0641\u0648\u0638 \u0641\u064A \u0637\u0627\u0628\u0648\u0631 \u0627\u0644\u0645\u062F\u0631\u0633\u0629 \u0644\u0644\u0631\u0641\u0639 \u0625\u0644\u0649 \u0642\u0648\u0642\u0644: " + _value219
    };
  } catch (_value220) {
    return {
      "ok": false,
      "error": String(_value220?.["message"] || _value220)
    };
  }
}
chrome.runtime.onMessage.addListener((_argument134, _argument135, _argument136) => {
  if (_argument134?.["type"] === "MIRSAD_CURRENT_MISSING_LINKS") {
    if (_argument135.url?.["split"]("?")[0] !== chrome.runtime.getURL("link-completion.html")) return _argument136({
      "ok": false,
      "error": "\u0645\u0635\u062F\u0631 \u063A\u064A\u0631 \u0645\u0633\u0645\u0648\u062D"
    }), false;
    return CloudMonitoring.missingLinkState().then(_argument136)["catch"](_argument137 => _argument136({
      "ok": false,
      "error": _argument137.message
    })), true;
  }
  if (_argument134?.["type"] === "MIRSAD_APPLY_MISSING_LINKS") {
    const _value221 = chrome.runtime.getURL("link-completion.html");
    if (_argument135.url?.["split"]("?")[0] !== _value221) return _argument136({
      "ok": false,
      "error": "\u0645\u0635\u062F\u0631 \u063A\u064A\u0631 \u0645\u0633\u0645\u0648\u062D"
    }), false;
    return CloudMonitoring.applyMissingReport(_argument134.reportId).then(_argument136)["catch"](_argument138 => _argument136({
      "ok": false,
      "error": _argument138.message
    })), true;
  }
  if (_argument134?.["type"] === "MIRSAD_MANUAL_LESSON_LINK") {
    if (!_argument135.tab || !/^https:\/\/mirsad-school\.onrender\.com\/automatic-monitoring\.html(?:[?#]|$)/.test(_argument135.tab.url || "")) return _argument136({
      "ok": false,
      "error": "\u0645\u0635\u062F\u0631 \u063A\u064A\u0631 \u0645\u0633\u0645\u0648\u062D"
    }), false;
    return CloudMonitoring.manualLessonLink(_argument134.payload || {}).then(_argument136)["catch"](_argument139 => _argument136({
      "ok": false,
      "error": _argument139.message
    })), true;
  }
  if (_argument134?.["type"] === "MIRSAD_CLASSIC_MATCH") {
    let _value222 = false;
    try {
      const _value223 = new URL(_argument135?.["tab"]?.["url"]);
      _value222 = _value223.origin === "https://mirsad-school.onrender.com" && _value223.pathname === "/schools/automatic-monitoring.html";
    } catch {}
    if (!_value222) return _argument136({
      "ok": false
    }), false;
    return CloudMonitoring.syncVisible(_argument134.reference).then(_argument136)["catch"](_argument140 => _argument136({
      "ok": false,
      "error": _argument140.message
    })), true;
  }
  if (_argument134?.["type"] === "MIRSAD_PURGED_DAY") {
    let _value224 = false;
    try {
      const _value225 = new URL(_argument135?.["tab"]?.["url"]);
      _value224 = _value225.origin === "https://mirsad-school.onrender.com" && _value225.pathname === "/schools/automatic-monitoring.html";
    } catch {}
    if (!_value224) return _argument136({
      "ok": false
    }), false;
    return CloudMonitoring.resetAfterPurge(_argument134.date, _argument134.requestId).then(_argument136)["catch"](_argument141 => _argument136({
      "ok": false,
      "error": _argument141.message
    })), true;
  }
  if (_argument134?.["type"] === "MIRSAD_DASHBOARD_ROUNDS") return (async () => {
    const _value226 = Number(_argument134.count),
      _value227 = Number(_argument134.gap),
      _value228 = Number(_argument134.thirdGap ?? 5);
    if (!Number.isInteger(_value228) || _value228 < 1 || _value228 > 10 || !Number.isInteger(_value226) || _value226 < 1 || _value226 > 3 || !Number.isInteger(_value227) || _value227 < 1 || _value227 > 10) throw new Error("\u0627\u062E\u062A\u0631 \u0645\u0646 \u062F\u0648\u0631\u0629 \u0625\u0644\u0649 \u062B\u0644\u0627\u062B\u060C \u0648\u0643\u0644 \u0641\u0627\u0635\u0644 \u0645\u0646 1 \u0625\u0644\u0649 10 \u062F\u0642\u0627\u0626\u0642");
    const _value229 = await getRun();
    if (_value229?.["running"]) throw new Error("\u0623\u0648\u0642\u0641 \u0627\u0644\u0631\u0635\u062F \u0642\u0628\u0644 \u062A\u063A\u064A\u064A\u0631 \u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A");
    const _value230 = (await chrome.storage.local.get("mirsadDriveDay")).mirsadDriveDay;
    await refreshScheduleSettings(), scheduleSettings = {
      ...scheduleSettings,
      "roundCount": _value226,
      "configuredRoundCount": _value226,
      "roundGapMinutes": _value227,
      "thirdRoundGapMinutes": _value228
    }, await chrome.storage.local.set({
      [SCHEDULE_SETTINGS_KEY]: scheduleSettings
    }), _argument136({
      "ok": true
    });
  })()["catch"](_argument142 => _argument136({
    "ok": false,
    "error": _argument142.message
  })), true;
  if (_argument134?.["type"] === "MIRSAD_REFRESH_REMOTE_LINKS") return CloudMonitoring.pullRemoteLinks().then(() => _argument136({
    "ok": true
  }))["catch"](_argument143 => _argument136({
    "ok": false,
    "error": _argument143.message
  })), true;
  if (_argument134?.["type"] === "MIRSAD_SCAN_ACTIVITY") return MirsadScanActivity.info().then(_argument136)["catch"](() => _argument136({
    "ok": false
  })), true;
  if (_argument134?.["type"] === "MIRSAD_LOCAL_BACKUP_INFO") return LocalBackup.info().then(_argument136)["catch"](_argument144 => _argument136({
    "ok": false,
    "error": String(_argument144.message)
  })), true;
  if (_argument134?.["type"] === "MIRSAD_LOCAL_BACKUP_CHECK") return LocalBackup.check().then(_argument136), true;
  if (_argument134?.["type"] === "MIRSAD_LOCAL_BACKUP_RETRY") return LocalBackup.flush().then(() => LocalBackup.info()).then(_argument136), true;
  if (_argument134?.["type"] === "MIRSAD_DRIVE_CONFIG") return CloudMonitoring.configure(String(_argument134.url || ""), String(_argument134.key || "")).then(_argument136)["catch"](_argument145 => _argument136({
    "ok": false,
    "error": _argument145.message
  })), true;
  if (_argument134?.["type"] === "MIRSAD_SERVICE_URL") {
    let _value231 = false;
    try {
      const _value232 = new URL(_argument135?.["tab"]?.["url"]);
      _value231 = _value232.origin === "https://mirsad-school.onrender.com" && _value232.pathname === "/schools/automatic-monitoring.html";
    } catch {}
    if (!_value231) return _argument136({
      "ok": false
    }), false;
    return chrome.storage.local.get("mirsadDriveConfig").then(_argument146 => _argument136({
      "ok": true,
      "url": _argument146.mirsadDriveConfig?.["url"] || null
    })), true;
  }
  if (_argument134?.["type"] === "MIRSAD_BEGIN_DAY") return CloudMonitoring.beginDay().then(_argument147 => _argument136({
    "ok": true,
    "day": _argument147
  }))["catch"](_argument148 => _argument136({
    "ok": false,
    "error": _argument148.message
  })), true;
  if (_argument134?.["type"] === "MIRSAD_DRIVE_INFO") return CloudMonitoring.info().then(_argument149 => _argument136({
    "ok": true,
    ..._argument149
  })), true;
  if (_argument134?.["type"] === "MIRSAD_DRIVE_RETRY") return CloudMonitoring.flush().then(() => _argument136({
    "ok": true
  })), true;
  if (_argument134?.["type"] === "MIRSAD_START") return startMonitoring(false).then(() => _argument136({
    "ok": true
  }))["catch"](async _argument150 => {
    await setStatus("\u0644\u0645 \u064A\u0628\u062F\u0623 \u0627\u0644\u0631\u0635\u062F: " + String(_argument150.message)), _argument136({
      "ok": false,
      "error": String(_argument150.message)
    });
  }), true;
  if (_argument134?.["type"] === "MIRSAD_START_NOW") return startMonitoring(true).then(() => _argument136({
    "ok": true
  }))["catch"](() => _argument136({
    "ok": false
  })), true;
  if (["MIRSAD_PAUSE", "MIRSAD_RESUME", "MIRSAD_STOP"].includes(_argument134?.["type"])) {
    const _value233 = _argument134.type === "MIRSAD_PAUSE" ? pauseMonitoring : _argument134.type === "MIRSAD_RESUME" ? resumeMonitoring : stopAndResetMonitoring;
    return _value233().then(_argument136)["catch"](_argument151 => _argument136({
      "ok": false,
      "error": String(_argument151.message)
    })), true;
  }
  if (_argument134?.["type"] === "MIRSAD_STATUS") return Promise.all([chrome.storage.local.get(STATUS_KEY), getRun()]).then(([_argument152, _argument153]) => _argument136({
    "status": _argument152[STATUS_KEY] || {
      "text": "\u0644\u0627 \u062A\u0648\u062C\u062F \u062D\u0627\u0644\u0629"
    },
    "run": _argument153
  })), true;
  if (_argument134?.["type"] === "MIRSAD_GET_LIVE_REPORT") return (async () => {
    await refreshScheduleSettings();
    const [_value234, _value235] = await Promise.all([getRun(), chrome.storage.local.get([DAILY_REPORT_KEY, "mirsadManualAttendanceOverrides", "mirsadManualMappings", SCHEDULE_SETTINGS_KEY])]);
    let _items6 = [],
      _items7 = [];
    const _value236 = await getScheduleTab();
    if (_value236) try {
      const _value237 = await loadPeriodsFromSchedule(_value236.id);
      _items6 = _value237.items, _items7 = _value237.periods;
    } catch (_value238) {}
    _argument136({
      "ok": true,
      "run": _value234 || {},
      "schedule": _items6,
      "dailyReports": _value235[DAILY_REPORT_KEY] || {},
      "manualOverrides": _value235.mirsadManualAttendanceOverrides || {},
      "manualMappings": _value235.mirsadManualMappings || {},
      "scheduleSettings": _value235[SCHEDULE_SETTINGS_KEY] || DEFAULT_SCHEDULE_SETTINGS,
      "periods": _items7
    });
  })()["catch"](() => _argument136({
    "ok": false
  })), true;
  if (_argument134?.["type"] === "MIRSAD_SAVE_SCHEDULE_SETTINGS" || _argument134?.["type"] === "MIRSAD_DASHBOARD_SCHEDULE") return (async () => {
    const _value239 = _argument134.settings || {},
      _options5 = {
        "manualStart": String(_value239.manualStart || ""),
        "periodDuration": Number(_value239.periodDuration),
        "manualGapMinutes": Number(_value239.manualGapMinutes),
        "periodCount": 7,
        "scanDelay": Number(_value239.scanDelay),
        "roundCount": Number(_value239.roundCount),
        "roundGapMinutes": Number(_value239.roundGapMinutes),
        "thirdRoundGapMinutes": Number(_value239.thirdRoundGapMinutes ?? scheduleSettings.thirdRoundGapMinutes ?? 5),
        "startPeriod": Number(_value239.startPeriod ?? scheduleSettings.startPeriod ?? 1),
        "endPeriod": Number(_value239.endPeriod ?? scheduleSettings.endPeriod ?? 7)
      };
    if (!Number.isInteger(_options5.thirdRoundGapMinutes) || _options5.thirdRoundGapMinutes < 1 || _options5.thirdRoundGapMinutes > 10 || !Number.isInteger(_options5.startPeriod) || !Number.isInteger(_options5.endPeriod) || _options5.startPeriod < 1 || _options5.endPeriod > 7 || _options5.startPeriod > _options5.endPeriod || parseClock(_options5.manualStart) === null || !Number.isInteger(_options5.periodDuration) || _options5.periodDuration < 1 || _options5.periodDuration > 180 || !Number.isInteger(_options5.manualGapMinutes) || _options5.manualGapMinutes < 0 || _options5.manualGapMinutes > 60 || !Number.isInteger(_options5.scanDelay) || _options5.scanDelay < 1 || _options5.scanDelay > 10 || !Number.isInteger(_options5.roundCount) || _options5.roundCount < 1 || _options5.roundCount > 3 || !Number.isInteger(_options5.roundGapMinutes) || _options5.roundGapMinutes < 1 || _options5.roundGapMinutes > 10) {
      _argument136({
        "ok": false,
        "reason": "invalid"
      });
      return;
    }
    const _value240 = await getRun();
    if (_value240?.["running"]) {
      _argument136({
        "ok": false,
        "detail": "\u0623\u0648\u0642\u0641 \u0627\u0644\u0631\u0635\u062F \u0645\u0624\u0642\u062A\u064B\u0627 \u0642\u0628\u0644 \u062A\u063A\u064A\u064A\u0631 \u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A"
      });
      return;
    }
    if (_argument134.type === "MIRSAD_DASHBOARD_SCHEDULE") {
      const _value241 = await getRun();
      if (_value241?.["running"]) {
        _argument136({
          "ok": false,
          "error": "\u0623\u0648\u0642\u0641 \u0627\u0644\u0631\u0635\u062F \u0642\u0628\u0644 \u062A\u063A\u064A\u064A\u0631 \u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A"
        });
        return;
      }
      const _value242 = (await chrome.storage.local.get("mirsadDriveDay")).mirsadDriveDay;
    }
    await CloudMonitoring.syncTiming(_options5), scheduleSettings = {
      ..._options5,
      "configuredRoundCount": _options5.roundCount,
      "updatedAt": Date.now()
    }, PERIODS = activePeriods(scheduleSettings), await chrome.storage.local.set({
      [SCHEDULE_SETTINGS_KEY]: scheduleSettings
    });
    const _value243 = await getRun();
    if (_value243?.["running"] && !_value243.current && !_value243.immediateMode) {
      await chrome.alarms.clear(NEXT_ALARM), _value243.period = null, _value243.periodItems = [], _value243.index = 0, _value243.periods = PERIODS;
      if (!(await saveRun(_value243))) return;
      const _value244 = periodNow();
      if (_value244) await beginPeriod(_value243, _value244.n);else {
        const _value245 = nextPeriod();
        await setStatus("\u062A\u0645 \u062A\u062D\u062F\u064A\u062B \u0627\u0644\u062A\u0648\u0642\u064A\u062A \u0627\u0644\u064A\u062F\u0648\u064A. \u064A\u0646\u062A\u0638\u0631 \u0631\u0627\u0635\u062F \u0627\u0644\u062D\u0635\u0629 " + _value245.period.n + " \u0639\u0646\u062F " + _value245.period.start + ".", {
          "waiting": true,
          "period": _value245.period.n
        }), await createRunAlarm(_value243, NEXT_ALARM, {
          "when": _value245.when
        });
      }
    } else await setStatus("\u062D\u064F\u0641\u0638\u062A \u0625\u0639\u062F\u0627\u062F\u0627\u062A \u0627\u0644\u062A\u0648\u0642\u064A\u062A \u0627\u0644\u064A\u062F\u0648\u064A. \u0644\u0627 \u064A\u062D\u062A\u0627\u062C \u062D\u0641\u0638\u0647\u0627 \u0625\u0644\u0649 \u0641\u062A\u062D \u062C\u062F\u0648\u0644 \u0645\u0631\u0635\u0627\u062F.", {
      "scheduleSettings": scheduleSettings,
      "periods": PERIODS
    });
    _argument136({
      "ok": true,
      "settings": scheduleSettings,
      "periods": PERIODS
    });
  })()["catch"](_argument154 => _argument136({
    "ok": false,
    "detail": _argument154.message
  })), true;
  if (_argument134?.["type"] === "MIRSAD_SAVE_MAPPING") return (async () => {
    if (!_argument134.teamsName) {
      _argument136({
        "ok": false
      });
      return;
    }
    const _text3 = "mirsadManualMappings",
      _value246 = await chrome.storage.local.get(_text3),
      _value247 = _value246[_text3] && typeof _value246[_text3] === "object" ? _value246[_text3] : {};
    if (_argument134.teacher) _value247[String(_argument134.teamsName)] = String(_argument134.teacher);else delete _value247[String(_argument134.teamsName)];
    await chrome.storage.local.set({
      [_text3]: _value247
    }), _argument136({
      "ok": true,
      "mappings": _value247
    });
  })()["catch"](() => _argument136({
    "ok": false
  })), true;
  if (_argument134?.["type"] === "MIRSAD_SET_MANUAL_STATUS") return (async () => {
    const _text4 = "mirsadManualAttendanceOverrides",
      _value248 = await chrome.storage.local.get(_text4),
      _value249 = _value248[_text4] && typeof _value248[_text4] === "object" ? _value248[_text4] : {},
      _value250 = String(_argument134.day || localDayKey()) + "|" + String(_argument134.period || "") + "|" + String(_argument134.teacher || "");
    if (!_argument134.teacher || !_argument134.period) {
      _argument136({
        "ok": false
      });
      return;
    }
    if (_argument134.status === "clear") delete _value249[_value250];else {
      if (["present", "absent"].includes(_argument134.status)) _value249[_value250] = {
        "status": _argument134.status,
        "updatedAt": Date.now(),
        "updatedBy": "manual"
      };else {
        _argument136({
          "ok": false
        });
        return;
      }
    }
    await chrome.storage.local.set({
      [_text4]: _value249
    }), _argument136({
      "ok": true
    });
  })()["catch"](() => _argument136({
    "ok": false
  })), true;
  if (_argument134?.["type"] === "MIRSAD_PAGE_READY") return getRun().then(_argument155 => _argument136(_argument155?.["running"] && _argument155.current ? {
    "active": true,
    "teacher": _argument155.current.teacher,
    "period": _argument155.period,
    "index": _argument155.index,
    "scanId": _argument155.current.scanId
  } : {
    "active": false
  })), true;
  if (_argument134?.["type"] === "MIRSAD_CAPTURE_EVIDENCE") return captureEvidenceForScan(_argument134, _argument135).then(_argument136)["catch"](_argument156 => _argument136({
    "ok": false,
    "error": String(_argument156.message)
  })), true;
  if (_argument134?.["type"] === "MIRSAD_SCAN_RESULT") return receiveResult(_argument134)["catch"](() => {}), _argument136({
    "ok": true
  }), false;
}), importScripts("commercial-listener.js", "commercial-auth.js", "guardian-tabs.js");
importScripts("guardian-workspace.js", "auto-links.js");
importScripts("commercial-auth.js", "simple/cycle-runtime.js", "simple/controller.js", "simple/daily.js");