"use strict";

(async () => {
  try {
    const v = await chrome.runtime.sendMessage({
      type: "MIRSAD_VIDEO_IS_CAPTURE_TAB"
    });
    if (v?.capture === true) return;
  } catch {}
  (() => {
    if (window.__mirsadTeamsProbeLoaded) return;
    window.__mirsadTeamsProbeLoaded = true;
    const _value = globalThis.MirsadScheduleCore,
      _value2 = _argument => (_argument || "").normalize("NFKC").replace(/[\u064B-\u065F\u0670\u0640]/g, "").replace(/[أإآ]/g, "\u0627").replace(/ى/g, "\u064A").replace(/\s+/g, " ").trim(),
      _value3 = _argument2 => {
        if (!_argument2 || !_argument2.getBoundingClientRect) return false;
        const _value4 = _argument2.getBoundingClientRect();
        return _value4.width > 0 && _value4.height > 0;
      },
      _value5 = _argument3 => String(_argument3).replace(/[٠-٩]/g, _argument4 => String("\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669".indexOf(_argument4))).replace(/[۰-۹]/g, _argument5 => String("\u06F0\u06F1\u06F2\u06F3\u06F4\u06F5\u06F6\u06F7\u06F8\u06F9".indexOf(_argument5))),
      _text = "[data-cid=\"roster-participant\"], [data-tid^=\"participantsFromMeeting-\"], [id^=\"participantsFromMeeting-\"], [data-tid^=\"participantsInCall-\"], [id^=\"participantsInCall-\"]",
      _items = [{
        "key": "present",
        "labels": ["\u0627\u0644\u062D\u0636\u0648\u0631", "\u0641\u064A \u0647\u0630\u0627 \u0627\u0644\u0627\u062C\u062A\u0645\u0627\u0639", "\u0641\u064A \u0627\u0644\u0627\u062C\u062A\u0645\u0627\u0639", "In this meeting", "In this call", "Attendees"]
      }, {
        "key": "invited",
        "labels": ["\u062A\u0645\u062A \u062F\u0639\u0648\u0629 \u0627\u0644\u0622\u062E\u0631\u064A\u0646", "\u0645\u0646 \u062A\u0645\u062A \u062F\u0639\u0648\u062A\u0647\u0645", "\u0645\u0646 \u062A\u0645 \u062F\u0639\u0648\u062A\u0647\u0645", "\u062A\u0645\u062A \u062F\u0639\u0648\u062A\u0647\u0645", "\u062A\u0645 \u062F\u0639\u0648\u062A\u0647\u0645", "\u0627\u0644\u0623\u0634\u062E\u0627\u0635 \u0627\u0644\u0645\u062F\u0639\u0648\u0648\u0646", "Invited", "Other invitees", "Invited participants", "Invited people", "Not in this meeting"]
      }, {
        "key": "noResponse",
        "labels": ["\u0644\u0627 \u062A\u0648\u062C\u062F \u0627\u0633\u062A\u062C\u0627\u0628\u0629", "Didn't respond", "Hasn't responded"]
      }, {
        "key": "other",
        "labels": ["\u0645\u0642\u062F\u0645\u0648 \u0627\u0644\u0627\u062C\u062A\u0645\u0627\u0639", "\u0645\u0642\u062F\u0645\u0648 \u0627\u0644\u0639\u0631\u0636", "\u0645\u0646\u0638\u0645\u0648 \u0627\u0644\u0627\u062C\u062A\u0645\u0627\u0639", "Meeting organizers", "Presenters", "Organizers"]
      }],
      _value6 = _argument6 => {
        const _value7 = _value5(_value2(_argument6)).toLocaleLowerCase();
        for (const _value8 of _items) {
          for (const _value9 of _value8.labels) {
            const _value0 = _value2(_value9).toLocaleLowerCase();
            if (_value7 === _value0) return _value8.key;
            if (_value7.startsWith(_value0)) {
              const _value1 = _value7.slice(_value0.length).trim();
              if (!_value1 || /^[：:]$/.test(_value1) || /^[（(]?\s*\d+(?:\s*[/،,]\s*\d+)?\s*[）)]?$/.test(_value1)) return _value8.key;
            }
          }
        }
        return null;
      };
    function _value10() {
      const _value11 = [...document.querySelectorAll("body *")].filter(_value3),
        _items2 = [];
      for (const _value12 of _value11) {
        const _value13 = _value2(_value12.innerText || _value12.textContent);
        if (!_value13 || _value13.length > 90) continue;
        const _value14 = _value6(_value13);
        if (!_value14) continue;
        if ([..._value12.children].some(_argument7 => _value2(_argument7.innerText || _argument7.textContent).toLocaleLowerCase() === _value13.toLocaleLowerCase())) continue;
        _items2.push({
          "el": _value12,
          "key": _value14,
          "label": _value13
        });
      }
      const _options = {
          "present": [],
          "invited": [],
          "noResponse": []
        },
        _value15 = _items2.filter(_argument8 => _argument8.key === "present" || _argument8.key === "invited" || _argument8.key === "noResponse");
      for (const _value16 of _value15) {
        let _value17 = _value16.el;
        for (let _number = 0; _number < 8 && _value17.parentElement; _number++) {
          const _value18 = _value17.parentElement,
            _value19 = _value2(_value18.innerText || _value18.textContent);
          if (_value19.length > 10000) break;
          const _value20 = _value15.some(_argument9 => _argument9 !== _value16 && _value18.contains(_argument9.el));
          if (_value20) break;
          _value17 = _value18;
          if (_value19.length > _value16.label.length + 20 && _value19.length < 6000) break;
        }
        const _value21 = _value2(_value17.innerText || _value17.textContent);
        _value21 && !_options[_value16.key].some(_argument0 => _argument0.root === _value17 || _argument0.text === _value21) && _options[_value16.key].push({
          "label": _value16.label,
          "text": _value21,
          "root": _value17,
          "heading": _value16.el
        });
      }
      return _options;
    }
    function _value22(_argument1) {
      return _value2(_argument1).split(/[^\p{L}\p{N}]+/u).filter(Boolean).filter(_argument10 => !["\u0628\u0646", "\u0627\u0628\u0646", "\u0627\u0644"].includes(_argument10));
    }
    function _value23(_argument11, _argument12) {
      const _value24 = _value22(_argument11),
        _value25 = new Set(_value22(_argument12));
      if (_value24.length < 2 || _value25.size === 0) return {
        "match": false,
        "reason": "\u0627\u0644\u0627\u0633\u0645 \u063A\u064A\u0631 \u0645\u0643\u062A\u0645\u0644"
      };
      const _value26 = _value24[0],
        _value27 = _value24[_value24.length - 1],
        _value28 = [_value26, _value27].filter((_argument13, _argument14) => _value25.has(_argument13));
      return {
        "match": _value28.length === 2,
        "matched": _value28,
        "required": 2
      };
    }
    function _value29(_argument15, _argument16) {
      const _value30 = _value22(_argument15),
        _items3 = [];
      for (let _number2 = 2; _number2 <= Math.min(7, _value30.length); _number2++) for (let _number3 = 0; _number3 + _number2 <= _value30.length; _number3++) {
        const _value31 = _value30.slice(_number3, _number3 + _number2).join(" ");
        if (_value23(_argument16, _value31).match) _items3.push(_value31);
      }
      return _items3.sort((_argument17, _argument18) => _value22(_argument17).length - _value22(_argument18).length)[0] || "";
    }
    function _value32(_argument19, _argument20) {
      const _value33 = _argument19.getBoundingClientRect();
      if (!_value33.width || !_value33.height) return "";
      const _value34 = (_value33.top + _value33.bottom) / 2,
        _value35 = [...document.querySelectorAll("body *")].filter(_argument21 => {
          if (!_value3(_argument21) || _argument21 === _argument19 || _argument21.contains(_argument19) || _argument19.contains(_argument21) || _argument21.closest?.("#mirsad-teams-probe")) return false;
          if ([..._argument21.children].some(_argument22 => _value3(_argument22) && _value23(_argument20, _value2(_argument22.innerText || _argument22.textContent)).match)) return false;
          const _value36 = _argument21.getBoundingClientRect();
          return Math.abs((_value36.top + _value36.bottom) / 2 - _value34) <= Math.max(42, _value33.height * 2) && Math.abs((_value36.left + _value36.right) / 2 - (_value33.left + _value33.right) / 2) <= 400 && _value36.width <= 380 && _value36.height <= 90;
        }).map(_argument23 => {
          const _value37 = _value2(_argument23.innerText || _argument23.textContent || ""),
            _value38 = _value37.length <= 100 ? _value29(_value37, _argument20) : "",
            _value39 = _argument23.getBoundingClientRect(),
            _value40 = Math.abs((_value39.top + _value39.bottom) / 2 - _value34) + Math.abs((_value39.left + _value39.right) / 2 - (_value33.left + _value33.right) / 2) * 0.15;
          return {
            "match": _value38,
            "distance": _value40
          };
        }).filter(_argument24 => _argument24.match).sort((_argument25, _argument26) => _argument25.distance - _argument26.distance);
      if (!_value35.length) return "";
      if (_value35.some(_argument27 => _value2(_argument27.match) !== _value2(_value35[0].match) && _argument27.distance - _value35[0].distance < 20)) return "";
      return _value35[0].match;
    }
    function _value41(_argument28) {
      const _value42 = _value5(_value2(_argument28)).match(/(\d+)(?:\s*[/،,]\s*(\d+))?\s*[）)]?\s*$/);
      return _value42 ? Math.max(..._value42.slice(1).filter(Boolean).map(Number)) : null;
    }
    function _value43(_argument29) {
      const _value44 = new Set(),
        _value45 = _argument29.root,
        _items4 = [..._value45.querySelectorAll("[role=\"listitem\"], [data-tid*=\"participant\" i], [data-tid*=\"attendee\" i]")];
      for (const _value46 of _items4) {
        if (!_value3(_value46)) continue;
        const _value47 = (_value46.innerText || "").split(/\n+/).map(_value2).filter(Boolean),
          _value48 = _value47.find(_argument30 => {
            const _value49 = _value22(_argument30);
            return _value49.length >= 2 && _value49.length <= 7 && _argument30.length <= 100 && !_value6(_argument30) && !/(?:المنظّم|المنظم|organizer|تمت دعوة الآخرين)/i.test(_argument30);
          });
        if (_value48) _value44.add(_value2(_value48));
      }
      return _value44;
    }
    function _value50(_argument31, _argument32) {
      const _value51 = _argument31.root,
        _items5 = [..._value51.querySelectorAll("[role=\"listitem\"], [data-tid*=\"participant\" i], [data-tid*=\"attendee\" i], [role=\"treeitem\"]")],
        _items6 = [];
      for (const _value52 of _items5) {
        if (!_value3(_value52)) continue;
        const _value53 = (_value52.innerText || "").split(/\n+/).map(_value2).filter(Boolean),
          _value54 = _value53.find(_argument33 => _argument33.length <= 110 && _value22(_argument33).length >= 2 && _value22(_argument33).length <= 7 && _value23(_argument32, _argument33).match && !_value6(_argument33));
        if (_value54) _items6.push({
          "name": _value54,
          "el": _value52
        });
      }
      if (!_items6.length) for (const _value55 of _value51.querySelectorAll("span,div,[data-tid]")) {
        if (!_value3(_value55) || [..._value55.children].some(_argument34 => _value3(_argument34) && _value2(_argument34.innerText || _argument34.textContent))) continue;
        const _value56 = _value2(_value55.innerText || _value55.textContent || "");
        if (_value56.length <= 110 && _value22(_value56).length >= 2 && _value22(_value56).length <= 7 && _value23(_argument32, _value56).match && !_value6(_value56)) _items6.push({
          "name": _value56,
          "el": _value55
        });
      }
      return _items6;
    }
    const _value57 = /(?:المنظ[ِ\u0650ّ\u0651]*م|organizer|organiser)/i,
      _items7 = ["participantsFromMeeting-", "participantsInCall-"];
    function _value58() {
      const _value59 = [...document.querySelectorAll("body *")].filter(_value3);
      return _value59.filter(_argument35 => {
        const _value60 = _value2(_argument35.innerText || _argument35.textContent || "");
        if (_value60.length > 90 || !_value6(_value60)) return false;
        return ![..._argument35.children].some(_argument36 => _value2(_argument36.innerText || _argument36.textContent || "") === _value60);
      }).map(_argument37 => ({
        "el": _argument37,
        "key": _value6(_value2(_argument37.innerText || _argument37.textContent)),
        "label": _value2(_argument37.innerText || _argument37.textContent)
      }));
    }
    function _value61(_argument38, _argument39) {
      let _value62 = null;
      for (const _value63 of _argument39) {
        if (_value63.el.compareDocumentPosition(_argument38) & Node.DOCUMENT_POSITION_FOLLOWING) _value62 = _value63;
      }
      return _value62?.["key"] || null;
    }
    function _value64(_argument40) {
      const _value65 = [...document.querySelectorAll(_text)].filter(_value3).filter(_argument41 => !_argument41.parentElement?.["closest"](_text));
      return _value65.map(_argument42 => {
        const _value66 = [_argument42.getAttribute("data-tid"), _argument42.id].find(_argument43 => _items7.some(_argument44 => _argument43?.["startsWith"](_argument44))) || "",
          _value67 = _items7.find(_argument45 => _value66.startsWith(_argument45)),
          _value68 = _argument42.querySelector("[id^=\"roster-avatar-img-\"], .fui-TreeItemPersonaLayout__main span[title]"),
          _value69 = _value2(_value68?.["innerText"] || _value68?.["textContent"] || _value68?.["getAttribute"]("title") || ""),
          _value70 = _value69 || (_value67 ? _value2(_value66.slice(_value67.length)) : ""),
          _value71 = _value2(_argument42.innerText || _argument42.textContent || ""),
          _value72 = [..._argument42.querySelectorAll("[data-tid=\"ts-roster-organizer-status\"],span")].some(_argument46 => _value3(_argument46) && _argument46.closest(_text) === _argument42 && /^(?:المنظم|organizer|organiser)$/i.test(_value2(_argument46.innerText || _argument46.textContent || "")) && ![..._argument46.children].some(_argument47 => _value3(_argument47) && _value2(_argument47.innerText || _argument47.textContent || "")));
        return {
          "el": _argument42,
          "name": _value70,
          "contents": _value71,
          "group": _value61(_argument42, _argument40),
          "organizer": _value72
        };
      }).filter(_argument48 => _argument48.name && _argument48.name.length <= 130);
    }
    function _value73(_argument49) {
      for (let _value74 = _argument49; _value74; _value74 = _value74.parentElement) {
        if (_value74.clientHeight > 80 && _value74.scrollHeight > _value74.clientHeight + 10 && /(auto|scroll|hidden)/.test(getComputedStyle(_value74).overflowY)) return _value74;
      }
      return null;
    }
    async function _value75(_argument50, _argument51) {
      const _value76 = new Set(),
        _value77 = new Set(),
        _value78 = new Set();
      let _value79 = null,
        _value80 = false,
        _value81 = false,
        _value82 = null,
        _value83 = false,
        _value84 = false,
        _value85 = false;
      const _value86 = new Set();
      let _number4 = 0,
        _number5 = 0;
      const _items8 = [],
        _value87 = Date.now() + 10000,
        _value88 = _argument52 => {
          if (!_argument52 || !_argument52.isConnected || _items8.some(_argument53 => _argument53.el === _argument52) || _argument52.clientHeight <= 80 || _argument52.scrollHeight <= _argument52.clientHeight + 10) return;
          if (_argument52 !== document.scrollingElement && !/(auto|scroll|overlay|hidden)/.test(window.getComputedStyle(_argument52).overflowY || "")) return;
          _items8.push({
            "el": _argument52,
            "top": _argument52.scrollTop,
            "ended": false,
            "rewound": false
          });
        },
        _value89 = () => {
          for (let _value90 = _items8.length - 1; _value90 >= 0; _value90--) if (!_items8[_value90].el.isConnected) _items8.splice(_value90, 1);
          for (const _value91 of document.querySelectorAll(_text)) {
            if (_value3(_value91)) _value88(_value73(_value91));
          }
        };
      _value89();
      const _value92 = () => {
        const _value93 = _value58();
        for (const _value94 of _value93.filter(_argument54 => _argument54.key === "invited")) {
          _value80 = true;
          const _value95 = _value41(_value94.label);
          if (_value95 !== null) {
            if (_value79 !== null && _value79 !== _value95) _value84 = true;
            _value79 = _value95;
          }
          if (_value94.el.closest("[aria-expanded=\"false\"]")) _value85 = true;
        }
        const _value96 = [...document.querySelectorAll(_text)].filter(_value3).filter(_argument55 => !_argument55.parentElement?.["closest"](_text)),
          _value97 = _value64(_value93);
        _number4 = Math.max(_number4, _value96.length), _number5 = Math.max(_number5, _value97.length);
        for (const _value98 of _value96) {
          const _value99 = _value98.getAttribute("data-tid") || "",
            _value100 = /^([A-Za-z]+)-/.exec(_value99)?.[1] || "roster-participant";
          _value86.add(_value100);
          if (_value61(_value98, _value93) === "invited" && !_value97.some(_argument56 => _argument56.el === _value98)) _value85 = true;
        }
        for (const _value101 of _value97) {
          if (_value101.organizer) {
            _value77.add(_value101.name);
            if (_value101.group === "invited") _value82 = _value101.el;
          }
          if (_value101.group === "invited") _value76.add(_value101.name);
          if (_value101.group === "present") _value78.add(_value101.name);
        }
        if (_value77.size === 1 && _value76.has([..._value77][0])) _value81 = true;
        const _value102 = _value77.size === 1 ? [..._value77][0] : null;
        _value83 = !!_value102 && _value97.some(_argument57 => {
          if (_argument57.group !== "invited" || _value2(_argument57.name) !== _value2(_value102)) return false;
          const _value103 = _value73(_argument57.el),
            _value104 = _value103?.["getBoundingClientRect"]() || {
              "top": 0,
              "bottom": innerHeight
            },
            _value105 = _argument57.el.getBoundingClientRect();
          return _value105.bottom > _value104.top && _value105.top < _value104.bottom;
        });
      };
      _value92();
      for (const _value106 of _items8) {
        _value106.el.scrollTop > 2 && (_value106.el.scrollTop = 0, _value106.el.dispatchEvent(new Event("scroll", {
          "bubbles": true
        })), await new Promise(_argument58 => setTimeout(_argument58, 140))), _value106.rewound = true, _value92();
      }
      _value92();
      let _number6 = 64;
      while (_number6-- > 0 && Date.now() < _value87) {
        _value89();
        const _value107 = _items8.filter(_argument59 => !_argument59.ended);
        if (!_value107.length) {
          if (!_value77.size) {
            await new Promise(_argument60 => setTimeout(_argument60, 180)), _value92();
            continue;
          }
          break;
        }
        const _value108 = _value107[0],
          _value109 = _value108.el;
        if (!_value108.rewound) {
          _value108.rewound = true, _value109.scrollTop = 0, _value109.dispatchEvent(new Event("scroll", {
            "bubbles": true
          })), await new Promise(_argument61 => setTimeout(_argument61, 180)), _value92();
          continue;
        }
        const _value110 = Math.min(_value109.scrollHeight - _value109.clientHeight, _value109.scrollTop + Math.max(120, Math.floor(_value109.clientHeight * 0.75)));
        if (_value110 <= _value109.scrollTop + 2) {
          _value108.ended = true;
          continue;
        }
        _value109.scrollTop = _value110, _value109.dispatchEvent(new Event("scroll", {
          "bubbles": true
        })), await new Promise(_argument62 => setTimeout(_argument62, 140)), _value92();
      }
      const _value111 = _items8.every(_argument63 => _argument63.ended || _argument63.el.scrollTop >= _argument63.el.scrollHeight - _argument63.el.clientHeight - 3);
      if (_value81 && _value77.size === 1 && !_value83) {
        for (const _value112 of _items8) {
          if (!_value112.el.isConnected) continue;
          _value112.el.scrollTop = 0, _value112.ended = false, _value112.el.dispatchEvent(new Event("scroll", {
            "bubbles": true
          }));
        }
        await new Promise(_argument64 => setTimeout(_argument64, 180)), _value92();
        let _number7 = 64;
        while (!_value83 && _number7-- > 0 && Date.now() < _value87) {
          _value89();
          const _value113 = _items8.find(_argument65 => !_argument65.ended);
          if (!_value113) break;
          const _value114 = _value113.el,
            _value115 = Math.min(_value114.scrollHeight - _value114.clientHeight, _value114.scrollTop + Math.max(120, Math.floor(_value114.clientHeight * 0.75)));
          if (_value115 <= _value114.scrollTop + 2) {
            _value113.ended = true;
            continue;
          }
          _value114.scrollTop = _value115, _value114.dispatchEvent(new Event("scroll", {
            "bubbles": true
          })), await new Promise(_argument66 => setTimeout(_argument66, 140)), _value92();
        }
      }
      const _items9 = [..._value77],
        _value116 = _value80 && !_value85 && (_value76.size > 0 || _value79 === 0),
        _value117 = _value116 && !_value84 && (_value79 === null || _value76.size === _value79) && _value111;
      if (_items9.length !== 1 || !_value81) {
        for (const _value118 of _items8) _value118.el.scrollTop = _value118.top;
      }
      return {
        "name": _items9.length === 1 ? _items9[0] : "",
        "ambiguous": _items9.length > 1,
        "inInvitees": _items9.length === 1 && _value81,
        "fullyScanned": _value117,
        "inviteesReadable": _value116,
        "expectedCount": _value79,
        "reason": !_value80 ? "\u062A\u0639\u0630\u0651\u0631 \u0627\u0644\u0648\u0635\u0648\u0644 \u0625\u0644\u0649 \u0639\u0646\u0648\u0627\u0646 \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0645\u062F\u0639\u0648\u064A\u0646" : _value85 ? "\u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0645\u062F\u0639\u0648\u064A\u0646 \u0645\u0637\u0648\u064A\u0629 \u0623\u0648 \u062A\u062D\u062A\u0648\u064A \u0635\u0641\u0648\u0641\u064B\u0627 \u062A\u0639\u0630\u0651\u0631 \u0627\u0633\u062A\u062E\u0631\u0627\u062C \u0623\u0633\u0645\u0627\u0626\u0647\u0627" : !_value116 ? "\u062A\u0639\u0630\u0631\u062A \u0642\u0631\u0627\u0621\u0629 \u0623\u064A \u0635\u0641 \u0645\u0646 \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0645\u062F\u0639\u0648\u064A\u0646" : !_value117 ? _value79 !== null && _value76.size !== _value79 ? "\u0644\u0645 \u062A\u0643\u062A\u0645\u0644 \u0623\u0633\u0645\u0627\u0621 \u0627\u0644\u0645\u062F\u0639\u0648\u064A\u0646: " + _value76.size + " \u0645\u0646 " + _value79 : _value84 ? "\u062A\u063A\u064A\u0631 \u0639\u062F\u062F \u0627\u0644\u0645\u062F\u0639\u0648\u064A\u0646 \u0623\u062B\u0646\u0627\u0621 \u0627\u0644\u0641\u062D\u0635" : "\u062A\u0639\u0630\u0631 \u0625\u0646\u0647\u0627\u0621 \u062A\u0645\u0631\u064A\u0631 \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0645\u062F\u0639\u0648\u064A\u0646" : "",
        "diagnostics": "\u0625\u0635\u062F\u0627\u0631 \u0627\u0644\u0642\u0627\u0631\u0626=0.6.69\u061B \u0635\u0641\u0648\u0641 \u0645\u0643\u062A\u0634\u0641\u0629=" + _number4 + "\u061B \u0635\u0641\u0648\u0641 \u0645\u0633\u0645\u0627\u0629=" + _number5 + "\u061B \u0623\u0646\u0648\u0627\u0639 \u0627\u0644\u0635\u0641\u0648\u0641=" + [..._value86].slice(0, 6).join(",") + "\u061B \u0646\u0648\u0627\u0641\u0630 \u062A\u0645\u0631\u064A\u0631=" + _items8.length + "\u061B \u0639\u062F\u062F \u0627\u0644\u0645\u062F\u0639\u0648\u064A\u0646 \u0627\u0644\u0645\u0639\u0644\u0646=" + (_value79 ?? "\u063A\u064A\u0631 \u0645\u062A\u0627\u062D") + "\u061B \u062A\u063A\u064A\u0631 \u0627\u0644\u0639\u062F\u062F=" + _value84,
        "observedCount": _value76.size,
        "invitedText": [..._value76].join("\n"),
        "presentText": [..._value78].join("\n")
      };
    }
    function _value119(_argument67) {
      return _value2(_argument67?.["innerText"] || _argument67?.["textContent"] || "");
    }
    function _value120() {
      const _value121 = /(?:open|launch|use|get|download).{0,60}(?:microsoft\s+)?teams|teams.{0,60}(?:app|application)|(?:فتح|استخدام|تنزيل).{0,60}(?:تطبيق|تيمز|teams)|(?:تطبيق|تيمز|teams).{0,60}(?:فتح|استخدام|تنزيل)|teams.{0,70}(?:microphone|mic|camera|permission)|(?:الميكروفون|الكاميرا).{0,80}(?:teams|تيمز|السماح)/i;
      return [...document.querySelectorAll("[role=\"dialog\"],[aria-modal=\"true\"],[data-tid*=\"dialog\" i],[data-tid*=\"modal\" i],body *")].filter(_value3).map(_argument68 => ({
        "el": _argument68,
        "text": _value2(_argument68.innerText || _argument68.textContent || "")
      })).filter(_argument69 => _argument69.text.length > 0 && _argument69.text.length <= 1600 && _value121.test(_argument69.text)).sort((_argument70, _argument71) => _argument70.text.length - _argument71.text.length);
    }
    async function _value122() {
      const _value123 = _value120();
      if (!_value123.length) return true;
      const _text2 = "button,[role=\"button\"],a,[aria-label],[title],[data-icon-name],[data-tid]",
        _value124 = /^(?:close|dismiss|cancel|إغلاق|اغلاق|إقفال|إلغاء|×|x|✕|✖)$/i,
        _value125 = _argument72 => _value2([_argument72.getAttribute("aria-label"), _argument72.getAttribute("title"), _argument72.getAttribute("data-icon-name"), _argument72.getAttribute("data-tid"), _argument72.innerText, _argument72.textContent].filter(Boolean).join(" "));
      let _value126 = null,
        _value127 = null;
      for (const _value128 of _value123) {
        let _value129 = _value128.el;
        for (let _number8 = 0; _number8 < 4 && _value129; _number8++, _value129 = _value129.parentElement) {
          const _value130 = _value2(_value129.innerText || _value129.textContent || "");
          if (_value130.length > 2200 || !/(?:teams|تيمز|الميكروفون|microphone|camera|الكاميرا)/i.test(_value130)) break;
          const _value131 = [..._value129.querySelectorAll(_text2)].filter(_value3);
          _value126 = _value131.find(_argument73 => {
            const _value132 = _value125(_argument73);
            if (_value124.test(_value132) || /(?:dismiss|close|cancel|إغلاق|اغلاق|إقفال)/i.test(_value132) && _value132.length < 80) return true;
            const _value133 = _argument73.getBoundingClientRect(),
              _value134 = _value129.getBoundingClientRect(),
              _value135 = _value2(_argument73.innerText || _argument73.textContent || ""),
              _value136 = _value133.top >= _value134.top - 4 && _value133.top <= _value134.top + 64,
              _value137 = _value133.left <= _value134.left + 72 || _value133.right >= _value134.right - 72,
              _value138 = _value133.width > 0 && _value133.height > 0 && _value133.width <= 52 && _value133.height <= 52;
            return !_value135 && _value136 && _value137 && _value138;
          }) || _value126, _value127 = _value131.find(_argument74 => /continue.{0,20}browser|use teams on the web|متابعة.{0,20}(?:المستعرض|المتصفح)|استخدام teams على الويب/i.test(_value125(_argument74))) || _value127;
          if (_value126) break;
        }
        if (_value126 || _value127) break;
      }
      const _value139 = _value126 || _value127;
      if (_value139) try {
        _value139.click();
      } catch (_value140) {
        return false;
      }
      await new Promise(_argument75 => setTimeout(_argument75, 350));
      if (_value120().length === 0) return true;
      try {
        document.activeElement?.["dispatchEvent"](new KeyboardEvent("keydown", {
          "key": "Escape",
          "code": "Escape",
          "bubbles": true
        }));
      } catch (_value141) {}
      return await new Promise(_argument76 => setTimeout(_argument76, 350)), _value120().length === 0;
    }
    async function _value142(_argument77) {
      const _value143 = _value58(),
        _value144 = _value64(_value143).filter(_argument78 => _argument78.organizer && _argument78.group === "invited" && _value2(_argument78.name) === _value2(_argument77));
      for (const _value145 of _value144) {
        try {
          _value145.el.scrollIntoView({
            "block": "nearest",
            "inline": "nearest"
          });
        } catch (_value146) {}
        await new Promise(_argument79 => setTimeout(_argument79, 180));
        if (_value64(_value58()).some(_argument80 => {
          if (!_argument80.organizer || _argument80.group !== "invited" || _value2(_argument80.name) !== _value2(_argument77)) return false;
          const _value147 = _value73(_argument80.el),
            _value148 = _value147?.["getBoundingClientRect"]() || {
              "top": 0,
              "bottom": innerHeight
            },
            _value149 = _argument80.el.getBoundingClientRect();
          return _value149.top >= Math.max(0, _value148.top) - 1 && _value149.bottom <= Math.min(innerHeight, _value148.bottom) + 1;
        })) return true;
      }
      return false;
    }
    function _value150() {
      if (document.getElementById("mirsad-teams-probe")) return;
      const _value151 = document.createElement("section");
      _value151.id = "mirsad-teams-probe", _value151.dir = "rtl", _value151.style.cssText = "position:fixed;z-index:2147483647;bottom:14px;right:14px;left:auto;width:400px;max-height:65vh;overflow:auto;background:#fff;color:#17202a;border:2px solid #287a54;border-radius:12px;box-shadow:0 4px 20px #0004;padding:12px;font:14px/1.6 Arial,sans-serif", _value151.innerHTML = "<div style=\"display:flex;align-items:center;justify-content:space-between;gap:8px\"><strong>\u0631\u0627\u0635\u062F | \u0641\u062D\u0635 \u062D\u0636\u0648\u0631 Teams</strong><button id=\"mirsad-probe-close\" type=\"button\">\u0625\u062E\u0641\u0627\u0621</button></div><p style=\"margin:8px 0\">\u0627\u0643\u062A\u0628 \u0627\u0644\u0627\u0633\u0645 \u0627\u0644\u0631\u0633\u0645\u064A \u0644\u0644\u0645\u0639\u0644\u0645\u060C \u062B\u0645 \u0627\u0641\u062A\u062D \u0644\u0648\u062D\u0629 \u0627\u0644\u0645\u0634\u0627\u0631\u0643\u064A\u0646 \u0648\u0627\u0636\u063A\u0637 \u0641\u062D\u0635. \u0644\u0646 \u064A\u0633\u062C\u0651\u0644 \u0627\u0644\u0641\u062D\u0635 \u063A\u064A\u0627\u0628\u064B\u0627 \u0625\u0630\u0627 \u0643\u0627\u0646\u062A \u0627\u0644\u0642\u0631\u0627\u0621\u0629 \u0645\u0644\u062A\u0628\u0633\u0629.</p><label for=\"mirsad-teacher-name\">\u0627\u0633\u0645 \u0627\u0644\u0645\u0639\u0644\u0645 \u0627\u0644\u0631\u0633\u0645\u064A</label><input id=\"mirsad-teacher-name\" type=\"text\" placeholder=\"\u0645\u062B\u0627\u0644: \u0633\u0639\u064A\u062F \u0639\u0644\u064A \u0627\u0644\u0634\u0647\u0631\u064A\" style=\"box-sizing:border-box;width:100%;padding:8px;margin:4px 0 8px;border:1px solid #bbb;border-radius:6px\"><button id=\"mirsad-probe-scan\" type=\"button\" style=\"padding:7px 12px;background:#287a54;color:white;border:0;border-radius:6px;cursor:pointer\">\u0641\u062D\u0635 \u0627\u0644\u0622\u0646</button><div id=\"mirsad-probe-results\" style=\"margin-top:8px\">\u0644\u0645 \u064A\u062A\u0645 \u0627\u0644\u0641\u062D\u0635 \u0628\u0639\u062F.</div>", document.documentElement.appendChild(_value151), _value151.querySelector("#mirsad-probe-close").addEventListener("click", () => _value151.remove()), _value151.querySelector("#mirsad-probe-scan").addEventListener("click", async () => {
        const _value152 = _value151.querySelector("#mirsad-teacher-name").value,
          _value153 = _value151.querySelector("#mirsad-probe-results");
        _value153.replaceChildren();
        const _value154 = _argument81 => {
          const _value155 = document.createElement("p");
          _value155.textContent = _argument81, _value153.appendChild(_value155);
        };
        if (!_value2(_value152)) {
          _value154("\u0627\u0643\u062A\u0628 \u0627\u0633\u0645 \u0627\u0644\u0645\u0639\u0644\u0645 \u0623\u0648\u0644\u064B\u0627.");
          return;
        }
        const _value156 = _value10();
        if (!_value156.invited.length) {
          _value154("\u0644\u0645 \u0623\u0633\u062A\u0637\u0639 \u0642\u0631\u0627\u0621\u0629 \u0642\u0633\u0645 \xAB\u062A\u0645\u062A \u062F\u0639\u0648\u0629 \u0627\u0644\u0622\u062E\u0631\u064A\u0646\xBB\u061B \u0627\u0644\u0646\u062A\u064A\u062C\u0629 \u063A\u064A\u0631 \u0645\u062D\u0633\u0648\u0645\u0629.");
          return;
        }
        _value154("\u062C\u0627\u0631\u064D \u062A\u062D\u062F\u064A\u062F \u0627\u0644\u0645\u0646\u0638\u0651\u0645 \u0648\u0641\u062D\u0635 \u0642\u0627\u0626\u0645\u0629 \xAB\u062A\u0645\u062A \u062F\u0639\u0648\u0629 \u0627\u0644\u0622\u062E\u0631\u064A\u0646\xBB...");
        const _value157 = await _value75(_value152, _value156);
        if (!_value153.isConnected) return;
        _value153.replaceChildren();
        if (!_value157.name) _value154("\u062A\u0639\u0630\u0651\u0631 \u062A\u062D\u062F\u064A\u062F \u0627\u0633\u0645 \u0627\u0644\u0645\u0639\u0644\u0645 \u0645\u0646 \xAB\u0627\u0644\u0645\u0646\u0638\u0651\u0645\xBB \u062D\u062A\u0649 \u0628\u0639\u062F \u0627\u0644\u0628\u062D\u062B \u0628\u0627\u0644\u0645\u0633\u0637\u0631\u0629\u061B \u0627\u0644\u0646\u062A\u064A\u062C\u0629 \u063A\u064A\u0631 \u0645\u062D\u0633\u0648\u0645\u0629.");else {
          _value154("\u0627\u0633\u0645 \u0627\u0644\u0645\u0646\u0638\u0651\u0645 \u0645\u0646 Teams: " + _value157.name);
          const _value158 = _value157.inInvitees ? {
            "status": "absent",
            "teacher": _value157.name
          } : _value?.["classifyOrganizerMembership"](_value157.name, _value157.invitedText, _value157.inviteesReadable, _value157.fullyScanned, _value157.presentText);
          if (_value158?.["status"] === "absent") _value154("\u0627\u0644\u0646\u062A\u064A\u062C\u0629 \u0627\u0644\u0623\u0648\u0644\u064A\u0629: \u063A\u0627\u0626\u0628 \u2014 \u0627\u0633\u0645 \u0627\u0644\u0645\u0646\u0638\u0651\u0645 \u0645\u0648\u062C\u0648\u062F \u0636\u0645\u0646 \xAB\u062A\u0645\u062A \u062F\u0639\u0648\u0629 \u0627\u0644\u0622\u062E\u0631\u064A\u0646\xBB. \u064A\u0644\u0632\u0645 \u062D\u0641\u0638 \u062F\u0644\u064A\u0644 \u0627\u0644\u063A\u064A\u0627\u0628 \u0642\u0628\u0644 \u0627\u0639\u062A\u0645\u0627\u062F\u0647.");else _value158?.["status"] === "present" ? _value154("\u0627\u0644\u0646\u062A\u064A\u062C\u0629: \u062D\u0627\u0636\u0631 \u2014 \u0627\u0633\u0645 \u0627\u0644\u0645\u0646\u0638\u0651\u0645 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F \u0641\u064A \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0645\u062F\u0639\u0648\u064A\u0646 \u0628\u0639\u062F \u0627\u0643\u062A\u0645\u0627\u0644 \u0642\u0631\u0627\u0621\u062A\u0647\u0627.") : _value154("\u0627\u0644\u0646\u062A\u064A\u062C\u0629: \u063A\u064A\u0631 \u0645\u062D\u0633\u0648\u0645 \u2014 \u0644\u0645 \u062A\u0643\u062A\u0645\u0644 \u0642\u0631\u0627\u0621\u0629 \u0642\u0627\u0626\u0645\u0629 \xAB\u062A\u0645\u062A \u062F\u0639\u0648\u0629 \u0627\u0644\u0622\u062E\u0631\u064A\u0646\xBB (\u0627\u0644\u0645\u0642\u0631\u0648\u0621 " + _value157.observedCount + " \u0645\u0646 " + (_value157.expectedCount ?? "\u0639\u062F\u062F \u063A\u064A\u0631 \u0645\u0639\u0631\u0648\u0641") + ").");
        }
        const _value159 = document.createElement("details"),
          _value160 = document.createElement("summary");
        _value160.textContent = "\u0639\u0631\u0636 \u0627\u0644\u0646\u0635\u0648\u0635 \u0627\u0644\u062A\u064A \u0642\u0631\u0623\u062A\u0647\u0627 \u0627\u0644\u0623\u062F\u0627\u0629 \u0644\u0644\u062A\u0634\u062E\u064A\u0635", _value159.appendChild(_value160);
        for (const [_value161, _value162] of [["\u0627\u0644\u062D\u0636\u0648\u0631", _value156.present], ["\u062A\u0645\u062A \u062F\u0639\u0648\u0629 \u0627\u0644\u0622\u062E\u0631\u064A\u0646", _value156.invited], ["\u0644\u0627 \u062A\u0648\u062C\u062F \u0627\u0633\u062A\u062C\u0627\u0628\u0629", _value156.noResponse]]) {
          const _value163 = document.createElement("strong");
          _value163.textContent = _value161, _value159.appendChild(_value163);
          const _value164 = document.createElement("pre");
          _value164.style.cssText = "white-space:pre-wrap;overflow-wrap:anywhere;font:12px/1.5 Arial", _value164.textContent = _value162.map(_argument82 => _argument82.text).join("\n---\n") || "\u0644\u0645 \u064A\u064F\u0643\u062A\u0634\u0641", _value159.appendChild(_value164);
        }
        _value153.appendChild(_value159);
      });
    }
    async function _value165(_argument83) {
      if (!(await _value122())) return {
        "status": "unresolved",
        "teacher": _argument83,
        "detail": "\u0638\u0647\u0631\u062A \u0646\u0627\u0641\u0630\u0629 \u0641\u062A\u062D \u062A\u0637\u0628\u064A\u0642 Teams \u0648\u062A\u0639\u0630\u0631 \u0625\u063A\u0644\u0627\u0642\u0647\u0627\u061B \u0644\u0645 \u062A\u064F\u0641\u062D\u0635 \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0645\u0634\u0627\u0631\u0643\u064A\u0646 \u0648\u0644\u0645 \u064A\u064F\u0633\u062C\u0651\u0644 \u063A\u064A\u0627\u0628."
      };
      const _value166 = () => {
          const _value167 = _value2(document.body?.["innerText"] || "").toLocaleLowerCase();
          return _value167.includes("\u0627\u0644\u062D\u0636\u0648\u0631") && _value167.includes("\u062A\u0645\u062A \u062F\u0639\u0648\u0629 \u0627\u0644\u0622\u062E\u0631\u064A\u0646") || [...document.querySelectorAll("[role=dialog],[data-tid*='roster' i],[data-tid*='participant' i]")].some(_value3);
        },
        _value168 = () => {
          const _value169 = document.querySelector("button[data-inp=\"roster-button\"],button[aria-label=\"\u0623\u0634\u062E\u0627\u0635\"]");
          if (_value169 && _value3(_value169) && !_value169.disabled && _value169.getAttribute("aria-disabled") !== "true") {
            try {
              _value169.scrollIntoView({
                "block": "nearest"
              });
            } catch (_value170) {}
            return _value169.click(), true;
          }
          const _items0 = ["\u0623\u0634\u062E\u0627\u0635", "\u0627\u0644\u0623\u0634\u062E\u0627\u0635", "\u0627\u0644\u0645\u0634\u0627\u0631\u0643\u0648\u0646", "\u0627\u0644\u0645\u0634\u0627\u0631\u0643\u064A\u0646", "\u0639\u0631\u0636 \u0627\u0644\u0645\u0634\u0627\u0631\u0643\u064A\u0646", "people", "participants", "view participants", "show participants"],
            _items1 = [...document.querySelectorAll("button,[role=button],[role=menuitem],[data-tid],span,div")],
            _value171 = _items1.filter(_argument84 => {
              if (!_value3(_argument84)) return false;
              const _value172 = _value2([_argument84.getAttribute("aria-label"), _argument84.getAttribute("title"), _argument84.getAttribute("data-tid"), _argument84.innerText, _argument84.textContent].filter(Boolean).join(" ")).toLocaleLowerCase();
              return _value172 && _items0.some(_argument85 => _value172 === _value2(_argument85).toLocaleLowerCase() || _value172.startsWith(_value2(_argument85).toLocaleLowerCase() + " "));
            });
          for (const _value173 of _value171) {
            const _value174 = _value173.closest("button,[role=button],[role=menuitem]") || _value173;
            if (!_value3(_value174)) continue;
            try {
              _value174.scrollIntoView({
                "block": "nearest"
              });
            } catch (_value175) {}
            try {
              return _value174.click(), true;
            } catch (_value176) {}
          }
          return false;
        };
      let _value177 = _value10(),
        _value178 = false;
      if (!_value177.present.length && !_value177.invited.length && !window.__mirsadRosterClickAttempted) {
        const _value179 = _value168();
        if (!_value179) {
          const _value180 = document.querySelector("button#roster-button,button[data-inp=\"roster-button\"],button[aria-label=\"\u0623\u0634\u062E\u0627\u0635\"]");
          return {
            "status": "unresolved",
            "detail": "\u0627\u0644\u062A\u0634\u062E\u064A\u0635: \u0644\u0645 \u0623\u062C\u062F \u0632\u0631 \xAB\u0623\u0634\u062E\u0627\u0635\xBB \u0642\u0627\u0628\u0644\u064B\u0627 \u0644\u0644\u0636\u063A\u0637. \u0632\u0631 roster=" + !!_value180 + "\u060C \u0638\u0627\u0647\u0631=" + (!!_value180 && _value3(_value180)) + "\u060C \u0639\u0646\u0627\u0648\u064A\u0646 \u0627\u0644\u062D\u0636\u0648\u0631 \u0627\u0644\u0645\u0643\u062A\u0634\u0641\u0629=0\u061B \u0644\u0645 \u064A\u064F\u0633\u062C\u0651\u0644 \u063A\u064A\u0627\u0628."
          };
        }
        window.__mirsadRosterClickAttempted = true, _value178 = true;
      }
      if (!_value177.present.length && !_value177.invited.length) for (let _number9 = 0; _number9 < (_value178 ? 6 : 2); _number9++) {
        await new Promise(_argument86 => setTimeout(_argument86, 1000)), _value177 = _value10();
        if (_value177.present.length || _value177.invited.length) break;
      }
      if (!_value177.present.length && !_value177.invited.length) {
        const _value181 = document.querySelector("button#roster-button,button[data-inp=\"roster-button\"],button[aria-label=\"\u0623\u0634\u062E\u0627\u0635\"]"),
          _value182 = [...document.querySelectorAll("[role=\"dialog\"],[data-tid*=\"roster\" i],[data-tid*=\"participant\" i]")].filter(_value3).length,
          _value183 = _value2(document.body?.["innerText"] || ""),
          _value184 = /الحضور|attendees|in this meeting/i.test(_value183),
          _value185 = /تمت دعوة الآخرين|other invitees|invited/i.test(_value183),
          _value186 = [...document.querySelectorAll("body *")].filter(_argument87 => _value3(_argument87)).map(_argument88 => ({
            "el": _argument88,
            "text": _value2(_argument88.innerText || _argument88.textContent)
          })).filter(_argument89 => _argument89.text && _argument89.text.length <= 100 && /الحضور|تمت دعوة|attendees|in this meeting|invitees|invited/i.test(_argument89.text)).filter(_argument90 => ![..._argument90.el.children].some(_argument91 => _value2(_argument91.innerText || _argument91.textContent) === _argument90.text)).slice(0, 6).map(_argument92 => _argument92.el.tagName.toLowerCase() + (_argument92.el.getAttribute("data-tid") ? "[" + _argument92.el.getAttribute("data-tid").slice(0, 40) + "]" : "") + "=" + _argument92.text).join(" | ");
        return {
          "status": "unresolved",
          "detail": "\u0627\u0644\u062A\u0634\u062E\u064A\u0635: \u0636\u063A\u0637 \u0627\u0644\u0623\u0634\u062E\u0627\u0635 \u0641\u064A \u0647\u0630\u0647 \u0627\u0644\u0635\u0641\u062D\u0629=" + !!window.__mirsadRosterClickAttempted + "\u061B \u0632\u0631 \u0627\u0644\u0623\u0634\u062E\u0627\u0635 \u0638\u0627\u0647\u0631=" + (!!_value181 && _value3(_value181)) + "\u061B \u0646\u0648\u0627\u0641\u0630/\u062D\u0627\u0648\u064A\u0627\u062A \u0645\u0634\u0627\u0631\u0643\u064A\u0646 \u0638\u0627\u0647\u0631\u0629=" + _value182 + "\u061B \u0646\u0635 \u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u062D\u0636\u0648\u0631 \u0645\u0648\u062C\u0648\u062F=" + _value184 + "\u061B \u0646\u0635 \u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u0645\u062F\u0639\u0648\u064A\u0646 \u0645\u0648\u062C\u0648\u062F=" + _value185 + "\u061B \u0623\u0642\u0633\u0627\u0645 \u0627\u0644\u0642\u0631\u0627\u0621\u0629 \u0627\u0644\u0645\u0643\u062A\u0634\u0641\u0629=0\u061B \u0646\u0645\u0627\u0630\u062C \u0627\u0644\u0639\u0646\u0627\u0648\u064A\u0646=" + (_value186 || "\u0644\u0627 \u062A\u0648\u062C\u062F").slice(0, 700) + ". \u0642\u0627\u0626\u0645\u0629 Teams \u0644\u0645 \u062A\u064F\u0642\u0631\u0623 \u0628\u0646\u062C\u0627\u062D\u061B \u0644\u0645 \u064A\u064F\u0633\u062C\u0651\u0644 \u063A\u064A\u0627\u0628."
        };
      }
      const _value187 = await _value75(_argument83, _value177);
      if (!_value187.name) return {
        "status": "unresolved",
        "teacher": _argument83,
        "reason": "organizer-not-found",
        "retryable": !_value187.ambiguous,
        "detail": _value187.ambiguous ? "\u0638\u0647\u0631 \u0623\u0643\u062B\u0631 \u0645\u0646 \u0627\u0633\u0645 \u0645\u062D\u062A\u0645\u0644 \u0645\u0631\u062A\u0628\u0637 \u0628\u0648\u0633\u0645 \xAB\u0627\u0644\u0645\u0646\u0638\u0651\u0645\xBB\u061B \u0644\u0645 \u062A\u064F\u0633\u062C\u0651\u0644 \u062D\u0627\u0644\u0629 \u062D\u0636\u0648\u0631 \u0623\u0648 \u063A\u064A\u0627\u0628." : "\u062A\u0639\u0630\u0651\u0631 \u0627\u0644\u0639\u062B\u0648\u0631 \u0639\u0644\u0649 \u0627\u0633\u0645 \u0645\u0631\u062A\u0628\u0637 \u0628\u0648\u0633\u0645 \xAB\u0627\u0644\u0645\u0646\u0638\u0651\u0645\xBB \u0628\u0639\u062F \u0627\u0644\u0628\u062D\u062B \u0648\u0627\u0644\u062A\u0645\u0631\u064A\u0631 \u0641\u064A \u0627\u0644\u0635\u0641\u062D\u0629\u061B \u0644\u0645 \u062A\u064F\u0633\u062C\u0651\u0644 \u062D\u0627\u0644\u0629 \u062D\u0636\u0648\u0631 \u0623\u0648 \u063A\u064A\u0627\u0628."
      };
      const _value188 = _value187.inInvitees ? {
        "status": "absent",
        "teacher": _value187.name
      } : _value?.["classifyOrganizerMembership"](_value187.name, _value187.invitedText, _value187.inviteesReadable, _value187.fullyScanned, _value187.presentText);
      if (_value188?.["status"] === "absent") {
        const _value189 = await _value142(_value187.name);
        if (!_value189) return {
          "status": "unresolved",
          "teacher": _argument83,
          "detail": "\u0627\u0633\u0645 \u0627\u0644\u0645\u0646\u0638\u0651\u0645 \xAB" + _value187.name + "\xBB \u0638\u0647\u0631 \u0636\u0645\u0646 \u0627\u0644\u0645\u062F\u0639\u0648\u064A\u0646\u060C \u0644\u0643\u0646 \u062A\u0639\u0630\u0651\u0631 \u0625\u0638\u0647\u0627\u0631 \u0627\u0644\u0627\u0633\u0645 \u0648\u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u0642\u0627\u0626\u0645\u0629 \u0645\u0639\u064B\u0627 \u0644\u0644\u062A\u0635\u0648\u064A\u0631\u061B \u0644\u0645 \u064A\u064F\u0633\u062C\u0651\u0644 \u063A\u064A\u0627\u0628."
        };
        return {
          "status": "absent",
          "teacher": _value187.name,
          "evidenceTeacher": _value187.name,
          "detail": "\u0627\u0633\u0645 \u0627\u0644\u0645\u0646\u0638\u0651\u0645 \xAB" + _value187.name + "\xBB \u0645\u0631\u062A\u0628\u0637 \u0628\u0627\u0644\u0645\u0639\u0644\u0645 \u0648\u064A\u0638\u0647\u0631 \u062A\u062D\u062A \xAB\u062A\u0645\u062A \u062F\u0639\u0648\u0629 \u0627\u0644\u0622\u062E\u0631\u064A\u0646\xBB\u061B \u0627\u0644\u062D\u0627\u0644\u0629 \u063A\u0627\u0626\u0628. \u062C\u064F\u0647\u0632\u062A \u0627\u0644\u0642\u0627\u0626\u0645\u0629 \u0644\u0644\u062A\u0635\u0648\u064A\u0631.",
          "evidence": {
            "verified": true,
            "teacherInInvitees": true,
            "teacherNotPresent": true,
            "inviteesReadable": true
          }
        };
      }
      if (_value188?.["status"] === "present") return {
        "status": "present",
        "teacher": _value187.name,
        "detail": "\u0627\u0633\u0645 \u0627\u0644\u0645\u0646\u0638\u0651\u0645 \xAB" + _value187.name + "\xBB \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F \u0636\u0645\u0646 \u0627\u0644\u0645\u062F\u0639\u0648\u064A\u0646\u061B \u0627\u0644\u062D\u0627\u0644\u0629 \u062D\u0627\u0636\u0631 \u0648\u0641\u0642 \u0642\u0627\u0639\u062F\u0629 \u0627\u0644\u0645\u0646\u0638\u0651\u0645."
      };
      return {
        "status": "unresolved",
        "teacher": _value187.name,
        "detail": (_value187.reason || "\u062A\u0639\u0630\u0631 \u062A\u0623\u0643\u064A\u062F \u0627\u0643\u062A\u0645\u0627\u0644 \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0645\u062F\u0639\u0648\u064A\u0646") + "\u061B \u0627\u0644\u0623\u0633\u0645\u0627\u0621 \u0627\u0644\u0645\u0642\u0631\u0648\u0621\u0629 \u0645\u0646 \u0627\u0644\u0645\u062F\u0639\u0648\u064A\u0646=" + _value187.observedCount + ". " + _value187.diagnostics
      };
    }
    chrome.runtime.onMessage.addListener((_argument93, _argument94, _argument95) => {
      if (_argument93?.["type"] === "MIRSAD_AUTO_SCAN") return _value165(_argument93.teacher || "").then(_argument95)["catch"](_argument96 => _argument95({
        "status": "unresolved",
        "teacher": _argument93.teacher || "",
        "detail": "\u062A\u0639\u0630\u0631 \u0641\u062D\u0635 \u0648\u0627\u062C\u0647\u0629 Teams \u0628\u0633\u0628\u0628 \u062E\u0637\u0623 \u062F\u0627\u062E\u0644\u064A: " + String(_argument96?.["message"] || _argument96 || "\u062E\u0637\u0623 \u063A\u064A\u0631 \u0645\u0639\u0631\u0648\u0641").slice(0, 180) + "\u061B \u0644\u0645 \u062A\u064F\u0633\u062C\u0651\u0644 \u062D\u0627\u0644\u0629 \u062D\u0636\u0648\u0631 \u0623\u0648 \u063A\u064A\u0627\u0628."
      })), true;
    });
    function _value190(_argument97) {
      const _items10 = [...document.querySelectorAll("button,[role=button],input[type=button],input[type=submit],a")],
        _value191 = _argument97.map(_argument98 => _value2(_argument98).toLocaleLowerCase()),
        _value192 = _items10.find(_argument99 => {
          const _value193 = _value2([_argument99.innerText, _argument99.textContent, _argument99.getAttribute("aria-label"), _argument99.getAttribute("title"), _argument99.value].filter(Boolean).join(" ")).toLocaleLowerCase();
          return _value3(_argument99) && _value191.some(_argument100 => _value193 === _argument100 || _value193.includes(_argument100));
        });
      if (!_value192 || _value192.disabled || _value192.getAttribute("aria-disabled") === "true") return false;
      try {
        _value192.focus({
          "preventScroll": true
        });
      } catch (_value194) {}
      return _value192.click(), true;
    }
    function _value195() {
      const _value196 = _value2(document.body?.["innerText"] || "").toLocaleLowerCase(),
        _value197 = ["leave", "leave meeting", "\u0645\u063A\u0627\u062F\u0631\u0629", "\u0645\u063A\u0627\u062F\u0631\u0629 \u0627\u0644\u0627\u062C\u062A\u0645\u0627\u0639"].some(_argument101 => _value196.includes(_value2(_argument101).toLocaleLowerCase())),
        _value198 = document.querySelector("button#roster-button,button[data-inp=\"roster-button\"],button[aria-label=\"\u0623\u0634\u062E\u0627\u0635\"]"),
        _value199 = !!(_value198 && _value3(_value198)) || [...document.querySelectorAll("button,[role=button]")].some(_argument102 => {
          const _value200 = _value2([_argument102.innerText, _argument102.getAttribute("aria-label"), _argument102.getAttribute("title")].filter(Boolean).join(" ")).toLocaleLowerCase();
          return ["people", "participants", "\u0623\u0634\u062E\u0627\u0635", "\u0627\u0644\u0623\u0634\u062E\u0627\u0635", "\u0627\u0644\u0645\u0634\u0627\u0631\u0643\u0648\u0646", "\u0627\u0644\u0645\u0634\u0627\u0631\u0643\u064A\u0646"].some(_argument103 => _value200.includes(_value2(_argument103).toLocaleLowerCase()));
        });
      return _value197 && _value199;
    }
    function _value201() {
      const _value202 = _value2(document.body?.["innerText"] || "").toLocaleLowerCase();
      if (/(?:this |the )?meeting (?:is|has been) locked|you (?:can.t|cannot) join this meeting|you (?:don.t|do not) have permission to join|only people (?:from|in) (?:this|the) organi[sz]ation can join/.test(_value202) || /(?:تم (?:قفل|تأمين|تامين) الاجتماع|(?:هذا )?الاجتماع (?:مغلق|مقفل|مؤمن|مومن)|لا يمكنك الانضمام (?:الي|الى|إلى) هذا الاجتماع|غير مسموح لك بالانضمام|ليس لديك (?:اذن|إذن|صلاحية) للانضمام)/.test(_value202)) return "\u0627\u0644\u062D\u0635\u0629 \u0645\u0624\u0645\u0651\u0646\u0629: \u062A\u0639\u0631\u0636 Teams \u0631\u0633\u0627\u0644\u0629 \u0635\u0631\u064A\u062D\u0629 \u0628\u0642\u0641\u0644 \u0627\u0644\u0627\u062C\u062A\u0645\u0627\u0639 \u0623\u0648 \u0645\u0646\u0639 \u0627\u0644\u062F\u062E\u0648\u0644.";
      if (/waiting in the lobby|someone will let you in|في ساحة الانتظار|بانتظار (?:موافقة|السماح)|انتظار موافقة المنظم/.test(_value202)) return "\u0627\u0644\u062D\u0635\u0629 \u0645\u0624\u0645\u0651\u0646\u0629: \u0627\u0644\u062F\u062E\u0648\u0644 \u064A\u062A\u0637\u0644\u0628 \u0633\u0645\u0627\u062D \u0627\u0644\u0645\u0646\u0638\u0651\u0645 \u0645\u0646 \u0633\u0627\u062D\u0629 \u0627\u0644\u0627\u0646\u062A\u0638\u0627\u0631.";
      return "";
    }
    async function _value203() {
      const _value204 = document.querySelector("button#roster-button,button[data-inp=\"roster-button\"],button[aria-label=\"\u0623\u0634\u062E\u0627\u0635\"]");
      if (_value204 && _value3(_value204)) return "already-in";
      if (_value195()) return "already-in";
      const _items11 = ["join now", "join", "join meeting", "join the meeting", "join on the web", "\u0627\u0646\u0636\u0645\u0627\u0645 \u0627\u0644\u0622\u0646", "\u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0627\u0644\u0622\u0646", "\u0627\u0646\u0636\u0645 \u0627\u0644\u0622\u0646", "\u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645", "\u0627\u0646\u0636\u0645\u0627\u0645", "\u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0625\u0644\u0649 \u0627\u0644\u0627\u062C\u062A\u0645\u0627\u0639", "\u0627\u0646\u0636\u0645\u0627\u0645 \u0644\u0644\u0627\u062C\u062A\u0645\u0627\u0639"];
      for (let _number0 = 0; _number0 < 12; _number0++) {
        if (_value201()) return "entry-blocked";
        if (_value190(_items11)) {
          for (let _number1 = 0; _number1 < 15; _number1++) {
            await new Promise(_argument104 => setTimeout(_argument104, 1000));
            if (_value195()) return "joined";
            if (_value201()) return "entry-blocked";
            const _value205 = _value2(document.body?.["innerText"] || "").toLocaleLowerCase();
            if (_value205.includes("waiting in the lobby") || _value205.includes("someone will let you in") || _value205.includes("\u0641\u064A \u0633\u0627\u062D\u0629 \u0627\u0644\u0627\u0646\u062A\u0638\u0627\u0631") || _value205.includes("\u0633\u064A\u0646\u0636\u0645 \u0625\u0644\u064A\u0643 \u0627\u0644\u0645\u0646\u0638\u0645")) return "waiting-for-admission";
          }
          return "join-clicked-not-confirmed";
        }
        await new Promise(_argument105 => setTimeout(_argument105, 1000));
      }
      return "join-not-available";
    }
    async function _value206() {
      await new Promise(_argument106 => setTimeout(_argument106, 2000));
      const _value207 = _value190(["leave", "leave meeting", "\u0645\u063A\u0627\u062F\u0631\u0629", "\u0645\u063A\u0627\u062F\u0631\u0629 \u0627\u0644\u0627\u062C\u062A\u0645\u0627\u0639"]);
      if (_value207) await new Promise(_argument107 => setTimeout(_argument107, 2000));
      return _value207;
    }
    function _value208() {
      const _items12 = ["continue on this browser", "use teams on the web instead", "join on the web instead", "continue in this browser", "\u0645\u062A\u0627\u0628\u0639\u0629 \u0639\u0644\u0649 \u0647\u0630\u0627 \u0627\u0644\u0645\u0633\u062A\u0639\u0631\u0636", "\u0627\u0644\u0645\u062A\u0627\u0628\u0639\u0629 \u0639\u0644\u0649 \u0647\u0630\u0627 \u0627\u0644\u0645\u0633\u062A\u0639\u0631\u0636", "\u0627\u0633\u062A\u062E\u062F\u0627\u0645 teams \u0639\u0644\u0649 \u0627\u0644\u0648\u064A\u0628", "\u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0639\u0644\u0649 \u0627\u0644\u0648\u064A\u0628 \u0628\u062F\u0644\u064B\u0627 \u0645\u0646 \u0630\u0644\u0643", "\u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0639\u0644\u0649 \u0627\u0644\u0648\u064A\u0628 \u0628\u062F\u0644\u0627 \u0645\u0646 \u0630\u0644\u0643"],
        _items13 = [...document.querySelectorAll("button,a,[role=button]")],
        _value209 = _items13.find(_argument108 => {
          const _value210 = _value2([_argument108.innerText, _argument108.getAttribute("aria-label"), _argument108.getAttribute("title")].filter(Boolean).join(" "));
          return _value210 && _items12.some(_argument109 => _value210.toLocaleLowerCase().includes(_value2(_argument109).toLocaleLowerCase()));
        });
      if (!_value209 || _value209.dataset.mirsadWebFallbackClicked === "1") return false;
      return _value209.dataset.mirsadWebFallbackClicked = "1", _value209.click(), true;
    }
    async function _value211() {
      for (let _number10 = 0; _number10 < 3; _number10++) {
        if (_value208()) return await new Promise(_argument110 => setTimeout(_argument110, 1800)), true;
        await new Promise(_argument111 => setTimeout(_argument111, 1000));
      }
      return false;
    }
    !window.__mirsadAutoPageHandshake && (window.__mirsadAutoPageHandshake = true, chrome.runtime.sendMessage({
      "type": "MIRSAD_PAGE_READY"
    }).then(async _argument112 => {
      let _value212 = _argument112;
      for (let _number11 = 0; _number11 < 10 && (!_value212?.["active"] || !_value212.teacher || !_value212.scanId); _number11++) {
        await new Promise(_argument113 => setTimeout(_argument113, 700)), _value212 = await chrome.runtime.sendMessage({
          "type": "MIRSAD_PAGE_READY"
        });
      }
      if (!_value212?.["active"] || !_value212.teacher || !_value212.scanId) return;
      await new Promise(_argument114 => setTimeout(_argument114, 2000)), await _value211();
      const _value213 = await _value203();
      let _options2 = {
        "status": "unresolved",
        "detail": "\u0644\u0645 \u064A\u062A\u0623\u0643\u062F \u0627\u0644\u062F\u062E\u0648\u0644 \u0625\u0644\u0649 \u0627\u0644\u0627\u062C\u062A\u0645\u0627\u0639 \u0623\u0648 \u0644\u0645 \u062A\u0638\u0647\u0631 \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0645\u0634\u0627\u0631\u0643\u064A\u0646\u061B \u0644\u0645 \u064A\u064F\u0633\u062C\u0651\u0644 \u063A\u064A\u0627\u0628."
      };
      if (_value213 === "entry-blocked") _options2 = {
        "status": "unresolved",
        "teacher": _value212.teacher,
        "detail": _value201() || "\u0627\u0644\u062D\u0635\u0629 \u0645\u0624\u0645\u0651\u0646\u0629: \u062A\u0639\u0630\u0631 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u0633\u0628\u0628 \u0642\u064A\u0648\u062F \u0627\u0644\u0627\u062C\u062A\u0645\u0627\u0639."
      };else {
        if (_value213 === "join-not-available") _options2 = {
          "status": "unresolved",
          "detail": "\u0644\u0645 \u064A\u0638\u0647\u0631 \u0632\u0631 \xAB\u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0627\u0644\u0622\u0646\xBB \u062C\u0627\u0647\u0632\u064B\u0627. \u0642\u062F \u062A\u062A\u0637\u0644\u0628 \u0627\u0644\u0635\u0641\u062D\u0629 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0623\u0648 \u0627\u062E\u062A\u064A\u0627\u0631 \u0627\u0644\u062D\u0633\u0627\u0628\u061B \u0644\u0645 \u064A\u064F\u0633\u062C\u0651\u0644 \u063A\u064A\u0627\u0628."
        };else {
          if (_value213 === "waiting-for-admission") _options2 = {
            "status": "unresolved",
            "teacher": _value212.teacher,
            "detail": "\u0627\u0644\u062D\u0635\u0629 \u0645\u0624\u0645\u0651\u0646\u0629: \u062A\u0645 \u0637\u0644\u0628 \u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645 \u0644\u0643\u0646 Teams \u064A\u0639\u0631\u0636 \u0627\u0646\u062A\u0638\u0627\u0631 \u0645\u0648\u0627\u0641\u0642\u0629 \u0627\u0644\u0645\u0646\u0638\u0651\u0645\u061B \u0644\u0645 \u064A\u064F\u0633\u062C\u0651\u0644 \u063A\u064A\u0627\u0628."
          };else {
            if (_value213 === "join-clicked-not-confirmed") _options2 = {
              "status": "unresolved",
              "detail": "\u0636\u063A\u0637 \u0631\u0627\u0635\u062F \u0632\u0631 \u0627\u0644\u0627\u0646\u0636\u0645\u0627\u0645\u060C \u0644\u0643\u0646 \u0644\u0645 \u064A\u062A\u0623\u0643\u062F \u0638\u0647\u0648\u0631 \u0648\u0627\u062C\u0647\u0629 \u0627\u0644\u0627\u062C\u062A\u0645\u0627\u0639\u061B \u0644\u0645 \u064A\u064F\u0633\u062C\u0651\u0644 \u063A\u064A\u0627\u0628."
            };else {
              await new Promise(_argument115 => setTimeout(_argument115, 2000));
              let _value214 = false;
              for (let _number12 = 0; _number12 < 6; _number12++) {
                if (_number12 > 0) await new Promise(_argument116 => setTimeout(_argument116, 1000));
                _options2 = await _value165(_value212.teacher);
                _options2.reason === "organizer-not-found" && _options2.retryable && !_value214 && (_value214 = true, await new Promise(_argument117 => setTimeout(_argument117, 5000)), _options2 = await _value165(_value212.teacher));
                if (_options2.reason === "organizer-not-found" || _options2.status !== "unresolved" || !/لم يمكن تحديد أقسام الحضور|لم يتم الانضمام|لم تظهر قائمة المشاركين|تعذر تحديد أقسام|التشخيص:/i.test(_options2.detail || "")) break;
              }
            }
          }
        }
      }
      if (_options2.status === "absent") try {
        const _value215 = _options2.evidenceTeacher || _options2.teacher || _value212.teacher,
          _value216 = await _value122(),
          _value217 = _value216 && (await _value142(_value215));
        if (!_value217) _options2 = {
          "status": "unresolved",
          "teacher": _value215,
          "detail": "\u062A\u0639\u0630\u0631 \u0625\u063A\u0644\u0627\u0642 \u0646\u0627\u0641\u0630\u0629 Teams \u0623\u0648 \u0625\u0638\u0647\u0627\u0631 \u0627\u0633\u0645 \u0627\u0644\u0645\u0639\u0644\u0645 \u0648\u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0645\u062F\u0639\u0648\u064A\u0646 \u0644\u0644\u062A\u0635\u0648\u064A\u0631\u061B \u0644\u0645 \u064A\u064F\u0633\u062C\u0651\u0644 \u063A\u064A\u0627\u0628."
        };else {
          const _value218 = await chrome.runtime.sendMessage({
            "type": "MIRSAD_CAPTURE_EVIDENCE",
            "scanId": _value212.scanId,
            "teacher": _value215,
            "period": _value212.period,
            "status": _options2.status,
            "detail": _options2.detail,
            "evidence": _options2.evidence
          });
          if (!_value218?.["ok"]) _options2 = {
            "status": "unresolved",
            "teacher": _value212.teacher,
            "detail": "\u062A\u0639\u0630\u0631 \u062D\u0641\u0638 \u0644\u0642\u0637\u0629 \u062A\u064F\u0638\u0647\u0631 \u0627\u0633\u0645 \u0627\u0644\u0645\u0639\u0644\u0645 \u0641\u064A \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0645\u062F\u0639\u0648\u064A\u0646" + (_value218?.["error"] ? ": " + String(_value218.error).slice(0, 180) : "") + "\u061B \u0644\u0645 \u064A\u064F\u0633\u062C\u0651\u0644 \u063A\u064A\u0627\u0628."
          };else _options2.detail += " \u062D\u064F\u0641\u0638\u062A \u0644\u0642\u0637\u0629 \u0627\u0644\u062F\u0644\u064A\u0644: " + _value218.filename;
        }
      } catch (_value219) {
        _options2 = {
          "status": "unresolved",
          "teacher": _value212.teacher,
          "detail": "\u062A\u0639\u0630\u0631 \u062D\u0641\u0638 \u0644\u0642\u0637\u0629 \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0645\u062F\u0639\u0648\u064A\u0646\u061B \u0644\u0645 \u064A\u064F\u0633\u062C\u0651\u0644 \u063A\u064A\u0627\u0628."
        };
      }
      if (_options2.status === "unresolved") {
        const _value220 = _options2.teacher || _value212.teacher;
        try {
          const _value221 = await chrome.runtime.sendMessage({
            "type": "MIRSAD_CAPTURE_EVIDENCE",
            "scanId": _value212.scanId,
            "teacher": _value220,
            "period": _value212.period,
            "status": "unresolved",
            "detail": _options2.detail
          });
          _options2.detail += _value221?.["ok"] ? " \u062D\u064F\u0641\u0638\u062A \u0635\u0648\u0631\u0629 \u063A\u064A\u0631 \u0645\u062D\u0633\u0648\u0645: " + _value221.filename : " \u062A\u0639\u0630\u0631 \u062D\u0641\u0638 \u0635\u0648\u0631\u0629 \u063A\u064A\u0631 \u0645\u062D\u0633\u0648\u0645" + (_value221?.["error"] ? ": " + String(_value221.error).slice(0, 180) : "");
        } catch (_value222) {
          _options2.detail += " \u062A\u0639\u0630\u0631 \u062D\u0641\u0638 \u0635\u0648\u0631\u0629 \u063A\u064A\u0631 \u0645\u062D\u0633\u0648\u0645: " + String(_value222?.["message"] || _value222).slice(0, 180);
        }
      }
      if (_value195()) await _value206();
      chrome.runtime.sendMessage({
        "type": "MIRSAD_SCAN_RESULT",
        "scanId": _value212.scanId,
        "result": _options2
      });
    })["catch"](async _argument118 => {
      try {
        const _value223 = await chrome.runtime.sendMessage({
          "type": "MIRSAD_PAGE_READY"
        });
        if (_value223?.["active"] && _value223.scanId) {
          const _value224 = "\u062A\u0639\u0637\u0644 \u0641\u062D\u0635 Teams \u0628\u0633\u0628\u0628 \u062E\u0637\u0623 \u062F\u0627\u062E\u0644\u064A: " + String(_argument118?.["message"] || _argument118 || "\u062E\u0637\u0623 \u063A\u064A\u0631 \u0645\u0639\u0631\u0648\u0641").slice(0, 180) + ". \u0644\u0645 \u064A\u064F\u0633\u062C\u0651\u0644 \u063A\u064A\u0627\u0628.";
          await chrome.runtime.sendMessage({
            "type": "MIRSAD_SCAN_RESULT",
            "scanId": _value223.scanId,
            "result": {
              "status": "unresolved",
              "detail": _value224
            }
          });
        }
      } catch (_value225) {}
    }));
  })();
})();