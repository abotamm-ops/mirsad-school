"use strict";

(function (_argument) {
  'use strict';

  const _value = _argument2 => String(_argument2 || "").normalize("NFKC").replace(/[\u064B-\u065F\u0670\u0640]/g, "").replace(/[أإآ]/g, "\u0627").replace(/ى/g, "\u064A").replace(/\s+/g, " ").trim(),
    _value2 = (_argument3 = new Date()) => new Intl.DateTimeFormat("en-CA", {
      "timeZone": "Asia/Riyadh",
      "year": "numeric",
      "month": "2-digit",
      "day": "2-digit"
    }).format(_argument3);
  function _value3(_argument4, _argument5) {
    if (_argument4.length !== _argument5 || _argument4.some(_argument6 => !["present", "absent"].includes(_argument6?.["status"]))) return "unresolved";
    const _value4 = _argument4.filter(_argument7 => _argument7.status === "absent").length;
    return _value4 === _argument5 ? "absent" : _value4 === 0 ? "present" : _argument5 === 3 && _value4 === 2 ? "partial-absence" : "partial";
  }
  const _options = {
    "manualStart": "06:30",
    "periodDuration": 45,
    "manualGapMinutes": 1
  };
  function _value5(_argument8, _argument9, _argument0 = new Date()) {
    const _value6 = _argument8.snapshot.date,
      _value7 = _value2(_argument0);
    if (_value6 < _value7) return true;
    if (_value6 > _value7) return false;
    const _options2 = {
        ..._options,
        ..._argument8.snapshot.scheduleSettings,
        ..._argument8.reportSchedule
      },
      _value8 = /^(\d{2}):(\d{2})$/.exec(_options2.manualStart || "");
    if (!_value8) return false;
    const _value9 = Number(_options2.periodDuration),
      _value0 = Number(_options2.manualGapMinutes);
    if (!Number.isFinite(_value9) || _value9 < 1 || !Number.isFinite(_value0) || _value0 < 0) return false;
    const _value1 = Number(_value8[1]) * 60 + Number(_value8[2]) + (_argument9 - 1) * (_value9 + _value0) + _value9;
    return _argument0.getTime() >= new Date(_value6 + "T00:00:00+03:00").getTime() + _value1 * 60000;
  }
  function _value10(_argument1, _argument10, _argument11) {
    if (Number(_argument10) !== 7) return false;
    if (typeof _argument11?.["seventhPeriodEnabled"] === "boolean") return !_argument11.seventhPeriodEnabled;
    return Number(_argument10) === 7 && /^\d{4}-\d{2}-\d{2}$/.test(String(_argument1)) && new Date(_argument1 + "T12:00:00Z").getUTCDay() === 4;
  }
  function _value11(_argument12, _argument13, _argument14 = new Date()) {
    const _value12 = _argument12.snapshot.date,
      _value13 = _value2(_argument14);
    if (_value12 < _value13) return true;
    if (_value12 > _value13) return false;
    const _options3 = {
        ..._options,
        ..._argument12.snapshot.scheduleSettings,
        ..._argument12.reportSchedule
      },
      _value14 = /^(\d{2}):(\d{2})$/.exec(_options3.manualStart || ""),
      _value15 = Number(_options3.periodDuration),
      _value16 = Number(_options3.manualGapMinutes);
    if (!_value14 || !Number.isFinite(_value15) || _value15 < 1 || !Number.isFinite(_value16) || _value16 < 0) return false;
    const _value17 = Number(_value14[1]) * 60 + Number(_value14[2]) + (_argument13 - 1) * (_value15 + _value16);
    return _argument14.getTime() >= new Date(_value12 + "T00:00:00+03:00").getTime() + _value17 * 60000;
  }
  function _value18(_argument15, _argument16 = {}) {
    if (!_argument15?.["snapshot"]) return [];
    const _value19 = _argument15.adjustments || [];
    return _argument15.snapshot.lessons.filter(_argument17 => !_value10(_argument15.snapshot.date, _argument17.period, _argument15.snapshot)).map(_argument18 => {
      const _value20 = [..._value19].reverse().find(_argument19 => _argument19.type === "reset" || _argument19.type === "range-reset" && _argument19.teacherId === _argument18.teacherId && _argument19.period === _argument18.period),
        _value21 = _value20?.["at"] || 0,
        _value22 = (_argument15.records || []).filter(_argument20 => _argument20.teacherId === _argument18.teacherId && Number(_argument20.period) === _argument18.period),
        _value23 = _value22.filter(_argument21 => !_value20 || _argument21.scannedAt > _value21),
        _value24 = _value11(_argument15, _argument18.period, _argument16.now || new Date()),
        _value25 = Array.from({
          "length": _argument15.snapshot.roundCount
        }, (_argument22, _argument23) => _value23.filter(_argument24 => _argument24.cycle === _argument23 + 1).sort((_argument25, _argument26) => _argument26.scannedAt - _argument25.scannedAt)[0] || {
          "status": "unresolved",
          "pending": true
        }).map(_argument27 => _argument27.status === "no-link" && _value24 ? {
          ..._argument27,
          "status": "absent",
          "absenceReason": "no-link"
        } : _argument27),
        _value26 = _value25.filter(_argument28 => ["present", "absent"].includes(_argument28.status)),
        _value27 = [..._value19].reverse().find(_argument29 => _argument29.type === "override" && _argument29.teacherId === _argument18.teacherId && _argument29.period === _argument18.period && (!_value20 || _argument29.sequence > _value20.sequence)),
        _value28 = _value5(_argument15, _argument18.period, _argument16.now || new Date()),
        _value29 = !_value20 && !_value26.some(_argument30 => _argument30.status === "present") && _value24 && (_argument18.url || "") === "",
        _value30 = _value28 && !_value23.length && !_value27 && !_value20,
        _value31 = _value29,
        _value32 = _value25.every(_argument31 => ["present", "absent"].includes(_argument31.status)),
        _value33 = _value27 ? _value27.status : _value31 ? "absent" : _value30 ? "unresolved" : _argument15.snapshot.roundCount === 3 ? _value32 ? _value3(_value25, 3) : _value25.some(_argument32 => !_argument32.pending && !["present", "absent"].includes(_argument32.status)) ? "unresolved" : "pending" : _value26.length ? _value3(_value26, _value26.length) : _value23.some(_argument33 => _argument33.status === "unresolved") ? "unresolved" : "pending";
      return {
        ..._argument18,
        "rounds": _value25,
        "state": _value33,
        "displayState": _value33,
        "override": _value27 || null,
        "inferred": !_value27 && _value31,
        "noLinkAbsence": !_value27 && _value29,
        "ended": _value28,
        "started": _value24,
        "unscanned": _value30,
        "reset": !!_value20 && !_value23.length && !_value27,
        "pendingRounds": _value27 || _value31 || _value30 ? 0 : _value25.filter(_argument34 => _argument34.pending).length,
        "failedRounds": _value27 ? 0 : _value25.filter(_argument35 => !_argument35.pending && !["present", "absent"].includes(_argument35.status)).length,
        "evidence": _value22.filter(_argument36 => _argument36.evidenceUrl && _argument36.status !== "present"),
        "history": _value22,
        "adjustments": _value19.filter(_argument37 => _argument37.type === "reset" || _argument37.teacherId === _argument18.teacherId && _argument37.period === _argument18.period),
        "late": !_value27 && _value33 === "partial" && _value25[0]?.["status"] === "absent" && _value25.slice(1).some(_argument38 => _argument38.status === "present")
      };
    });
  }
  function _value34(_argument39) {
    const _value35 = _argument39.rounds.filter(_argument40 => !_argument40.pending),
      _value36 = _value35.slice().sort((_argument41, _argument42) => Number(_argument42.scannedAt || 0) - Number(_argument41.scannedAt || 0) || Number(_argument42.cycle || 0) - Number(_argument41.cycle || 0))[0],
      _value37 = !_argument39.override && !_argument39.inferred && !_argument39.reset && _argument39.pendingRounds > 0 && !!_value36;
    return {
      "state": _value37 && ["present", "absent", "unresolved"].includes(_value36.status) ? _value36.status : _argument39.displayState || _argument39.state,
      "provisional": _value37,
      "cycle": _value36 ? _argument39.rounds.indexOf(_value36) + 1 : 0,
      "completed": _value35.length,
      "total": _argument39.rounds.length
    };
  }
  function _value38(_argument43, _argument44 = {}) {
    const _value39 = new Map();
    for (const _value40 of _argument43) {
      const _value41 = _value18(_value40, _argument44);
      for (const _value42 of _value40.snapshot?.["teachers"] || []) {
        let _value43 = _value39.get(_value42.id) || {
          ..._value42,
          "scheduled": 0,
          "absentLessons": 0,
          "absentDays": 0,
          "present": 0,
          "unknown": 0,
          "partial": 0,
          "partialAbsence": 0,
          "late": 0
        };
        const _value44 = _value41.filter(_argument45 => _argument45.teacherId === _value42.id);
        _value43.scheduled += _value44.length;
        for (const _value45 of _value44) {
          _value43.absentLessons += Number(_value45.state === "absent"), _value43.present += Number(["present", "partial"].includes(_value45.state)), _value43.unknown += Number(_value45.state === "unresolved"), _value43.partial += Number(_value45.state === "partial"), _value43.partialAbsence += Number(_value45.state === "partial-absence"), _value43.late += Number(_value45.late);
        }
        _value43.absentDays += Number(_value44.length > 0 && _value44.every(_argument46 => _argument46.state === "absent")), _value43.percent = _value43.scheduled ? Math.round(_value43.absentLessons / _value43.scheduled * 1000) / 10 : 0, _value39.set(_value42.id, _value43);
      }
    }
    return [..._value39.values()];
  }
  function _value46(_argument47, _argument48 = {}) {
    const _value47 = _argument48.now || new Date(),
      _value48 = _value2(_value47),
      _options4 = {
        "date": _value48,
        "period": null,
        "alerts": [],
        "cycles": [],
        "latestScanAt": null
      };
    if (!_argument47?.["snapshot"] || _argument47.snapshot.date !== _value48) return _options4;
    const _options5 = {
        ..._options,
        ..._argument47.snapshot.scheduleSettings,
        ..._argument47.reportSchedule
      },
      _value49 = /^(\d{2}):(\d{2})$/.exec(_options5.manualStart || "");
    if (!_value49) return _options4;
    const _value50 = Number(_options5.periodDuration),
      _value51 = Number(_options5.manualGapMinutes);
    if (!Number.isFinite(_value50) || _value50 < 1 || !Number.isFinite(_value51) || _value51 < 0) return _options4;
    const _value52 = new Date(_value48 + "T00:00:00+03:00").getTime() + (Number(_value49[1]) * 60 + Number(_value49[2])) * 60000;
    if (!_argument47.reportSchedule && !_argument47.snapshot.scheduleSettings && (_argument47.records || []).some(_argument49 => {
      if (!Number.isInteger(_argument49.period) || _argument49.period < 1 || _argument49.period > 7 || !Number.isFinite(_argument49.scannedAt) || _value2(new Date(_argument49.scannedAt)) !== _value48) return false;
      const _value53 = _value52 + (_argument49.period - 1) * (_value50 + _value51) * 60000;
      return _argument49.scannedAt < _value53 - 120000 || _argument49.scannedAt > _value53 + _value50 * 60000 + 120000;
    })) return {
      ..._options4,
      "timingMismatch": true
    };
    let _value54 = null,
      _value55,
      _value56;
    for (let _number = 1; _number <= 7; _number++) {
      if (_value10(_argument47.snapshot.date, _number, _argument47.snapshot)) continue;
      const _value57 = _value52 + (_number - 1) * (_value50 + _value51) * 60000,
        _value58 = _value57 + _value50 * 60000;
      if (_value47.getTime() >= _value57 && _value47.getTime() < _value58) {
        _value54 = _number, _value55 = _value57, _value56 = _value58;
        break;
      }
    }
    if (!_value54) return _options4;
    const _value59 = [...(_argument47.adjustments || [])].reverse().find(_argument50 => _argument50.type === "reset"),
      _value60 = _value59?.["at"] || 0,
      _value61 = (_argument47.records || []).filter(_argument51 => Number(_argument51.period) === _value54 && _argument51.scannedAt >= _value55 && _argument51.scannedAt <= _value47.getTime() && _argument51.scannedAt > _value60),
      _value62 = Array.from({
        "length": _argument47.snapshot.roundCount
      }, (_argument52, _argument53) => {
        const _value63 = _value61.filter(_argument54 => _argument54.cycle === _argument53 + 1);
        return {
          "cycle": _argument53 + 1,
          "count": _value63.length,
          "firstResultAt": _value63.length ? Math.min(..._value63.map(_argument55 => _argument55.scannedAt)) : null,
          "lastResultAt": _value63.length ? Math.max(..._value63.map(_argument56 => _argument56.scannedAt)) : null
        };
      }),
      _items = [];
    for (const _value64 of _value18(_argument47, {
      "now": _value47
    }).filter(_argument57 => _argument57.period === _value54)) {
      const _value65 = _value61.filter(_argument58 => _argument58.teacherId === _value64.teacherId).map(_argument59 => _argument59.status === "no-link" ? {
          ..._argument59,
          "status": "absent",
          "absenceReason": "no-link"
        } : _argument59).sort((_argument60, _argument61) => _argument60.scannedAt - _argument61.scannedAt || _argument60.cycle - _argument61.cycle),
        _value66 = _value65.filter(_argument62 => ["present", "absent"].includes(_argument62.status)),
        _value67 = _value66[_value66.length - 1];
      if (_value64.override ? _value64.override.status !== "absent" : _value67?.["status"] !== "absent") continue;
      _items.push({
        "teacherId": _value64.teacherId,
        "teacher": _value64.teacherName,
        "period": _value54,
        "cycle": _value64.override ? null : _value67.cycle,
        "scannedAt": _value64.override ? _value64.override.at : _value67.scannedAt,
        "manual": !!_value64.override,
        ...(_value67?.["absenceReason"] ? {
          "absenceReason": _value67.absenceReason
        } : {}),
        "evidenceUrl": _value67?.["status"] === "absent" ? _value67.evidenceUrl || null : null,
        "evidenceCycle": _value67?.["status"] === "absent" ? _value67.cycle : null,
        "evidenceAt": _value67?.["status"] === "absent" ? _value67.scannedAt : null,
        "cycles": _value62.map(_argument63 => {
          const _value68 = _value65.filter(_argument64 => _argument64.cycle === _argument63.cycle),
            _value69 = _value68[_value68.length - 1];
          return {
            "cycle": _argument63.cycle,
            "status": _value69?.["status"] || "pending",
            "scannedAt": _value69?.["scannedAt"] || null
          };
        })
      });
    }
    return _items.sort((_argument65, _argument66) => _argument65.scannedAt - _argument66.scannedAt), {
      "date": _value48,
      "period": _value54,
      "startedAt": _value55,
      "endAt": _value56,
      "minutesIntoPeriod": Math.floor((_value47.getTime() - _value55) / 60000),
      "alerts": _items,
      "cycles": _value62,
      "latestScanAt": _value61.length ? Math.max(..._value61.map(_argument67 => _argument67.scannedAt)) : null
    };
  }
  const _options6 = {
    "normalize": _value,
    "day": _value2,
    "state": _value3,
    "cells": _value18,
    "presentation": _value34,
    "stats": _value38,
    "lessonEnded": _value5,
    "lessonStarted": _value11,
    "isExcludedPeriod": _value10,
    "defaultSchedule": _options,
    "live": _value46
  };
  if (typeof module !== "undefined") module.exports = _options6;else _argument.MirsadMonitorModel = _options6;
})(globalThis);