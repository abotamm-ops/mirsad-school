"use strict";

var MirsadCommercialAccount = (() => {
  const _text = "mirsadDriveConfig",
    _text2 = "mirsadCommercialDevice",
    _value = () => [...crypto.getRandomValues(new Uint8Array(32))].map(_argument => _argument.toString(16).padStart(2, "0")).join("");
  async function _value2(_argument2) {
    if (!/^https:\/\/script\.google\.com\/macros\/s\/[A-Za-z0-9_-]+\/exec$/.test(_argument2.endpoint || "")) throw new Error("\u0631\u0627\u0628\u0637 \u0627\u0644\u062A\u0641\u0639\u064A\u0644 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D");
    const _value3 = (await chrome.storage.local.get("mirsadCommercialSchool")).mirsadCommercialSchool,
      _value4 = /^a\.([a-f0-9-]{36})\./.exec(_argument2.adminKey || "")?.[1];
    if (!_value4) throw new Error("\u062C\u0644\u0633\u0629 \u0627\u0644\u0645\u062F\u0631\u0633\u0629 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D\u0629");
    if (_value3?.["id"] && _value3.id !== _value4) throw new Error("\u0645\u0644\u0641 Chrome \u0647\u0630\u0627 \u0645\u0631\u062A\u0628\u0637 \u0628\u0645\u062F\u0631\u0633\u0629 \u0623\u062E\u0631\u0649\u061B \u0627\u0633\u062A\u062E\u062F\u0645 \u0645\u0644\u0641 Chrome \u0645\u0633\u062A\u0642\u0644\u064B\u0627 \u0644\u0647\u0630\u0647 \u0627\u0644\u0645\u062F\u0631\u0633\u0629");
    const _value5 = typeof getRun === "function" ? await getRun() : null;
    if (_value5?.["running"]) throw new Error("\u0623\u0648\u0642\u0641 \u0627\u0644\u0631\u0635\u062F \u0645\u0624\u0642\u062A\u064B\u0627 \u0642\u0628\u0644 \u0625\u0639\u0627\u062F\u0629 \u0631\u0628\u0637 \u0627\u0644\u062C\u0647\u0627\u0632");
    let _value6 = (await chrome.storage.local.get(_text2))[_text2];
    !_value6 && (_value6 = {
      "deviceId": crypto.randomUUID(),
      "deviceSecret": _value()
    }, await chrome.storage.local.set({
      [_text2]: _value6
    }));
    const _value7 = await fetch(_argument2.endpoint, {
        "method": "POST",
        "headers": {
          "Content-Type": "text/plain;charset=utf-8"
        },
        "body": JSON.stringify({
          "action": "commercialEnrollDevice",
          "key": _argument2.adminKey,
          ..._value6
        }),
        "signal": AbortSignal.timeout(35000)
      }),
      _value8 = await _value7.json();
    if (!_value7.ok || !_value8.ok) throw new Error(_value8.error || "\u062A\u0639\u0630\u0631 \u0631\u0628\u0637 \u0627\u0644\u062C\u0647\u0627\u0632");
    await chrome.storage.local.set({
      [_text]: {
        "url": _argument2.endpoint,
        "key": _value8.writerKey
      },
      "mirsadCommercialSchool": _value8.school,
      "mirsadCommercialSubscription": {
        "active": _value8.school.active,
        "expiresAt": _value8.school.expiresAt,
        "at": Date.now()
      }
    });
    const _value9 = await _value0(_value4);
    if (!_value9.configured) throw new Error("\u0644\u0645 \u064A\u062B\u0628\u062A \u062D\u0641\u0638 \u0631\u0628\u0637 \u0627\u0644\u0645\u062F\u0631\u0633\u0629 \u062F\u0627\u062E\u0644 \u0627\u0644\u0625\u0636\u0627\u0641\u0629\u061B \u0623\u0639\u062F \u0627\u0644\u0631\u0628\u0637 \u0645\u0646 \u0647\u0630\u0627 \u0627\u0644\u0645\u062A\u0635\u0641\u062D");
    return {
      "ok": true,
      ..._value9
    };
  }
  const _value1 = new Map();
  function _value10(_argument3) {
    return _argument3?.["retryable"] === true || ["TimeoutError", "AbortError", "TypeError"].includes(_argument3?.["name"]) || /signal timed out|failed to fetch|network|تعذر الاتصال بخدمة Drive \((408|429|5\d\d)\)/i.test(_argument3?.["message"] || "");
  }
  async function _value11(_argument4, _argument5) {
    if (!_argument4) return;
    const _value12 = (await chrome.storage.local.get(_text))[_text];
    if (_value12?.["key"] !== _argument5) return;
    await chrome.storage.local.set({
      "mirsadCommercialSubscription": {
        ..._argument4,
        "verifiedKey": _argument5,
        "at": Date.now()
      }
    });
  }
  async function _value13() {
    const _value14 = await chrome.storage.local.get(["mirsadCommercialSubscription", _text]),
      _value15 = _value14.mirsadCommercialSubscription,
      _value16 = _value14[_text];
    if (!_value16?.["key"]) throw new Error("\u0633\u062C\u0651\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u0627\u0644\u0625\u064A\u0645\u064A\u0644 \u0648\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u0645\u0646 \u062F\u0627\u062E\u0644 \u0627\u0644\u0625\u0636\u0627\u0641\u0629");
    const _value17 = Date.now() - Number(_value15?.["at"]),
      _value18 = Number(_value15?.["serverTime"]) || Date.now() - _value17;
    if (_value15?.["verifiedKey"] === _value16.key && _value15.active && _value17 >= 0 && _value17 < 45000 && Number(_value15.expiresAt) > _value18 + _value17) return;
    if (_value1.has(_value16.key)) return _value1.get(_value16.key);
    const _value19 = (async () => {
      const _value20 = await fetch(_value16.url, {
        "method": "POST",
        "headers": {
          "Content-Type": "text/plain;charset=utf-8"
        },
        "body": JSON.stringify({
          "action": "getTimetableSource",
          "key": _value16.key,
          ...(await _value21())
        }),
        "signal": AbortSignal.timeout(12000)
      });
      if ([408, 429].includes(_value20.status) || _value20.status >= 500) {
        const _value22 = new Error("\u062A\u0623\u062E\u0631 \u0627\u0644\u0627\u062A\u0635\u0627\u0644 \u0628\u062E\u062F\u0645\u0629 \u0631\u0627\u0635\u062F");
        _value22.retryable = true;
        throw _value22;
      }
      const _value23 = await _value20.json();
      if (!_value20.ok || !_value23.ok) {
        const _value24 = new Error(_value23.error || "\u062A\u0639\u0630\u0631 \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u0627\u0634\u062A\u0631\u0627\u0643 \u0627\u0644\u0645\u062F\u0631\u0633\u0629");
        _value24.code = _value23.code, await _value25(_value24, _value16.key);
        throw _value24;
      }
      if ((await chrome.storage.local.get(_text))[_text]?.["key"] !== _value16.key) throw new Error("\u062A\u063A\u064A\u0631\u062A \u062C\u0644\u0633\u0629 \u0627\u0644\u0625\u0636\u0627\u0641\u0629\u061B \u0623\u0639\u062F \u062A\u0634\u063A\u064A\u0644 \u0627\u0644\u0631\u0635\u062F");
      await _value11(_value23.subscription, _value16.key);
      if (!_value23.subscription?.["active"]) {
        const _value26 = new Error("\u0627\u0646\u062A\u0647\u0649 \u0627\u0644\u0627\u0634\u062A\u0631\u0627\u0643 \u0627\u0644\u0634\u0647\u0631\u064A\u061B \u062A\u0648\u0627\u0635\u0644 \u0645\u0639 \u0631\u0627\u0635\u062F \u0644\u0644\u062A\u062C\u062F\u064A\u062F");
        _value26.code = "subscription-expired", await _value25(_value26, _value16.key);
        throw _value26;
      }
    })();
    _value1.set(_value16.key, _value19);
    try {
      return await _value19;
    } finally {
      if (_value1.get(_value16.key) === _value19) _value1["delete"](_value16.key);
    }
  }
  async function _value25(_argument6, _argument7) {
    if (!["subscription-expired", "device-revoked", "school-disabled", "invalid-session", "device-proof"].includes(_argument6.code)) return;
    const _value27 = await chrome.storage.local.get(["mirsadAutoRun", _text]);
    if (_argument7 && _value27[_text]?.["key"] !== _argument7) return;
    if (_value27.mirsadAutoRun?.["running"] && typeof pauseMonitoring === "function") await pauseMonitoring();
    await chrome.storage.local.set({
      "mirsadCommercialSubscription": {
        "active": false,
        "expiresAt": 0,
        "at": Date.now()
      },
      "mirsadAutoStatus": {
        "text": _argument6.message,
        "at": Date.now(),
        "error": true
      }
    });
  }
  async function _value21() {
    return (await chrome.storage.local.get(_text2))[_text2] || {};
  }
  async function _value0(_argument8) {
    const _value28 = await chrome.storage.local.get([_text, _text2, "mirsadCommercialSchool"]),
      _value29 = _value28[_text],
      _value30 = _value28[_text2],
      _value31 = _value28.mirsadCommercialSchool,
      _value32 = !!_value29?.["url"] && !!_value29?.["key"] && !!_value30?.["deviceId"] && !!_value30?.["deviceSecret"] && !!_value31?.["id"] && (!_argument8 || _value31.id === _argument8);
    return {
      "configured": _value32,
      "schoolId": _value31?.["id"] || null,
      "schoolName": _value31?.["profile"]?.["school"] || "",
      "version": chrome.runtime.getManifest().version
    };
  }
  async function _value33(_argument9) {
    const _value34 = await _value0(_argument9);
    if (!_value34.configured) return {
      "ok": true,
      ..._value34
    };
    const _value35 = (await chrome.storage.local.get(_text))[_text],
      _value36 = await fetch(_value35.url, {
        "method": "POST",
        "headers": {
          "Content-Type": "text/plain;charset=utf-8"
        },
        "body": JSON.stringify({
          "action": "getTimetableSource",
          "key": _value35.key,
          ...(await _value21())
        }),
        "signal": AbortSignal.timeout(35000)
      }),
      _value37 = await _value36.json();
    if (!_value36.ok || !_value37.ok) {
      const _value38 = new Error(_value37.error || "\u062A\u0639\u0630\u0631 \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u062C\u0644\u0633\u0629 \u0627\u0644\u0625\u0636\u0627\u0641\u0629");
      _value38.code = _value37.code;
      throw _value38;
    }
    return {
      "ok": true,
      ..._value34
    };
  }
  return {
    "enroll": _value2,
    "assertActive": _value13,
    "denied": _value25,
    "remember": _value11,
    "transient": _value10,
    "identity": _value21,
    "binding": _value0,
    "verifyBinding": _value33
  };
})();