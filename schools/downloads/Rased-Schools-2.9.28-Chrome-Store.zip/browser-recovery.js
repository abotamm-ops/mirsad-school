"use strict";

var MirsadBrowserRecovery = (() => {
  const _text = "mirsadBrowserRecoveryHeartbeat",
    _text2 = "mirsadBrowserRecoveryStatus";
  let _value = Promise.resolve(),
    _value2 = null,
    _number = 0;
  function _value3(_argument) {
    if (_argument?.["immediateMode"]) return _value3(_argument.suspendedRun);
    return !!_argument?.["running"] && !_argument.paused && _argument.autoResume !== false && !_argument.testMode && !_argument.backtestMode;
  }
  async function _value4() {
    const _value5 = await chrome.storage.local.get("mirsadAutoRun"),
      _value6 = _value3(_value5.mirsadAutoRun),
      _value7 = chrome.windows?.["getAll"] ? (await chrome.windows.getAll({
        "windowTypes": ["normal"]
      })).length > 0 : true,
      _value8 = _value6 + "|" + _value7;
    if (_value2 === _value8 && Date.now() - _number < 20000) return;
    _value2 = _value8, _number = Date.now(), await new Promise(_argument2 => {
      let _value9 = false,
        _value0;
      const _value1 = (_argument3, _argument4) => {
        if (_value9) return;
        _value9 = true, clearTimeout(_value0), chrome.storage.local.set({
          [_text2]: {
            "ok": _argument3,
            "running": _value6,
            "text": _argument3 ? _value6 ? "\u062D\u0645\u0627\u064A\u0629 \u0627\u0644\u0625\u063A\u0644\u0627\u0642 \u062A\u0639\u0645\u0644\u061B \u064A\u0639\u064A\u062F \u0627\u0644\u0645\u0633\u0627\u0639\u062F \u0641\u062A\u062D \u0643\u0631\u0648\u0645 \u0628\u0639\u062F \u0627\u0646\u0642\u0637\u0627\u0639 \u062F\u0642\u064A\u0642\u0629." : "\u062D\u0645\u0627\u064A\u0629 \u0627\u0644\u0625\u063A\u0644\u0627\u0642 \u0645\u062A\u0648\u0642\u0641\u0629 \u0645\u0639 \u0625\u064A\u0642\u0627\u0641 \u0627\u0644\u0631\u0635\u062F." : "\u0625\u0639\u0627\u062F\u0629 \u0641\u062A\u062D \u0643\u0631\u0648\u0645 \u063A\u064A\u0631 \u0645\u0641\u0639\u0651\u0644\u0629\u061B \u062D\u062F\u0651\u062B \u0645\u0633\u0627\u0639\u062F \u0627\u0644\u062D\u0641\u0638 \u062B\u0645 \u0627\u0641\u062D\u0635\u0647.",
            "error": _argument4,
            "at": Date.now()
          }
        }).then(_argument2, _argument2);
      };
      _value0 = setTimeout(() => _value1(false, "\u0627\u0646\u062A\u0647\u062A \u0645\u0647\u0644\u0629 \u0627\u0644\u0645\u0633\u0627\u0639\u062F"), 4000);
      try {
        chrome.runtime.sendNativeMessage("com.mirsad.local_backup", {
          "action": "browserRecovery",
          "running": _value6,
          "windowOpen": _value7
        }, _argument5 => {
          const _value10 = chrome.runtime.lastError;
          _value1(!_value10 && _argument5?.["ok"] === true && _argument5.browserRecoverySupport === true, _value10?.["message"] || _argument5?.["error"] || "");
        });
      } catch (_value11) {
        _value1(false, _value11.message);
      }
    });
  }
  function _value12() {
    return _value = _value.then(_value4, _value4), _value["catch"](() => {});
  }
  chrome.windows?.["onRemoved"]?.["addListener"](() => {
    _number = 0, void _value12();
  }), chrome.windows?.["onCreated"]?.["addListener"](() => {
    _number = 0, void _value12();
  }), chrome.alarms.onAlarm.addListener(_argument6 => {
    if (_argument6.name === _text) void _value12();
  });
  async function _value13() {
    await chrome.alarms.create(_text, {
      "periodInMinutes": 0.5
    }), await _value12();
  }
  return chrome.runtime.onStartup?.["addListener"](() => void _value13()), chrome.runtime.onInstalled?.["addListener"](() => void _value13()), void _value13(), {
    "sync": _value12,
    "active": _value3
  };
})();