"use strict";

var MirsadOfficialReady = Promise.resolve();