from pathlib import Path
import zipfile,json,base64,secrets,hashlib
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
root=Path(__file__).resolve().parents[1];work=Path('/tmp/mirsad-commercial');out=root/'schools/downloads/Mirsad-Schools-2.9.52-Setup.zip'
readme='''راصد المدارس 2.9.52 — حزمة الإعداد المبسط
1. استخرج الحزمة كاملة إلى مجلد ثابت على جهاز Windows.
2. شغّل «تجهيز راصد.vbs» مرة واحدة لتسجيل مكوّن الحفظ المحلي وفتح المساعد، دون نافذة أوامر سوداء. إذا كان VBScript معطلًا في جهاز المؤسسة، استخدم ملف «تحديث حفظ الفيديو.cmd» الموجود داخل مجلد مكوّن الحفظ المحلي. سيظل تثبيت الإضافة نفسه يدويًا حتى نشرها في متجر كروم.
3. افتح chrome://extensions أو edge://extensions، فعّل وضع المطور، ثم «تحميل إضافة غير محزمة» وحدد مجلد «الإضافة». إذا كانت مثبتة سابقًا استبدل ملفات نفس المجلد وأعد تحميلها؛ لا تحذفها حفاظًا على بياناتها.
4. من الإضافة: تفعيل الاشتراك، ثم بريدك الإلكتروني، ثم رمز الدخول الذي يصلك في البريد. الرمز من ثمانية أرقام ويستخدم مرة واحدة خلال عشر دقائق. بعد التحقق يُنشأ حساب جديد مجاني تلقائيًا ويظهر للمالك. للمالك إيقاف الرصد والمطالبة باشتراك 100 ريال شهريًا؛ يؤكد المالك استلام المبلغ لتفعيل شهر كامل. بعد التحقق، يجب ضبط رقم سري من أربع أرقام للموقع قبل إكمال التفعيل. يظهر اليوزر والرقم أعلى الإضافة والرقم مخفي مع عين لإظهاره. الموقع من أي متصفح أو جوال يطلب اليوزر والرقم السري، مع خيار حفظ الدخول على الجهاز.
5. عند الدخول الأول اربط Google، أو اختر «لا يوجد لدي حساب Google». جهّز الأرشيف المحلي في الحالتين. تنتقل بطاقة التجهيز للحساب عند نجاح الحفظ المحلي وإتمام اختيار Google. إذا لم تربط يبقى زر أحمر بعلامة تعجب فوق الجدول، ويمكن إخفاؤه مؤقتًا لأربع ساعات.
6. لابد من تثبيت دخول مدرستي بيوزر المدير فقط عبر متصفح كروم، واختر البقاء مسجلًا للدخول إذا ظهر. دخول حصص تيمز للرصد عبر كروم فقط؛ احذف برنامج تيمز من جهاز الرصد ليكون دخول الحصص عبر كروم فقط. افتح مدرستي على بيانات المعلمين للتحميل؛ التشغيل السريع يفتح راصد تلقائيًا. افتح تيمز وسجّل الدخول أيضًا. تحقق من أخضر التحميل ثم أخضر حفظ إعدادات الحصص ثم اضغط بدء الرصد.
7. في وضع «كل صباح»، يحدد تاريخ اليوم تلقائيًا ويحاول تهيئة جدوله قبل الحصة بنصف ساعة ويبدأ الرصد في موعد إعداداتك. يمكنك تفعيله من الليلة السابقة. إذا كان وضع «تاريخ أحدده»، يبقى تاريخ المصدر الذي تختاره ويُوثَّق الرصد بتاريخ اليوم. لا يعمل الجهاز وهو مطفأ؛ اترك كروم والمساعد يعملان ومدرستي وتيمز مسجّلًا دخولهما.
8. «تحديث النواقص — مستحسن» مفعّل افتراضيًا. يتوقف تحميل الصباح عند اكتمال الروابط، ثم يتبع التحديث بين الدورات وبعد الدورة الأخيرة إعداد الخدمة.
9. عند استبدال جدول موجود: حفظ السابق وتحميل الجديد، أو حذفه واستبداله، أو إلغاء. نسخ اليوم قابلة للاسترجاع بنتائجها وصورها؛ الأيام الأقدم تُراجع في أرشيف الموقع.
10. الموقع للعرض والمشاهدة. ضبط التسجيل والتوقيت والتحديث داخل الإضافة. إعداد الفيديو اختياري بجانب التشغيل السريع أعلى الواجهة. التسجيل للحصص والدورات التي تختارها فقط، ويتحقق من قائمة حضور الحصة قبل المقطع وأثناءه؛ لا يبدأ التسجيل على صفحة دخول أو تحميل.
التشغيل السريع أعلى الإضافة: افتح مدرستي على بيانات المعلمين، ثم اضغطه. يفتح راصد أولًا ويحاول تهيئة تبويب الفيديو المستقل، ولا تظهر علامة الصح إلا بعد نجاح التقاط الصوت والصورة. إذا رفض كروم الالتقاط، افتح الإضافة من راصد واضغط تفعيل الفيديو، أو اختر متابعة بدون فيديو. بعدها يطبّق أرقام اللوحة وتاريخ الجدول. إذا لم يكن جدول التاريخ المختار محمّلًا، يحدّث الصفحتين ويحمّله ثم يكمل التشغيل. في كل صباح يكون تاريخ المصدر يوم التشغيل ويجهز الجدول تلقائيًا. التحميل يقرأ بيانات المعلمين مباشرة ولا يشترط صفحة راصد أو تسجيل الدخول فيها. إذا لم تستجب بيانات المعلمين يحاول تحديث صفحة مدرستي مرة واحدة قبل إعادة القراءة. لا يُستبدل جدول ينتظر قرارك بصمت.
ترتيب الواجهة: 1 فتح مدرستي وراصد، 2 تحميل الجدول، 3 ضبط الحصص، 4 ضبط الدورات، 5 بدء الرصد. تتحول كل خطوة للأخضر عند جاهزيتها.
طريقة الاستخدام: https://mirsad-school.onrender.com/schools/guide.html
زر الواتساب يجهز رسالة بالرابط واليوزر والرقم السري؛ أرسلها للمخولين فقط. تغيير الرقم من الحساب يلغي جلسات الموقع القديمة.
11. رسائل المالك تظهر داخل الإضافة عند فتحها بعد المزامنة. صفحة الاشتراك ورفع الفاتورة متاحة من الحساب ومن حالة توقف الاشتراك. رفع الفاتورة والتفعيل الفوري يحتاج خدمة المالك 2.9.44 وفتح الدفع منها؛ يكون مغلقًا افتراضيًا. لا ترسل سكربت المالك للمدارس.
12. عند تحديث الخدمة إلى 2.9.44: الاشتراك على بريد واحد، ويسمح بعدة مدارس. افتح مدرستي بمدير المدرسة المطلوبة واضغط تحميل الجدول؛ تُضاف المدرسة تلقائيًا بأرشيف مستقل. أوقف رصد المدرسة الحالية قبل الانتقال لمدرسة أخرى. لا يمكن رصد مدرستين بنفس البريد في الوقت نفسه، سواء على جهاز واحد أو جهازين. لنقل الحساب، سجّل الخروج من الجهاز السابق. تعمل هذه النسخة مع الخدمة الحالية 2.9.40 لمدرسة واحدة، ويتفعل تعدد المدارس عند تحديث الخدمة إلى 2.9.44.
13. راصد يمنع السكون التلقائي وإطفاء الشاشة أثناء الرصد أو انتظار الموعد المجدول، ويحرر المنع عند الإيقاف أو الإيقاف المؤقت أو تسجيل الخروج. للاحتياط اضبط السكون وإيقاف الشاشة على «أبدًا» أثناء الشحن، ولا تغلق غطاء الجهاز أو تدخل السكون يدويًا.
هذه حزمة المسار المبسط. اختُبرت الواجهة والجدولة والخدمة آليًا. جرّب مدرسة واحدة ميدانيًا وتأكد من الرصد والحفظ والفيديو قبل التوزيع الواسع. ميزة الفواتير والتفعيل الجديدة تحتاج تجربة فعلية بعد نشر خدمة المالك.
'''
launcher='''Option Explicit
Dim shell, fso, base, host, helper, result
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
base = fso.GetParentFolderName(WScript.ScriptFullName)
host = fso.BuildPath(base, "مكوّن الحفظ المحلي\\MirsadSchoolFilesHost.exe")
helper = fso.BuildPath(base, "تطبيق راصد\\MirsadChromeGuardian\\MirsadChromeGuardian.exe")
If Not fso.FileExists(host) Then
 MsgBox "استخرج الحزمة كاملة قبل التشغيل.", 48, "راصد المدارس"
 WScript.Quit 1
End If
result = shell.Run(Chr(34) & host & Chr(34) & " --install-native", 0, True)
If result <> 0 Then
 MsgBox "تعذر تجهيز الحفظ. شغّل مكوّن الحفظ المحلي مرة أخرى أو تواصل مع الدعم.", 48, "راصد المدارس"
 WScript.Quit result
End If
If fso.FileExists(helper) Then shell.Run Chr(34) & helper & Chr(34), 1, False
MsgBox "تم تجهيز مكوّن الحفظ المحلي. حمّل مجلد الإضافة من صفحة إضافات كروم، ثم فعّل اشتراكك من الإضافة.", 64, "راصد المدارس"
'''
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted((work/'extension').rglob('*')):
  if f.is_file():z.write(f,'الإضافة/'+str(f.relative_to(work/'extension')))
 with zipfile.ZipFile(root/'schools/downloads/Rased-Schools-Store-Support-3.4.7.zip') as support:
  z.writestr('تطبيق راصد/MirsadChromeGuardian/MirsadChromeGuardian.exe',support.read('MirsadChromeGuardian.exe'))
  z.writestr('مكوّن الحفظ المحلي/MirsadSchoolFilesHost.exe',support.read('MirsadSchoolFilesHost.exe'))
  z.writestr('مكوّن الحفظ المحلي/تحديث حفظ الفيديو.cmd',support.read('تجهيز الحفظ المحلي.cmd'))
 z.writestr('ابدأ هنا.txt',readme.encode('utf-8-sig'))
 z.writestr('تجهيز راصد.vbs',launcher.encode('utf-16'))
(work/'README.ar.txt').write_text(readme)
import sys
if '--extensions-only' in sys.argv:
 (root/'schools/downloads/Mirsad-Schools-2.9.52-CHECKSUMS.txt').write_text(hashlib.sha256(out.read_bytes()).hexdigest()+'  '+out.name+'\n')
 print('Packaged extension-only layout update; owner script unchanged.')
 raise SystemExit(0)
linkfile=work/'OWNER-2.9.44-LINK.txt'
if linkfile.exists():key=base64.urlsafe_b64decode(linkfile.read_text().strip().split('#')[1]+'=')
else:key=secrets.token_bytes(32)
nonce=secrets.token_bytes(12);data=(work/'owner-2.9.44.gs').read_bytes();cipher=AESGCM(key).encrypt(nonce,data,None)
assert AESGCM(key).decrypt(nonce,cipher,None)==data
site=root/'schools';name='owner-script-2.9.44'
(site/(name+'.encrypted.json')).write_text(json.dumps({'nonce':base64.b64encode(nonce).decode(),'data':base64.b64encode(cipher).decode()}))
for ext in ['html','preview.js']:
 original=site/('owner-script-2.6.20'+('.html' if ext=='html' else '-preview.js'))
 dest=site/(name+('.html' if ext=='html' else '-preview.js'))
 dest.write_text(original.read_text().replace('2.6.20','2.9.44').replace('مرصاد','راصد'))
linkfile.write_text('https://mirsad-school.onrender.com/schools/'+name+'.html#'+base64.urlsafe_b64encode(key).decode().rstrip('=')+'\n')
(root/'schools/downloads/Mirsad-Schools-2.9.52-CHECKSUMS.txt').write_text(hashlib.sha256(out.read_bytes()).hexdigest()+'  '+out.name+'\n')
print('Packaged customer bundle and encrypted owner script; owner opening key retained locally.')
