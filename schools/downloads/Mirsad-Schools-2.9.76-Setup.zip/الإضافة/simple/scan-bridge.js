(() => {
  'use strict';
  const dashboard = 'https://mirsad-school.onrender.com/schools/automatic-monitoring.html';
  if (location.origin + location.pathname !== dashboard) return;
  const keys = ['mirsadActiveScan', 'mirsadAutoRun', 'mirsadCommercialSchool', 'mirsadMultiSchool'];
  let generation = 0;

  async function publishScan() {
    const root = document.documentElement;
    if (!root.classList.contains('mirsad-admin-ready')) return;
    const schoolId = root.dataset.mirsadSchoolId;
    const siteId = root.dataset.mirsadSiteId || '';
    if (!schoolId) return;
    const request = ++generation;
    try {
      const state = await chrome.storage.local.get(keys);
      if (request !== generation || !root.classList.contains('mirsad-admin-ready') ||
          root.dataset.mirsadSchoolId !== schoolId || (root.dataset.mirsadSiteId || '') !== siteId) return;
      if (state.mirsadCommercialSchool?.id !== schoolId || (state.mirsadMultiSchool?.site?.id || '') !== siteId) return;
      const run = state.mirsadAutoRun;
      const scan = state.mirsadActiveScan;
      const activity = run?.running && !run.paused && !run.testMode && !run.backtestMode &&
        (run.multiSiteId || '') === siteId && scan?.active && scan.scanId &&
        run.current?.scanId === scan.scanId ? scan : null;
      window.postMessage({source:'mirsad-monitor-extension',type:'activity',payload:{ok:true,activity}}, location.origin);
    } catch {
      // The website can still follow the server heartbeat if the extension is reloading.
    }
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && keys.some(key => key in changes)) void publishScan();
  });
  window.addEventListener('mirsad-admin-login', publishScan);
  window.addEventListener('pageshow', publishScan);
  setInterval(publishScan, 8000);
  void publishScan();
})();
