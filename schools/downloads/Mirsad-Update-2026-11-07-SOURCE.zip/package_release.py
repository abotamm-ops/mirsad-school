from pathlib import Path
import shutil,zipfile,hashlib,json
R=Path(__file__).parent;repo=Path('/tmp/mirsad-current-fix');out=Path('/workspace/downloads');out.mkdir(exist_ok=True)
# Preserve the final shared sources, not the earlier integration drafts.
for name in ['guardian-workspace.js','auto-links.js','auto-links-bridge.js','quick-start.js','quick-start-ui.js']:
 (R/'shared'/name).write_bytes((R/'private-extension'/name).read_bytes())
for edition,version,target in [('private','0.6.76',repo/'teams-probe'),('schools','2.2.1',repo/'schools/extension')]:
 source=R/(edition+'-extension');target.mkdir(exist_ok=True)
 html=source/'popup.html';text=html.read_text().replace('0.6.75','0.6.76') if edition=='private' else html.read_text().replace('2.2.0','2.2.1');html.write_text(text)
 for p in source.rglob('*'):
  if p.is_file():
   q=target/p.relative_to(source);q.parent.mkdir(exist_ok=True,parents=True);shutil.copy2(p,q)
 name=('Mirsad-Teams-' if edition=='private' else 'Mirsad-Schools-')+version+'.zip'
 with zipfile.ZipFile(out/name,'w',zipfile.ZIP_DEFLATED) as z:
  for p in source.rglob('*'):
   if p.is_file():z.write(p,'الإضافة/'+str(p.relative_to(source)))
  z.write(R/'helper/MirsadChromeGuardian.exe','تطبيق مرصاد/MirsadChromeGuardian.exe');z.write(R/'UPDATE-AR.txt','اقرأ أولًا.txt')
 shutil.copy2(out/name,repo/'schools/downloads'/name)
with zipfile.ZipFile(out/'Mirsad-Shared-Guardian-3.2.0.zip','w',zipfile.ZIP_DEFLATED) as z:
 z.write(R/'helper/MirsadChromeGuardian.exe','MirsadChromeGuardian.exe');z.write(R/'UPDATE-AR.txt','اقرأ أولًا.txt')
shutil.copy2(out/'Mirsad-Shared-Guardian-3.2.0.zip',repo/'schools/downloads/Mirsad-Shared-Guardian-3.2.0.zip')
shutil.copy2(R/'UPDATE-AR.txt',repo/'schools/downloads/Mirsad-UPDATE-2026-11-07.txt')
# Public source matching the shared binary; no owner Apps Script or OAuth data.
for p in (R/'helper').iterdir():
 if p.is_file() and p.suffix in ['.go','.ps1','.mod','.syso']:
  shutil.copy2(p,repo/'schools/guardian-shared'/p.name)
# Archive the exact final sources/tests for the next maintainer.
with zipfile.ZipFile(out/'Mirsad-Update-2026-11-07-SOURCE.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['helper','private-extension','schools-extension','shared','tests']:
  for p in (R/name).rglob('*'):
   if p.is_file() and p.suffix not in ['.exe','.pyc'] and '__pycache__' not in p.parts and p.name!='debug-extension.py':z.write(p,str(p.relative_to(R)))
 z.write(R/'UPDATE-AR.txt','UPDATE-AR.txt');z.write(R/'package_release.py','package_release.py')
checks=['Mirsad-Teams-0.6.76.zip','Mirsad-Schools-2.2.1.zip','Mirsad-Shared-Guardian-3.2.0.zip','Mirsad-Update-2026-11-07-SOURCE.zip']
checksum='\n'.join(hashlib.sha256((out/n).read_bytes()).hexdigest()+'  '+n for n in checks)+'\n';(out/'CHECKSUMS-2026-11-07.txt').write_text(checksum)
(repo/'schools/downloads/CHECKSUMS-2026-11-07.txt').write_text(checksum)
print('Packaged 0.6.76 / 2.2.1 with shared helper 3.2.0; existing download defaults retained')
