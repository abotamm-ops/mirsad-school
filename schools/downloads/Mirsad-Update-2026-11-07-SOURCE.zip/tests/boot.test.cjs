const fs=require('fs'),vm=require('vm'),path=require('path'),crypto=require('crypto');
(async()=>{for(const edition of ['private','schools']){
 const dir=path.resolve(__dirname,'..',edition+'-extension'),events=()=>({addListener(){},removeListener(){},hasListener(){return false}}),data={};
 const api=new Proxy({}, {get:(o,k)=>o[k]??(k.startsWith('on')?events():async()=>{})});
 const chrome={runtime:{id:edition==='schools'?'ologpgneejnippbdhboiaaijpgkejcck':'test',getManifest:()=>JSON.parse(fs.readFileSync(dir+'/manifest.json')),getURL:p=>'chrome-extension://test/'+p,onMessage:events(),onInstalled:events(),onStartup:events(),sendMessage:async()=>{},sendNativeMessage:(...args)=>args.at(-1)({ok:false})},storage:{local:{get:async k=>k===null?data:Object.fromEntries((Array.isArray(k)?k:[k]).map(k=>[k,data[k]])),set:async x=>Object.assign(data,x),remove:async()=>{}},onChanged:events()},tabs:{query:async()=>[],onCreated:events(),onRemoved:events(),onUpdated:events(),sendMessage:async()=>({ok:false})},windows:{onRemoved:events()},alarms:{create:async()=>{},get:async()=>null,clear:async()=>{},onAlarm:events()},webRequest:{onBeforeRequest:events(),onCompleted:events(),onErrorOccurred:events()},action:api,idle:{onStateChanged:events()},downloads:{onChanged:events()},notifications:api};
 const c=vm.createContext({chrome,console,URL,URLSearchParams,AbortSignal,AbortController,crypto:crypto.webcrypto,TextEncoder,TextDecoder,Date,setTimeout:()=>0,clearTimeout(){},setInterval:()=>0,clearInterval(){},atob,btoa,fetch:async()=>{throw Error('offline test')},indexedDB:{open:()=>({})}});
 c.self=c;c.importScripts=(...names)=>{for(const n of names)vm.runInContext(fs.readFileSync(path.join(dir,n),'utf8'),c,{filename:n,timeout:3000})};
 vm.runInContext(fs.readFileSync(dir+'/background.js','utf8'),c,{filename:edition+'-background',timeout:3000});await new Promise(r=>setTimeout(r,50));
 if(typeof c.MirsadAutoLinks?.beforeCycle!=='function'||typeof c.MirsadWorkspace?.prepareCapture!=='function')throw Error('new modules missing');
 console.log('PASS actual '+edition+' background and imported modules booted');
}})().catch(e=>{console.error(e);process.exitCode=1});
