import asyncio,json,pathlib,tempfile,threading
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from playwright.async_api import async_playwright
R=pathlib.Path(__file__).resolve().parents[1]
class Handler(SimpleHTTPRequestHandler):
 def __init__(self,*a,**kw):super().__init__(*a,directory=str(R),**kw)
 def log_message(self,*a):pass
async def main():
 server=ThreadingHTTPServer(('127.0.0.1',0),Handler);threading.Thread(target=server.serve_forever,daemon=True).start()
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);origin=f'http://127.0.0.1:{server.server_port}'
  for edition in ['private','schools']:
   for fail in [False,True]:
    page=await browser.new_page();calls=[]
    await page.add_init_script('''(()=>{const today=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Riyadh',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());window.calls=[];let collected=false,running=false;const store={};const key='mirsadQuickStart:test';store[key]={at:Date.now(),settings:{manualStart:'06:30',roundCount:3}};window.chrome={runtime:{getManifest:()=>({name:EDITION}),sendMessage:async m=>{calls.push(m);if(m.type==='MIRSAD_STATUS')return {run:{running},status:{text:'ready'}};if(m.type==='MIRSAD_SOURCE_INFO')return {ok:true,state:{running:false,error:FAIL&&collected,text:'فشل قراءة مدرستي'},lastSuccess:collected?{updatedAt:2,date:today,importedForDate:today,activeVerified:true,monitoringPrepared:true,lessons:2}:{updatedAt:1}};if(m.type==='MIRSAD_SOURCE_COLLECT'){collected=true;return {ok:true}};if(m.type==='MIRSAD_BEGIN_DAY')return {ok:true,day:{date:today,snapshot:{scheduleRevision:'R',lessons:[{}]}}};if(m.type==='MIRSAD_START'){running=true;return {ok:true}};return {ok:true}}},storage:{local:{get:async k=>({[k]:store[k]}),set:async x=>Object.assign(store,x),remove:async k=>delete store[k]}}};})()'''.replace('EDITION',json.dumps('مرصاد — المدارس' if edition=='schools' else 'مرصاد')).replace('FAIL','true' if fail else 'false'))
    await page.goto(f'{origin}/{edition}-extension/quick-start.html#test')
    await page.wait_for_function("document.querySelector('#quick-status').textContent.includes('اكتمل التجهيز') || document.querySelector('#quick-status').textContent.includes('توقف البدء السريع')")
    calls=await page.evaluate('calls')
    assert any(x['type']=='MIRSAD_START' for x in calls)!=fail
    assert not any(x['type']=='MIRSAD_START_NOW' for x in calls)
    if not fail:assert [x['type'] for x in calls if x['type'] not in ['MIRSAD_STATUS','MIRSAD_SOURCE_INFO']]==['MIRSAD_SOURCE_SELECT','MIRSAD_SOURCE_COLLECT','MIRSAD_SAVE_SCHEDULE_SETTINGS','MIRSAD_BEGIN_DAY','MIRSAD_START']
    await page.close()
  page=await browser.new_page(viewport={'width':390,'height':844});await page.goto(origin+'/shared/quick-start.html')
  await page.add_script_tag(content=(R/'shared/auto-links-control.js').read_text())
  assert await page.locator('#autoLinkSettings').count()==1
  assert await page.locator('#autoLinksEnabled').is_disabled()
  await page.evaluate("window.postMessage({source:'mirsad-auto-links-extension',requestId:'wrong',payload:{ok:true,enabled:true}},location.origin)")
  assert await page.locator('#autoLinksEnabled').is_disabled()
  await browser.close()
 server.shutdown();print('PASS quick-start success/failure sequencing in both editions; phone control (MV3 extension loading unavailable in this managed Chromium)')
asyncio.run(main())
