(() => {
  'use strict';
  const dashboard = 'https://mirsad-school.onrender.com/schools/automatic-monitoring.html';
  if (location.origin + location.pathname !== dashboard) return;
  const keys = ['mirsadActiveScan', 'mirsadAutoRun', 'mirsadCommercialSchool', 'mirsadMultiSchool',
    'mirsadDriveDay', 'mirsadRecordDelivery', 'mirsadSimpleOperation'];
  let generation = 0;

  async function publishScan() {
    const root = document.documentElement;
    if (!root.classList.contains('mirsad-admin-ready')) return;
    const schoolId = root.dataset.mirsadSchoolId;
    const siteId = root.dataset.mirsadSiteId || '';
    if (!schoolId) return;
    const request = ++generation;
    try {
      const state = await chrome.storage.local.get(keys);
      if (request !== generation || !root.classList.contains('mirsad-admin-ready') ||
          root.dataset.mirsadSchoolId !== schoolId || (root.dataset.mirsadSiteId || '') !== siteId) return;
      if (state.mirsadCommercialSchool?.id !== schoolId || (state.mirsadMultiSchool?.site?.id || '') !== siteId) return;
      const run = state.mirsadAutoRun;
      const scan = state.mirsadActiveScan;
      const activity = run?.running && !run.paused && !run.testMode && !run.backtestMode &&
        (run.multiSiteId || '') === siteId && scan?.active && scan.scanId &&
        run.current?.scanId === scan.scanId ? scan : null;
      window.postMessage({source:'mirsad-monitor-extension',type:'activity',payload:{ok:true,activity}}, location.origin);
      const snapshot = state.mirsadDriveDay?.snapshot;
      const operation = state.mirsadSimpleOperation;
      const current = run && !run.testMode && !run.backtestMode && !run.immediateMode &&
        (run.multiSiteId || '') === siteId && run.scheduleRevision &&
        run.scheduleRevision === snapshot?.scheduleRevision &&
        (snapshot.siteId || '') === siteId &&
        (operation?.kind !== 'RESET' || operation.phase !== 'running');
      const payload = {accountId:schoolId,siteId,snapshot:null,records:[]};
      if (current) {
        const receipts = Object.values(state.mirsadRecordDelivery?.receipts || {});
        const discarded = new Set(receipts.filter(receipt => receipt.discarded).map(receipt => receipt.scanId));
        const lessons = (snapshot.lessons || []).map(lesson => ({
          teacherId:lesson.teacherId,teacherName:lesson.teacherName,period:lesson.period,
          url:lesson.url?'linked':'',calendarUrl:lesson.calendarUrl?'linked':''
        }));
        const names = new Map();
        const normalize = value => String(value || '').trim().replace(/\s+/g,' ');
        for (const lesson of lessons) {
          const key = lesson.period + '|' + normalize(lesson.teacherName);
          names.set(key, names.has(key) ? null : lesson.teacherId);
        }
        payload.snapshot={date:snapshot.date,scheduleRevision:snapshot.scheduleRevision,siteId,
          roundCount:snapshot.roundCount,scheduleSettings:snapshot.scheduleSettings,lessons};
        payload.records=(run.results || []).filter(record=>
          record.scheduleRevision===snapshot.scheduleRevision &&
          (!record.siteId||record.siteId===siteId) && (!record.accountId||record.accountId===schoolId) &&
          ['present','absent'].includes(record.scanStatus||record.status) &&
          Number.isFinite(record.scannedAt) && typeof record.scanId==='string' && !discarded.has(record.scanId)
        ).slice(-800).map(record=>({
          scanId:record.scanId,teacherId:names.get(record.period+'|'+normalize(record.scheduledTeacher)),
          period:record.period,cycle:record.cycle,scannedAt:record.scannedAt,status:record.scanStatus||record.status
        })).filter(record=>record.teacherId);
      }
      window.postMessage({source:'mirsad-monitor-extension',type:'localAttendance',payload}, location.origin);
    } catch {
      // The website can still follow the server heartbeat if the extension is reloading.
    }
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && keys.some(key => key in changes)) void publishScan();
  });
  window.addEventListener('mirsad-admin-login', publishScan);
  window.addEventListener('pageshow', publishScan);
  setInterval(publishScan, 8000);
  void publishScan();
})();
