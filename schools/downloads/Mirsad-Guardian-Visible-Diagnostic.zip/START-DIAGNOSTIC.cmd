@echo off
setlocal
title Mirsad Guardian - visible startup diagnostic
if not exist "%LOCALAPPDATA%\MirsadGuardian" mkdir "%LOCALAPPDATA%\MirsadGuardian"
set "MIRSAD_GUARDIAN_LOG=%LOCALAPPDATA%\MirsadGuardian\last-start.log"
echo Mirsad Guardian visible diagnostic
echo Working folder: %~dp0
echo Windows architecture: %PROCESSOR_ARCHITECTURE%
echo.
if not exist "%~dp0MirsadChromeGuardian.ps1" (
 echo Extract ALL files from the ZIP first.
 pause
 exit /b 1
)
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -STA -ExecutionPolicy Bypass -NoExit -File "%~dp0MirsadChromeGuardian.ps1"
echo.
echo PowerShell exit code: %ERRORLEVEL%
echo Log: %MIRSAD_GUARDIAN_LOG%
pause
