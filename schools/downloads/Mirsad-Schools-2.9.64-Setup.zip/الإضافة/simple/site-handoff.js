(()=>{'use strict';if(location.origin!=='https://mirsad-school.onrender.com'||location.pathname!=='/schools/automatic-monitoring.html')return;chrome.runtime.onMessage.addListener((p,sender,reply)=>{if(sender.id!==chrome.runtime.id)return;if(p.type==='MIRSAD_SIMPLE_PING'){reply({ok:true,protocol:2});return}if(p.type==='MIRSAD_SIMPLE_READINESS'){const root=document.documentElement,ready=!!p.schoolId&&root.dataset.mirsadSchoolId===p.schoolId&&root.classList.contains('mirsad-admin-ready')&&(!p.siteId||root.dataset.mirsadSiteId===p.siteId);reply({ok:ready,protocol:2,error:ready?'':'ادخل اليوزر والرقم السري في موقع راصد للحساب نفسه'});return}if(p.type==='MIRSAD_SIMPLE_WEBSITE_HANDOFF'){
 if(!/^a\.[a-f0-9-]{36}\.[a-f0-9]{64}$/.test(p.key||'')){reply({ok:false});return}
 const key='mirsad-schools-website-login-v1';
 sessionStorage.removeItem(key);
 localStorage.setItem(key,p.key);
 reply({ok:true});
 return
}if(p.type==='MIRSAD_SIMPLE_DRIVE_HANDOFF'){if(!/^a\.[a-f0-9-]{36}\.[a-f0-9]{64}$/.test(p.key||'')||!/^([a-f0-9]{64})$/.test(p.state||'')){reply({ok:false});return}localStorage.setItem('mirsad-drive-pending-v1',JSON.stringify({key:p.key,state:p.state,until:Date.now()+600000}));reply({ok:true,protocol:2});return}})})();
